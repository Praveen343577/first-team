import { useState, useEffect, useRef, useMemo } from 'react';
import { Play, Square, ChevronDown, Check, Search, AlertCircle } from 'lucide-react'; 
import { clsx } from 'clsx';
import { Button } from '../components/common/Button';
import { Dropdown } from '../components/common/Dropdown';
import { LiveCanLayout } from '../components/data-display/LiveCanLayout';
import { useFleetSocket } from '../hooks/useFleetSocket';

export const LiveCan = () => {
  // 1. Get Vehicle List from Socket/API
  const { vehicles } = useFleetSocket(); 

  // 2. Filter State
  const [selectedType, setSelectedType] = useState('');
  const [selectedFleet, setSelectedFleet] = useState('');
  const [selectedVrn, setSelectedVrn] = useState('');
  
  // 3. Connection State
  const [isStreaming, setIsStreaming] = useState(false);
  const [canData, setCanData] = useState(null);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [noDataFound, setNoDataFound] = useState(false); 
  const socketRef = useRef(null);

  // --- Derived Data for Dropdowns ---
  
  // 1. Fleet Options (Always available)
  const fleetOptions = useMemo(() => {
    const uniqueFleets = [...new Set(vehicles.map(v => v.fleet).filter(Boolean))].sort();
    return uniqueFleets.map(f => ({ label: f, value: f }));
  }, [vehicles]);
  
  // 2. Type Options (Strictly dependent on Fleet)
  const typeOptions = useMemo(() => {
    if (!selectedFleet) return []; // strict dependency

    const fleetVehicles = vehicles.filter(v => v.fleet === selectedFleet);  
    const availableTypes = [...new Set(fleetVehicles.map(v => v.deviceTypeName).filter(Boolean))].sort();
    
    return availableTypes.map(t => ({ label: t, value: t }));
  }, [vehicles, selectedFleet]);

  // 3. VRN Options (Strictly dependent on Type)
  const vrnOptions = useMemo(() => {
    if (!selectedType) return []; 

    const filtered = vehicles.filter(v => 
      v.fleet === selectedFleet && 
      v.deviceTypeName === selectedType
    );

    return filtered.map(v => ({
      label: v.vrn || v.chassisNumber || v.imei,
      value: v.imei 
    }));
  }, [vehicles, selectedType, selectedFleet]);

  // --- Handlers ---
  const handleFleetChange = (val) => {
    setSelectedFleet(val);
    setSelectedType('');  
    setSelectedVrn('');   
    setNoDataFound(false); // Reset error
  };

  const handleTypeChange = (val) => {
    setSelectedType(val);
    setSelectedVrn('');   
    setNoDataFound(false); // Reset error
  };

  // --- WebSocket Logic ---
  const toggleStream = () => {
    if (isStreaming) {
      socketRef.current?.close();
      setConnectionStatus('disconnected');
      setIsStreaming(false);
      setCanData(null);
    } else {
      if (!selectedFleet || !selectedType || !selectedVrn) {
        return alert("Please select Fleet, Vehicle Type, and VRN to start streaming.");
      }
      
      // Reset states
      setNoDataFound(false); 
      setConnectionStatus('connecting');
      setIsStreaming(true);
      
      const ws = new WebSocket('wss://eka-stage.eka-connect.com/ws/can_data/');
      socketRef.current = ws;

      ws.onopen = () => {
        setConnectionStatus('connected');
        ws.send(JSON.stringify({ "device_id": selectedVrn.toString() }));
      };

      ws.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          
          // [NEW] Check for "No data found" message
          if (payload.message && /no data found/i.test(payload.message)) {
            ws.close();
            setIsStreaming(false);
            setConnectionStatus('disconnected');
            setNoDataFound(true);
            setCanData(null);
            return;
          }

          if (payload.can_data) {
            setCanData(prev => ({ ...prev, ...payload.can_data }));
          }
        } catch (e) { console.error(e); }
      };

      ws.onclose = () => {
        setConnectionStatus('disconnected');
        setIsStreaming(false);
      };
      
      ws.onerror = () => {
        setConnectionStatus('error');
        setIsStreaming(false);
      };
    }
  };

  useEffect(() => { return () => socketRef.current?.close(); }, []);

  return (
    <div className="h-full flex flex-col bg-brand-bg transition-colors duration-300 gap-4 overflow-hidden">
      
      {/* 1. Control Header */}
      <div className="p-5 bg-brand-surface border border-brand-border rounded-xl shadow-sm flex flex-col sm:flex-row items-end sm:items-center justify-between gap-4 z-20">
        
        <div className="flex items-center gap-4 flex-1 w-full">
          <Dropdown 
            label="Fleet" 
            value={selectedFleet} 
            options={fleetOptions} 
            onChange={handleFleetChange}
            placeholder="Select Fleet"
            disabled={isStreaming}
          />

          <Dropdown 
            label="Vehicle Type" 
            value={selectedType} 
            options={typeOptions} 
            onChange={handleTypeChange}
            placeholder={selectedFleet ? "Select Type" : "Select Fleet First"}
            disabled={!selectedFleet || isStreaming}
          />

          <Dropdown 
            label="VRN / Chassis" 
            value={selectedVrn} 
            options={vrnOptions} 
            onChange={setSelectedVrn}
            placeholder={selectedType ? "Select Vehicle" : "Select Type First"}
            disabled={!selectedType || isStreaming}
          />
        </div>

        {/* Action Button & Status */}
        <div className="flex items-center gap-4">
           {connectionStatus === 'error' && <span className="text-xs text-brand-red font-medium animate-pulse">Connection Failed</span>}
           
           <Button 
             variant="outline"
             className={clsx(
               "min-w-[140px] h-[42px] flex items-center justify-center gap-2 mt-auto border transition-all duration-300 shadow-sm",
               isStreaming 
                 ? "bg-rose-500/10 border-rose-200 text-rose-600 hover:bg-rose-500/20 hover:border-rose-300" 
                 : "bg-emerald-500/10 border-emerald-200 text-emerald-600 hover:bg-emerald-500/20 hover:border-emerald-300"
             )}
             onClick={toggleStream}
           >
             {isStreaming ? <><Square className="w-4 h-4 fill-current"/> Stop</> : <><Play className="w-4 h-4 fill-current"/> Start</>}
           </Button>
        </div>
      </div>

      {/* 2. Visualization Layout (Scrollable) */}
      <div className="flex-1 min-h-0 overflow-hidden">
        {/* Conditional Rendering for No Data Found */}
        {noDataFound ? (
           <div className="h-full border-2 border-solid border-brand-border rounded-xl flex flex-col items-center justify-center text-brand-text-muted gap-4 bg-brand-surface/50">
             <div className="w-16 h-16 rounded-full bg-brand-bg flex items-center justify-center border border-brand-border">
               <AlertCircle className="w-8 h-8 opacity-50 text-brand-red" />
             </div>
             <div className="text-center">
               <h3 className="text-lg font-semibold text-brand-text">No Data Found</h3>
               <p className="text-sm">The selected device is not transmitting any CAN data.</p>
             </div>
           </div>
        ) : (
          <LiveCanLayout data={canData} vehicleType={selectedType} />
        )}
      </div>
    </div>
  );
};