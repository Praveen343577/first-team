import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { clsx } from 'clsx';
import { Sidebar } from '../components/layout/Sidebar';
import { Table } from '../components/data-display/Table';
import { useFleetSocket } from '../hooks/useFleetSocket';
import { Search, Bell, Loader2 } from 'lucide-react';
import { Header } from '../components/common/Header';

export const DashboardLayout = () => {
  const location = useLocation();
  const isDashboardHome = location.pathname === '/dashboard';
  
  const { vehicles, status } = useFleetSocket();
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(true);
  const [pageData, setPageData] = useState([]);
  const searchData = isDashboardHome ? vehicles : pageData;

  // Global Filter Logic
  // This filters the raw list BEFORE it gets split into Active/Inactive
  const filteredVehicles = vehicles.filter(v => {
    if (!searchQuery) return true;
    const lowerQ = searchQuery.toLowerCase();
    return (
      (v.vrn && v.vrn.toLowerCase().includes(lowerQ)) ||
      (v.chassisNumber && v.chassisNumber.toLowerCase().includes(lowerQ)) ||
      (v.fleet && v.fleet.toLowerCase().includes(lowerQ)) ||
      (v.imei && v.imei.toString().includes(lowerQ))
    );
  });

  return (
    // 1. Update Main Background to Variable
    <div className="min-h-screen bg-brand-bg flex transition-colors duration-300">
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        toggleSidebar={() => setIsSidebarCollapsed(prev => !prev)} 
      />
      
      <main className={clsx(
        "flex-1 p-6 h-screen flex flex-col overflow-hidden transition-[margin] duration-300",
        isSidebarCollapsed ? "ml-20" : "ml-64"
      )}>
        <Header status={status} vehicles={vehicles} searchData={searchData} setSearchQuery={setSearchQuery} />

        {isDashboardHome ? (
          <>
            {status === 'connected' && vehicles.length === 0 ? (
              <div className="h-64 flex flex-col items-center justify-center text-brand-text-muted gap-3 border border-dashed border-brand-border rounded-xl transition-colors duration-300">
                {/* 7. Update Loader to Brand Blue */}
                <Loader2 className="w-8 h-8 animate-spin text-brand-blue" />
                <p>Waiting for live stream data...</p>
              </div>
            ) : (
              <div className="flex-1 min-h-0 animate-in fade-in duration-500 slide-in-from-bottom-4">
                <Table 
                  // title="All Vehicles" 
                  data={filteredVehicles} 
                />
              </div>
            )}
          </>
        ) : (
          <Outlet context={{ searchQuery, setPageData }} />
        )}
      </main>
    </div>
  );
};




