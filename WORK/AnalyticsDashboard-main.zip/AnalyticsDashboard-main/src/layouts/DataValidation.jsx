import { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { Loader2, RefreshCw } from 'lucide-react';
import { TableDataValidation } from '../components/data-display/TableDataValidation';

export const DataValidation = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const outletContext = useOutletContext();
  const searchQuery = outletContext?.searchQuery || '';
  const setPageData = outletContext?.setPageData;

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('http://192.168.24.136:8000/results');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const jsonData = await response.json();
      setData(jsonData);
    } catch (err) {
      console.error("Failed to fetch validation data:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (setPageData) setPageData(data);
    return () => { if (setPageData) setPageData([]); };
  }, [data, setPageData]);
  
  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-4 text-brand-text-muted">
        <Loader2 className="w-8 h-8 animate-spin text-brand-blue" />
        <p className="animate-pulse">Loading validation results...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full flex flex-col items-center justify-center gap-4">
        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg text-brand-red text-center">
          <p className="font-medium">Failed to load data</p>
          <p className="text-sm opacity-80">{error}</p>
        </div>
        <button 
          onClick={fetchData}
          className="flex items-center gap-2 px-4 py-2 bg-brand-surface border border-brand-border rounded-lg hover:bg-brand-bg transition-colors text-brand-text"
        >
          <RefreshCw className="w-4 h-4" />
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col min-h-0 text-brand-text-muted gap-3 border border-dashed border-brand-border rounded-xl transition-colors duration-300">
      <div className="h-full animate-in fade-in duration-500 slide-in-from-bottom-4">
        <TableDataValidation data={data} searchQuery={searchQuery} />
      </div>
    </div>
  );
};