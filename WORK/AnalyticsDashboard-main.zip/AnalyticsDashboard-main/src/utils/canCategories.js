export const CAN_CATEGORIES = {
  "All_Flag": [
    "Platform_Select", "Feature_Select", "VCU_Flag", "Aux_Inv_Flag", "BCS_Flag",
    "TCS_Flag", "Trq_Flag", "Mot_Trq_Flag", "DCDC_Flag", "Derate_Flag", "D_Locate", "Signal_1"
  ],
  "Component_Status": [
    "BMS_Status", "MCU_Status", "EVCC_1_Status", "EVCC_2_Status", "DCDC_Status",
    "Dual_Aux_Status", "EBS_Status", "TCS_Status", "BCS_Status", "HVAC_Status",
    "IC_MUX_Node_Status", "VTS_Status", "ITS_Status", "ESC_Status", "ECAS_Status",
    "TPMS_Status", "FCE_Status", "ADAS_Status", "DNR_Status", "ACU_Status",
    "EBS_2_Status", "Trailer_Tipper_Status", "RC1_Status", "RC2_Status", "Signal_2", "Signal_3"
  ],
  "Software_Version": [
    "VCU_SW_Version_X", "VCU_SW_Version_YY", "MCU_SW_Version", "BMS_SW_Version",
    "AUXInv_SW_Version", "EVCC_SW_Version", "DCDC_SW_Version", "HVAC_SW_Version",
    "TCS_SW_Version", "EBS_SW_Version", "ICMUX_SW_Version", "RC1_SW_Version",
    "RC2_SW_Version", "Signal_4"
  ],
  "DTC_1": [
    "VCU_DTC_1", "VCU_DTC_2", "BMS_DTC_1", "BMS_DTC_2", "MCU_DTC_1", "MCU_DTC_2",
    "EVCC_DTC_1", "EVCC_DTC_2"
  ],
  "DTC_2": [
    "Dual_Aux_DTC_1", "Dual_Aux_DTC_2", "Dual_Aux_DTC_3", "Dual_Aux_DTC_4",
    "EBS_DTC_1", "EBS_DTC_2", "EBS_DTC_3", "EBS_DTC_4"
  ],
  "DTC_3": [
    "DCDC_DTC_1", "DCDC_DTC_2", "TCS_DTC_1", "TCS_DTC_2", "HVAC_BCS_DTC_1",
    "HVAC_BCS_DTC_2", "IC_MUX_DTC_1", "IC_MUX_DTC_2"
  ],
  "DTC_4": [
    "RC1_DTC_1", "RC1_DTC_2", "RC2_DTC_1", "RC2_DTC_2", "ODOMETER_CRUT"
  ],
  "Hardwired_Input_IOS": [
    "Ignition_Sense", "Junction_Box_Switch", "HVPDU_HVIL_Out", "BCS_HVIL_Out",
    "TCS_Rad_Fan_FB", "Service_Indicator_Ecomp", "TCS_Coolent_Level_SW",
    "Oil_Pressure_Switch_1", "Oil_Pressure_Switch_2", "Suspension_Tank_Pressure",
    "Airdryer_Switch", "Accpedal_Position", "Brake_Liner_Wr_Sw_FR", "Brake_Liner_Wr_Sw_FL",
    "Brake_Liner_Wr_Sw_RR", "Brake_Liner_Wr_Sw_RL", "Steering_Temp_Prot_Sw",
    "Park_Brake", "DNR", "Brake_Tank_Pressure_1", "Brake_Tank_Pressure_2",
    "Max_Busbar_Temperature", "CCSA_Max_Temp", "CCSB_Max_Temp", "Signal_9"
  ],
  "Hardwired_Input_Temp": [
    "BCS_Thermistor_1", "BCS_Thermistor_2", "BCS_Thermistor_3", "TCS_Thermistor",
    "Temprature_Reserve_1", "Temprature_Reserve_2", "Temprature_Reserve_3",
    "Temprature_Reserve_4", "Temprature_Reserve_5"
  ],
  "Hardwired_Output": [
    "Traction_MotorEn_Contactor_LSO1", "ChargerA_En_Contactor_LSO2", "ChargerB_En_Contactor_LSO3",
    "HV_TCS_FAN_LSO4", "HV_TCS_Elctronic_On_Relay_LSO5", "BCS_Relay_Coil_GND_LSO7",
    "E_Comp_FAN_LSO8", "HV_Batt_A_B_IGN_Relay_Drive_LSO9", "IC_Relay_Drive_LSO10",
    "Solenoid_Relay_Drive_LSO11", "MCU_IGN_Relay_Drive_LSO12", "Aux_Inverter_1_IGN_Relay_LSO13",
    "Aux_Inverter_2_IGN_Relay_LSO14", "HVAC_Drive_Relay_LSO15", "Wheel_Chair_Operation_LSO",
    "Traction_Rad_Freq", "Traction_RadDuty_Cycle", "RC1_Energy", "RC2_Energy",
    "Battery_Net_Energy", "Big_Data_Reserve_1"
  ],
  "Energy_1": [
    "Total_KWh_Consumed", "Instantaneous_Power", "Total_KWh_Regenerated", "MCU_Energy",
    "DCDC_Energy", "EComp_Energy", "Steering_Energy", "BCS_HVAC_Energy", "TCS_Energy"
  ],
  "MCU_1": [
    "Operational_Mode_Cmd", "Command_Mode", "Torque_Command", "Select_Torquemap",
    "MCU_HighPowerCurrent", "MCU_HighPowerVoltage", "MCU_State", "MCU_Command_Mode",
    "MCU_Creep_Enable", "MCU_Crawl_Enable", "Traction_Torque_Avaliable"
  ],
  "MCU_2": [
    "MCU_Motor_Speed", "MCU_Motor_Torque_Estimated", "Motor_Temperature", "MCU_Temperature",
    "Traction_Derating", "Regen_Derating", "Motor_Fault_Bit", "Motor_Health",
    "MCU_DNR_Resp", "MCU_Brk_Resp", "MCU_Cruise_Control_Active", "MCU_Cruise_UP",
    "MCU_Cruise_Down", "MCU_Discharge_Status"
  ],
  "EVCC_Gun_1": [
    "EVCC_Cont_CCL_1", "EV_Ready_1", "Charging_Complete_1", "Vehicle_Stop_Charging_1",
    "EV_Error_Code_1", "Force_Actuator_Unlock_1", "Charging_Time", "EVCC_Status_Code_1",
    "EVCC_Ready_1", "Gun_Detection_1", "Charging_Status_1", "Max_Temperature_Gun_1",
    "Present_Current_1", "CP_Dutycycle_1", "PP_Resistance_1"
  ],
  "EVCC_Gun_2": [
    "EVCC_Cont_CCL_2", "EV_Ready_2", "Charging_Complete_2", "Vehicle_Stop_Charging",
    "EV_Error_Code_2", "Force_Actuator_Unlock_2", "EVCC_Status_Code_2", "EVCC_Ready_2",
    "Gun_Detection_2", "Charging_Status_2", "Max_Temperature_Gun_2", "Present_Current_2",
    "CP_Dutycycle_2", "PP_Resistance_2", "Signal_10"
  ],
  "DCDC_1": [
    "DCDC_Enable_Command", "DCDC_Outputvoltagepointsetting", "DCDC_Outputcurrentlimitsetting",
    "DCDC_Inputvoltagepointsetting", "DCDC_Inputcurrentlimitsetting", "DCDC_Input_Voltage",
    "DCDC_Output_Voltage", "DCDC_Input_Current", "DCDC_Output_Current", "Signal_11"
  ],
  "DCDC_2": [
    "DCDC_Con_AuxInterLock_1", "DCDC_Con_AuxInterLock_2", "DCDC_Temp_1", "DCDC_Temp_2",
    "DCDC_Temp_3", "DCDC_Temp_4", "Signal_12", "Signal_13", "Signal_14", "Signal_15"
  ],
  "Ecompressor_System": [
    "DC_Link_Voltage", "EComp_Enable", "Ecompressor_Set_Velocity", "Ecompressor_Actual_Velocity",
    "ECompressor_Input_Power", "Ecomp_Actual_Heat_Sink_Temp", "Ecomp_Actual_Motor_Temp",
    "Signal_16", "Signal_17", "Signal_18"
  ],
  "Steering_System": [
    "Steering_Enable", "Steering_Set_Velocity", "Steering_Actual_Velocity", "Streering_Input_Power",
    "Steering_Actual_Heat_Sink_Temp", "Steering_Actual_Motor_Temp", "Signal_19",
    "Signal_20", "Signal_21", "Signal_22"
  ],
  "EBS1_ESC_1": [
    "Anti_Lock_Braking_ABS_Active", "EBS_Brake_Switch", "ABS_Fully_Operational",
    "ABS_Offroad_Switch", "ABS_EBS_Amber_Warning_Lamp_State", "EBS_Red_Warning_Lamp_State",
    "Brake_Pedal_Position", "Regen_Info", "EM1_Torque_Mode_Driving_Braking",
    "EM1_Actual_Pct_Torque", "EM1_Ovr_Ctrl_Mode_Driving", "EM1_Ovr_Ctrl_ModePriorityDriving",
    "EM1_Ovr_Ctrl_Mode_Braking", "EM1_Ovr_Ctrl_ModePriorityBraking", "EM1_ReqTorqueTorqueLimitDriving",
    "EM1_Req_TorqueTorqueLimitBraking", "Halt_Brake_Mode", "Hill_Holder_Mode",
    "Foundation_Brake_Use", "VDC_Brake_Light_Rq_ESC", "VDC_Info_Signal", "VDC_Fully_Operational"
  ],
  "EBS1_ESC_2": [
    "Front_Axle_Left_Wheel_Speed", "Front_Axle_Right_Wheel_Speed", "Rear_Axle_Left_Wheel_Speed",
    "Rear_Axle_Right_Wheel_Speed", "EM1_Driver_Retarder_Pct_Trq", "EM1_Actual_Max_Avil_Ret_Pct_Torq",
    "Nominal_Friction_Percent_Torque", "Front_Axle_Speed", "Air_Compressor_Status", "Signal_23"
  ],
  "TCS_ITS": [
    "TCS_Target_Value", "Pump_Speed", "Pump_Voltage", "Pump_Current", "TCS_Pump_Temperature",
    "ITS_Passenger_Count", "ITS_Harsh_Braking", "ITS_Harsh_Acceleration", "ITS_Panic_Button_Status",
    "Signal_24", "Signal_25", "Signal_26"
  ],
  "Cluster_Parameters": [
    "WheelBasedVehicleSpeed_Rx", "Set_Speed_Limit", "Door_1_F", "Door_2_R", "Door_3",
    "Roof_Hatch", "Emergency_Door", "Seat_Belt_Indicator", "Interior_Light_Status",
    "Kneeling", "Stop_Request", "Disable_Person_Request", "Ramp_Status", "Rear_Flap_Status",
    "Wiper_Motor_Operation", "High_Beam_Status", "Park_Lamp", "Head_Lamp", "Hazard",
    "Hooter", "Left_Turn_Indicator", "Right_Turn_Indicator", "Speed_Limit_Warning",
    "DTE", "ODOMETER"
  ],
  "INTHVAC_BCS_PTC_1": [
    "ATC_Compressor_Enable", "Cmd_Speed_of_Compressor", "BCS_Compressor_Input_Voltage",
    "BCS_Compressor_Input_Current", "BCS_Compressor_Speed", "BCS_Compressor_Controller_Temp",
    "AC_System_EVA_Temprature", "AC_System_Exhaust_Temprature", "AC_System_Cond_Temprature",
    "BCS_Mode"
  ],
  "INTHVAC_BCS_PTC_2": [
    "B2T_Differential_1", "B2T_Differential_2", "B2T_Mode", "B2T_TMS_Control_CMD",
    "B2T_BMS_Work_Mode", "B2T_Compressor_Speed_Restriction", "B2T_Set_Target_Temp",
    "T2B_Tin", "T2B_Tout", "T2B_Mode", "T2B_TMS_Work_Mode", "T2B_BMS_Work_Mode",
    "T2B_Pump_Rly_Output", "T2B_HV_Voltage_Input", "T2B_HV_Current_Input", "T2B_AC_Mode",
    "T2B_PTC_Status"
  ],
  "INTHVAC_BCS_PTC_3": [
    "T2B_Comp_Frequency", "T2B_Comp_Current", "T2B_Comp_Voltage", "Ambient_Temprature",
    "Cabin_Temprature", "AC_Set_Temprature", "AC_System_IPM_Module_Temprature",
    "Signal_27", "Signal_28"
  ],
  "Acc_Brk_Time_1": [
    "Time_for_acc_pedal_0_per", "Time_acc_pedal_1to10_per", "Time_acc_pedal_11to20_per",
    "Time_acc_pedal_21to30_per", "Time_acc_pedal_31to40_per", "Harsh_Acceleration_Count",
    "Signal_29"
  ],
  "Acc_Brk_Time_2": [
    "Time_acc_pedal_41to50_per", "Time_acc_pedal_51to60_per", "Time_acc_pedal_61to70_per",
    "Time_acc_pedal_71to80_per", "Time_acc_pedal_81to90_per", "Harsh_Braking_Count",
    "Signal_30"
  ],
  "Acc_Brk_Time_3": [
    "Time_acc_pedal_91to100_per", "Vehicle_Acceleration", "RateofchangeofBrakePedalPosition",
    "RateofchangeofAccPedalPosition", "Acceleration_Time_Count", "Braking_Time_Count"
  ],
  "Acc_Brk_Time_4": [
    "Coasting_Time_Count", "Idling_Time_Count", "Change_in_Acc_Pedal_Position",
    "Change_in_Brake_Pedal_Position", "Change_in_Vehicle_Speed_mps", "Calculation_Verification_Flag"
  ],
  "CAN_Selection": [
    "CAN_Select"
  ],
  "CAN_Calibration_Selections_TX": [
    "LV_HV_Selection", "No_Use1", "LV_Calibration", "HV_Calibration", "No_Use2",
    "EVSE_TX", "LSO_Calibration", "MUX_TX", "No_Use_17", "No_Use_18", "No_Use3",
    "M_HV_TCS_Fan_LSO4", "Manual_Solenoidal_Relay", "Manual_HVAC_Drive_Relay_LSO15",
    "M_Aux_Inverter_2_IGN_Relay_LSO14", "M_Aux_Inverter_1_IGN_Rly_LSO13", "M_MCU_IGN_Relay_Drive_LSO12",
    "Manual_IC_Relay_Drive_LSO10", "M_HV_Batt_A_B_IGN_Rly_Drive_LSO9", "Manual_E_Comp_FAN_LSO8",
    "M_BCS_Relay_Coil_GND_LSO7", "M_Traction_Rad_Freq", "M_Traction_Rad_Duty_Cycle",
    "M_HV_TCS_Elctronic_On_Relay_LSO5", "M_Charger_B_EN_Contactor_LSO3", "M_Charger_A_EN_Contactor_LSO2",
    "M_Traction_Motor_En_Cont_LSO1", "Traction_Rad_Freq_Value", "Solenoidal_Val",
    "HVAC_Drive_Relay_Value", "Aux_Inverter_2_IGN_Relay_Value", "Aux_Inverter_1_IGN_Relay_Value",
    "MCU_IGN_Relay_Drive_Value", "IC_Relay_Drive_Value", "HV_Batt_A_B_IGN_Rly_Drive_Value",
    "E_Comp_FAN_Value", "BCS_Relay_Coil_GND_Value", "Traction_Rad_Duty_Cycle_Value",
    "HV_TCS_Fan_Value", "HV_TCS_Elctronic_On_Relay_Value", "Charger_B_EN_Contactor_Value",
    "Charger_A_EN_Contactor_Value", "Traction_Motor_En_Cont_Value", "No_Use15",
    "ECU_Calibration", "No_Use4", "BCS_TX", "BMS_TX", "DCDC_TX", "Dual_Aux_TX",
    "EVCC_TX", "TCS_TX", "Manual_TCS_Comp_Target_val", "No_Use16", "No_Use7",
    "No_Use12", "TCS_Comp_Target_Val", "KPTL_AUX", "INT_HVAC", "IND_BCS",
    "Bharat_Bijli_TX", "Four_Front_DCDC_TX", "KPTL_DCDC_TX", "No_Use6", "No_Use10",
    "No_Use5", "Manual_DCDC_Enable", "Manual_EVCC_Charge_Done", "Manual_EVCC_Peak_CCL_Value",
    "Manual_EVCC_CCL", "Manual_EVCC_Battery_Voltage", "Manual_VCU_BMS_No_of_Packs",
    "Manual_VCU_BMS_Charge_Flag", "Manual_VCU_BMS_Insulation_Enable", "Manual_VCU_BMS_MainC_Close",
    "Manual_VCU_BMS_EPO", "Manual_VCU_BMS_Enable", "No_Use_11", "No_Use14", "No_Use13",
    "Manual_Forfront_DCDC_Volt_Set", "Manual_Forfront_DCDC_Out_Cur_Set", "Manual_Fourfront_DCDC_Enable",
    "DCDC_Enable_Value", "EVCC_Chaarge_Done_Value", "Manual_IntHVAC_Set_Temp",
    "Manual_IntHVAC_Diff_Enable", "EVCC_Peak_CCL_Value", "EVCC_CCL_Value",
    "EVCC_Battery_Voltage", "Manual_BCS_Compressor_Enable", "Manual_BCS_Spd_Comp",
    "VCU_BMS_No_of_Packs_Value", "VCU_BMS_Charge_Flag_Value", "VCU_BMS_Insulation_Enable_Value",
    "VCU_BMS_MainC_Close_Value", "VCU_BMS_EPO_Val", "VCU_BMS_Enable_Val", "No_Use8",
    "Forfront_DCDC_Volt_Set_Val", "Forfront_DCDC_Out_Cur_Val", "Forfront_DCDC_Enable",
    "Manual_Steering_Velocity", "Manual_Steering_Enable", "Manual_Ecomp_Velocity",
    "Manual_Ecomp_Enable", "Inthvac_Set_Temp_Val", "IntHVAC_Diff_Value",
    "BCS_Compressor_Enable_Value", "BCS_Spd_Comp_Value", "P_BMS_No_Pack",
    "Steering_Velocity_Value", "Steering_Enable_Value", "Ecomp_Velocity_Value",
    "Ecomp_Enable_Value", "D_BMS_No_Pack", "IntHVAC_Diff_Permanant",
    "IntHvac_Set_Temp_Permanent", "IntHVAC_Diff_Default", "IntHVAC_Set_Temp_Default",
    "Logic_Calibration", "No_Use_19", "MCU_TX", "M_Regen_Trq_Change", "M_Trq_Map_Change",
    "M_Regen_Select", "M_Regen_OFF", "Manual_Immobilize_CMD", "Manual_Speed_Control_CMD",
    "VCU_Logic", "DCDC_Aux_Logic", "Cooling_Logic", "No_Use_15", "M_MCU_Trq_CMD",
    "Regen_Trq_Change_V", "Trq_Map_Change_V", "Regen_Select_Val", "Regen_OFF_Val",
    "Immobilize_Value", "Speed_Set_Value", "M_Logic_TCS_Target_Val", "MCU_Trq_CMD_Val",
    "P_Regen_Select_Val", "P_Regen_OFF", "Immobilize_PermanentChange_Value",
    "Logic_TCS_Target_Val", "P_Regen_Trq_Change", "P_Trq_Map_Change", "D_Regen_Select_Val",
    "D_Regen_OFF", "Immobilize_Defalut_Value", "M_VCU_Brake_Sw", "M_VCU_LV_Cal",
    "M_VCU_HV_Cal", "M_Auto_Logic", "D_Regen_Trq_Change", "D_Trq_Map_Change",
    "VCU_Brake_Sw", "VCU_HV_CAl", "VCU_LV_CAl", "Auto_Flag_Value", "P_VCU_Brake_Sw",
    "P_HV_Cal", "P_VCU_LV_CAL", "P_Auto_Val", "D_VCU_Brake_Sw", "D_HV_Cal",
    "D_VCU_LV_Cal", "D_Auto_Logic", "P_Logic_TCS_Target_Val", "D_Logic_TCS_Target_Val",
    "Speed_Permanant_Change_CMD", "Speed_Default_CMD"
  ],
  "CAN_Obs": [
    "Immobilize_Auto_Value", "Previous_Immobilize_Auto_Value", "Output_Immobilize_Auto_Value",
    "Immobilize_PermanentChange_Value", "Immobilize_Default_Value", "SLF_Auto_Value",
    "Previous_SLF_Auto_Value", "Output_SLF_Auto_Value", "SLF_Permanent_Change_Value",
    "SLF_Default_Value", "FOTA_1", "FOTA_2", "FOTA_Counter"
  ],
  "BMS_Pack_A_Status": [
    "A_SOC_Calibration_flag", "A_Balancing_Enabled_Flag", "A_Pack_Ready", "A_Charging_Done",
    "A_HVIL_Monitoring_Status", "A_Packlockout", "A_Main_Contactors_Status", "A_VCU_BMS_Enable",
    "A_VCU_BMS_EPO", "A_VCU_BMS_MainC_Close", "A_VCU_BMS_Insulation_Enable",
    "A_VCU_BMS_Charge_Flag", "A_VCU_BMS_No_of_packs", "A_Derate_Flag", "A_Fault_Rank",
    "A_Min_Cell_Temp", "A_Max_Cell_Temp", "A_Max_Cell_Volt", "A_Min_Cell_Volt",
    "A_LV_Power_Supply", "Signal_31"
  ],
  "BMS_Pack_A_Data_1": [
    "A_Pack_Current_Value", "A_Pack_Voltage_Value", "A_KWh_Remain", "A_Coolant_Inlet_Temp",
    "Calculated_CCL", "Calculated_DCL", "Signal_32"
  ],
  "BMS_Pack_A_Data_2": [
    "A_Insulation_Value", "A_SOH_Value", "A_SOC_Value", "A_Max_Cell_Volt_No",
    "A_Min_Cell_Volt_No", "A_Cont_Chrg_Curr_Limit", "A_Cont_Disch_Curr_Limit",
    "A_Coolant_Outlet_Temp"
  ],
  "BMS_Pack_B_Status": [
    "B_SOC_Calibration_flag", "B_Balancing_Enabled_Flag", "B_Pack_Ready", "B_Charging_Done",
    "B_HVIL_Monitoring_Status", "B_Packlockout", "B_Main_Contactors_Status", "B_Derate_Flag",
    "B_Fault_Rank", "B_Min_Cell_Temp", "B_Max_Cell_Temp", "B_Max_Cell_Volt",
    "B_Min_Cell_Volt", "B_LV_Power_Supply", "Signal_33", "Signal_34"
  ],
  "BMS_Pack_B_Data_1": [
    "B_Pack_Current_Value", "B_Pack_Voltage_Value", "B_KWh_Remain", "B_Coolant_Inlet_Temp",
    "Signal_35", "Signal_36", "Signal_37", "Signal_38"
  ],
  "BMS_Pack_B_Data_2": [
    "B_Insulation_Value", "B_SOH_Value", "B_SOC_Value", "B_Max_Cell_Volt_No",
    "B_Min_Cell_Volt_No", "B_Cont_Chrg_Curr_Limit", "B_Cont_Disch_Curr_Limit",
    "B_Coolant_Outlet_Temp"
  ],
  "BMS_Pack_C_Status": [
    "C_SOC_Calibration_flag", "C_Balancing_Enabled_Flag", "C_Pack_Ready", "C_Charging_Done",
    "C_HVIL_Monitoring_Status", "C_Packlockout", "C_Main_Contactors_Status", "C_Derate_Flag",
    "C_Fault_Rank", "C_Min_Cell_Temp", "C_Max_Cell_Temp", "C_Max_Cell_Volt",
    "C_Min_Cell_Volt", "C_LV_Power_Supply", "Signal_39", "Signal_40"
  ],
  "BMS_Pack_C_Data_1": [
    "C_Pack_Current_Value", "C_Pack_Voltage_Value", "C_KWh_Remain", "C_Coolant_Inlet_Temp",
    "Signal_41", "Signal_42", "Signal_43", "Signal_44"
  ],
  "BMS_Pack_C_Data_2": [
    "C_Insulation_Value", "C_SOH_Value", "C_SOC_Value", "C_Max_Cell_Volt_No",
    "C_Min_Cell_Volt_No", "C_Cont_Chrg_Curr_Limit", "C_Cont_Disch_Curr_Limit",
    "C_Coolant_Outlet_Temp"
  ]
};