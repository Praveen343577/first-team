/**
 * Formats a date string or timestamp into "Mon, 9 Feb 2026 09:35:56 AM" format.
 * Handles invalid inputs gracefully.
 * * @param {string|number|Date} dateInput - The date to format.
 * @returns {string} Formatted date string or original input if invalid.
 */
export const formatTimestamp = (dateInput) => {
  if (!dateInput) return '--:--:--';

  try {
    const safeInput = typeof dateInput === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(dateInput) && !/(Z|[+-]\d{2}(:\d{2})?)$/.test(dateInput)
      ? `${dateInput}Z` 
      : dateInput;
    const date = new Date(safeInput);
    
    // Check for invalid date
    if (isNaN(date.getTime())) return dateInput;

    return new Intl.DateTimeFormat('en-GB', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    }).format(date);
  } catch {
    return dateInput;
  }
};

/**
 * Rounds a numeric value to a specified number of decimal places.
 * Returns the original value if it's not a number.
 * * @param {number|string} value - The value to round.
 * @param {number} decimals - Number of decimal places (default 3).
 * @returns {number|string} Rounded value or original input.
 */
export const roundValue = (value, decimals = 3) => {
  const num = parseFloat(value);
  if (isNaN(num)) return value;
  
  // Use Number.EPSILON to ensure accurate rounding of floating point numbers
  return Math.round((num + Number.EPSILON) * Math.pow(10, decimals)) / Math.pow(10, decimals);
};