// alertStorage.js

const ALERT_KEY = "fleet_alerts_v2";
const STATE_KEY = "fleet_state_map_v2";

export function loadAlertState() {
  try {
    return {
      alerts: JSON.parse(localStorage.getItem(ALERT_KEY)) || {},
      stateMap: JSON.parse(localStorage.getItem(STATE_KEY)) || {}
    };
  } catch {
    return { alerts: {}, stateMap: {} };
  }
}

export function saveAlertState({ alerts, stateMap }) {
  localStorage.setItem(ALERT_KEY, JSON.stringify(alerts));
  localStorage.setItem(STATE_KEY, JSON.stringify(stateMap));
}
