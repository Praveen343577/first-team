// alertEngine.js

export const ALERT_TTL = 15 * 60 * 1000; // 15 minutes in milliseconds

export function evaluateVehicleAlerts({
  vehicles,
  prevStateMap,
  prevAlerts,
  enableTTL = false
}) {
  const nextStateMap = { ...prevStateMap };
  const alertMap = { ...prevAlerts }; 

  let latestEpoch = 0;

  for (const v of vehicles) {
    if (v.lastTimestamp) {
      const ts = new Date(v.lastTimestamp).getTime();
      if (!isNaN(ts) && ts > latestEpoch) {
        latestEpoch = ts;
      }
    }

    const prevMode = nextStateMap[v.imei];
    const currMode = v.mode;

    if (!prevMode) {
      nextStateMap[v.imei] = currMode;
      continue;
    }

    // active → inactive
    if (prevMode === "active" && currMode === "inactive") {
      if (!alertMap[v.imei]) {
        const ts = new Date(v.lastTimestamp).getTime();
        alertMap[v.imei] = {
          imei: v.imei,
          vrn: v.vrn || v.chassisNumber || v.imei,
          alertGeneratedAt: isNaN(ts) ? Date.now() : ts
        };
      }
    }

    // inactive → active
    if (prevMode === "inactive" && currMode === "active") {
      delete alertMap[v.imei];
    }

    nextStateMap[v.imei] = currMode;
  }

  // Optional TTL cleanup
  if (enableTTL && latestEpoch > 0) {
    for (const imei in alertMap) {
      if (latestEpoch - alertMap[imei].alertGeneratedAt > ALERT_TTL) {
        delete alertMap[imei];
      }
    }
  }

  return {
    nextStateMap,
    nextAlerts: alertMap
  };
}
