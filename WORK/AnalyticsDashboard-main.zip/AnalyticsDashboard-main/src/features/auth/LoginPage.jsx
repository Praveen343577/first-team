import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  Activity, 
  ShieldCheck, 
  Download, 
  Zap, 
  Eye, 
  EyeOff, 
  User, 
  Lock, 
  AlertCircle 
} from 'lucide-react';
import { AnimatedGradient } from '../../components/ui/AnimatedGradient';
import './LoginPage.css';

export const LoginPage = () => {
  const navigate = useNavigate();
  
  // UI State
  const [isLoginVisible, setIsLoginVisible] = useState(false);
  
  // Form State
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const features = [
    { icon: <Activity size={24} />, text: "Realtime Vehicle Status" },
    { icon: <ShieldCheck size={24} />, text: "Advanced Data Validation" },
    { icon: <Download size={24} />, text: "Instant Data Export" },
    { icon: <Zap size={24} />, text: "Live Performance Metrics" }
  ];

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (error) setError(''); // Clear error on typing
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Network Simulation
    setTimeout(() => {
      if (formData.email === 'test@gmail.com' && formData.password === 'admin@123') {
        localStorage.setItem('isAuthenticated', 'true');
        navigate('/dashboard');
      } else {
        setError('Invalid credentials');
        setIsLoading(false);
      }
    }, 1500);
  };

  return (
    <div className="login-page-container">
      {/* Background Layer */}
      <div className="gradient-layer">
        <AnimatedGradient />
      </div>

      <div className="content-wrapper">
        {/* Hero Section - Shifts to 60% width when login is active */}
        <div className={`hero-section ${isLoginVisible ? 'hero-compact' : ''}`}>
          <div className="hero-content">
            <h1 className="hero-title">EV Command Center</h1>
            <p className="hero-description">
              The next generation of electric vehicle telemetry and management. 
              Monitor, analyze, and optimize your fleet in real-time.
            </p>

            <div className="feature-grid">
              {features.map((feat, index) => (
                <div key={index} className="feature-item">
                  <div className="feature-icon">{feat.icon}</div>
                  <span>{feat.text}</span>
                </div>
              ))}
            </div>

            {!isLoginVisible && (
              <button 
                className="action-btn"
                onClick={() => setIsLoginVisible(true)}
              >
                Access Dashboard <ArrowRight size={20} />
              </button>
            )}
          </div>
        </div>

        {/* Login Panel - Slides in to 40% width */}
        <div className={`login-panel ${isLoginVisible ? 'panel-active' : ''}`}>
          <div className="login-form-container">
            <h2 className="form-title">Welcome Back</h2>
            <p className="form-subtitle">Enter your credentials to continue</p>

            {error && (
              <div className="error-alert">
                <AlertCircle size={18} />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="auth-form">
              <div className="input-group">
                <label>Email Address</label>
                <div className="input-wrapper">
                  <User className="input-icon" size={18} />
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="name@company.com"
                    required 
                  />
                </div>
              </div>

              <div className="input-group">
                <label>Password</label>
                <div className="input-wrapper">
                  <Lock className="input-icon" size={18} />
                  <input 
                    type={showPassword ? "text" : "password"} 
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    placeholder="Enter your password"
                    required 
                  />
                  <button 
                    type="button" 
                    className="toggle-visibility"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              <div className="form-options">
                <label className="checkbox-label">
                  <input type="checkbox" /> 
                  <span>Remember me</span>
                </label>
                <a href="#" className="forgot-link">Forgot password?</a>
              </div>

              <button 
                type="submit" 
                className="submit-btn" 
                disabled={isLoading}
              >
                {isLoading ? 'Verifying...' : 'Login'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};