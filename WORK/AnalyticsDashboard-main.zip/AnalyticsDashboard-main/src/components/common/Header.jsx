import { Wifi, WifiOff } from 'lucide-react';
import { SearchBar } from './Search';
import { Alerts } from '../data-display/Alerts';
import { AvatarMenu } from '../layout/AvatarMenu';

export const Header = ({ status, vehicles, searchData, setSearchQuery }) => {
  return (
    <header className="flex items-center justify-between mb-3">
      <div>
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-bold text-brand-text transition-colors duration-300">Fleet Overview</h2>
          
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-mono border transition-colors duration-300 ${
            status === 'connected' 
              ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' 
              : 'bg-red-500/10 text-brand-red border-red-500/20'
          }`}>
            {status === 'connected' ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
            {status.toUpperCase()}
          </div>
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <SearchBar data={searchData || vehicles} onSearch={setSearchQuery} />
        <Alerts vehicles={vehicles} />
        <AvatarMenu />
      </div>
    </header>
  );
};