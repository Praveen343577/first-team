// import { ChevronsUp } from 'lucide-react';
import { ChevronsUp } from 'lucide-react';
import { clsx } from 'clsx';

export const CollapseButton = ({ 
  onCollapse, 
  disabled = false, 
  label = "Collapse All",
  className 
}) => {
  return (
    <button
      onClick={onCollapse}
      disabled={disabled}
      className={clsx(
        // Base Layout
        "px-3 py-2 border rounded-lg text-sm font-medium flex items-center gap-2 transition-all duration-300",
        // Conditional Styling
        disabled
          ? "bg-brand-bg/50 border-brand-border/50 text-brand-text-muted/50 cursor-not-allowed"
          : "bg-brand-bg border-brand-border text-brand-text-muted hover:bg-brand-border hover:text-brand-text hover:text-brand-text",
        className
      )}
    >
      <ChevronsUp className="w-4 h-4" />
      {label}
    </button>
  );
};