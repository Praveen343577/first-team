import { useState, useEffect, useRef, useMemo } from 'react';
import { ChevronDown, Check, Search } from 'lucide-react';
import { clsx } from 'clsx';

export const Dropdown = ({ label, value, options, onChange, placeholder = "Select...", disabled = false }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  // 1. Derive Current Label (Always pure, no state sync needed)
  const selectedOption = options.find(o => o.value === value);
  const currentLabel = selectedOption?.label || value || '';

  // 2. Handle Outside Clicks
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 3. Filter Options (Memoized)
  const filteredOptions = useMemo(() => {
    if (!isOpen || !searchTerm) return options;
    
    // If search term exactly matches the current selection, show all (assume initial open)
    if (searchTerm === currentLabel) return options;

    return options.filter(opt => 
      String(opt.label).toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [options, searchTerm, currentLabel, isOpen]);

  // 4. Interaction Handlers
  const handleOpen = () => {
    if (disabled) return;
    setSearchTerm(currentLabel); // Initialize edit mode with current value
    setIsOpen(true);
  };

  const handleSelect = (val) => {
    onChange(val);
    setIsOpen(false);
    inputRef.current?.blur();
  };

  return (
    <div className="relative min-w-[250px]" ref={containerRef}>
      <label className="text-xs font-semibold text-brand-text-muted uppercase mb-1.5 block">{label}</label>
      
      <div 
        className={clsx(
          "w-full px-3 py-2.5 border rounded-lg flex items-center justify-between gap-2 transition-all duration-300 bg-brand-bg",
          isOpen 
            ? "border-brand-blue ring-1 ring-brand-blue/20" 
            : "border-brand-border hover:bg-brand-border/30",
          disabled && "opacity-50 cursor-not-allowed bg-brand-bg/50"
        )}
        onClick={() => inputRef.current?.focus()}
      >
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {/* Search Icon Indicator */}
          {isOpen && <Search className="w-3.5 h-3.5 text-brand-text-muted shrink-0" />}
          
          <input
            ref={inputRef}
            type="text"
            // KEY FIX: Switch source based on state to avoid useEffect sync
            value={isOpen ? searchTerm : currentLabel}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              if (!isOpen) setIsOpen(true);
            }}
            onFocus={handleOpen}
            placeholder={placeholder}
            disabled={disabled}
            className={clsx(
              "w-full bg-transparent border-none outline-none text-sm font-medium placeholder:text-brand-text-muted/70 truncate",
              isOpen ? "text-brand-text" : "text-brand-text cursor-pointer"
            )}
            autoComplete="off"
          />
        </div>
        
        <ChevronDown 
          className={clsx(
            "w-4 h-4 text-brand-text-muted transition-transform duration-200 shrink-0", 
            isOpen && "rotate-180 text-brand-blue"
          )} 
        />
      </div>

      {isOpen && (
        <div className="absolute top-full mt-2 left-0 w-full bg-brand-surface border border-brand-border rounded-xl shadow-xl z-50 overflow-hidden max-h-60 overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
           {filteredOptions.length === 0 ? (
             <div className="p-6 flex flex-col items-center justify-center text-brand-text-muted gap-2 opacity-60">
               <Search className="w-8 h-8 opacity-20" />
               <span className="text-xs font-medium">No results found</span>
             </div>
           ) : (
             <div className="p-1">
               {filteredOptions.map((opt) => (
                 <button
                   key={opt.value}
                   onClick={(e) => {
                     e.stopPropagation();
                     handleSelect(opt.value);
                   }}
                   className={clsx(
                     "w-full flex items-center justify-between p-2 rounded-lg text-sm transition-colors text-left",
                     value === opt.value 
                        ? "bg-brand-blue/10 text-brand-blue font-medium" 
                        : "text-brand-text hover:bg-brand-bg/50"
                   )}
                 >
                   <span className="truncate">{opt.label}</span>
                   {value === opt.value && <Check className="w-3.5 h-3.5 shrink-0" />}
                 </button>
               ))}
             </div>
           )}
        </div>
      )}
    </div>
  );
};