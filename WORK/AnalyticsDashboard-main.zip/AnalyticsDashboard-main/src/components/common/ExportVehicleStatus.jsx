import XLSX from 'xlsx-js-style';
import { Download } from 'lucide-react';

export const ExportData = ({ data }) => { 
  
  const handleExport = () => {
    // 1. Transform data to match specific column requirements
    const exportData = data.map(vehicle => {
      // Replicate logic from Table.jsx for consistency
      const isSevenDigit = vehicle.imei?.toString().length === 7;
      const lastSeenDate = vehicle.lastTimestamp ? new Date(vehicle.lastTimestamp) : null;
      
      return {
        'VRN / Chassis Number': vehicle.vrn || vehicle.chassisNumber || vehicle.imei || 'N/A',
        'Vehicle Type': vehicle.deviceTypeName || 'N/A',
        'Fleet': vehicle.fleet || '-',
        'Latitude': vehicle.latitude || '0',
        'Longitude': vehicle.longitude || '0',
        'Last Seen': lastSeenDate 
          ? lastSeenDate.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true }) 
          : 'Not Available',
        'Provider': isSevenDigit ? 'MapMyIndia' : 'Roadpoint',
        'Remarks': 'No Remarks'
      };
    });

    // 2. Create Worksheet and Workbook
    const worksheet = XLSX.utils.json_to_sheet(exportData);

    // --- START STYLING LOGIC ---

    // const headerStyle = {
    //   font: { bold: true, color: { rgb: "000000" } },
    //   fill: { fgColor: { rgb: "CCCCCC" } },
    //   alignment: { horizontal: "center", vertical: "center" }
    // };

    // const range = XLSX.utils.decode_range(worksheet['!ref']);
    // for (let C = range.s.c; C <= range.e.c; ++C) {
    //   const address = XLSX.utils.encode_cell({ r: 0, c: C }); 
    //   if (!worksheet[address]) continue;
    //   worksheet[address].s = headerStyle;
    // }

    // C. Set Row Height (Row 0)
    // if (!worksheet['!rows']) worksheet['!rows'] = [];
    // worksheet['!rows'][0] = { hpt: 25 }; 

    // --- END STYLING LOGIC ---

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

    // 3. Adjust Column Widths
    const wscols = [
      { wch: 25 }, // VRN
      { wch: 15 }, // Type
      { wch: 25 }, // Fleet
      { wch: 15 }, // Lat
      { wch: 15 }, // Long
      { wch: 25 }, // Last Seen
      { wch: 15 }, // Provider
      { wch: 35 }, // Remarks
    ];
    worksheet['!cols'] = wscols;

    // 4. Trigger Download with Timestamp. Filename is Vehicle_Status_YYYY-MM-DD_HH-mm-ss
    const now = new Date();
    const timestamp = now.getFullYear() + '-' +
      String(now.getMonth() + 1).padStart(2, '0') + '-' +
      String(now.getDate()).padStart(2, '0') + '_' +
      String(now.getHours()).padStart(2, '0') + '-' +
      String(now.getMinutes()).padStart(2, '0') + '-' +
      String(now.getSeconds()).padStart(2, '0');

    XLSX.writeFile(workbook, `Vehicle_Status_${timestamp}.xlsx`);
  };

  return (
    <button 
      onClick={handleExport}
      className="px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text flex items-center gap-2 transition-colors duration-300"
    >
      <Download className="w-4 h-4" />
      Export
    </button>
  );
};