import * as XLSX from 'xlsx';
import { Download } from 'lucide-react';

export const ExportData = ({ data }) => {

  const handleExport = () => {
    if (!data || data.length === 0) return;

    const exportRows = [];

    // 1. Dynamic Header Extraction (Future Proofing)
    // We grab keys from the first record, excluding the nested array key 'errors_json'
    const sampleParent = data[0];
    const parentHeaders = Object.keys(sampleParent).filter(k => k !== 'errors_json');
    
    // We also grab keys from the first nested error of the first record (if available) for nested headers
    // If first record has no errors, we try to find one that does, or fallback to default
    const sampleNested = data.find(d => d.errors_json?.length > 0)?.errors_json[0] || {};
    const nestedHeaders = Object.keys(sampleNested);

    // 2. Push Main Header Row
    exportRows.push(parentHeaders);

    // 3. Process Data
    data.forEach(record => {
      // A. Add Parent Row
      const parentRow = parentHeaders.map(header => {
        const val = record[header];
        // formatting logic for timestamps if needed
        if (header.includes('date') || header.includes('at')) {
           return new Date(val).toLocaleString('en-IN');
        }
        return val;
      });
      exportRows.push(parentRow);

      // B. Add Nested Table (if exists)
      if (record.errors_json && record.errors_json.length > 0) {
        // B1. Nested Header Row (Indented by 1 cell)
        exportRows.push(['', ...nestedHeaders]);

        // B2. Nested Data Rows
        record.errors_json.forEach(errorItem => {
          const nestedRow = nestedHeaders.map(h => errorItem[h]);
          exportRows.push(['', ...nestedRow]);
        });
      }
    });

    // 4. Create Workbook
    const worksheet = XLSX.utils.aoa_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Validation_Results");

    // 5. Generate Filename
    const now = new Date();
    const timestamp = now.getFullYear() + '-' +
      String(now.getMonth() + 1).padStart(2, '0') + '-' +
      String(now.getDate()).padStart(2, '0') + '_' +
      String(now.getHours()).padStart(2, '0') + '-' +
      String(now.getMinutes()).padStart(2, '0');

    XLSX.writeFile(workbook, `Validation_Export_${timestamp}.xlsx`);
  };

  return (
    <button 
      onClick={handleExport}
      className="px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text flex items-center gap-2 transition-colors duration-300"
    >
      <Download className="w-4 h-4" />
      Export
    </button>
  );
};