import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, FileSpreadsheet, Box, Settings, BarChart3, Zap, ChevronLeft, ChevronRight } from 'lucide-react';
import { clsx } from 'clsx';

const menuItems = [
  { icon: LayoutDashboard, label: "Vehicle Status", path: "/dashboard" },
  { icon: BarChart3, label: "Data Validation", path: "/dataValidation" },
  { icon: FileSpreadsheet, label: "Live CAN", path: "/liveCan" },
  // { icon: Users, label: "User redeem", path: "/users", active: false }, 
  // { icon: Box, label: "Products", path: "/products" },
];

export const Sidebar = ({ isCollapsed, toggleSidebar }) => {
  return (
    <aside className={clsx(
      "h-screen fixed left-0 top-0 bg-brand-bg border-r border-brand-border flex flex-col z-20 transition-[width] duration-300",
      isCollapsed ? "w-20" : "w-64"
    )}>
      <div className="p-6 flex items-center justify-between gap-3 relative">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-8 h-8 shrink-0 rounded-lg bg-linear-to-r from-pink-500 via-red-500 to-orange-500 flex items-center justify-center">
          </div>
          {!isCollapsed && <span className="font-bold text-lg tracking-wide text-brand-text transition-colors duration-300 whitespace-nowrap">EKA</span>}
        </div>
        
        {/* Toggle Button */}
        <button 
          onClick={toggleSidebar}
          className="absolute -right-3 top-7 w-6 h-6 bg-brand-surface border border-brand-border rounded-full flex items-center justify-center text-brand-text-muted hover:text-brand-blue hover:border-brand-blue transition-colors z-50 cursor-pointer"
        >
          {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      <div className="p-4 flex-1 overflow-hidden">
        <nav className="space-y-2">
          {!isCollapsed}
          {menuItems.map((item) => (
            <NavLink
              key={item.label}
              to={item.path}
              title={isCollapsed ? item.label : undefined}
              className={({ isActive }) => clsx(
                "flex items-center rounded-lg text-sm font-medium transition-all duration-200",
                isCollapsed ? "justify-left p-3" : "gap-3 px-3 py-3",
                isActive || item.active 
                  ? "bg-brand-blue/10 text-brand-blue border border-brand-blue/20" 
                  : "text-brand-text-muted hover:text-brand-text hover:bg-brand-surface border border-transparent"
              )}
            >
              <item.icon className="w-5 h-5 shrink-0" />
              {!isCollapsed && <span className="truncate">{item.label}</span>}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-4 border-t border-brand-border transition-colors duration-300">
        <button 
          title={isCollapsed ? "System Settings" : undefined}
          className={clsx(
            "flex items-center text-sm font-medium text-brand-text-muted hover:text-brand-red transition-colors w-full",
            isCollapsed ? "justify-center p-3" : "gap-3 px-3 py-3"
          )}
        >
          <Settings className="w-5 h-5 shrink-0" />
          {!isCollapsed && <span className="truncate">System Settings</span>}
        </button>
      </div>
    </aside>
  );
};