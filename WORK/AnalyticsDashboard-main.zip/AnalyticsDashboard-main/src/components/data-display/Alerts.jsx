import { useState, useEffect, useRef } from "react";
import { Bell, X, AlertTriangle } from "lucide-react";
import { useVehicleAlerts } from "../../hooks/useVehicleAlerts";

export const Alerts = ({ vehicles }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef(null);
  const {
    alerts,
    alertCount,
    dismissAlert,
    clearAll
  } = useVehicleAlerts(vehicles);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative z-50">
      {/* Bell Button */}
      <button
        onClick={() => setIsOpen((prev) => !prev)}
        className="p-2 text-brand-text-muted hover:text-brand-blue transition-colors relative"
      >
        <div className="w-10 h-10 rounded-full bg-brand-blue/10 text-brand-blue flex items-center justify-center font-bold text-xs border border-brand-blue/20 transition-colors duration-300">
          <Bell className="w-5 h-5" />
        </div>

        {alertCount > 0 && (
          <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white ring-2 ring-brand-bg">
            {alertCount}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 bg-brand-surface border border-brand-border rounded-xl shadow-lg z-50 overflow-hidden flex flex-col max-h-[400px]">
          
          {/* Header */}
          <div className="p-3 border-b border-brand-border flex items-center justify-between bg-brand-bg/50">
            <h3 className="text-sm font-bold text-brand-text">
              Inactive Alerts
            </h3>

            {alertCount > 0 && (
              <button
                onClick={clearAll}
                className="text-xs text-brand-text-muted hover:text-brand-red transition-colors"
              >
                Clear All
              </button>
            )}
          </div>

          {/* Alert List */}
          <div className="overflow-y-auto flex-1 p-2 flex flex-col gap-2">
            {alertCount === 0 ? (
              <div className="p-4 text-center text-xs text-brand-text-muted">
                No active alerts.
              </div>
            ) : (
              alerts.map((alert) => (
                <div
                  key={alert.imei}
                  className="flex items-start justify-between p-3 bg-brand-bg rounded-lg border border-brand-border hover:border-brand-red/30 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-4 h-4 text-brand-red shrink-0 mt-0.5" />

                    <div className="flex flex-col">
                      <span className="text-sm font-bold text-brand-text">
                        {alert.vrn}
                      </span>

                      <span className="text-[10px] text-brand-text-muted">
                        {new Date(alert.alertGeneratedAt).toLocaleString(
                          "en-IN"
                        )}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => dismissAlert(alert.imei)}
                    className="text-brand-text-muted hover:text-brand-text p-1"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
