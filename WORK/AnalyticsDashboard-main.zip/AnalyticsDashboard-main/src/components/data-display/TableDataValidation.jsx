import { useState, useCallback } from 'react';
import { ChevronDown, ChevronUp, AlertCircle, CheckCircle2 } from 'lucide-react';
import { clsx } from 'clsx';
import { SortDropdown } from '../common/Sorting';
import { FilterDropdown } from '../common/Filter';
import { CollapseButton } from '../common/Collapse';
import { ExportData } from '../common/ExportDataValidation';

export const TableDataValidation = ({ data = [], searchQuery = '' }) => {
  const [expandedRows, setExpandedRows] = useState(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 20;

  // State mirroring Table.jsx structure
  const [activeFilters, setActiveFilters] = useState({ types: new Set(), fleets: new Set() });
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  // Toggle Row Expansion
  const toggleRow = (id) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  // Filter Logic - Fixed Dependencies
  const handleFilterChange = useCallback((filters) => {
    setActiveFilters(filters);
    setCurrentPage(1);
  }, [setActiveFilters, setCurrentPage]);

  const filteredData = data.filter(record => {
    const typeMatch = !activeFilters.types || activeFilters.types.size === 0 || activeFilters.types.has(record.type);
    const fleetMatch = !activeFilters.fleets || activeFilters.fleets.size === 0 || activeFilters.fleets.has(record.fleet);
    
    const lowerQ = searchQuery.toLowerCase();
    const searchMatch = !searchQuery || 
      (record.VRN && record.VRN.toLowerCase().includes(lowerQ)) ||
      (record.device_id && record.device_id.toString().toLowerCase().includes(lowerQ)) ||
      (record.fleet && record.fleet.toLowerCase().includes(lowerQ));

    return typeMatch && fleetMatch && searchMatch;
  });

  const sortOptions = [
    { label: 'VRN', key: 'VRN' },
    { label: 'IMEI', key: 'device_id' },
    { label: 'Type', key: 'type' },
    { label: 'Fleet', key: 'fleet' },
    { label: 'Date', key: 'data_date' },
    { label: 'Errors', key: 'errors_json' },
  ];

  // Sort Logic
  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortConfig.key) return 0;
    
    const valA = a[sortConfig.key] ?? '';
    const valB = b[sortConfig.key] ?? '';
    
    const comparison = String(valA).localeCompare(String(valB), 'en', { numeric: true, sensitivity: 'base' });
    return sortConfig.direction === 'asc' ? comparison : -comparison;
  });

  // Pagination Logic
  const totalPages = Math.ceil(sortedData.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const currentData = sortedData.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const goToNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
  };

  const goToPrevPage = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1);
  };

  // This hides scrollbar but allows scrolling
  const hideScrollbarStyle = `
    .no-scrollbar::-webkit-scrollbar {
      display: none;
    }
    .no-scrollbar {
      -ms-overflow-style: none; 
      scrollbar-width: none;  
    }
  `;

  return (
    <div className="bg-brand-surface border border-brand-border rounded-xl overflow-visible shadow-sm h-full flex flex-col transition-colors duration-300">
      <style>{hideScrollbarStyle}</style>
      <div className="p-5 border-b border-brand-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h3 className="text-lg font-bold text-brand-text transition-colors duration-300">
          Validation Results <span className="text-brand-text-muted text-sm font-normal">({filteredData.length})</span>
        </h3>
        
        <div className="flex items-center gap-3">
          <CollapseButton onCollapse={() => setExpandedRows(new Set())} disabled={expandedRows.size === 0} />
          <SortDropdown options={sortOptions} onSortChange={setSortConfig} />
          <FilterDropdown data={data} onFilterChange={handleFilterChange} visibleSections={['type', 'fleet']} />
          <ExportData data={sortedData} />
        </div> 
      </div>

      {/* Main Table */}
      <div className="overflow-auto flex-1 relative min-h-0 no-scrollbar">
        <table className="w-full text-left border-collapse min-w-[1200px]">
          <thead className="sticky top-0 z-10 bg-brand-surface border-b border-brand-border transition-colors duration-300">
            <tr className="bg-brand-bg/50 border-b border-brand-border transition-colors duration-300">
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">VRN</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">IMEI</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Vehicle Type</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Fleet</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Data Date</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Errors</th>
              <th className="w-[5%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Generated At</th>
            </tr>
          </thead>

            {currentData.map((record) => {
              const isExpanded = expandedRows.has(record.device_id);
              const errorCount = record.errors_json?.length || 0;

              return (
                <tbody key={record.device_id} className="group transition-colors duration-300 hover:bg-brand-bg/50">
                  <tr 
                    onClick={() => toggleRow(record.device_id)}
                    className={clsx(
                      "group transition-colors duration-300 hover:bg-brand-bg/50",
                      isExpanded ? "bg-brand-blue/5" : "hover:bg-brand-bg/50"
                    )}
                  >
                    <td className="px-4 py-2.5 text-sm font-medium text-brand-text transition-colors duration-300">{record.VRN}</td>
                    <td className="px-4 py-2.5 text-sm text-brand-text-muted font-mono transition-colors duration-300">{record.device_id}</td>
                    <td className="px-4 py-2.5 text-sm text-brand-text transition-colors duration-300">{record.type}</td>
                    <td className="px-4 py-2.5 text-sm text-brand-text transition-colors duration-300">{record.fleet}</td>
                    <td className="px-4 py-2.5 text-sm text-brand-text transition-colors duration-300">{record.data_date}</td>
                    <td className="px-4 py-2.5">
                      <div className={clsx(
                        "inline-flex items-center justify-center gap-1 w-25 px-2 py-1 rounded-sm text-xs font-medium border transition-colors duration-300",
                        errorCount === 0 
                          ? "bg-emerald-500/10 border-emerald-500 text-emerald-500"
                          : errorCount < 3
                            ? "bg-amber-500/10 border-amber-500 text-amber-500"
                            : "bg-red-500/10 border-red-500 text-red-500"
                      )}>
                        {errorCount === 0 ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                        {errorCount} Issues
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-brand-text-muted transition-colors duration-300">
                       {new Date(record.generated_at).toLocaleString('en-IN', {
                          day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'
                       })}
                    </td>
                  </tr>

                  {/* Child Row (Nested Table) */}
                  {isExpanded && (
                    <tr className="bg-brand-bg/30 transition-colors duration-300">
                      <td colSpan="8" className="p-0">
                        <div className="px-12 py-4 border-b border-brand-border">
                          <div className="no-scrollbar bg-brand-surface border border-brand-border rounded-lg shadow-sm max-h-75 overflow-y-auto relative transition-colors duration-300">
                            <table className="w-full text-left text-sm table-fixed">
                              <thead className="sticky top-0 z-10 bg-brand-bg border-b border-brand-border transition-colors duration-300">
                                <tr>
                                  <th className="w-[15%] px-4 py-2 font-medium text-brand-text-muted">Column</th>
                                  {/* <th className="w-[15%] px-4 py-2 font-medium text-brand-text-muted">Error Type</th> */}
                                  <th className="w-[25%] px-4 py-2 font-medium text-brand-text-muted">Message</th>
                                  <th className="w-[15%] px-4 py-2 font-medium text-brand-text-muted">Observed Value</th>
                                  <th className="w-[15%] px-4 py-2 font-medium text-brand-text-muted">Occurrences</th>
                                </tr>
                              </thead>
                              <tbody>
                                {record.errors_json.map((err, idx) => (
                                  <tr key={idx} className="border-b border-brand-border/80 last:border-0 hover:bg-brand-bg/50 transition-colors duration-300">
                                    <td className="px-4 py-2 font-mono text-brand-blue">{err.column}</td>
                                    {/* <td className="px-4 py-2 text-brand-text">{err.error_type}</td> */}
                                    <td className="px-4 py-2 text-brand-red">{err.message}</td>
                                    <td className="px-4 py-2 font-mono text-brand-text">{err.observed}</td>
                                    <td className="px-4 py-2 text-brand-text-muted">{err.occurrences}</td>
                                  </tr>
                                ))}
                                {record.errors_json.length === 0 && (
                                  <tr>
                                    <td colSpan="5" className="px-4 py-4 text-center text-brand-text-muted">
                                      No errors found for this record.
                                    </td>
                                  </tr>
                                )}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              );
            })}
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-brand-border flex items-center gap-12 justify-center bg-brand-bg/30 transition-colors duration-300">
        
        {/* LEFT GROUP */}
        <div className="flex items-center gap-5">
          <button 
            onClick={() => setCurrentPage(1)} 
            disabled={currentPage === 1}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >  
            First
          </button>

          <button
            onClick={goToPrevPage}
            disabled={currentPage === 1}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Previous
          </button>
        </div>

        {/* PAGE INDICATOR */}
        <span className="text-sm text-brand-text-muted transition-colors duration-300">
          Page <span className="text-brand-text font-medium">{currentPage}</span>
          {' '}of{' '}
          <span className="text-brand-text font-medium">{totalPages || 1}</span>
        </span>

        {/* RIGHT GROUP */}
        <div className="flex items-center gap-5">
          <button
            onClick={goToNextPage}
            disabled={currentPage === totalPages || totalPages === 0}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Next
          </button>

          <button 
            onClick={() => setCurrentPage(totalPages)} 
            disabled={currentPage === totalPages || totalPages === 0}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Last
          </button>
        </div>
      </div>
    </div>
  );
};