import { useMemo } from 'react';
import { clsx } from 'clsx';
import { Gauge, AlertTriangle, Layers, Battery, Truck, Activity, Cpu, Clock, Power, GitBranch, Box } from 'lucide-react';
import { CAN_CONFIG } from '../../utils/canParameters';
import { CAN_CATEGORIES } from '../../utils/canCategories';
import { formatTimestamp, roundValue } from '../../utils/formatters';

// Categorization Logic
const categorizeData = (data) => {
  if (!data) return {};

  // Initialize Priority, Uncategorized, and dynamically build the rest
  const categories = {
    priority: { label: "Key Parameters", icon: Cpu, items: {} },
    uncategorized: { label: "Uncategorized", icon: Activity, items: {} }
  };

  Object.keys(CAN_CATEGORIES).forEach(categoryKey => {
    categories[categoryKey] = {
      label: categoryKey.replace(/_/g, ' '), 
      icon: Box, // Fallback icon for dynamic categories
      items: {}
    };
  });

  const PRIORITY_KEYS = [
    'Ignition_Sense', 
    'VCU_SW_Version_X', 
    'VCU_SW_Version_YY', 
    'timestamp'
  ];

  Object.entries(data).forEach(([key, value]) => {
    if (PRIORITY_KEYS.includes(key)) {
      categories.priority.items[key] = value;
      return; 
    }

    // Lookup category in the imported JSON structure
    const targetCategory = Object.keys(CAN_CATEGORIES).find(cat => 
      CAN_CATEGORIES[cat].includes(key)
    );

    if (targetCategory) {
      categories[targetCategory].items[key] = value;
    } else {
      categories.uncategorized.items[key] = value;
    }
  });

  return categories;
};

export const LiveCanLayout = ({ data, vehicleType }) => {
  // 1. FILTER LOGIC
  const filteredData = useMemo(() => {
    if (!data) return null;
    
    // Get whitelist for this vehicle type. If not found, show everything (safe fallback)
    const whitelist = CAN_CONFIG[vehicleType];
    
    if (!whitelist) return data; 

    // Filter the raw data to include only keys present in the whitelist
    const allowedKeys = new Set(whitelist);
    const result = {};
    
    Object.keys(data).forEach(key => {
      // Ensure Priority Keys are always included, even if missing from config whitelist (Safety fallback)
      if (allowedKeys.has(key) || ['Ignition_Sense', 'VCU_SW_Version_X', 'VCU_SW_Version_YY', 'timestamp'].includes(key)) {
        result[key] = data[key];
      }
    });

    return result;
  }, [data, vehicleType]);
  
  const categorizedGroups = useMemo(() => categorizeData(filteredData), [filteredData]);
  const hasData = filteredData && Object.keys(filteredData).length > 0;

  if (!hasData) {
    return (
       <div className="h-full border-2 border-solid border-brand-border rounded-xl flex flex-col items-center justify-center text-brand-text-muted gap-4 bg-brand-surface/50">
         <div className="w-16 h-16 rounded-full bg-brand-bg flex items-center justify-center border border-brand-border">
           <Activity className="w-8 h-8 opacity-50" />
         </div>
         <div className="text-center">
           <h3 className="text-lg font-semibold text-brand-text">Awaiting Telemetry</h3>
           <p className="text-sm">Select a vehicle and start stream to view parameters.</p>
         </div>
       </div>
    );
  }

  // 1. Extract Priority Items separately
  const priorityItems = categorizedGroups.priority?.items || {};
  
  // 2. Prepare Data for Custom Cards
  const ignition = priorityItems['Ignition_Sense'];
  const isIgnitionOn = ignition === 1 || ignition === '1' || ignition === 'Y';
  
  const vcuX = priorityItems['VCU_SW_Version_X'] || 0;
  const vcuYY = priorityItems['VCU_SW_Version_YY'] || 0;
  const rawTime = priorityItems['timestamp'] || priorityItems['Time'];
  const timeVal = rawTime ? formatTimestamp(rawTime) : '--:--:--';

  // 3. Remove 'priority' from the loop list
  const gridGroups = Object.entries(categorizedGroups).filter(([key]) => key !== 'priority');

  return (
    <div className="h-full flex flex-col gap-4">
      
      {/* --- FIXED PRIORITY HEADER --- */}
      <div className="shrink-0 flex items-center justify-start gap-3 px-1">
        
        {/* Card 1: Ignition */}
        <div className={clsx(
          "border rounded-lg p-3 flex items-center gap-3 shadow-sm transition-all duration-300 min-w-[180px]",
          isIgnitionOn ? "bg-emerald-500/30 border-emerald-500" : "bg-brand-surface border-brand-border"
        )}>
          <div className={clsx(
            "w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all",
            isIgnitionOn ? "bg-emerald-600 text-white shadow-lg shadow-emerald-500/20" : "bg-brand-bg text-brand-text-muted"
          )}>
            <Power className="w-4 h-4" />
          </div>
          <div className="overflow-hidden min-w-0">
             <span className="text-[10px] font-bold text-brand-text-muted uppercase block truncate">Ignition</span>
             <span className={clsx("text-sm font-bold truncate block", isIgnitionOn ? "text-emerald-600" : "text-brand-text")}>
               {isIgnitionOn ? "ON" : "OFF"}
             </span>
          </div>
        </div>

        {/* Card 2: VCU Version (Split with Divider) */}
        <div className="bg-brand-surface border border-brand-border rounded-lg p-3 flex items-center gap-3 shadow-sm min-w-[180px]">
          <div className="w-8 h-8 rounded-full bg-indigo-500/10 border border-indigo-500/50 flex items-center justify-center shrink-0">
            <GitBranch className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="overflow-hidden min-w-0">
             {/* UPDATED: Label split to match values X | YY */}
             <span 
               className="text-[10px] font-bold text-brand-text-muted uppercase block truncate" 
               title="VCU SW Version X | VCU SW Version YY"
             >
               VCU SW Version X | YY
             </span>
             <div className="flex items-center gap-2 text-sm font-bold text-brand-text">
                <span>{vcuX}</span>
                <div className="w-px h-3 bg-brand-border"></div> {/* Vertical Divider */}
                <span>{vcuYY}</span>
             </div>
          </div>
        </div>

        {/* Card 3: Time */}
        <div className="bg-brand-surface border border-brand-border rounded-lg p-3 flex items-center gap-3 shadow-sm min-w-[200px]">
          <div className="w-8 h-8 rounded-full bg-brand-blue/10 border border-brand-blue/50 flex items-center justify-center shrink-0">
            <Clock className="w-4 h-4 text-brand-blue" />
          </div>
          <div className="overflow-hidden min-w-0">
             <span className="text-[10px] font-bold text-brand-text-muted uppercase block truncate">Last Update</span>
             <span className="text-sm font-bold text-brand-text truncate block">{timeVal}</span>
          </div>
        </div>
      </div>

      {/* --- SCROLLABLE BODY --- */}
      <div className="flex-1 overflow-y-auto custom-scrollbar rounded-xl border border-transparent">
        <div className="columns-1 xl:columns-2 gap-4 pb-2">
          {gridGroups.map(([key, group]) => {
            const items = Object.entries(group.items);
            if (items.length === 0) return null;
            
            return (
              <div key={key} className="break-inside-avoid mb-4 bg-brand-surface border border-brand-border rounded-xl overflow-hidden shadow-sm flex flex-col transition-all duration-300bg-brand-surface border border-brand-border rounded-xl overflow-hidden shadow-sm flex flex-col transition-all duration-300">
                {/* Header */}
                <div className="px-4 py-2 border-b border-brand-border bg-brand-bg/50 flex items-center gap-2">
                  <group.icon className="w-4 h-4 text-brand-blue" />
                  <h4 className="text-xs font-bold text-brand-text uppercase tracking-wide">{group.label}</h4>
                  <span className="ml-auto text-[10px] bg-brand-bg border border-brand-border px-1.5 py-0.5 rounded text-brand-text">
                    {items.length} Params
                  </span>
                </div>

                {/* Content Grid */}
                <div className="p-4 grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-3">
                  {items.map(([k, v]) => {
                    const isBool = v === 'N' || v === 'Y' || v === 0 || v === 1;
                    const isActive = v === 'Y' || v === 1 || (typeof v === 'number' && v > 0 && !k.includes('Hazard'));
                    const isAlert = (k.includes('Hazard') && v === 1) || (k === 'DTE' && v < 20);
                    const displayValue = roundValue(v, 3);

                    return (
                      <div key={k} className="flex flex-col justify-between p-2.5 rounded-lg bg-brand-bg/30 border border-brand-border hover:border-brand-blue transition-colors min-h-[60px]">
                         <span className="text-[10px] font-semibold text-brand-text-muted uppercase truncate mb-1" title={k}>
                            {k.replace(/_/g, ' ')}
                         </span>
                         
                         <div className="flex items-center gap-2">
                           {isBool && (
                             <div className={clsx(
                               "w-1.5 h-1.5 rounded-full shrink-0 transition-colors duration-300",
                               isActive ? "bg-emerald-500 shadow-[0_0_6px_rgba(16,185,129,0.6)]" : "bg-slate-600/50"
                             )} />
                           )}
                           
                           <span className={clsx(
                             "text-base font-mono font-medium leading-none truncate",
                             isAlert ? "text-red-500" : isActive ? "text-brand-text" : "text-brand-text-muted"
                           )}>
                             {displayValue}
                           </span>
                         </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
