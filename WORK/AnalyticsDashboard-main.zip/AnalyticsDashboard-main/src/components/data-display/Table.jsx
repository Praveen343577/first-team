import { useState, useCallback } from 'react';
import { MoreVertical, ArrowDown, ArrowUp, Edit2, Trash2, Filter, Download, Plus, Truck, Clock } from 'lucide-react';
import { clsx } from 'clsx';
import { Button } from '../common/Button';
import { LocationCell } from './Location';
import { FilterDropdown } from '../common/Filter';
import { SortDropdown } from '../common/Sorting';
import { ExportData } from '../common/ExportVehicleStatus';
import { Tooltip } from '../ui/Tooltip';

export const Table = ({ data = [] }) => {
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [statusView, setStatusView] = useState('total'); 

  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 18;

  const [activeFilters, setActiveFilters] = useState({ types: new Set(), fleets: new Set(), providers: new Set(), statuses: new Set(), timeRanges: new Set() });
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  const handleFilterChange = useCallback(
    (filters) => {
      setActiveFilters(filters);
      setCurrentPage(1);
    },
    [setActiveFilters, setCurrentPage]
  );


  const filteredData = data.filter(vehicle => {
      const typeMatch = activeFilters.types.size === 0 || activeFilters.types.has(vehicle.deviceTypeName);
      const fleetMatch = activeFilters.fleets.size === 0 || activeFilters.fleets.has(vehicle.fleet);
      
      const providerName = vehicle.imei?.toString().length === 7 ? "MapMyIndia" : "Roadpoint";
      const providerMatch = activeFilters.providers.size === 0 || activeFilters.providers.has(providerName);

      const currentStatus = vehicle.mode === 'active' ? 'Active' : 'Inactive';
      const statusMatch = !activeFilters.statuses || activeFilters.statuses.size === 0 || activeFilters.statuses.has(currentStatus);

      // Discrete Slot Logic - MUST match values from Filter.jsx
      const timeMatch = !activeFilters.timeRanges || activeFilters.timeRanges.size === 0 || (() => {
        // Treat missing timestamp as 'Over 7 Days'
        if (!vehicle.lastTimestamp) return activeFilters.timeRanges.has('7d+');

        const now = new Date();
        const lastSeen = new Date(vehicle.lastTimestamp);
        const diffInMs = now - lastSeen;
        const diffHours = diffInMs / (1000 * 60 * 60);

        return Array.from(activeFilters.timeRanges).some(range => {
          switch(range) {
            case '0-1h':   return diffHours < 1;
            case '1h-48h': return diffHours >= 1 && diffHours <= 48;
            case '48h+':   return diffHours > 48;
            default: return false;
          }
        });
      })();

      return typeMatch && fleetMatch && providerMatch && statusMatch && timeMatch;
    });

  // Calculate counts based on current filtered data
  const activeCount = filteredData.filter(v => v.mode === 'active').length;
  const inactiveCount = filteredData.length - activeCount;

  const statusFilteredData = filteredData.filter(v => {
    if (statusView === 'active') return v.mode === 'active';
    if (statusView === 'inactive') return v.mode !== 'active';
    return true; // total
  });

  const sortOptions = [
    { label: 'VRN / Chassis Number', key: 'name' }, 
    { label: 'Vehicle Type', key: 'deviceTypeName' },
    { label: 'Fleet', key: 'fleet' },
    { label: 'Last Seen', key: 'lastTimestamp' },
    // Add other keys as needed
  ];

  // Sorting Logic
  const sortedData = [...statusFilteredData].sort((a, b) => {
    if (!sortConfig.key) return 0;

    const valA = a[sortConfig.key] ?? '';
    const valB = b[sortConfig.key] ?? '';

    // 2. Use a smart comparator that handles Mixed Types & "Natural" Numbers
    const comparison = String(valA).localeCompare(String(valB), 'en', {
      numeric: true,       // Sorts "Fleet 2" before "Fleet 10" (Natural sort)
      sensitivity: 'base'  // Ignores case (A == a)
    });

    // 1. Determine Direction Multiplier
    // Default: Ascending = 1, Descending = -1
    let directionMultiplier = sortConfig.direction === 'asc' ? 1 : -1;

    // 2. EXCEPTION: Reverse logic for Last Seen
    // Why: Ascending usually means "Smallest Number". 
    // For "Time Ago", "5 mins" is smaller than "10 mins", but "5 mins" implies a NEWER (Larger) timestamp.
    if (sortConfig.key === 'lastTimestamp') {
      directionMultiplier = -directionMultiplier; 
    }

    return comparison * directionMultiplier;
  });

  const totalPages = Math.ceil(sortedData.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const currentData = sortedData.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const goToNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
  };

  const goToPrevPage = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1);
  };

  const hideScrollbarStyle = `
    .no-scrollbar::-webkit-scrollbar {
      display: none;
    }
    .no-scrollbar {
      -ms-overflow-style: none; 
      scrollbar-width: none;  
    }
  `;

  return (
    <div className="bg-brand-surface border border-brand-border rounded-xl overflow-visible shadow-sm h-full flex flex-col transition-colors duration-300">
      <style>{hideScrollbarStyle}</style>
      <div className="p-5 border-b border-brand-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {['total', 'active', 'inactive'].map(type => (
            <button
              key={type}
              onClick={() => {
                setStatusView(type);
                setCurrentPage(1);
              }}
              className={clsx(
                "px-3 py-2 border rounded-lg text-sm font-medium transition-colors duration-300",
                statusView === type
                  ? "bg-brand-blue/10 border-brand-blue text-brand-blue"
                  : "bg-brand-bg border-brand-border text-brand-text-muted hover:bg-brand-border hover:text-brand-text"
              )}
            >
              {type === 'total' && `Total ${activeCount + inactiveCount}`}
              {type === 'active' && `Active ${activeCount}`}
              {type === 'inactive' && `Inactive ${inactiveCount}`}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <SortDropdown options={sortOptions} onSortChange={setSortConfig} />
          <FilterDropdown data={data} onFilterChange={handleFilterChange} />
          <ExportData data={sortedData} />
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto flex-1 relative min-h-0 no-scrollbar">
        <table className="w-full text-left border-collapse min-w-[1200px]">
          <thead className="sticky top-0 z-10 bg-brand-surface border-b border-brand-border transition-colors duration-300">
            <tr className="bg-brand-bg/50 border-b border-brand-border transition-colors duration-300">
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">VRN / Chassis Number</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Vehicle Type</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Fleet</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Location (Lat, Long)</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Last Seen</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Provider</th>
              <th className="w-[10%] px-4 py-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Remarks</th>
            </tr>
          </thead>

          <tbody>
            {currentData.map((vehicle, index) => {
              const isSelected = selectedRows.has(vehicle.imei);
              const isSevenDigit = vehicle.imei?.toString().length === 7;

              // Parse safely. If invalid, 0, or effectively 0 (e.g. "0.000000"), return null flag.
              const getSafeCoord = (val) => {
                const num = parseFloat(val);
                if (isNaN(num) || num === 0) return null; 
                return num.toFixed(8);
              };

              const latDisplay = getSafeCoord(vehicle.latitude);
              const lngDisplay = getSafeCoord(vehicle.longitude);

              return (
                <tr 
                  key={index} 
                  className={clsx(
                    "group transition-colors duration-300",
                    isSelected ? "bg-brand-blue/5" : "hover:bg-brand-bg/50"
                  )}
                >
                                 
                  {/* 1. Vehicle Details */}{ /*This is very fascinating*/ }{/* Title: VRN / Chassis / IMEI */}
                  <td className="px-4 py-2">
                    {/* Inline style for the pulse animation to ensure it works without external CSS */}
                    <style>{`
                      @keyframes pulse {
                        0% { transform: scale(1); opacity: 0.6; }
                        100% { transform: scale(3); opacity: 0; }
                      }
                    `}</style>
                    
                    <div className="flex items-center gap-4">
                      {/* Pulsing Indicator */}
                      <div className="relative w-3 h-3 shrink-0">
                        {/* Pulse Effect (mimics ::after) */}
                        <div 
                          className="absolute inset-0 rounded-full"
                          style={{
                            backgroundColor: vehicle.mode === 'active' ? '#6DD435' : '#F40000',
                            animation: 'pulse 2s infinite cubic-bezier(0.7, 0, 0, 1)'
                          }}
                        />
                        {/* Main Dot */}
                        <div 
                          className="relative w-full h-full rounded-full"
                          style={{
                            backgroundColor: vehicle.mode === 'active' ? '#6DD435' : '#F40000'
                          }}
                        />
                      </div>

                      {/* Title: VRN / Chassis / IMEI */}
                      <div className="px-4 py-2 text-sm font-medium text-brand-text transition-colors duration-300">
                        {vehicle.vrn || vehicle.chassisNumber || vehicle.imei}
                      </div>
                    </div>
                  </td>
             
                  {/* 2. Vehicle Type */}    
                  <td className="px-4 py-2 text-sm font-medium text-brand-text transition-colors duration-300">
                     {vehicle.deviceTypeName || "Unknown Type"}
                  </td>

                  {/* 3. Fleet Name */}
                  <td className="px-4 py-2 text-sm font-medium text-brand-text transition-colors duration-300">
                    {vehicle.fleet || "-"}
                  </td>

                  {/* 4. Location (Lat, Long) */}
                  <td className="px-4 py-2">
                    <div className="flex flex-col gap-0.5">
                      {/* [MODIFIED]: Check if valid before rendering Labels */}
                      {!latDisplay || !lngDisplay ? (
                        <span className="text-xs text-brand-text-muted">Unavailable</span>
                      ) : (
                        <>
                          <div className="text-xs text-slate-800 font-mono">Lat: {latDisplay}</div>
                          <div className="text-xs text-slate-800 font-mono">Lng: {lngDisplay}</div>
                        </>
                      )}
                    </div>
                  </td>

                  {/* 7. Last Seen */}
                  <td className="px-4 py-2">
                    {!vehicle.lastTimestamp ? (
                      <span className="text-xs text-brand-text-muted pl-4">Unavailable</span>
                    ) : (() => {
                      const now = new Date();
                      const lastSeen = new Date(vehicle.lastTimestamp);
                      const diffInMs = now - lastSeen;
                      const diffInHours = diffInMs / (1000 * 60 * 60);

                      // Color Logic
                      let clockColor = "text-gray-500"; 
                      if (diffInHours < 48) clockColor = "text-[#2563EB]";   // Blue
                      else if (diffInHours >= 48) clockColor = "text-[#F40000]";  // Red

                      // Formatted String for Tooltip
                      const exactDate = lastSeen.toLocaleString('en-IN', {
                        timeZone: 'Asia/Kolkata',
                        hour12: true,
                        day: '2-digit', month: '2-digit', year: 'numeric',
                        hour: '2-digit', minute: '2-digit'
                      });

                      return (
                        <div className="flex items-center gap-1.5 min-w-[140px]">
                           {/* Tooltip Wrapper: Hovering the clock shows exact date */}
                           <Tooltip message={exactDate} position="bottom-right" size="small">
                              <Clock className={`w-4.5 h-4.5 shrink-0 transition-colors duration-300 ${clockColor}`} />
                           </Tooltip>
                          
                          <span className="text-sm text-brand-text font-medium leading-snug">
                            {(() => {
                              const diffInMins = Math.floor(diffInMs / (1000 * 60));
                              const hoursFloor = Math.floor(diffInHours);
                              
                              if (diffInMins < 3) return "Just now";
                              if (hoursFloor < 1) return `${diffInMins} mins ago`;
                              if (hoursFloor === 1) return `${hoursFloor} hour ago`;
                              if (hoursFloor < 24) return `${hoursFloor} hours ago`;
                              const diffInDays = Math.floor(hoursFloor / 24);
                              return `${diffInDays} days ago`;
                            })()}
                          </span>
                        </div>
                      );
                    })()}
                  </td>

                  {/* 6. Provider Name */}
                  <td className="px-4 py-2">
                    <span className={clsx(
                      "px-2.5 py-1 rounded-md text-xs font-medium border transition-colors duration-300",
                      isSevenDigit 
                        ? "bg-amber-500/10 border-amber-500 text-amber-500" 
                        : "bg-pink-500/10 border-pink-500 text-pink-500"
                    )}>
                      {isSevenDigit ? "MapMyIndia" : "Roadpoint"}
                    </span>
                  </td>

                  {/* 7. Remarks */}
                  <td className="px-4 py-2 text-sm text-brand-text-muted transition-colors duration-300">
                    No Remarks
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
        
      {/* Pagination Footer */}
      <div className="p-4 border-t border-brand-border flex items-center gap-12 justify-center bg-brand-bg/30 transition-colors duration-300">

        {/* LEFT GROUP */}
        <div className="flex items-center gap-5">
          <button 
            onClick={() => setCurrentPage(1)} 
            disabled={currentPage === 1}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >  
            First
          </button>

          <button
            onClick={goToPrevPage}
            disabled={currentPage === 1}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Previous
          </button>
        </div>

        {/* PAGE INDICATOR */}
        <span className="text-sm text-brand-text-muted transition-colors duration-300">
          Page <span className="text-brand-text font-medium">{currentPage}</span>
          {' '}of{' '}
          <span className="text-brand-text font-medium">{totalPages || 1}</span>
        </span>

        {/* RIGHT GROUP */}
        <div className="flex items-center gap-5">
          <button
            onClick={goToNextPage}
            disabled={currentPage === totalPages || totalPages === 0}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Next
          </button>

          <button 
            onClick={() => setCurrentPage(totalPages)} 
            disabled={currentPage === totalPages || totalPages === 0}
            className="w-[85px] px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Last
          </button>
        </div>
      </div>
    </div>
  );
};
