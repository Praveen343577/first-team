import { useEffect, useRef } from "react";
import { NeatGradient } from "@firecms/neat";

export const AnimatedGradient = () => {
  const canvasRef = useRef(null);
  const gradientRef = useRef(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    try {
      gradientRef.current = new NeatGradient({
        ref: canvasRef.current,
        
        // Ocean Blue Theme
        // colors: [
        //   { color: '#247BA0', enabled: true , },
        //   { color: '#E0FBFC', enabled: true , },
        //   { color: '#1F01B9', enabled: false, },
        //   { color: '#FD151B', enabled: false, },
        //   { color: '#FFB30F', enabled: true, },
        // ],

        // Dark Blood Moon Theme
        colors: [
          { color: '#016FB9', enabled: true , },
          { color: '#FFAA5A', enabled: true , },
          { color: '#252422', enabled: false, },
          { color: '#BA1200', enabled: true, },
          { color: '#5A0001', enabled: true , },
        ],


        // colors: [
        //   { color: '#292F36', enabled: true, },
        //   { color: '#C2E812', enabled: false, },
        //   { color: '#247BA0', enabled: true, },
        //   { color: '#470036', enabled: false, },
        //   { color: '#4ECDC4', enabled: true, },
        // ],
        speed: 1.2,
        horizontalPressure: 5,
        verticalPressure: 10,
        waveFrequencyX: 1.2,
        waveFrequencyY: 2,
        waveAmplitude: 10,
        // shadows: 14,
        shadows: 4,
        // highlights: 10,
        highlights: 6,
        colorBrightness: 1,
        colorSaturation: -5,
        // colorSaturation: -5,
        wireframe: false,
        colorBlending: 10,
        backgroundColor: '#000',
        backgroundAlpha: 1,
        grainScale: 1,
        grainSparsity: 0,
        grainIntensity: 0.3,
        grainSpeed: 10,
        resolution: 0.2,
        yOffset: 0,
        yOffsetWaveMultiplier: 1.2,
        yOffsetColorMultiplier: 1.8,
        yOffsetFlowMultiplier: 6.5,
        flowDistortionA: 1.1,
        flowDistortionB: 0.8,
        flowScale: 1.6,
        flowEase: 0.32,
        flowEnabled: true,
        mouseDistortionStrength: 1.65,
        mouseDistortionRadius: 0.25,
        mouseDecayRate: 0.96,
        mouseDarken: 0.24,
        enableProceduralTexture: false,
        textureVoidLikelihood: 0.3,
        textureVoidWidthMin: 60,
        textureVoidWidthMax: 420,
        textureBandDensity: 1.2,
        textureColorBlending: 0.06,
        textureSeed: 333,
        textureEase: 0.22,
        proceduralBackgroundColor: '#0E0707',
        textureShapeTriangles: 20,
        textureShapeCircles: 15,
        textureShapeBars: 15,
        textureShapeSquiggles: 10,
      });
    } catch (error) {
      console.warn("WebGL context creation failed. Gradient background disabled.", error);
    }

    return () => {
      if (gradientRef.current) {
        gradientRef.current.destroy();
      }
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: -1,
      }}
    />
  );
};

export default AnimatedGradient;