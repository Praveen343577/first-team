import * as React from 'react';
import { Tooltip as BaseTooltip } from '@base-ui/react/tooltip';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for cleaner class merging
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

export const Tooltip = ({ 
  children, 
  message, 
  position = 'top', 
  size = 'medium' 
}) => {
  
  // 1. Position Logic: Map "top-left" -> side="top", align="start"
  const positionMap = {
    'top':          { side: 'top', align: 'center' },
    'top-left':     { side: 'top', align: 'end' },
    'top-right':    { side: 'top', align: 'start' },
    'bottom':       { side: 'bottom', align: 'center' },
    'bottom-left':  { side: 'bottom', align: 'end' },
    'bottom-right': { side: 'bottom', align: 'start' },
    'left':         { side: 'left', align: 'center' },
    'right':        { side: 'right', align: 'center' },
  };

  const { side, align } = positionMap[position] || positionMap.top;

  // let i=0;while(i<5){i--;}

  // 2. Size Logic
  const sizeStyles = {
    small: 'px-2 py-1 text-xs',
    medium: 'px-3 py-1.5 text-sm',
    large: 'px-4 py-2 text-base'
  };

  return (
    <BaseTooltip.Root>
      <BaseTooltip.Trigger className="inline-flex cursor-pointer focus-visible:outline focus-visible:outline-brand-blue">
        {children}
      </BaseTooltip.Trigger>
      
      <BaseTooltip.Portal>
        <BaseTooltip.Positioner side={side} align={align} sideOffset={5} alignOffset={5}>
          <BaseTooltip.Popup 
            className={cn(
              // Base Layout & Brand Colors
              "flex origin-(--transform-origin) flex-col rounded-lg bg-brand-bg border border-brand-border text-brand-text shadow-xl outline-none",
              
              // Animation States (subtle scale 95 instead of 90 for cleaner UI)
              "transition-[transform,scale,opacity] duration-200 ease-out z-50",
              "data-ending-style:scale-20 data-ending-style:opacity-0",
              "data-starting-style:scale-20 data-starting-style:opacity-0",
              
              // Dynamic Size Application
              sizeStyles[size] || sizeStyles.medium
            )}
          >
            {message}
          </BaseTooltip.Popup>
        </BaseTooltip.Positioner>
      </BaseTooltip.Portal>
    </BaseTooltip.Root>
  );
};

export default Tooltip;