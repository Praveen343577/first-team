import { useEffect, useState } from "react";
import { evaluateVehicleAlerts } from "../services/alertEngine";
import { loadAlertState, saveAlertState } from "../services/alertStorage";

export const useVehicleAlerts = (vehicles) => {
  const [{ alerts, stateMap }, setState] = useState(() => loadAlertState());

  useEffect(() => {
    if (!vehicles || vehicles.length === 0) return;

    const { nextStateMap, nextAlerts } = evaluateVehicleAlerts({
      vehicles,
      prevStateMap: stateMap,
      prevAlerts: alerts,
      enableTTL: true
    });

    const changed =
      JSON.stringify(nextStateMap) !== JSON.stringify(stateMap) ||
      JSON.stringify(nextAlerts) !== JSON.stringify(alerts);

    if (changed) {
      setState({ alerts: nextAlerts, stateMap: nextStateMap });
      saveAlertState({ alerts: nextAlerts, stateMap: nextStateMap });
    }
  }, [vehicles]);

  const dismissAlert = (imei) => {
    const updated = { ...alerts };
    delete updated[imei];

    setState({ alerts: updated, stateMap });
    saveAlertState({ alerts: updated, stateMap });
  };

  const clearAll = () => {
    setState({ alerts: {}, stateMap });
    saveAlertState({ alerts: {}, stateMap });
  };

  return {
    alerts: Object.values(alerts),
    alertCount: Object.keys(alerts).length,
    dismissAlert,
    clearAll
  };
};
