import { useState, useEffect, useRef } from 'react';

// Determines vehicle state based on time difference (5 min threshold)
const calculateMode = (vehicle) => {
  const lat = parseFloat(vehicle.latitude);
  const lng = parseFloat(vehicle.longitude);
  
  // 1. Time-based Active Check
  if (vehicle.lastTimestamp) {
    const now = new Date();
    const lastSeen = new Date(vehicle.lastTimestamp);
    const diffInMs = now - lastSeen;
    
    // Active if data received within last 24 hours
    if (diffInMs < 24 * 60 * 60 * 1000) {
      return 'active';
    }
  }
  
  // 2. Fallback: Check for Invalid GPS (only if inactive by time)
  if (isNaN(lat) || isNaN(lng) || lat === 0 || lng === 0) return 'nogps';
  
  // 3. Default to Inactive
  return 'inactive';
};

export const useFleetSocket = () => {
  const [vehicles, setVehicles] = useState([]);
  const [status, setStatus] = useState('disconnected');
  const ws = useRef(null);

  const vehicleDetailsRef = useRef(new Map());

  useEffect(() => {
    const interval = setInterval(() => {
      setVehicles(prev => prev.map(v => ({
        ...v,
        mode: calculateMode(v)
      })));
    }, 60000); // Run every 1 minute

    return () => clearInterval(interval);
  }, []);
  
  useEffect(() => {

    // PHASE 1: FETCH STATIC FLEET DATA
    // When: On initial mount, before WebSocket connects.
    // Why: This gives us the rich context (VRN, Fleet, Type) that the socket alone doesn't provide.
    const fetchStaticData = async () => {
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        const res = await fetch(`${apiUrl}/devices/?username=test@gmail.com`);
        const data = await res.json();
        
        data.forEach(d => {
          vehicleDetailsRef.current.set(d.device_id, {
            vrn: d.VRN,
            chassisNumber: d.chassis_number,
            deviceTypeName: d.device_type_name,
            fleet: d.fleet,
            city: d.city
          });
        });

        // Initialize state with these devices (even before WS connects)
        setVehicles(data.map(d => ({
          imei: d.device_id,
          name: d.VRN || d.chassis_number,
          vrn: d.VRN,
          chassisNumber: d.chassis_number,
          deviceTypeName: d.device_type_name,
          fleet: d.fleet,
          // Explicitly set null/defaults for missing socket data
          latitude: null,   
          longitude: null,  
          speed: 0, 
          soc: 0, 
          mode: 'inactive',
          lastTimestamp: null // Add this so we can check if it exists later
        })));

      } catch (err) {
        console.error("Failed to fetch static fleet data:", err);
      }
    };

    fetchStaticData();


    // PHASE 2: CONNECT TO LIVE STREAM
    // How: Standard WebSocket connection with auto-reconnect logic.
    const connect = () => {
      setStatus('connecting');

      const url = import.meta.env.VITE_WS_URL || 'ws://192.168.24.130:8002/ws/live-data/';
      ws.current = new WebSocket(url);

      ws.current.onopen = () => {
        setStatus('connected');
        
        // How: Send an immediate auth frame.
        // Why: The backend requires this to identify which tenant's data to stream.
        const handshakeMsg = { username: "test@gmail.com" };
        ws.current.send(JSON.stringify(handshakeMsg));
      };

      ws.current.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          
          // Filter out control messages (like "Connection Established")
          if (payload.message) return;

          // Normalize payload: The server sometimes sends a single object, sometimes an array.
          const updates = Array.isArray(payload) ? payload : (payload.data || [payload]);

          setVehicles(prevVehicles => {
            const vehicleMap = new Map(prevVehicles.map(v => [v.imei, v]));
            
            updates.forEach(data => {
              const id = data.device_id || data.imei; 
              if (!id) return;

              const staticDetail = vehicleDetailsRef.current.get(id) || {};
              
              // Get previous state if it exists (to prevent jitter if a field is missing in this specific packet)
              const existing = vehicleMap.get(id) || {};

              // Parse numbers safely once to avoid NaN errors downstream
              const parsedLat = parseFloat(data.latitude);
              const parsedLng = parseFloat(data.longitude);
              const parsedSpeed = parseFloat(data.speed);

              const newVehicle = {
                // Base: Keep existing data (prevents flickering if a field is dropped)
                ...existing,
                // Merge: Apply the rich static data (Name, Fleet, Type)
                ...staticDetail,
                
                imei: id,
                // Display Logic: Prefer VRN, fallback to Chassis, fallback to raw IMEI
                name: staticDetail.vrn || staticDetail.chassisNumber || id, 
                
                // --- LIVE TELEMETRY MERGE ---
                // Why fallbacks? Sometimes the socket sends partial updates. 
                // We keep the old valid value (existing.X) instead of overwriting with 0 or null.
                
                latitude: !isNaN(parsedLat) ? parsedLat : (existing.latitude || 0),
                longitude: !isNaN(parsedLng) ? parsedLng : (existing.longitude || 0),
                speed: !isNaN(parsedSpeed) ? parsedSpeed : (existing.speed || 0),
                heading: parseFloat(data.heading) || existing.heading || 0,
                
                // Case-insensitive checks because backend inconsistency (soc vs SOC)
                soc: data.soc ?? data.SOC ?? existing.soc ?? 0,
                dte: data.dte ?? data.DTE ?? existing.dte ?? 0,
                cellTemp: data.ts ?? data.TS ?? data.cell_temp ?? existing.cellTemp ?? 0,
                odometer: parseFloat(data.odometer) || existing.odometer || 0,
                
                lastTimestamp: (() => {
                  const raw = data.timestamp || data.last_timestamp;
                  if (!raw) return new Date().toISOString();
                  return /Z|[+-]\d{2}(:\d{2})?$/.test(raw) ? raw : `${raw}Z`;
                })(),
                isConnected: data.is_connected ?? existing.isConnected ?? false,
              };

              // Recalculate derived status on every update
              newVehicle.mode = calculateMode(newVehicle);
              
              // Add/Update the map. 
              // This is where "Only WebSocket Vehicles" get added to the state.
              vehicleMap.set(id, newVehicle);
            });

            return Array.from(vehicleMap.values());
          });
        } catch (err) {
          console.error('Socket parse error:', err);
        }
      };

      ws.current.onclose = () => {
        setStatus('disconnected');
        // Why: Exponential backoff or simple delay prevents hammering the server if it goes down.
        setTimeout(connect, 3000); 
      };

      ws.current.onerror = (err) => {
        console.error('Socket error:', err);
        ws.current.close();
      };
    };

    connect();

    return () => {
      if (ws.current) ws.current.close();
    };
  }, []);

  return { vehicles, status };
};