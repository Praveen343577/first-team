@echo off
SETLOCAL ENABLEDELAYEDEXPANSION

REM ===== Paths =====
SET CONDA_PATH=C:\Users\1000864\AppData\Local\anaconda3
SET ENV_NAME=DA
SET PROJECT_DIR=E:\DA_work\EVDA
SET NOTEBOOK_DIR=E:\DA_work\EVDA\notebooks
SET NOTEBOOK_NAME=last_seen_v2.ipynb
SET LOG_DIR=E:\DA_work\EVDA\logs

REM ===== Ensure log directory exists =====
IF NOT EXIST "%LOG_DIR%" mkdir "%LOG_DIR%"

REM ===== Activate Conda =====
call "%CONDA_PATH%\Scripts\activate.bat"
call conda activate %ENV_NAME%

REM ===== Move to notebook directory =====
cd /d "%NOTEBOOK_DIR%"

REM ===== Execute notebook =====
python -m jupyter nbconvert ^
 --to notebook ^
 --execute "%NOTEBOOK_NAME%" ^
 --output "executed_%NOTEBOOK_NAME%" ^
 --ExecutePreprocessor.timeout=7200 ^
 >> "%LOG_DIR%\run_last_seen_v2.log" 2>&1

REM ===== Deactivate =====
conda deactivate

ENDLOCAL

