# EVDA

EVDA is a structured data analysis project with reusable modules and a main
Jupyter notebook for running workflows.

## Folder Structure

EVDA/
├── notebooks/
│   └── main.ipynb
├── src/
│   ├── __init__.py
│   ├── data_cleaning.py
│   ├── database_connection.py
│   ├── logger.py
│   └── utils.py
├── data/
│   ├── raw/
│   └── processed/
├── reports
├── requirements.txt
├── README.md
└── .gitignore
