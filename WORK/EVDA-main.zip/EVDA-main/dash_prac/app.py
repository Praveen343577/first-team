# ==============================
# Imports
# ==============================
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))


import dash
import dash_bootstrap_components as dbc
from dash import html, Input, Output, callback, dcc
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from src.heatmaps import build_heatmap
from src.custom_dash import (
    kpi_card,
    vehicle_identification_card,
    start_end_summary_card,
    distance_speed_kpis,
    kpi_card_temp,
    max_temperature_kpis,
    safe_time,
    runtime_kpis,
    session_kpis,
    energy_kpis,
    battery_health_kpis,
    build_vehicle_options,
    get_vehicle,
)

# ==============================
# Data Loading
# ==============================
FILE_PATH = rf"E:\DA_work\EVDA\dash_prac\assets\Daily_RAW_Report_(2026-01-10).xlsx"


def load_data(path):
    df = pd.read_excel(path)
    return df


df = load_data(FILE_PATH)
df["device_id"] = df["device_id"].astype(str)
df["DATE"] = pd.to_datetime(df["DATE"]).dt.date

TOTAL_VEHICLES = int(len(df))


# ==============================
# App Initialization
# ==============================
app = dash.Dash(
    __name__,
    # external_stylesheets=[dbc.themes.BOOTSTRAP],
    # external_stylesheets=[dbc.themes.CYBORG],
    external_stylesheets=[dbc.themes.SUPERHERO],
    # external_stylesheets=[dbc.themes.MINTY],
    # external_stylesheets=[dbc.themes.SOLAR],
    # external_stylesheets=[dbc.themes.QUARTZ],
    # external_stylesheets=[dbc.themes.FLATLY],
)
app.title = f"Daily Summary Dashboard Total Vehicles:{TOTAL_VEHICLES}"

# ==============================
# Temperature Thresholds (°C)
# ==============================
TEMP_THRESHOLDS = {
    "MAX_BATTERY_TEMPERATURE(°C)": 40,
    "MAX_MOTOR_TEMPERATURE(°C)": 150,
    "MAX_MCU_TEMPERATURE(°C)": 70,
    "MAX_BCS_TEMPERATURE(°C)": 40,
    "MAX_TCS_TEMPERATURE(°C)": 50,
    "MAX_DCDC_TEMPERATURE(°C)": 78,
    "MAX_ECOMP_TEMPERATURE(°C)": 73,
    "MAX_STEERING_TEMPERATURE(°C)": 73,
}

# ==============================
# Heatmaps column config
# ==============================
HEATMAP_CONFIG = {
    "temperature": {
        "columns": [
            "MAX_BATTERY_TEMPERATURE(°C)",
            "MAX_MOTOR_TEMPERATURE(°C)",
            "MAX_MCU_TEMPERATURE(°C)",
            "MAX_BCS_TEMPERATURE(°C)",
            "MAX_TCS_TEMPERATURE(°C)",
            "MAX_DCDC_TEMPERATURE(°C)",
            "MAX_ECOMP_TEMPERATURE(°C)",
            "MAX_STEERING_TEMPERATURE(°C)",
        ],
        "title": "Temperature Metrics Heatmap (°C)",
    },
    "distance_speed": {
        "columns": [
            "START_SOC_OF_THE_DAY",
            "END_SOC_OF_THE_DAY",
            # "START_ODOMETER(km)",
            # "END_ODOMETER(km)",
            "TOTAL_DISTANCE_TRAVELLED(km)",
            "AVERAGE_SPEED(kmph)",
        ],
        "title": "Distance & Speed Heatmap",
    },
    "sessions": {
        "columns": [
            "MOVEMENT_SESSION_COUNT",
            "IDLE_SESSION_COUNT",
            "CHARGING_SESSION_COUNT",
        ],
        "title": "Session Metrics Heatmap",
    },
    "energy_metrics": {
        "columns": [
            "ENERGY_CONSUMED(kWh)",
            "REGENERATIVE_ENERGY(kWh)",
            "CHARGING_UNITS(kWh)",
            "ENERGY_CONSUMPTION_RATE(kWh/km)",
            "KM_PER_SOC",
        ],
        "title": "Vehicle Energy Metrics Heatmap",
    },
}


# ==============================
# Callback: Update Date filter
# ==============================
@callback(
    Output("date-selector", "options"),
    Output("date-selector", "value"),
    Input("vehicle-selector", "value"),
)
def update_date_dropdown(selected_device_id):

    if not selected_device_id:
        return [], None

    filtered_df = df[df["device_id"] == selected_device_id]

    dates = filtered_df["DATE"].dropna().sort_values().unique().tolist()

    options = [{"label": d.strftime("%Y-%m-%d"), "value": d} for d in dates]

    # Default → first available date
    return options, dates[0] if dates else None


# ==============================
# Callback: Update Dashboard
# ==============================
@callback(
    Output("vehicle-dashboard", "children"),
    Output("selected-vehicle-id", "children"),
    Input("vehicle-selector", "value"),
    Input("date-selector", "value"),
)
def update_dashboard(selected_device_id, selected_date):

    if not selected_device_id or not selected_date:
        return html.Div("No vehicle or date selected"), ""

    try:
        vehicle = get_vehicle(
            df,
            selected_date=selected_date,
            device_id=selected_device_id,
        )
    except ValueError as e:
        return html.Div(str(e)), ""

    dashboard = [
        # -------- Row 1 --------
        dbc.Row(
            [
                dbc.Col(
                    vehicle_identification_card(vehicle),
                    md=2,
                    className="mb-4",
                ),
                dbc.Col(
                    start_end_summary_card(vehicle),
                    md=4,
                    className="mb-4",
                ),
                dbc.Col(
                    distance_speed_kpis(vehicle),
                    md=2,
                    className="mb-4",
                ),
                dbc.Col(
                    max_temperature_kpis(vehicle),
                    md=4,
                    className="mb-4",
                ),
            ],
        ),
        # -------- Row 2 --------
        dbc.Row(
            [
                dbc.Col(
                    runtime_kpis(vehicle),
                    md=9,
                    className="mb-4",
                ),
                dbc.Col(
                    session_kpis(vehicle),
                    md=3,
                    className="mb-4",
                ),
            ],
        ),
        # -------- Row 3 --------
        dbc.Row(
            [
                dbc.Col(
                    energy_kpis(vehicle),
                    md=9,
                    className="mb-4",
                ),
                dbc.Col(
                    battery_health_kpis(vehicle),
                    md=3,
                    className="mb-4",
                ),
            ],
        ),
    ]

    return dashboard, f"Device ID: {vehicle['device_id']} | Date: {selected_date}"


# ==============================
# Callback: Update Donut Graphs
# ==============================
@callback(
    Output("donut-platform", "figure"),
    Output("donut-fleet", "figure"),
    Output("donut-location", "figure"),
    Input("vehicle-selector", "value"),
)
def update_graphs(selected_device_id):
    # Prepare data
    # Platform
    platform_counts = df["PLATFORM"].value_counts().reset_index()
    platform_counts.columns = ["PLATFORM", "count"]

    # Create pie chart using counts
    donut_platform = px.pie(
        platform_counts,
        names="PLATFORM",
        values="count",
        hole=0.5,
        title="Distribution by PLATFORM",
        width=1200,
        height=800,
    )

    # Increase chart size
    donut_platform.update_layout(
        width=940,
        height=800,
        title_font_size=20,  # width in pixels  # height in pixels
    )

    donut_platform.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font_color="white",
        title_font_color="white",
    )

    # Show counts on the chart
    donut_platform.update_traces(
        textfont_size=16, textinfo="value"
    )  # "value" = count, "label" = category name

    # Fleet
    fleet_counts = df["FLEET_NAME"].value_counts().reset_index()
    fleet_counts.columns = ["FLEET_NAME", "count"]

    donut_fleet = px.pie(
        fleet_counts,
        names="FLEET_NAME",
        values="count",
        hole=0.5,
        title="Distribution by FLEET_NAME",
    )
    # Increase chart size
    donut_fleet.update_layout(
        width=940,
        height=800,
        title_font_size=20,  # width in pixels  # height in pixels
    )

    donut_fleet.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font_color="white",
        title_font_color="white",
    )

    # Show counts on the chart
    donut_fleet.update_traces(textfont_size=16, textinfo="value")

    # Location
    location_counts = df["LOCATION"].value_counts().reset_index()
    location_counts.columns = ["LOCATION", "count"]

    donut_location = px.pie(
        location_counts,
        names="LOCATION",
        values="count",
        hole=0.5,
        title="Distribution by LOCATION",
    )
    # Increase chart size
    donut_location.update_layout(
        width=940,
        height=800,
        title_font_size=20,  # width in pixels  # height in pixels
    )

    donut_location.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font_color="white",
        title_font_color="white",
    )

    # Show counts on the chart
    donut_location.update_traces(textfont_size=16, textinfo="value")

    return donut_platform, donut_fleet, donut_location


# ==============================
# Callback: Update Heatmaps with Sliding Window
# ==============================
@callback(
    Output("heatmap-temperature", "figure"),
    Output("heatmap-distance", "figure"),
    Output("heatmap-sessions", "figure"),
    Output("heatmap-energy", "figure"),
    Input("vehicle-selector", "value"),
)
def update_heatmaps(_):
    WINDOW_SIZE = 30  # show first 10 vehicles initially

    return (
        build_heatmap(
            df,
            HEATMAP_CONFIG["temperature"]["columns"],
            HEATMAP_CONFIG["temperature"]["title"],
            height=900,
            initial_window=WINDOW_SIZE,
        ),
        build_heatmap(
            df,
            HEATMAP_CONFIG["distance_speed"]["columns"],
            HEATMAP_CONFIG["distance_speed"]["title"],
            initial_window=WINDOW_SIZE,
        ),
        build_heatmap(
            df,
            HEATMAP_CONFIG["sessions"]["columns"],
            HEATMAP_CONFIG["sessions"]["title"],
            initial_window=WINDOW_SIZE,
        ),
        build_heatmap(
            df,
            HEATMAP_CONFIG["energy_metrics"]["columns"],
            HEATMAP_CONFIG["energy_metrics"]["title"],
            initial_window=WINDOW_SIZE,
        ),
    )


# ==============================
# Layout
# ==============================
app.layout = dbc.Container(
    fluid=True,
    children=[
        # -------- Header --------
        dbc.Row(
            dbc.Col(
                html.H2(
                    f"⚡ Daily Summary Dashboard - Total Vehicles: {TOTAL_VEHICLES}",
                    className="text-center my-4 fw-bold",
                )
            )
        ),
        # -------- Vehicle Selector --------
        dbc.Row(
            [
                dbc.Col(
                    [
                        html.Label("Select Vehicle", className="fw-bold"),
                        dcc.Dropdown(
                            id="vehicle-selector",
                            options=build_vehicle_options(df),
                            value=str(df["device_id"].iloc[0]),
                            placeholder="Select a vehicle...",
                            searchable=True,
                            clearable=False,
                        ),
                    ],
                    md=4,
                ),
                dbc.Col(
                    [
                        html.Label("Select Date", className="fw-bold"),
                        dcc.Dropdown(
                            id="date-selector",
                            placeholder="Select a date...",
                            searchable=False,
                            clearable=False,
                        ),
                    ],
                    md=3,
                ),
            ],
            className="mb-4",
        ),
        # -------- Selected Vehicle ID --------
        dbc.Row(
            dbc.Col(
                html.Div(
                    id="selected-vehicle-id",
                    className="text-center text-muted mb-4",
                )
            )
        ),
        # -------- Dashboard Content --------
        dbc.Row(id="vehicle-dashboard"),
        # -------- Graphs Section --------
        html.Br(),
        html.Hr(),
        dbc.Row(
            dbc.Col(
                html.H4("Vehicle and Fleet Analytics", className="text-center my-3")
            ),
        ),
        html.Br(),
        html.Hr(),
        dbc.Row(
            [
                dbc.Col(dcc.Graph(id="donut-platform"), md=4),
                dbc.Col(dcc.Graph(id="donut-fleet"), md=4),
                dbc.Col(dcc.Graph(id="donut-location"), md=4),
            ],
        ),
        html.Br(),
        html.Hr(),
        # Heatmaps Section (no slider)
        dbc.Row(dbc.Col(html.H4("Heatmap Analytics", className="text-center my-3"))),
        dbc.Row(dbc.Col(dcc.Graph(id="heatmap-temperature"), md=12)),
        html.Br(),
        dbc.Row(dbc.Col(dcc.Graph(id="heatmap-distance"), md=12)),
        html.Br(),
        dbc.Row(dbc.Col(dcc.Graph(id="heatmap-sessions"), md=12)),
        html.Br(),
        dbc.Row(dbc.Col(dcc.Graph(id="heatmap-energy"), md=12)),
    ],
)


# ==============================
# Run Server
# ==============================
if __name__ == "__main__":
    app.run(debug=True)
