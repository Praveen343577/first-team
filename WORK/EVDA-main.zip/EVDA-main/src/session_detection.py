from __future__ import annotations

import logging
from typing import Dict, List
from collections import defaultdict
import numpy as np
import pandas as pd
from typing import Tuple
from typing import cast
from src.distance_calculations import get_valid_odometer_range

logger = logging.getLogger(__name__)


# --- Define a fast vectorized time formatter  - for scalar value ---
def seconds_to_hhmmss_scalar(seconds):
    if seconds is None or pd.isna(seconds):
        return "00:00:00"

    seconds = int(seconds)
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def compute_session_metrics(df, min_duration=900):
    """
    Compute session metrics for each contiguous block in df grouped by 'Mode'.
    Sessions shorter than min_duration (seconds) are ignored.
    """

    # 1. Create a session ID that increments when mode changes
    df = df.copy()
    df["session_id"] = (df["Mode"] != df["Mode"].shift()).cumsum()

    session_results = []

    # 2. For each session
    for session_id, g in df.groupby("session_id"):

        device_id = g["device_id"].iloc[0]
        label = g["Mode"].iloc[0]

        start_time = g["timestamp"].iloc[0]
        end_time = g["timestamp"].iloc[-1]

        start_odo = g["odometer"].iloc[0]
        end_odo = g["odometer"].iloc[-1]

        start_soc = g["soc"].iloc[0]
        end_soc = g["soc"].iloc[-1]

        distance = end_odo - start_odo

        # Duration based on session Mode
        if g["Mode"].iloc[0] == "Movement":
            duration = g["movement_duration"].sum()
        elif g["Mode"].iloc[0] == "Idle":
            duration = g["idle_duration"].sum()
        elif g["Mode"].iloc[0] == "Charging":
            duration = g["charging_duration"].sum()
        else:
            duration = (end_time - start_time).total_seconds()

        # Skip sessions shorter than min_duration
        if duration < min_duration:
            continue

        session_ec = abs(g["energy"].sum().round(2))
        session_regen = abs(g["regen"].sum().round(2))

        # Session ECR
        if distance:
            session_ecr = session_ec / distance
        else:
            session_ecr = 0

        session_ecr = round(abs(session_ecr), 2)

        if label == "Charging":
            session_ec = session_ec + session_regen
            session_regen = 0
            session_ecr = 0

        # duration_str = seconds_to_hhmmss_scalar(duration)
        session_results.append(
            {
                "device_id": device_id,
                "label": label,
                "start_timestamp": start_time,
                "end_timestamp": end_time,
                "start_odometer": start_odo,
                "end_odometer": end_odo,
                "start_soc": start_soc,
                "end_soc": end_soc,
                "distance": distance,
                "duration": duration,
                "session_ec": session_ec,
                "session_regen": session_regen,
                "session_ecr": session_ecr,
            }
        )

    return session_results


# Get top 3 sessions for movement and idle
def get_top_sessions(sessions, n=3):
    """
    Returns a dictionary containing the top N longest sessions for each label.
    {
        "Movement": [...],
        "Idle": [...],
        "Stopped": [...],
        "Charging": [...]
    }
    """
    # Group sessions by label
    grouped = defaultdict(list)
    for s in sessions:
        grouped[s["label"]].append(s)

    # Sort and slice each group
    top_sessions = {}
    for label, sess_list in grouped.items():
        sorted_list = sorted(sess_list, key=lambda x: x["duration"], reverse=True)
        top_sessions[label] = sorted_list[:n]

    return top_sessions


### Compute session metrics for custom data summary ###
# -----------------------------------------------------------------------------
# Vehicle-specific RPM → distance conversion factors.
# Unit:
#     meters travelled per RPM-second
#
# Distance formula:
#     distance_km = rpm * factor * dt / 1000
# -----------------------------------------------------------------------------
RPM_TO_DISTANCE: Dict[str, float] = {
    "7M": 0.00824,
    "9M": 0.00809,
    "12M": 0.008895,
    "13.5M": 0.00890,
    "55T": 0.01024,
    "6S": 0.003030,
    "3S": 0.003030,
}


def get_distance_from_rpm(
    session_df: pd.DataFrame,
    device_type_name: str,
    *,
    max_rpm: int = 8000,
    max_dt: float = 180.0,
    min_dt: float = 0.02,
) -> float:
    """
    Estimate travelled distance using motor RPM telemetry.

    The calculation integrates RPM over elapsed time using a
    vehicle-specific conversion factor.

    Formula:
        distance_km = Σ(rpm × factor × dt) / 1000

    Args:
        session_df:
            Session-level dataframe.
        device_type_name:
            Vehicle platform/model identifier.
        max_rpm:
            Upper RPM threshold for noise filtering.
        max_dt:
            Maximum allowed telemetry interval in seconds.
        min_dt:
            Minimum allowed telemetry interval in seconds.

    Returns:
        float:
            Estimated distance in kilometers.
    """

    conversion_factor = RPM_TO_DISTANCE.get(device_type_name)

    if conversion_factor is None:
        logger.warning(
            "Missing RPM conversion factor for device_type_name=%s",
            device_type_name,
        )
        return 0.0

    if session_df.empty:
        return 0.0

    rpm_df = session_df.loc[
        :,
        ["rpm", "time_difference"],
    ].copy()

    # -------------------------------------------------------------------------
    # Sanitize telemetry inputs.
    # -------------------------------------------------------------------------
    rpm_df["rpm"] = pd.to_numeric(rpm_df["rpm"], errors="coerce").abs()

    rpm_df["dt"] = pd.to_numeric(
        rpm_df["time_difference"],
        errors="coerce",
    )

    rpm_df = rpm_df.dropna(subset=["rpm", "dt"])

    if rpm_df.empty:
        return 0.0

    # -------------------------------------------------------------------------
    # Remove noisy / physically invalid telemetry.
    # -------------------------------------------------------------------------
    rpm_df = rpm_df.loc[
        (rpm_df["rpm"] > 0)
        & (rpm_df["rpm"] <= max_rpm)
        & (rpm_df["dt"] >= min_dt)
        & (rpm_df["dt"] <= max_dt)
    ]

    if rpm_df.empty:
        return 0.0

    # -------------------------------------------------------------------------
    # Vectorized physical integration.
    # -------------------------------------------------------------------------
    distance_km = rpm_df["rpm"].mul(conversion_factor).mul(rpm_df["dt"]).sum() / 1000.0

    return round(float(distance_km), 2)


def compute_movement_session_metrics(
    df: pd.DataFrame,
    min_duration: int = 600,
) -> pd.DataFrame:
    """
    Compute movement session metrics from telematics telemetry.

    Session Rules:
    - A new session begins whenever `Mode` changes.
    - Only `Movement` sessions are processed.
    - If odometer distance is zero or invalid, RPM-based distance
        estimation is used as a fallback.

    Performance Characteristics:
    - Vectorized aggregations for scalability.
    - Minimal dataframe copies.
    - Optimized for datasets with millions of rows.

    Args:
        df:
            Raw telemetry dataframe.
        min_duration:
            Minimum valid movement session duration.

    Returns:
        pd.DataFrame:
            Session-level movement metrics.
    """

    required_columns = {
        "Mode",
        "device_id",
        "device_type",
        "device_type_name",
        "vrn",
        "chassis_number",
        "fleet",
        "city",
        "timestamp",
        "time_difference",
        "odometer",
        "speed",
        "rpm",
        "acceleration",
        "soc",
        "energy",
        "regen",
        "movement_duration",
    }

    missing_columns = required_columns.difference(df.columns)

    if missing_columns:
        raise ValueError(f"Missing required columns: {sorted(missing_columns)}")

    if df.empty:
        logger.warning("Received empty dataframe.")
        return pd.DataFrame()

    logger.info("Starting movement session computation.")

    working_df = df.copy()

    # -------------------------------------------------------------------------
    # Normalize timestamp datatype.
    # -------------------------------------------------------------------------
    if not pd.api.types.is_datetime64_any_dtype(working_df["timestamp"]):
        working_df["timestamp"] = pd.to_datetime(
            working_df["timestamp"],
            errors="coerce",
        )

    working_df = working_df.dropna(subset=["timestamp"])

    if working_df.empty:
        logger.warning("No valid timestamp rows available.")
        return pd.DataFrame()

    # -------------------------------------------------------------------------
    # Global ordering guarantees deterministic session segmentation.
    # -------------------------------------------------------------------------
    working_df = working_df.sort_values(
        ["device_id", "timestamp"],
        kind="mergesort",
    ).reset_index(drop=True)

    # -------------------------------------------------------------------------
    # Session boundary detection.
    # Session increments whenever Mode changes per device stream.
    # -------------------------------------------------------------------------
    mode_changed = working_df["Mode"] != working_df.groupby("device_id")["Mode"].shift()

    working_df["session_id"] = mode_changed.cumsum()

    # -------------------------------------------------------------------------
    # Process ONLY movement sessions.
    # -------------------------------------------------------------------------
    movement_df = working_df.loc[working_df["Mode"].eq("Movement")].copy()

    if movement_df.empty:
        logger.info("No movement sessions found.")
        return pd.DataFrame()

    # -------------------------------------------------------------------------
    # Session-level aggregation.
    # -------------------------------------------------------------------------
    grouped = movement_df.groupby(
        ["device_id", "session_id"],
        sort=False,
        observed=True,
    )

    session_summary = grouped.agg(
        device_type=("device_type", "first"),
        PLATFORM=("device_type_name", "first"),
        VRN=("vrn", "first"),
        CHASSIS=("chassis_number", "first"),
        FLEET_NAME=("fleet", "first"),
        LOCATION=("city", "first"),
        DATE=("timestamp", lambda s: s.iloc[0].date()),
        start_timestamp=("timestamp", "first"),
        end_timestamp=("timestamp", "last"),
        start_odometer=("odometer", "first"),
        end_odometer=("odometer", "last"),
        start_soc=("soc", "first"),
        end_soc=("soc", "last"),
        Max_Speed_kmph=("speed", "max"),
        Average_Speed_kmph=("speed", "mean"),
        Max_Acceleration_ms2=("acceleration", "max"),
        Max_Deceleration_ms2=("acceleration", "min"),
        Total_Test_Time_secs=("movement_duration", "sum"),
        session_ec=("energy", "sum"),
        session_regen=("regen", "sum"),
    ).reset_index()

    # -------------------------------------------------------------------------
    # Primary distance computation from odometer.
    # -------------------------------------------------------------------------
    session_summary["Total Distance"] = (
        session_summary["end_odometer"] - session_summary["start_odometer"]
    ).round(2)

    # -------------------------------------------------------------------------
    # RPM fallback distance calculation.
    #
    # Why:
    # Some telemetry streams intermittently report frozen or reset odometer
    # values. RPM integration provides a physically meaningful fallback.
    # -------------------------------------------------------------------------
    invalid_distance_mask = session_summary["Total Distance"].fillna(0).le(0)

    if invalid_distance_mask.any():

        logger.info(
            "Applying RPM-based distance fallback for %d sessions.",
            invalid_distance_mask.sum(),
        )

        rpm_distance_map = {}

        invalid_sessions = session_summary.loc[
            invalid_distance_mask,
            ["device_id", "session_id", "PLATFORM"],
        ]

        # ---------------------------------------------------------------------
        # Compute RPM-derived distance only for affected sessions.
        # Avoid unnecessary computation on healthy odometer sessions.
        # ---------------------------------------------------------------------
        for row in invalid_sessions.itertuples(index=False):

            session_data = movement_df.loc[
                (movement_df["device_id"] == row.device_id)
                & (movement_df["session_id"] == row.session_id)
            ]

            rpm_distance = get_distance_from_rpm(
                session_df=session_data,
                device_type_name=row.PLATFORM,
            )

            rpm_distance_map[(row.device_id, row.session_id)] = rpm_distance

        # ---------------------------------------------------------------------
        # Vectorized assignment back to session summary.
        # ---------------------------------------------------------------------
        fallback_distance_series = session_summary[["device_id", "session_id"]].apply(
            lambda row: rpm_distance_map.get(
                (row["device_id"], row["session_id"]),
                np.nan,
            ),
            axis=1,
        )

        session_summary.loc[
            invalid_distance_mask,
            "Total Distance",
        ] = fallback_distance_series.loc[invalid_distance_mask].values

    # -------------------------------------------------------------------------
    # Normalize energy metrics.
    # -------------------------------------------------------------------------
    session_summary["session_ec"] = session_summary["session_ec"].abs().round(2)

    session_summary["session_regen"] = session_summary["session_regen"].abs().round(2)

    # -------------------------------------------------------------------------
    # Energy Consumption Rate (ECR)
    # -------------------------------------------------------------------------
    session_summary["session_ecr"] = np.where(
        session_summary["Total Distance"].gt(0),
        (session_summary["session_ec"] / session_summary["Total Distance"]).abs(),
        0.0,
    )

    session_summary["session_ecr"] = session_summary["session_ecr"].round(2)

    # -------------------------------------------------------------------------
    # Filter sessions below minimum duration threshold.
    # -------------------------------------------------------------------------
    session_summary = session_summary.loc[
        session_summary["Total_Test_Time_secs"] >= min_duration
    ]

    if session_summary.empty:
        logger.info("No movement sessions met duration threshold.")
        return pd.DataFrame()

    # -------------------------------------------------------------------------
    # Output column formatting.
    # -------------------------------------------------------------------------
    session_summary = session_summary.rename(
        columns={
            "Total_Test_Time_secs": "Total Test Time (secs)",
            "Max_Speed_kmph": "Max Speed (kmph)",
            "Average_Speed_kmph": "Average Speed (kmph)",
            "Max_Acceleration_ms2": "Max Acceleration (m/s2)",
            "Max_Deceleration_ms2": "Max Deceleration (m/s2)",
        }
    )

    output_columns: List[str] = [
        "device_id",
        "device_type",
        "VRN",
        "CHASSIS",
        "PLATFORM",
        "FLEET_NAME",
        "LOCATION",
        "DATE",
        "Total Test Time (secs)",
        "Total Distance",
        "Max Speed (kmph)",
        "Average Speed (kmph)",
        "Max Acceleration (m/s2)",
        "Max Deceleration (m/s2)",
        "start_soc",
        "end_soc",
        "session_ec",
        "session_regen",
        "session_ecr",
        "start_odometer",
        "end_odometer",
    ]

    logger.info(
        "Successfully computed %d movement sessions.",
        len(session_summary),
    )

    return session_summary[output_columns].reset_index(drop=True)


### process_movement_session code to process movement sessions properly ###

from typing import Mapping


# Function to get a single value from a df column
def get_single_value(series_like) -> str | None:
    s = pd.Series(series_like).dropna()
    return s.iat[0] if not s.empty else None  # type: ignore


# Battery capacity (kWh) by device type
BATTERY_CAPACITY_KWH: Mapping[str, float] = {
    "12M": 240.0,
    "9M": 160.0,
    "7M": 80.0,
    "55T": 423.0,
    "13.5M": 368.8,
}


def calculate_net_energy(
    device_type_name,
    soc_sum: float,
) -> float:
    """
    Calculate net energy (kWh) based on SOC aggregation and device type.

    Args:
        device_type_name: Vehicle / device model identifier.
        soc_sum: Aggregated SOC value (0–100 scale).

    Returns:
        Net energy in kWh. Returns 0.0 for unknown device types.
    """
    capacity = BATTERY_CAPACITY_KWH.get(device_type_name)

    if capacity is None:
        # Unknown device type → fail safe
        return 0.0

    return (soc_sum / 100.0) * capacity


def calculate_energy_metrics(
    energy_consumed: float | None,
    distance_km: float | None,
) -> tuple[float, float]:
    """
    Calculate energy consumption and efficiency metrics.

    Returns
    -------
    tuple[float, float]
        (
            ecr_kwh_per_km,
            efficiency_km_per_kwh,
        )

    Notes
    -----
    ECR (Energy Consumption Rate):
        kWh/km = energy_consumed / distance_km

    Energy Efficiency:
        km/kWh = distance_km / energy_consumed
    """

    energy_consumed = float(energy_consumed) if pd.notna(energy_consumed) else 0.0

    distance_km = float(distance_km) if pd.notna(distance_km) else 0.0

    ecr_kwh_per_km = round(energy_consumed / distance_km, 2) if distance_km > 0 else 0.0

    efficiency_km_per_kwh = (
        round(distance_km / energy_consumed, 2) if energy_consumed > 0 else 0.0
    )

    return ecr_kwh_per_km, efficiency_km_per_kwh


### process_movement_session code to process movement sessions properly ###
def process_movement_session(
    session_df: pd.DataFrame,
) -> dict:

    required_columns = {
        "Mode",
        "device_id",
        "device_type",
        "device_type_name",
        "timestamp",
        "time_difference",
        "odometer",
        "odo_delta",
        "speed",
        "rpm",
        "soc",
        "soc_delta",
        "battery_current",
        "battery_voltage",
        "mcu_high_power_voltage",
        "mcu_high_power_current",
        "dcdc_input_voltage",
        "dcdc_input_current",
        "ecompressor_input_power",
        "steering_input_power",
        "bcscompressor_input_current",
        "bcscompressor_input_voltage",
    }

    missing_columns = required_columns.difference(session_df.columns)

    if missing_columns:
        raise ValueError(f"Missing required columns: {sorted(missing_columns)}")

    if session_df.empty:
        logger.warning("Received empty dataframe.")
        return {}

    logger.info("Starting movement session computation.")

    working_df = session_df.copy()

    # -------------------------------------------------------------------------
    # Normalize timestamp datatype.
    # -------------------------------------------------------------------------
    if not pd.api.types.is_datetime64_any_dtype(working_df["timestamp"]):
        working_df["timestamp"] = pd.to_datetime(
            working_df["timestamp"],
            errors="coerce",
        )

    working_df = working_df.dropna(subset=["timestamp"])

    if working_df.empty:
        logger.warning("No valid timestamp rows available.")
        return {}

    # -------------------------------------------------------------------------
    # Global ordering guarantees deterministic session segmentation.
    # -------------------------------------------------------------------------
    working_df = working_df.sort_values(
        ["device_id", "timestamp"],
        kind="mergesort",
    ).reset_index(drop=True)

    # -------------------------------------------------------------------------
    # Calculate required metrics
    # -------------------------------------------------------------------------
    # SOC
    soc_series = pd.to_numeric(
        working_df["soc"],
        errors="coerce",
    ).astype("float64")

    start_soc: float = round(
        float(soc_series.iat[0]),  # type: ignore
        2,
    )

    end_soc: float = round(
        float(soc_series.iat[-1]),  # type: ignore
        2,
    )

    soc_consumed: float = round(
        abs(start_soc - end_soc),
        2,
    )

    # soc ec
    # Get device type name
    device_type_name = get_single_value(working_df["device_type_name"])
    soc_ec = calculate_net_energy(
        device_type_name=device_type_name, soc_sum=soc_consumed
    )

    # Battery Current
    # battery_current_consumed = working_df["battery_current"].abs().round(2).sum()

    # Max Cell Voltage
    max_cell_voltage = round(((working_df["max_cell_volt"].round(3).max()) * 1000), 2)
    min_cell_voltage = round(((working_df["min_cell_volt"].round(3).min()) * 1000), 2)

    # Battery metrics
    working_df["battery_energy"] = (
        (working_df["battery_voltage"] / 1)
        * (working_df["battery_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )

    # battery ec with regen
    working_df["battery_discharge"] = working_df["battery_energy"].clip(upper=0)

    working_df["battery_regen"] = working_df["battery_energy"].clip(lower=0)

    battery_discharge = round(
        abs(working_df["battery_discharge"].sum()),
        2,
    )
    # Positive battery regen only
    battery_regen = round(
        abs(working_df["battery_regen"].sum()),
        2,
    )

    # battery ec without regen
    battery_energy_consumed = working_df["battery_energy"].sum().round(2)

    ## MOTOR METRICS ##
    # Motor Energy
    working_df["motor_energy"] = (
        (working_df["mcu_high_power_voltage"] / 1)
        * (working_df["mcu_high_power_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )

    # Motor total discharge
    working_df["motor_discharge"] = working_df["motor_energy"].clip(lower=0)
    motor_discharge = working_df["motor_discharge"].sum().round(2)

    # Motor regen
    working_df["motor_regen"] = working_df["motor_energy"].clip(upper=0)
    motor_regen = working_df["motor_regen"].sum().round(2)

    # Motor energy consumed
    motor_energy_consumed = working_df["motor_energy"].sum().round(2)

    ## DCDC ##
    # DCDC Energy
    working_df["dcdc_energy"] = (
        (working_df["dcdc_input_voltage"] / 1)
        * (working_df["dcdc_input_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )
    dcdc_ec = working_df["dcdc_energy"].sum().round(2)

    ## Ecomp and Steering Energy ##
    working_df["ecomp_energy"] = (working_df["ecompressor_input_power"]) * (
        working_df["time_difference"] / 3_600_000
    )
    working_df["steering_energy"] = (working_df["steering_input_power"]) * (
        working_df["time_difference"] / 3_600_000
    )

    ecomp_ec = working_df["ecomp_energy"].sum().round(2)
    steering_ec = working_df["steering_energy"].sum().round(2)

    ## BCS EC ##
    working_df["bcs_energy"] = (
        (working_df["bcscompressor_input_current"] / 1)
        * (working_df["bcscompressor_input_voltage"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )
    bcs_ec = working_df["bcs_energy"].sum().round(2)

    ## All HV components ec sum
    ec_components = round(
        abs(motor_discharge + dcdc_ec + ecomp_ec + steering_ec + bcs_ec), 2
    )

    ## Distance
    (
        start_odometer,
        end_odometer,
        total_distance,
    ) = get_valid_odometer_range(
        session_df,
        max_delta=10,
    )
    max_speed = working_df["speed"].max()
    avg_speed = working_df["speed"].mean()

    ## ECR metrics ## kWh/Km km/kWh
    ecr_kwh_per_km, efficiency_km_per_kwh = calculate_energy_metrics(
        energy_consumed=soc_ec,
        distance_km=total_distance,
    )
    # km per soc # Km/SOC
    km_per_soc = round((total_distance / soc_consumed if soc_consumed else 0), 2)
    # kWh/(km/SOC)
    kwh_per_km_soc = round((soc_ec / km_per_soc if km_per_soc else 0), 2)

    # Percentages of battery regen and components ec
    battery_regen_pct = (
        round(
            (battery_regen / battery_discharge) * 100,
            2,
        )
        if battery_discharge > 0
        else 0.0
    )
    # motor ec pct
    motor_ec_pct = (
        round(
            (motor_discharge / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # dcdc ec pct
    dcdc_ec_pct = (
        round(
            (dcdc_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # Ecomp ec pct
    ecomp_ec_pct = (
        round(
            (ecomp_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # steering ec pct
    steering_ec_pct = (
        round(
            (steering_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # bcs ec pct
    bcs_ec_pct = (
        round(
            (bcs_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )

    # Return calculated metrics
    return {
        # Battery Metrics
        "start_soc": start_soc,
        "end_soc": end_soc,
        "soc_consumed": round(soc_consumed, 2),
        # "battery_current_consumed": battery_current_consumed,
        "max_cell_voltage": max_cell_voltage,
        "min_cell_voltage": min_cell_voltage,
        "energy_consumed_soc": round(soc_ec, 2),
        "battery_discharge": battery_discharge,
        "battery_regen": battery_regen,
        "battery_energy_consumed": abs(battery_energy_consumed),
        # Motor and MCU metrics
        "motor_discharge": motor_discharge,
        "motor_regen": motor_regen,
        "motor_energy_consumed": motor_energy_consumed,
        # DCDC metrics
        "dcdc_energy_cosumed": dcdc_ec,
        # Ecomp
        "ecomp_ec": ecomp_ec,
        # steering
        "steering_ec": steering_ec,
        # BCS EC
        "bcs_ec": bcs_ec,
        # All HV ec sum
        "ec_components": ec_components,
        # Difference in battery ec and all HV ec
        "energy_difference": round(abs(ec_components - battery_discharge), 2),
        # Distance metrics
        "start_odometer": start_odometer,
        "end_odometer": end_odometer,
        "distance": total_distance,
        "max_speed": round(max_speed, 2),
        "avg_speed": round(avg_speed, 2),
        # ECR metrics
        "ecr_range": ecr_kwh_per_km,
        "energy_efficiency": efficiency_km_per_kwh,
        "km_per_soc": km_per_soc,
        "kwh_per_km_soc": kwh_per_km_soc,
        # Percentages of battery regen and components ec
        "battery_regen_pct": battery_regen_pct,
        "motor_ec_pct": motor_ec_pct,
        "dcdc_ec_pct": dcdc_ec_pct,
        "ecomp_ec_pct": ecomp_ec_pct,
        "steering_ec_pct": steering_ec_pct,
        "bcs_ec_pct": bcs_ec_pct,
    }


### process_idle_session code to process idle sessions properly ###
def process_idle_session(
    session_df: pd.DataFrame,
) -> dict:
    required_columns = {
        "Mode",
        "device_id",
        "device_type",
        "device_type_name",
        "timestamp",
        "time_difference",
        "odometer",
        "odo_delta",
        "speed",
        "rpm",
        "soc",
        "soc_delta",
        "battery_current",
        "battery_voltage",
        "mcu_high_power_voltage",
        "mcu_high_power_current",
        "dcdc_input_voltage",
        "dcdc_input_current",
        "ecompressor_input_power",
        "steering_input_power",
        "bcscompressor_input_current",
        "bcscompressor_input_voltage",
    }

    missing_columns = required_columns.difference(session_df.columns)

    if missing_columns:
        raise ValueError(f"Missing required columns: {sorted(missing_columns)}")

    if session_df.empty:
        logger.warning("Received empty dataframe.")
        return {}

    logger.info("Starting movement session computation.")

    working_df = session_df.copy()

    # -------------------------------------------------------------------------
    # Normalize timestamp datatype.
    # -------------------------------------------------------------------------
    if not pd.api.types.is_datetime64_any_dtype(working_df["timestamp"]):
        working_df["timestamp"] = pd.to_datetime(
            working_df["timestamp"],
            errors="coerce",
        )

    working_df = working_df.dropna(subset=["timestamp"])

    if working_df.empty:
        logger.warning("No valid timestamp rows available.")
        return {}

    # -------------------------------------------------------------------------
    # Global ordering guarantees deterministic session segmentation.
    # -------------------------------------------------------------------------
    working_df = working_df.sort_values(
        ["device_id", "timestamp"],
        kind="mergesort",
    ).reset_index(drop=True)

    # -------------------------------------------------------------------------
    # Calculate required metrics
    # -------------------------------------------------------------------------
    # SOC
    soc_series = pd.to_numeric(
        working_df["soc"],
        errors="coerce",
    ).astype("float64")

    start_soc: float = round(
        float(soc_series.iat[0]),  # type: ignore
        2,
    )

    end_soc: float = round(
        float(soc_series.iat[-1]),  # type: ignore
        2,
    )

    soc_consumed: float = round(
        abs(start_soc - end_soc),
        2,
    )

    # soc ec
    # Get device type name
    device_type_name = get_single_value(working_df["device_type_name"])
    soc_ec = calculate_net_energy(
        device_type_name=device_type_name, soc_sum=soc_consumed
    )

    # Battery Current
    # battery_current_consumed = working_df["battery_current"].abs().round(2).sum()

    # Max Cell Voltage
    max_cell_voltage = round(((working_df["max_cell_volt"].round(3).max()) * 1000), 2)
    min_cell_voltage = round(((working_df["min_cell_volt"].round(3).min()) * 1000), 2)

    # Battery metrics
    working_df["battery_energy"] = (
        (working_df["battery_voltage"] / 1)
        * (working_df["battery_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )

    # battery ec with regen
    working_df["battery_discharge"] = working_df["battery_energy"].clip(upper=0)

    working_df["battery_regen"] = working_df["battery_energy"].clip(lower=0)

    battery_discharge = round(
        abs(working_df["battery_discharge"].sum()),
        2,
    )
    # Positive battery regen only
    battery_regen = round(
        abs(working_df["battery_regen"].sum()),
        2,
    )

    # battery ec without regen
    battery_energy_consumed = working_df["battery_energy"].sum().round(2)

    ## MOTOR METRICS ##
    # Motor Energy
    working_df["motor_energy"] = (
        (working_df["mcu_high_power_voltage"] / 1)
        * (working_df["mcu_high_power_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )

    # Motor total discharge
    working_df["motor_discharge"] = working_df["motor_energy"].clip(lower=0)
    motor_discharge = working_df["motor_discharge"].sum().round(2)

    # Motor regen
    working_df["motor_regen"] = working_df["motor_energy"].clip(upper=0)
    motor_regen = working_df["motor_regen"].sum().round(2)

    # Motor energy consumed
    motor_energy_consumed = working_df["motor_energy"].sum().round(2)

    ## DCDC ##
    # DCDC Energy
    working_df["dcdc_energy"] = (
        (working_df["dcdc_input_voltage"] / 1)
        * (working_df["dcdc_input_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )
    dcdc_ec = working_df["dcdc_energy"].sum().round(2)

    ## Ecomp and Steering Energy ##
    working_df["ecomp_energy"] = (working_df["ecompressor_input_power"]) * (
        working_df["time_difference"] / 3_600_000
    )
    working_df["steering_energy"] = (working_df["steering_input_power"]) * (
        working_df["time_difference"] / 3_600_000
    )

    ecomp_ec = working_df["ecomp_energy"].sum().round(2)
    steering_ec = working_df["steering_energy"].sum().round(2)

    ## BCS EC ##
    working_df["bcs_energy"] = (
        (working_df["bcscompressor_input_current"] / 1)
        * (working_df["bcscompressor_input_voltage"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )
    bcs_ec = working_df["bcs_energy"].sum().round(2)

    ## All HV components ec sum
    ec_components = round(
        abs(motor_discharge + dcdc_ec + ecomp_ec + steering_ec + bcs_ec), 2
    )

    ## Distance
    (
        start_odometer,
        end_odometer,
        total_distance,
    ) = get_valid_odometer_range(
        session_df,
        max_delta=10,
    )
    max_speed = working_df["speed"].max()
    avg_speed = working_df["speed"].mean()

    ## ECR metrics ## kWh/Km km/kWh
    ecr_kwh_per_km, efficiency_km_per_kwh = calculate_energy_metrics(
        energy_consumed=soc_ec,
        distance_km=total_distance,
    )
    # km per soc # Km/SOC
    km_per_soc = round((total_distance / soc_consumed if soc_consumed else 0), 2)
    # kWh/(km/SOC)
    kwh_per_km_soc = round((soc_ec / km_per_soc if km_per_soc else 0), 2)

    # Percentages of battery regen and components ec
    battery_regen_pct = (
        round(
            (battery_regen / battery_discharge) * 100,
            2,
        )
        if battery_discharge > 0
        else 0.0
    )
    # motor ec pct
    motor_ec_pct = (
        round(
            (motor_discharge / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # dcdc ec pct
    dcdc_ec_pct = (
        round(
            (dcdc_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # Ecomp ec pct
    ecomp_ec_pct = (
        round(
            (ecomp_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # steering ec pct
    steering_ec_pct = (
        round(
            (steering_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # bcs ec pct
    bcs_ec_pct = (
        round(
            (bcs_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )

    # Return calculated metrics
    return {
        # Battery Metrics
        "start_soc": start_soc,
        "end_soc": end_soc,
        "soc_consumed": round(soc_consumed, 2),
        # "battery_current_consumed": battery_current_consumed,
        "max_cell_voltage": max_cell_voltage,
        "min_cell_voltage": min_cell_voltage,
        "energy_consumed_soc": round(soc_ec, 2),
        "battery_discharge": battery_discharge,
        "battery_regen": battery_regen,
        "battery_energy_consumed": abs(battery_energy_consumed),
        # Motor and MCU metrics
        "motor_discharge": motor_discharge,
        "motor_regen": motor_regen,
        "motor_energy_consumed": motor_energy_consumed,
        # DCDC metrics
        "dcdc_energy_cosumed": dcdc_ec,
        # Ecomp
        "ecomp_ec": ecomp_ec,
        # steering
        "steering_ec": steering_ec,
        # BCS EC
        "bcs_ec": bcs_ec,
        # All HV ec sum
        "ec_components": ec_components,
        # Difference in battery ec and all HV ec
        "energy_difference": round(abs(ec_components - battery_discharge), 2),
        # Distance metrics
        "start_odometer": start_odometer,
        "end_odometer": end_odometer,
        "distance": total_distance,
        "max_speed": round(max_speed, 2),
        "avg_speed": round(avg_speed, 2),
        # ECR metrics
        "ecr_range": ecr_kwh_per_km,
        "energy_efficiency": efficiency_km_per_kwh,
        "km_per_soc": km_per_soc,
        "kwh_per_km_soc": kwh_per_km_soc,
        # Percentages of battery regen and components ec
        "battery_regen_pct": battery_regen_pct,
        "motor_ec_pct": motor_ec_pct,
        "dcdc_ec_pct": dcdc_ec_pct,
        "ecomp_ec_pct": ecomp_ec_pct,
        "steering_ec_pct": steering_ec_pct,
        "bcs_ec_pct": bcs_ec_pct,
    }


### process_charging_session code to process charging sessions properly ###
def process_charging_session(
    session_df: pd.DataFrame,
) -> dict:
    required_columns = {
        "Mode",
        "device_id",
        "device_type",
        "device_type_name",
        "timestamp",
        "time_difference",
        "odometer",
        "odo_delta",
        "speed",
        "rpm",
        "soc",
        "soc_delta",
        "battery_current",
        "battery_voltage",
        "mcu_high_power_voltage",
        "mcu_high_power_current",
        "dcdc_input_voltage",
        "dcdc_input_current",
        "ecompressor_input_power",
        "steering_input_power",
        "bcscompressor_input_current",
        "bcscompressor_input_voltage",
    }

    missing_columns = required_columns.difference(session_df.columns)

    if missing_columns:
        raise ValueError(f"Missing required columns: {sorted(missing_columns)}")

    if session_df.empty:
        logger.warning("Received empty dataframe.")
        return {}

    logger.info("Starting movement session computation.")

    working_df = session_df.copy()

    # -------------------------------------------------------------------------
    # Normalize timestamp datatype.
    # -------------------------------------------------------------------------
    if not pd.api.types.is_datetime64_any_dtype(working_df["timestamp"]):
        working_df["timestamp"] = pd.to_datetime(
            working_df["timestamp"],
            errors="coerce",
        )

    working_df = working_df.dropna(subset=["timestamp"])

    if working_df.empty:
        logger.warning("No valid timestamp rows available.")
        return {}

    # -------------------------------------------------------------------------
    # Global ordering guarantees deterministic session segmentation.
    # -------------------------------------------------------------------------
    working_df = working_df.sort_values(
        ["device_id", "timestamp"],
        kind="mergesort",
    ).reset_index(drop=True)

    # -------------------------------------------------------------------------
    # Calculate required metrics
    # -------------------------------------------------------------------------
    # SOC
    soc_series = pd.to_numeric(
        working_df["soc"],
        errors="coerce",
    ).astype("float64")

    start_soc: float = round(
        float(soc_series.iat[0]),  # type: ignore
        2,
    )

    end_soc: float = round(
        float(soc_series.iat[-1]),  # type: ignore
        2,
    )

    soc_consumed: float = round(
        abs(start_soc - end_soc),
        2,
    )

    # soc ec
    # Get device type name
    device_type_name = get_single_value(working_df["device_type_name"])
    soc_ec = calculate_net_energy(
        device_type_name=device_type_name, soc_sum=soc_consumed
    )

    # Battery Current
    # battery_current_consumed = working_df["battery_current"].abs().round(2).sum()

    # Max Cell Voltage
    max_cell_voltage = round(((working_df["max_cell_volt"].round(3).max()) * 1000), 2)
    min_cell_voltage = round(((working_df["min_cell_volt"].round(3).min()) * 1000), 2)

    # Battery metrics
    working_df["battery_energy"] = (
        (working_df["battery_voltage"] / 1)
        * (working_df["battery_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )

    # battery ec with regen
    working_df["battery_discharge"] = working_df["battery_energy"].clip(upper=0)

    working_df["battery_regen"] = working_df["battery_energy"].clip(lower=0)

    battery_discharge = round(
        abs(working_df["battery_discharge"].sum()),
        2,
    )
    # Positive battery regen only
    battery_regen = round(
        abs(working_df["battery_regen"].sum()),
        2,
    )

    # battery ec without regen
    battery_energy_consumed = working_df["battery_energy"].sum().round(2)

    ## MOTOR METRICS ##
    # Motor Energy
    working_df["motor_energy"] = (
        (working_df["mcu_high_power_voltage"] / 1)
        * (working_df["mcu_high_power_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )

    # Motor total discharge
    working_df["motor_discharge"] = working_df["motor_energy"].clip(lower=0)
    motor_discharge = working_df["motor_discharge"].sum().round(2)

    # Motor regen
    working_df["motor_regen"] = working_df["motor_energy"].clip(upper=0)
    motor_regen = working_df["motor_regen"].sum().round(2)

    # Motor energy consumed
    motor_energy_consumed = working_df["motor_energy"].sum().round(2)

    ## DCDC ##
    # DCDC Energy
    working_df["dcdc_energy"] = (
        (working_df["dcdc_input_voltage"] / 1)
        * (working_df["dcdc_input_current"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )
    dcdc_ec = working_df["dcdc_energy"].sum().round(2)

    ## Ecomp and Steering Energy ##
    working_df["ecomp_energy"] = (working_df["ecompressor_input_power"]) * (
        working_df["time_difference"] / 3_600_000
    )
    working_df["steering_energy"] = (working_df["steering_input_power"]) * (
        working_df["time_difference"] / 3_600_000
    )

    ecomp_ec = working_df["ecomp_energy"].sum().round(2)
    steering_ec = working_df["steering_energy"].sum().round(2)

    ## BCS EC ##
    working_df["bcs_energy"] = (
        (working_df["bcscompressor_input_current"] / 1)
        * (working_df["bcscompressor_input_voltage"] / 1)
        * (working_df["time_difference"] / 3_600_000)
    )
    bcs_ec = working_df["bcs_energy"].sum().round(2)

    ## All HV components ec sum
    ec_components = round(
        abs(motor_discharge + dcdc_ec + ecomp_ec + steering_ec + bcs_ec), 2
    )

    ## Distance
    (
        start_odometer,
        end_odometer,
        total_distance,
    ) = get_valid_odometer_range(
        session_df,
        max_delta=10,
    )
    max_speed = working_df["speed"].max()
    avg_speed = working_df["speed"].mean()

    ## ECR metrics ## kWh/Km km/kWh
    ecr_kwh_per_km, efficiency_km_per_kwh = calculate_energy_metrics(
        energy_consumed=soc_ec,
        distance_km=total_distance,
    )
    # km per soc # Km/SOC
    km_per_soc = round((total_distance / soc_consumed if soc_consumed else 0), 2)
    # kWh/(km/SOC)
    kwh_per_km_soc = round((soc_ec / km_per_soc if km_per_soc else 0), 2)

    # Percentages of battery regen and components ec
    battery_regen_pct = (
        round(
            (battery_regen / battery_discharge) * 100,
            2,
        )
        if battery_discharge > 0
        else 0.0
    )
    # motor ec pct
    motor_ec_pct = (
        round(
            (motor_discharge / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # dcdc ec pct
    dcdc_ec_pct = (
        round(
            (dcdc_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # Ecomp ec pct
    ecomp_ec_pct = (
        round(
            (ecomp_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # steering ec pct
    steering_ec_pct = (
        round(
            (steering_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )
    # bcs ec pct
    bcs_ec_pct = (
        round(
            (bcs_ec / ec_components) * 100,
            2,
        )
        if ec_components > 0
        else 0.0
    )

    # Return calculated metrics
    return {
        # Battery Metrics
        "start_soc": start_soc,
        "end_soc": end_soc,
        "soc_consumed": round(soc_consumed, 2),
        # "battery_current_consumed": battery_current_consumed,
        "max_cell_voltage": max_cell_voltage,
        "min_cell_voltage": min_cell_voltage,
        "energy_consumed_soc": round(soc_ec, 2),
        "battery_discharge": battery_discharge,
        "battery_regen": battery_regen,
        "battery_energy_consumed": abs(battery_energy_consumed),
        # Motor and MCU metrics
        "motor_discharge": motor_discharge,
        "motor_regen": motor_regen,
        "motor_energy_consumed": motor_energy_consumed,
        # DCDC metrics
        "dcdc_energy_cosumed": dcdc_ec,
        # Ecomp
        "ecomp_ec": ecomp_ec,
        # steering
        "steering_ec": steering_ec,
        # BCS EC
        "bcs_ec": bcs_ec,
        # All HV ec sum
        "ec_components": ec_components,
        # Difference in battery ec and all HV ec
        "energy_difference": round(abs(ec_components - battery_discharge), 2),
        # Distance metrics
        "start_odometer": start_odometer,
        "end_odometer": end_odometer,
        "distance": total_distance,
        "max_speed": round(max_speed, 2),
        "avg_speed": round(avg_speed, 2),
        # ECR metrics
        "ecr_range": ecr_kwh_per_km,
        "energy_efficiency": efficiency_km_per_kwh,
        "km_per_soc": km_per_soc,
        "kwh_per_km_soc": kwh_per_km_soc,
        # Percentages of battery regen and components ec
        "battery_regen_pct": battery_regen_pct,
        "motor_ec_pct": motor_ec_pct,
        "dcdc_ec_pct": dcdc_ec_pct,
        "ecomp_ec_pct": ecomp_ec_pct,
        "steering_ec_pct": steering_ec_pct,
        "bcs_ec_pct": bcs_ec_pct,
    }
