# ==============================
# Imports
# ==============================
import dash
import dash_bootstrap_components as dbc
from dash import html
import pandas as pd


# ==============================
# Reusable KPI Card
# ==============================
def kpi_card(title, value, color="text-body"):
    color_class = color if color else None
    return dbc.Card(
        dbc.CardBody(
            [
                html.H6(title, className="text-muted text-center"),
                html.H4(
                    str(value) if pd.notna(value) else "—",
                    className=f"fw-bold {color_class}",
                ),
            ]
        ),
        className="shadow-sm text-center h-100",
    )


# ==============================
# Vehicle Identification Card
# ==============================
def vehicle_identification_card(vehicle):
    items = [
        ("Device ID", vehicle.get("device_id")),
        ("VRN", vehicle.get("VRN")),
        ("Chassis", vehicle.get("CHASSIS")),
        ("Platform", vehicle.get("PLATFORM")),
        ("Fleet Name", vehicle.get("FLEET_NAME")),
        ("Location", vehicle.get("LOCATION")),
    ]

    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Vehicle Identification", className="fw-bold mb-3"),
                html.Hr(className="my-2"),
                dbc.ListGroup(
                    [
                        dbc.ListGroupItem(
                            dbc.Row(
                                [
                                    dbc.Col(
                                        label, className="text-muted fw-semibold", md=5
                                    ),
                                    dbc.Col(
                                        str(value) if pd.notna(value) else "—",
                                        className="fw-bold text-right",
                                        md=7,
                                    ),
                                ]
                            ),
                            className="border-0 px-0 py-2",
                        )
                        for label, value in items
                    ],
                    flush=True,
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


# ==============================
# Start / End Summary Card
# ==============================
def start_end_summary_card(vehicle):
    rows = [
        (
            "Time",
            vehicle.get("START_TIME_OF_DAY"),
            vehicle.get("END_TIME_OF_DAY"),
        ),
        (
            "SOC (%)",
            vehicle.get("START_SOC_OF_THE_DAY"),
            vehicle.get("END_SOC_OF_THE_DAY"),
        ),
        (
            "Odometer (km)",
            vehicle.get("START_ODOMETER(km)"),
            vehicle.get("END_ODOMETER(km)"),
        ),
    ]

    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Start / End Summary", className="fw-bold mb-3"),
                html.Hr(className="my-2"),
                dbc.Table(
                    [
                        html.Thead(
                            html.Tr(
                                [
                                    html.Th("Metric"),
                                    html.Th("Start", className="text-center"),
                                    html.Th("End", className="text-center"),
                                ]
                            )
                        ),
                        html.Tbody(
                            [
                                html.Tr(
                                    [
                                        html.Td(
                                            label, className="text-muted fw-semibold"
                                        ),
                                        html.Td(
                                            str(start) if pd.notna(start) else "—",
                                            className="fw-bold text-center",
                                        ),
                                        html.Td(
                                            str(end) if pd.notna(end) else "—",
                                            className="fw-bold text-center",
                                        ),
                                    ]
                                )
                                for label, start, end in rows
                            ]
                        ),
                    ],
                    bordered=False,
                    hover=True,
                    responsive=True,
                    className="mb-0",
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


# ==============================
# Distance & Speed KPIs
# ==============================
def distance_speed_kpis(vehicle):
    distance = vehicle.get("TOTAL_DISTANCE_TRAVELLED(km)")
    distance_rpm = vehicle.get("TOTAL_DISTANCE_TRAVELLED_RPM(km)")
    speed = vehicle.get("AVERAGE_SPEED(kmph)")

    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Distance & Speed", className="fw-bold mb-3"),
                dbc.Row(
                    [
                        dbc.Col(
                            kpi_card(
                                "Total Distance (km)",
                                round(distance, 2) if pd.notna(distance) else None,
                            ),
                            md=12,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Total Distance RPM (km)",
                                (
                                    round(distance_rpm, 2)
                                    if pd.notna(distance_rpm)
                                    else None
                                ),
                            ),
                            md=12,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Average Speed (kmph)",
                                round(speed, 2) if pd.notna(speed) else None,
                            ),
                            md=12,
                        ),
                    ],
                    className="g-3",
                ),
            ]
        ),
        className="shadow-sm h-100",
    )


# ==============================
# Temperature Thresholds (°C)
# ==============================
TEMP_THRESHOLDS = {
    "MAX_BATTERY_TEMPERATURE(°C)": 40,
    "MAX_MOTOR_TEMPERATURE(°C)": 150,
    "MAX_MCU_TEMPERATURE(°C)": 70,
    "MAX_BCS_TEMPERATURE(°C)": 40,
    "MAX_TCS_TEMPERATURE(°C)": 50,
    "MAX_DCDC_TEMPERATURE(°C)": 78,
    "MAX_ECOMP_TEMPERATURE(°C)": 73,
    "MAX_STEERING_TEMPERATURE(°C)": 73,
}


# ==============================
# Reusable KPI Card (with alert)
# ==============================
def kpi_card_temp(title, value, danger=False):
    color_class = "text-danger" if danger else "text-body"

    return dbc.Card(
        dbc.CardBody(
            [
                html.H6(title, className="text-muted text-uppercase"),
                html.H4(
                    f"{value} °C" if pd.notna(value) else "—",
                    className=f"fw-bold {color_class}",
                ),
            ]
        ),
        className=(
            "shadow-sm text-center h-100 border border-danger"
            if danger
            else "shadow-sm text-center h-100"
        ),
    )


# ==============================
# Max Temperature KPIs
# ==============================
def max_temperature_kpis(vehicle):
    kpis = []

    for col, threshold in TEMP_THRESHOLDS.items():
        value = vehicle.get(col)

        danger = pd.notna(value) and threshold is not None and value > threshold

        kpis.append(
            dbc.Col(
                kpi_card_temp(
                    title=col.replace("MAX_", "")
                    .replace("_TEMPERATURE(°C)", "")
                    .replace("_", " "),
                    value=round(value, 1) if pd.notna(value) else None,
                    danger=danger,
                ),
                md=3,
            )
        )

    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Max Temperature Summary", className="fw-bold mb-3"),
                dbc.Row(kpis, className="g-3"),
            ]
        ),
        className="shadow-sm",
    )


def safe_time(value):
    return value if pd.notna(value) and str(value).strip() != "" else "—"


# ==============================
# Vehicle Runtime KPIs
# ==============================
def runtime_kpis(vehicle):
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Vehicle Runtime Summary (HH:MM:SS)", className="fw-bold mb-3"),
                dbc.Row(
                    [
                        dbc.Col(
                            kpi_card(
                                "Runtime Time",
                                safe_time(vehicle.get("RUNTIME_TIME(HH:MM)")),
                            ),
                            md=3,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Idle Time",
                                safe_time(vehicle.get("IDLE_TIME(HH:MM)")),
                            ),
                            md=3,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Charging Time",
                                safe_time(vehicle.get("CHARGING_TIME(HH:MM)")),
                            ),
                            md=3,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Stoppage Time",
                                safe_time(vehicle.get("STOPPAGE_TIME(HH:MM)")),
                            ),
                            md=3,
                        ),
                    ],
                    className="g-3",
                ),
            ]
        ),
        className="shadow-sm",
    )


# ==============================
# Vehicle Session KPIs
# ==============================
def session_kpis(vehicle):
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Vehicle Session Count", className="fw-bold mb-3"),
                dbc.Row(
                    [
                        dbc.Col(
                            kpi_card(
                                "Movement Sessions",
                                vehicle.get("MOVEMENT_SESSION_COUNT"),
                            ),
                            md=4,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Idle Sessions",
                                vehicle.get("IDLE_SESSION_COUNT"),
                            ),
                            md=4,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Charging Sessions",
                                vehicle.get("CHARGING_SESSION_COUNT"),
                            ),
                            md=4,
                        ),
                    ],
                    className="g-3",
                ),
            ]
        ),
        className="shadow-sm",
    )


# ==============================
# Vehicle Energy KPIs
# ==============================
def energy_kpis(vehicle):
    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Vehicle Energy Metrics", className="fw-bold mb-3"),
                # --- Row 1: High-level energy KPIs ---
                dbc.Row(
                    [
                        dbc.Col(
                            kpi_card(
                                "Energy Consumed (kWh)",
                                vehicle.get("ENERGY_CONSUMED(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Regenerative Energy (kWh)",
                                vehicle.get("REGENERATIVE_ENERGY(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Charging Units (kWh)",
                                vehicle.get("CHARGING_UNITS(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Energy Rate (kWh/km)",
                                vehicle.get("ENERGY_CONSUMPTION_RATE(kWh/km)"),
                            ),
                            md=3,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Km per SOC",
                                vehicle.get("KM_PER_SOC"),
                            ),
                            md=3,
                        ),
                    ],
                    className="g-3 mb-4",
                ),
                # --- Row 2: Energy breakdown KPIs ---
                dbc.Row(
                    [
                        dbc.Col(
                            kpi_card(
                                "Motor Energy Consumed (kWh)",
                                vehicle.get("MOTOR_EC(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Motor Regen (kWh)",
                                vehicle.get("MOTOR_REGEN(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "DC-DC Energy (kWh)",
                                vehicle.get("DCDC_EC(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "E-Comp & Steering (kWh)",
                                vehicle.get("ECOMPRESSOR_AND_STEERING_EC(kWh)"),
                            ),
                            md=3,
                        ),
                        dbc.Col(
                            kpi_card(
                                "BCS Energy (kWh)",
                                vehicle.get("BCS_EC(kWh)"),
                            ),
                            md=2,
                        ),
                        dbc.Col(
                            kpi_card(
                                "TCS Energy",
                                vehicle.get("TCS_EC"),
                            ),
                            md=1,
                        ),
                    ],
                    className="g-3",
                ),
            ]
        ),
        className="shadow-sm",
    )


# ==============================
# Battery Health KPIs
# ==============================
def battery_health_kpis(vehicle):
    # Optionally, highlight low SOC issues
    low_soc_color = (
        "danger" if vehicle.get("LOW_SOC_INCIDENCE(<20%)", 0) > 0 else "success"
    )

    return dbc.Card(
        dbc.CardBody(
            [
                html.H5("Battery Health Metrics", className="fw-bold mb-3"),
                dbc.Row(
                    [
                        dbc.Col(
                            kpi_card(
                                "Low SOC Incidence (<20%)",
                                vehicle.get("LOW_SOC_INCIDENCE(<20%)"),
                                color=low_soc_color,  # type: ignore
                            ),
                            md=6,
                        ),
                        dbc.Col(
                            kpi_card(
                                "Cell Balancing (%)",
                                vehicle.get("CELL_BALANCING"),
                                color="primary",  # type: ignore
                            ),
                            md=6,
                        ),
                    ],
                    className="g-3",
                ),
            ]
        ),
        className="shadow-sm",
    )


# ==============================
# Build KPI Cards Dynamically
# ==============================
def build_kpi_grid(vehicle_series):
    cards = []

    for col, val in vehicle_series.items():
        cards.append(
            dbc.Col(
                kpi_card(col.replace("_", " "), val),
                md=3,
                sm=6,
                xs=12,
                className="mb-4",
            )
        )

    return dbc.Row(cards)


# for vehicle filter
# ==============================
# Helper Functions
# ==============================
def build_vehicle_options(df: pd.DataFrame):
    options = []

    for _, row in df.iterrows():
        device_id = str(row["device_id"])

        label = (
            f"Device: {device_id} | "
            f"VRN: {row.get('VRN', 'NA')} | "
            f"CHASSIS: {row.get('CHASSIS', 'NA')}"
        )

        options.append(
            {
                "label": label,
                "value": device_id,
            }
        )

    return options


def get_vehicle(df: pd.DataFrame, selected_date, device_id: str):

    # 🔥 Convert Dash string → date
    selected_date = pd.to_datetime(selected_date).date()

    date_col = pd.to_datetime(df["DATE"]).dt.date

    filtered = df.loc[(df["device_id"] == device_id) & (date_col == selected_date)]

    if filtered.empty:
        raise ValueError(
            f"No vehicle found for device_id={device_id} on date={selected_date}"
        )

    return filtered.iloc[0]
