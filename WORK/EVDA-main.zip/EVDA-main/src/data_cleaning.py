import pandas as pd
import numpy as np
from typing import Iterable, Optional


# ALL FUNCTIONS TO CLEAN AND PREPROCESS DATA
def clean_numeric(
    df: pd.DataFrame,
    cols: Iterable[str],
    *,
    dtype=float,
    round_digits: Optional[int] = None,
) -> None:
    """
    In-place numeric cleaning:
    - coercion
    - NaN → 0
    - optional rounding
    """
    for col in cols:
        if col not in df.columns:
            continue

        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0).astype(dtype)

        if round_digits is not None:
            df[col] = df[col].round(round_digits)


# Function to clean 3w df
def clean_3w_df(df):
    # --- 1. Normalize column names ---
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

    # --- 2. Timestamp processing ---
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df["timestamp"] = df["timestamp"].dt.tz_localize(None).dt.floor("s")  # type: ignore
    df = df.dropna(subset=["timestamp"])

    # --- 3. Odometer processing ---
    odometer_col = "mcu_odometer_val_3w"

    df.rename(columns={odometer_col: "odometer"}, inplace=True)
    df["odometer"] = df["odometer"].replace("N", 0).fillna(0).astype(float).round(2)

    # --- 4. Drop irrelevant columns ---
    drop_cols = [
        "ignition_sense_4w",
        "wheel_based_vehicle_speed_4w",
        "mcu_motor_speed_4w",
        "odometer_4w",
        "odometer_crut_4w",
        "a_max_cell_temp",
        "b_max_cell_temp",
        "c_max_cell_temp",
        "motor_temp_4w",
        "mcu_temperature_4w",
        "bcs_thermistor_1",
        "bcs_thermistor_2",
        "bcs_thermistor_3",
        "tcs_temp",
        "dcdc_temp_1",
        "dcdc_temp_2",
        "dcdc_temp_3",
        "dcdc_temp_4",
        "ecomp_temp",
        "steering_temp",
        "a_soc",
        "b_soc",
        "c_soc",
        "a_pack_voltage",
        "b_pack_voltage",
        "c_pack_voltage",
    ]
    df.drop(columns=drop_cols, errors="ignore", inplace=True)

    # --- 5. Rename key columns ---
    rename_map = {
        "ignition_status_3w": "ignition",
        "mcu_speed_kmph_3w": "speed",
        "mcu_motor_speed_3w": "rpm",
        "motor_temp_3w": "motor_temperature",
        "battery_voltage_3w": "battery_voltage",
        "battery_current_3w": "battery_current",
        "vrn": "VRN",
    }
    df.rename(columns=rename_map, inplace=True)

    # 7. Clean individual numeric columns
    clean_numeric(
        df,
        [
            "ignition",
            "vcu_flag",
            "rpm",
            "charger_output_vol",
            "charger_output_cur",
            "ts1",
            "ts2",
            "ts3",
            "ts4",
            "ts5",
            "ts6",
            "motor_temperature",
        ],
        dtype=int,
    )
    clean_numeric(df, ["speed"], dtype=float, round_digits=2)
    clean_numeric(
        df,
        ["soc", "battery_voltage", "battery_current"],
        dtype=float,
        round_digits=2,
    )

    # --- 8. Temperature processing ---
    battery_temp_cols = [
        "ts1",
        "ts2",
        "ts3",
        "ts4",
        "ts5",
        "ts6",
    ]

    for col in battery_temp_cols:
        df[col] = df[col].replace("N", 0).fillna(0).astype(int)

    df["battery_temperature"] = (
        df[battery_temp_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace(0, np.nan)
        .max(axis=1, skipna=True)
        .fillna(0)
        .astype(int)
    )

    # --- 11. DTC processing ---
    dtc_cols = [
        "vcu_dtc_1",
        "vcu_dtc_2",
        "bms_dtc_1",
        "bms_dtc_2",
        "mcu_dtc_1",
        "mcu_dtc_2",
        "evcc_dtc_1",
        "evcc_dtc_2",
        "dcdc_dtc_1",
        "dcdc_dtc_2",
        "tcs_dtc_1",
        "tcs_dtc_2",
        "hvac_bcs_dtc_1",
        "hvac_bcs_dtc_2",
        "ic_mux_dtc_1",
        "ic_mux_dtc_2",
    ]
    clean_numeric(df, dtc_cols, dtype=int)

    # --- 12. Reorder columns ---
    reorder_cols = [
        "device_id",
        "device_type",
        "device_type_name",
        "VRN",
        "chassis_number",
        "city",
        "fleet",
        "timestamp",
        "ignition",
        "vcu_flag",
        "speed",
        "rpm",
        "odometer",
        "charger_output_vol",
        "charger_output_cur",
        "mcu_high_power_voltage",
        "mcu_high_power_current",
        "dcdc_input_voltage",
        "dcdc_input_current",
        "bcscompressor_input_voltage",
        "bcscompressor_input_current",
        "tcs_energy",
        "ecompressor_input_power",
        "steering_input_power",
        "battery_temperature",
        "motor_temperature",
        "mcu_temperature",
        "bcs_temperature",
        "tcs_temperature",
        "dcdc_temperature",
        "ecomp_temperature",
        "steering_temperature",
        "soc",
        "battery_voltage",
        "battery_current",
        "vcu_dtc_1",
        "vcu_dtc_2",
        "bms_dtc_1",
        "bms_dtc_2",
        "mcu_dtc_1",
        "mcu_dtc_2",
        "evcc_dtc_1",
        "evcc_dtc_2",
        "dcdc_dtc_1",
        "dcdc_dtc_2",
        "tcs_dtc_1",
        "tcs_dtc_2",
        "hvac_bcs_dtc_1",
        "hvac_bcs_dtc_2",
        "ic_mux_dtc_1",
        "ic_mux_dtc_2",
    ]

    # Adding energy columns
    for col in reorder_cols:
        if col not in df.columns:
            df[col] = 0

    cleaned_df = df[reorder_cols].copy()
    return cleaned_df


# Function to clean 4w df
def clean_4w_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Clean 4W vehicle raw dataframe.
    - Normalize columns
    - Process timestamps, odometer, speeds, voltages, currents, SOC, temperatures, and DTCs
    - Reorder columns for final cleaned dataframe
    """

    # --- 1. Normalize column names ---
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

    # --- 2. Timestamp processing ---
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df["timestamp"] = df["timestamp"].dt.tz_localize(None).dt.floor("s")  # type: ignore
    df = df.dropna(subset=["timestamp"])

    # --- 3. Odometer processing ---
    fleet_vals = df["fleet"].dropna().unique()
    if np.isin(fleet_vals, ["Odisha_AC", "Microsoft_Hyderabad"]).all():
        df.drop(columns=["odometer_4w"], errors="ignore", inplace=True)
        odometer_col = "odometer_crut_4w"
    else:
        df.drop(columns=["odometer_crut_4w"], errors="ignore", inplace=True)
        odometer_col = "odometer_4w"

    df.rename(columns={odometer_col: "odometer"}, inplace=True)
    df["odometer"] = df["odometer"].replace("N", 0).fillna(0).astype(float).round(2)

    # --- 4. Drop irrelevant columns ---
    drop_cols = [
        "ignition_status_3w",
        "mcu_speed_kmph_3w",
        "mcu_motor_speed_3w",
        "mcu_odometer_val_3w",
        "ts1",
        "ts2",
        "ts3",
        "ts4",
        "ts5",
        "ts6",
        "soc",
        "battery_voltage_3w",
    ]
    df.drop(columns=drop_cols, errors="ignore", inplace=True)

    # --- 5. Rename key columns ---
    rename_map = {
        "ignition_sense_4w": "ignition",
        "wheel_based_vehicle_speed_4w": "speed",
        "mcu_motor_speed_4w": "rpm",
        "motor_temp_4w": "motor_temperature",
        "mcu_temperature_4w": "mcu_temperature",
        "tcs_temp": "tcs_temperature",
        "ecomp_temp": "ecomp_temperature",
        "steering_temp": "steering_temperature",
        "vrn": "VRN",
    }
    df.rename(columns=rename_map, inplace=True)

    # --- 6. Generic numeric cleaning helper ---

    # 7. Clean individual numeric columns
    clean_numeric(
        df,
        ["ignition", "vcu_flag", "rpm", "charger_output_vol", "charger_output_cur"],
        dtype=int,
    )
    clean_numeric(df, ["speed"], dtype=float, round_digits=2)
    clean_numeric(
        df,
        [
            "mcu_high_power_voltage",
            "mcu_high_power_current",
            "dcdc_input_voltage",
            "dcdc_input_current",
            "bcscompressor_input_voltage",
            "bcscompressor_input_current",
            "tcs_energy",
            "ecompressor_input_power",
            "steering_input_power",
        ],
        dtype=float,
        round_digits=2,
    )

    # --- 8. Temperature processing ---
    temp_int_cols = {
        "motor_temperature": ["motor_temperature"],
        "mcu_temperature": ["mcu_temperature"],
        "tcs_temperature": ["tcs_temperature"],
        "ecomp_temperature": ["ecomp_temperature"],
        "steering_temperature": ["steering_temperature"],
    }

    # Battery temperature
    battery_temp_cols = ["a_max_cell_temp", "b_max_cell_temp", "c_max_cell_temp"]
    df["battery_temperature"] = (
        df[battery_temp_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace(0, np.nan)
        .max(axis=1, skipna=True)
        .fillna(0)
        .astype(int)
    )

    # BCS temperature
    bcs_temp_cols = ["bcs_thermistor_1", "bcs_thermistor_2", "bcs_thermistor_3"]
    df["bcs_temperature"] = (
        df[bcs_temp_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace(0, np.nan)
        .max(axis=1, skipna=True)
        .fillna(0)
        .astype(int)
    )

    # DCDC temperature
    dcdc_temp_cols = ["dcdc_temp_1", "dcdc_temp_2", "dcdc_temp_3", "dcdc_temp_4"]
    df["dcdc_temperature"] = (
        df[dcdc_temp_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace(0, np.nan)
        .max(axis=1, skipna=True)
        .fillna(0)
        .astype(int)
    )

    # Clean individual component temps
    for col, cols_list in temp_int_cols.items():
        if col not in df.columns:
            continue

        df[col] = (
            pd.to_numeric(df[col], errors="coerce")
            .replace("N", 0)
            .fillna(0)
            .round()
            .astype(int)
        )

    # --- 9. SOC processing ---
    soc_cols = ["a_soc", "b_soc", "c_soc"]
    clean_numeric(df, soc_cols, dtype=float, round_digits=2)
    df["soc"] = (
        df[soc_cols].replace(0, np.nan).mean(axis=1, skipna=True).round(2).fillna(0)
    )

    # --- 10. Battery voltage and current processing ---
    battery_voltage_cols = ["a_pack_voltage", "b_pack_voltage", "c_pack_voltage"]
    battery_current_cols = ["a_pack_current", "b_pack_current", "c_pack_current"]
    clean_numeric(df, battery_voltage_cols, dtype=float, round_digits=2)
    clean_numeric(df, battery_current_cols, dtype=float, round_digits=2)

    df["battery_voltage"] = (
        df[battery_voltage_cols]
        .replace(0, np.nan)
        .mean(axis=1, skipna=True)
        .round(2)
        .fillna(0)
    )
    df["battery_current"] = (
        df[battery_current_cols]
        .replace(0, np.nan)
        .sum(axis=1, skipna=True)
        .round(2)
        .fillna(0)
    )

    # --- 11. DTC processing ---
    dtc_cols = [
        "vcu_dtc_1",
        "vcu_dtc_2",
        "bms_dtc_1",
        "bms_dtc_2",
        "mcu_dtc_1",
        "mcu_dtc_2",
        "evcc_dtc_1",
        "evcc_dtc_2",
        "dcdc_dtc_1",
        "dcdc_dtc_2",
        "tcs_dtc_1",
        "tcs_dtc_2",
        "hvac_bcs_dtc_1",
        "hvac_bcs_dtc_2",
        "ic_mux_dtc_1",
        "ic_mux_dtc_2",
    ]
    clean_numeric(df, dtc_cols, dtype=int)

    # --- 12. Reorder columns ---
    reorder_cols = [
        "device_id",
        "device_type",
        "device_type_name",
        "VRN",
        "chassis_number",
        "city",
        "fleet",
        "timestamp",
        "ignition",
        "vcu_flag",
        "speed",
        "rpm",
        "odometer",
        "charger_output_vol",
        "charger_output_cur",
        "mcu_high_power_voltage",
        "mcu_high_power_current",
        "dcdc_input_voltage",
        "dcdc_input_current",
        "bcscompressor_input_voltage",
        "bcscompressor_input_current",
        "tcs_energy",
        "ecompressor_input_power",
        "steering_input_power",
        "battery_temperature",
        "motor_temperature",
        "mcu_temperature",
        "bcs_temperature",
        "tcs_temperature",
        "dcdc_temperature",
        "ecomp_temperature",
        "steering_temperature",
        "soc",
        "battery_voltage",
        "battery_current",
        "vcu_dtc_1",
        "vcu_dtc_2",
        "bms_dtc_1",
        "bms_dtc_2",
        "mcu_dtc_1",
        "mcu_dtc_2",
        "evcc_dtc_1",
        "evcc_dtc_2",
        "dcdc_dtc_1",
        "dcdc_dtc_2",
        "tcs_dtc_1",
        "tcs_dtc_2",
        "hvac_bcs_dtc_1",
        "hvac_bcs_dtc_2",
        "ic_mux_dtc_1",
        "ic_mux_dtc_2",
    ]

    cleaned_df = df[reorder_cols].copy()
    return cleaned_df


# Function to clean df and return the cleaned_df
# ------------------------------------------------------------------
# Dispatcher
# ------------------------------------------------------------------
def clean_raw_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Entry-point cleaner.
    Dispatches dataframe to the correct device cleaner based on device_type.
    """
    if df.empty or "device_type" not in df.columns:
        return df.copy()

    device_type = pd.Series(df["device_type"]).dropna().astype(str).iat[0]

    return {
        "3w": clean_3w_df,
        "4w": clean_4w_df,
    }.get(
        device_type, lambda x: x.copy()  # type: ignore
    )(
        df
    )  # type: ignore


# Function to further clean individual vehicle
def clean_individual_vehicle(df: pd.DataFrame) -> pd.DataFrame:

    df = df.copy()

    # round odometer
    df["odometer"] = pd.to_numeric(df["odometer"], errors="coerce").fillna(0).round(2)

    # assume single device type
    device_type = pd.Series(df["device_type"]).dropna().astype(str).iat[0]

    # 4W filtering
    if device_type == "4w" and "vcu_flag" in df.columns:
        df = df.loc[df["vcu_flag"] >= 13]

    # sort
    df = df.sort_values(["device_id", "timestamp"])

    # time delta
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df = df.dropna(subset=["timestamp"])
    time_delta = df["timestamp"].diff()

    df["time_difference"] = pd.to_timedelta(time_delta).dt.total_seconds().fillna(0)

    # odometer delta
    df["odo_delta"] = df["odometer"].diff().fillna(0)

    # DROP rows with time_difference > 300
    df = df.loc[(df["time_difference"] <= 300) & (df["time_difference"] > 1)].copy()

    # remove unrealistic jumps
    time_threshold = 4 * 3600
    odo_jump_threshold = 200

    mask = ~(
        (df["time_difference"] < time_threshold)
        & (df["odo_delta"] > odo_jump_threshold)
    )

    df = df.loc[mask].copy()

    # ignition filter (now safe)
    if {"ignition", "odo_delta"}.issubset(df.columns):
        df = df.loc[(df["ignition"] == 1) & (df["odo_delta"] >= 0)].copy()
        # df = df.loc[df["odo_delta"] >= 0]

    return df


# Function to clean MMI Device Data
# Function to get odometer for MMI
# ------------------------------------------------------------------
# Utility helpers
# ------------------------------------------------------------------
def to_padded_str(series: Optional[pd.Series], width: int = 2) -> pd.Series:
    """
    Convert a Series to zero-padded numeric strings.
    If None is passed, returns a zero-filled Series.
    """
    if series is None:
        # Return a scalar-zero series; caller will align index via concat
        return pd.Series("0" * width)

    return (
        pd.to_numeric(series.replace("", pd.NA), errors="coerce")
        .fillna(0)
        .astype(int)
        .astype(str)
        .str.zfill(width)
    )


# Get mean or sum of columns
def aggregate_nonzero(
    df: pd.DataFrame,
    cols: Iterable[str],
    *,
    method: str = "mean",
    round_digits: int = 2,
) -> pd.Series:
    """
    Aggregate across columns while ignoring zeros.
    """
    valid = df[list(cols)].replace(0, np.nan)

    if method == "sum":
        out = valid.sum(axis=1, skipna=True)
    else:
        out = valid.mean(axis=1, skipna=True)

    return out.round(round_digits).fillna(0)


# ------------------------------------------------------------------
# MMI Cleaner
# ------------------------------------------------------------------
def mmi_clean_raw_df(df: pd.DataFrame, device_type_name) -> pd.DataFrame:
    """
    Clean and normalize raw MMI device telemetry.
    """

    df = df.copy()

    # --------------------------------------------------------------
    # Odometer construction (string concat → numeric)
    # --------------------------------------------------------------
    df["odometer"] = (
        (
            to_padded_str(df.get("TRANSFORMERTEMP"))
            + to_padded_str(df.get("SecondarymosfetTemperature"))
            + to_padded_str(df.get("PrimarymosfetTemperature"))
        )
        .astype(float)
        .round(2)
    )

    # --------------------------------------------------------------
    # Column renaming
    # --------------------------------------------------------------
    rename_map = {
        "Server_Time": "timestamp",
        "IgnitionSense": "ignition",
        "VCUFlag": "vcu_flag",
        "WheelBasedVehicleSpeedRx": "speed",
        "MCUMotorSpeed": "rpm",
        "MCUHighPowerCurrent": "mcu_high_power_current",
        "MCUHighPowerVoltage": "mcu_high_power_voltage",
        "DCDCInputVoltage": "dcdc_input_voltage",
        "DCDCInputCurrent": "dcdc_input_current",
        "BCScompressorinputvoltage": "bcscompressor_input_voltage",
        "BCScompressorinputcurrent": "bcscompressor_input_current",
        "PumpVoltage": "tcs_voltage",
        "PumpCurrent": "tcs_current",
        "ECompressorInputPower": "ecompressor_input_power",
        "StreeringinputPower": "steering_input_power",
        "batteryTemperature": "battery_temperature",
        "MCUMotorTemperature": "motor_temperature",
        "MCUTemperature": "mcu_temperature",
        "BCSThermistor1": "bcs_thermistor_1",
        "BCSThermistor2": "bcs_thermistor_2",
        "TCSThermistor": "tcs_temperature",
        "SHIMINDUCTORTEMP": "dcdc_temperature",
        "EcompActualHeatSinkTemp": "ecomp_temperature",
        "SteeringActualHeatSinkTemp": "steering_temperature",
        "BrakePedalPosition": "c_soc",
        "A_Pack_Voltage_Value": "a_pack_voltage",
        "B_Pack_Voltage_Value_V": "b_pack_voltage",
        "B_Pack_Current_Value_A": "b_pack_current",
        "A_Pack_Current_Value_A": "a_pack_current",
        "A_SOC_Value_": "a_soc",
        "B_SOC_Value_": "b_soc",
    }

    df.rename(columns=rename_map, inplace=True)

    # --- 1. Normalize column names ---
    df.columns = df.columns.str.strip()

    # --- 2. Timestamp processing ---
    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    df["timestamp"] = df["timestamp"].dt.tz_localize(None).dt.floor("s")  # type: ignore
    df = df.dropna(subset=["timestamp"])

    # --------------------------------------------------------------
    # Battery config by vehicle type
    # --------------------------------------------------------------
    battery_config = {
        "12M": {
            "currents": ["a_pack_current", "b_pack_current"],
            "voltages": ["a_pack_voltage", "b_pack_voltage"],
            "socs": ["a_soc", "b_soc", "c_soc"],
            "voltage_divisor": 3,
        },
        "9M": {
            "currents": ["a_pack_current", "b_pack_current"],
            "voltages": ["a_pack_voltage", "b_pack_voltage"],
            "socs": ["a_soc", "b_soc"],
            "voltage_divisor": None,
        },
        "DEFAULT": {
            "currents": ["a_pack_current"],
            "voltages": ["a_pack_voltage"],
            "socs": ["a_soc"],
            "voltage_divisor": None,
        },
    }

    cfg = battery_config.get(device_type_name, battery_config["DEFAULT"])

    clean_numeric(df, cfg["currents"], round_digits=2)
    clean_numeric(df, cfg["voltages"], round_digits=2)
    clean_numeric(df, cfg["socs"], round_digits=2)

    df["battery_current"] = aggregate_nonzero(df, cfg["currents"], method="sum")

    if cfg["voltage_divisor"]:
        df["battery_voltage"] = (
            df[cfg["voltages"]].sum(axis=1) / cfg["voltage_divisor"]
        ).round(2)
    else:
        df["battery_voltage"] = aggregate_nonzero(df, cfg["voltages"])

    df["soc"] = aggregate_nonzero(df, cfg["socs"])

    # --------------------------------------------------------------
    # TCS energy
    # --------------------------------------------------------------
    clean_numeric(df, ["tcs_voltage", "tcs_current"], round_digits=2)
    df["tcs_energy"] = (df["tcs_voltage"] * df["tcs_current"]).round(2)

    # --------------------------------------------------------------
    # BCS temperature (max non-zero thermistor)
    # --------------------------------------------------------------
    bcs_cols = ["bcs_thermistor_1", "bcs_thermistor_2"]
    df["bcs_temperature"] = (
        df[bcs_cols]
        .apply(pd.to_numeric, errors="coerce")
        .replace(0, np.nan)
        .max(axis=1)
        .fillna(0)
        .astype(int)
    )

    # --------------------------------------------------------------
    # Integer temperature cleanup
    # --------------------------------------------------------------
    clean_numeric(
        df,
        [
            "bcs_thermistor_1",
            "bcs_thermistor_2",
            "battery_temperature",
            "motor_temperature",
            "mcu_temperature",
            "bcs_temperature",
            "tcs_temperature",
            "dcdc_temperature",
            "ecomp_temperature",
            "steering_temperature",
        ],
        dtype=int,
    )

    # --------------------------------------------------------------
    # Final column ordering (safe selection)
    # --------------------------------------------------------------
    # final_cols = [
    #     "device_id",
    #     "device_type",
    #     "device_type_name",
    #     "VRN",
    #     "chassis_number",
    #     "city",
    #     "fleet",
    #     "timestamp",
    #     "ignition",
    #     "vcu_flag",
    #     "speed",
    #     "rpm",
    #     "odometer",
    #     "mcu_high_power_voltage",
    #     "mcu_high_power_current",
    #     "dcdc_input_voltage",
    #     "dcdc_input_current",
    #     "bcscompressor_input_voltage",
    #     "bcscompressor_input_current",
    #     "tcs_energy",
    #     "ecompressor_input_power",
    #     "steering_input_power",
    #     "battery_temperature",
    #     "motor_temperature",
    #     "mcu_temperature",
    #     "bcs_temperature",
    #     "tcs_temperature",
    #     "dcdc_temperature",
    #     "ecomp_temperature",
    #     "steering_temperature",
    #     "soc",
    #     "battery_voltage",
    #     "battery_current",
    # ]

    return df.copy()
