# ─────────────────────────────────────────────
# Excel Utilities (openpyxl)
# ─────────────────────────────────────────────

from openpyxl import load_workbook, Workbook
from openpyxl.comments import Comment
from openpyxl.styles import PatternFill, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet


# ─────────────────────────────────────────────
# 1️⃣ Threshold Highlighting with Comments
# ─────────────────────────────────────────────


def highlight_threshold_cells_with_comments(
    ws: Worksheet,
    thresholds: dict,
    comment_columns: dict,
    start_row: int = 2,
    fill_color: str = "FFC7CE",
    comment_author: str = "AutoCheck",
) -> None:
    """
    Highlight cells crossing thresholds and add contextual comments.

    thresholds:
        {
            column_name: {
                "value": float,
                "operator": ">" | "<" | ">=" | "<="
            }
        }

    comment_columns:
        {
            "distance": "TOTAL_DISTANCE_TRAVELLED(km)",
            "energy": "ENERGY_CONSUMPTION_RATE(kWh/km)",
            "regen": "REGEN_ENERGY(kWh)"
        }
    """

    header_to_col = {
        cell.value: idx + 1 for idx, cell in enumerate(ws[1]) if cell.value
    }

    highlight_fill = PatternFill(
        start_color=fill_color,
        end_color=fill_color,
        fill_type="solid",
    )

    comment_col_idx = {
        key: header_to_col.get(col_name) for key, col_name in comment_columns.items()
    }

    def condition_met(value: float, rule: dict) -> bool:
        op = rule["operator"]
        thr = rule["value"]

        return (
            (op == ">" and value > thr)
            or (op == "<" and value < thr)
            or (op == ">=" and value >= thr)
            or (op == "<=" and value <= thr)
        )

    def safe_cell_value(row: int, col_idx: int | None):
        if not col_idx:
            return "N/A"
        val = ws.cell(row=row, column=col_idx).value
        return val if val is not None else "N/A"

    for col_name, rule in thresholds.items():
        col_idx = header_to_col.get(col_name)
        if not col_idx:
            continue

        for row in range(start_row, ws.max_row + 1):
            cell = ws.cell(row=row, column=col_idx)

            try:
                value = float(str(cell.value).strip())
            except (TypeError, ValueError):
                continue

            if not condition_met(value, rule):
                continue

            cell.fill = highlight_fill

            comment_text = (
                f"Distance (km): {safe_cell_value(row, comment_col_idx.get('distance'))}\n"
                f"Energy (kWh/km): {safe_cell_value(row, comment_col_idx.get('energy'))}\n"
                f"Regen (kWh): {safe_cell_value(row, comment_col_idx.get('regen'))}"
            )

            cell.comment = Comment(comment_text, comment_author)


# ─────────────────────────────────────────────
# 2️⃣ Custom Column Widths
# ─────────────────────────────────────────────


def apply_custom_column_widths(
    worksheet: Worksheet,
    column_widths: dict,
    header_row: int = 1,
    default_width: int | None = 20,
    strict: bool = False,
) -> None:
    """
    Apply column widths based on column headers.
    """

    for col in range(1, worksheet.max_column + 1):
        header = worksheet.cell(row=header_row, column=col).value
        if not header:
            continue

        col_letter = get_column_letter(col)

        if header in column_widths:
            worksheet.column_dimensions[col_letter].width = column_widths[header]
        elif strict:
            raise KeyError(f"Missing width definition for column: '{header}'")
        elif default_width is not None:
            worksheet.column_dimensions[col_letter].width = default_width


# ─────────────────────────────────────────────
# 3️⃣ Autofilter + Freeze Panes
# ─────────────────────────────────────────────


def apply_autofilter_and_freeze(
    ws: Worksheet,
    max_col: int,
    freeze_cell: str = "J2",
) -> None:
    ws.auto_filter.ref = f"A1:{get_column_letter(max_col)}1"
    ws.freeze_panes = freeze_cell


# ─────────────────────────────────────────────
# 4️⃣ Header Formatting
# ─────────────────────────────────────────────


def format_header_row(
    ws: Worksheet,
    max_col: int,
    header_fill,
    thin_border,
) -> None:
    for col in range(1, max_col + 1):
        cell = ws.cell(row=1, column=col)
        cell.fill = header_fill
        cell.alignment = Alignment(
            horizontal="center",
            vertical="center",
            wrap_text=True,
        )
        cell.border = thin_border


# ─────────────────────────────────────────────
# 5️⃣ Zebra Row Formatting
# ─────────────────────────────────────────────


def apply_zebra_rows(
    ws: Worksheet,
    max_row: int,
    max_col: int,
    odd_row_fill,
    even_row_fill,
    thin_border,
) -> None:
    for row in range(2, max_row + 1):
        row_fill = odd_row_fill if row % 2 else even_row_fill

        for col in range(1, max_col + 1):
            cell = ws.cell(row=row, column=col)
            cell.fill = row_fill
            cell.alignment = Alignment(
                horizontal="center",
                vertical="center",
                wrap_text=True,
            )
            cell.border = thin_border


# ─────────────────────────────────────────────
# 6️⃣ Threshold Highlighting (Override Zebra)
# ─────────────────────────────────────────────


def apply_threshold_highlighting(
    ws: Worksheet,
    df,
    temp_cols: list,
    thresholds: dict,
    red_fill,
) -> None:
    for col in temp_cols:
        if col not in thresholds or col not in df.columns:
            continue

        threshold = thresholds[col]
        col_idx = df.columns.get_loc(col) + 1

        for row in range(2, len(df) + 2):
            cell = ws.cell(row=row, column=col_idx)

            try:
                value = float(str(cell.value).strip())
            except (TypeError, ValueError):
                continue

            if value > threshold:
                cell.fill = red_fill
