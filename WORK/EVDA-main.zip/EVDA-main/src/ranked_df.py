import pandas as pd


# ---------------------------
def get_ranked(input_df: pd.DataFrame, desired_cols: list):
    if input_df.empty:
        return pd.DataFrame(columns=["RANKING"] + desired_cols)

    ranked_rows = []
    group_by_col = "PLATFORM"

    for platform, group in input_df.groupby(group_by_col):
        if group.empty:
            continue
        grp = group[~group["TOTAL_DISTANCE_TRAVELLED(km)"].isna()]
        if grp.empty:
            continue

        best_idx = grp["TOTAL_DISTANCE_TRAVELLED(km)"].idxmax()
        trailing_idx = grp["TOTAL_DISTANCE_TRAVELLED(km)"].idxmin()

        best = grp.loc[best_idx].copy()
        best["RANKING"] = "Best Performer"
        ranked_rows.append(best)

        if trailing_idx != best_idx:
            trailing = grp.loc[trailing_idx].copy()
            trailing["RANKING"] = "Trailing Performer"
            ranked_rows.append(trailing)

    ranked_df = pd.DataFrame(ranked_rows)
    # ranked_df.rename(
    #     columns={"VRN": "VRN", "DEPTH_OF_DISCHARGE": "LOW_SOC"}, inplace=True
    # )

    final_cols = ["RANKING"] + [c for c in desired_cols if c in ranked_df.columns]
    return ranked_df[final_cols]
