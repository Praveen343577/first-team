"""
logger.py
A clean, production-ready logging setup for Python applications.

Features
--------
✓ Colored console logging for readability
✓ Daily rotating log files with retention
✓ Separate log levels for console and file
✓ Module-based logging support
✓ Optional UTC timestamps
✓ Prevents duplicate handlers
✓ Easy to reuse across projects

Usage
-----
from logger import setup_logger

setup_logger(log_file="default.log")

import logging
logger = logging.getLogger(__name__)

logger.info("Logger initialized")
logger.debug("Logger initialized")
"""

import logging
import sys
import time
from logging.handlers import TimedRotatingFileHandler


# ─────────────────────────────────────────────
# Console Color Formatter
# ─────────────────────────────────────────────
class ColorFormatter(logging.Formatter):
    """
    Adds ANSI colors to console logs based on log level.
    Improves readability during development.
    """

    COLORS = {
        logging.DEBUG: "\033[94m",  # Blue
        logging.INFO: "\033[92m",  # Green
        logging.WARNING: "\033[93m",  # Yellow
        logging.ERROR: "\033[91m",  # Red
        logging.CRITICAL: "\033[95m",  # Magenta
    }

    RESET = "\033[0m"

    def format(self, record):
        log_color = self.COLORS.get(record.levelno, self.RESET)
        message = super().format(record)
        return f"{log_color}{message}{self.RESET}"


# ─────────────────────────────────────────────
# Logger Setup Function
# ─────────────────────────────────────────────
def setup_logger(
    log_file: str = "default.log",
    console_level: int = logging.INFO,
    file_level: int = logging.DEBUG,
    retention_days: int = 7,
    use_utc: bool = False,
) -> None:
    """
    Configure application-wide logging.

    Parameters
    ----------
    log_file : str
        Path to the main log file.

    console_level : int
        Logging level for console output.

    file_level : int
        Logging level for file logging.

    retention_days : int
        Number of rotated log files to keep.

    use_utc : bool
        Whether timestamps should use UTC instead of local time.
    """

    # Root logger
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)

    # Prevent duplicate handlers if setup_logger() is called multiple times
    if logger.handlers:
        logger.handlers.clear()

    # ─────────────────────────────────────────
    # Log Format
    # ─────────────────────────────────────────
    log_format = (
        "%(asctime)s | %(levelname)-8s | %(name)s | "
        "%(filename)s:%(lineno)d | %(message)s"
    )

    plain_formatter = logging.Formatter(log_format)
    color_formatter = ColorFormatter(log_format)

    # Optional UTC timestamps
    if use_utc:
        plain_formatter.converter = time.gmtime
        color_formatter.converter = time.gmtime

    # ─────────────────────────────────────────
    # Console Handler (Colored)
    # ─────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(console_level)
    console_handler.setFormatter(color_formatter)

    # ─────────────────────────────────────────
    # File Handler (Daily Rotation)
    # ─────────────────────────────────────────
    file_handler = TimedRotatingFileHandler(
        filename=log_file,
        when="midnight",  # rotate every day
        interval=1,
        backupCount=retention_days,
        encoding="utf-8",
    )

    file_handler.setLevel(file_level)
    file_handler.setFormatter(plain_formatter)

    # ─────────────────────────────────────────
    # Register Handlers
    # ─────────────────────────────────────────
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)


# ─────────────────────────────────────────────
# Example Usage
# ─────────────────────────────────────────────
if __name__ == "__main__":

    setup_logger(log_file="default.log")

    logger = logging.getLogger(__name__)

#     logger.debug("Debug message")
#     logger.info("Application started")
#     logger.warning("This is a warning")
#     logger.error("Something went wrong")
#     logger.critical("Critical failure")
