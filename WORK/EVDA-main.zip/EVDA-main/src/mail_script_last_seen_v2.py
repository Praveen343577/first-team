import smtplib
from email.message import EmailMessage
from pathlib import Path
import pandas as pd


def send_email_last_seen_v2(filename, file_path):
    """
    Send an email with an Excel attachment using Outlook SMTP.

    Parameters:
    - file_path (str): Full path to the Excel file
    - to_emails (list): Primary recipients
    - cc_emails (list): CC recipients
    - sender_email (str): Sender Outlook email
    - password (str): App password (NOT normal password)
    """

    # Define Sender Email and Password
    # Email id: notifications.ekaconnect@ekamobility.com
    # Password : Eka@2026
    sender_email = "notifications.ekaconnect@ekamobility.com"
    password = "Eka@2026"

    # Define recipients
    ### SERVICE TEAM EMAIL LIST ###

    to_emails = [
        "arun.jalali@ekamobility.com",
        "shrikrishna.n@ekamobility.com",
        "Amardeep.Sharma@ekamobility.com",
        "Dawood.Elluru@ekamobility.com",
        "Santosh.Namye@ekamobility.com",
        "Sanket.Domb@ekamobility.com",
        "Sairaj.Harmale@ekamobility.com",
        "yogesh.murkute@ekamobility.com",
        "MdFaizan.Ansari@ekamobility.com",
        "Manoj.Kumar@ekamobility.com",
        "Rajat.Ruhela@ekamobility.com",
        "Ankit.Upadhyay@ekamobility.com",
        "Vivek.Chaurasiya@ekamobility.com",
        "Satyaranjan.Barik@ekamobility.com",
        "Abhijit.Das@ekamobility.com",
        "Babloo.Sah@ekamobility.com",
        "rohit.k@ekamobility.com",
        "anup.kumar@ekamobility.com",
        "Hari.Banda@ekamobility.com",
        "Anirban.Hatui@ekamobility.com",
        "Himanshu.K@ekamobility.com",
        "kavya.Joshi@ekamobility.com",
        "Revananth.khule@ekamobility.com",
        "Choppa.Nagendra@ekamobility.com",
        "ramprasad.kv@ekamobility.com",
        "amol.ghodke@ekamobility.com",
        "Altaf.Kamal@ekamobility.com",
        "suresh.prudvi@ekamobility.com",
        "Deepak.Jain@ekamobility.com",
        "Prithwi.Raj@ekamobility.com",
    ]

    cc_emails = [
        "ekavehiclesoftwareanddashboardteam@pinnacleindustries.com",
        "ekaconnect@pinnacleindustries.com",
    ]

    # ---------- 1. Prepare timestamp ----------
    date_str = pd.Timestamp.now().strftime("%Y-%m-%d")

    # ---------- 2. Create email object ----------
    msg = EmailMessage()
    msg["Subject"] = f"Inactive Device Alert Report - {date_str}"
    msg["From"] = sender_email
    msg["To"] = ", ".join(to_emails)
    msg["Cc"] = ", ".join(cc_emails)

    # ---------- 3. Email body (HTML) ----------
    html_body = f"""
    <html>
        <body>
            <p>Dear Team,</p>

            <p>
                Please find attached the <b>Inactive Device Alert Report</b>
                for <b>{date_str}</b>.
            </p>

            <p>
                Kindly verify the device connectivity status.
            </p>

            <br>
            <!-- Signature -->
            <p style="margin:0;">
                <b>Regards,<br>
                EKA Connect (R&D Software Development)</b>
            </p>
        </body>
    </html>
    """

    msg.add_alternative(html_body, subtype="html")

    # ---------- 4. Attach file ----------
    file_path = Path(file_path)

    with file_path.open("rb") as f:
        msg.add_attachment(
            f.read(),
            maintype="application",
            subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename=filename,
        )

    # ---------- 5. Combine recipients ----------
    all_recipients = to_emails + cc_emails

    print("Sending email to:", all_recipients)

    # ---------- 6. Send email ----------
    try:
        with smtplib.SMTP("smtp.office365.com", 587) as server:
            server.starttls()  # Secure connection
            server.login(sender_email, password)
            server.send_message(msg)

        print("✅ Email sent successfully!")

    except smtplib.SMTPAuthenticationError as e:
        print("❌ Authentication failed. Check app password.")
        print(e)

    except Exception as e:
        print("❌ Failed to send email:")
        print(e)
