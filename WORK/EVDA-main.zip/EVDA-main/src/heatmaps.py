import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go


def prepare_x_labels(df: pd.DataFrame) -> pd.Series:
    """
    Prepare x-axis labels using VRN if available, else CHASSIS.
    """
    return df.apply(
        lambda row: (
            row["VRN"]
            if pd.notna(row.get("VRN")) and row["VRN"] != "NA"
            else row.get("CHASSIS", "NA")
        ),
        axis=1,
    )


def get_numeric_columns(df: pd.DataFrame, columns: list) -> list:
    """
    Return only valid numeric columns from a given list.
    """
    return [
        col
        for col in columns
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col])
    ]


# Function with colorscale applied to entire heatmap
# def build_heatmap(
#     df: pd.DataFrame,
#     y_columns: list,
#     title: str,
#     height: int = 700,
#     colorscale=px.colors.sequential.Agsunset,
#     initial_window: int = 10,
# ):
#     """
#     Build a heatmap with dynamic color scaling and readable text overlay.

#     Parameters:
#     - df: DataFrame containing data
#     - y_columns: list of columns to show on y-axis
#     - title: heatmap title
#     - height: figure height in pixels
#     - colorscale: sequential colorscale
#     - initial_window: number of vehicles initially visible

#     Returns:
#     - Plotly Figure
#     """
#     df_hm = df.copy()
#     df_hm["x_label"] = prepare_x_labels(df_hm)

#     # Filter valid columns
#     valid_columns = [c for c in y_columns if c in df_hm.columns]
#     if not valid_columns:
#         return go.Figure(go.Heatmap(z=[[0]]), layout=dict(title=f"{title} (No Data)"))

#     # Prepare z-values and text
#     z_values = np.array([df_hm[col].values for col in valid_columns])
#     text_values = np.array(
#         [df_hm[col].round(1).astype(str).values for col in valid_columns]
#     )

#     if np.isnan(z_values).all():
#         fig = go.Figure(go.Heatmap(z=[[0]]))
#         fig.update_layout(
#             title=f"{title} (No Valid Data)",
#             paper_bgcolor="rgba(0,0,0,0)",
#             plot_bgcolor="rgba(0,0,0,0)",
#             font_color="white",
#         )
#         return fig

#     # Dynamic color scaling
#     z_min, z_max = np.nanmin(z_values), np.nanmax(z_values)
#     z_norm = (z_values - z_min) / (z_max - z_min + 1e-9)

#     # Build text annotations with dynamic color
#     annotations = []
#     for i, row in enumerate(valid_columns):
#         for j, val in enumerate(df_hm["x_label"]):
#             text_color = "white" if z_norm[i, j] < 0.5 else "black"
#             annotations.append(
#                 dict(
#                     x=val,
#                     y=row,
#                     text=text_values[i, j],
#                     font=dict(color=text_color, size=14),
#                     showarrow=False,
#                 )
#             )

#     # Build heatmap
#     fig = go.Figure(
#         data=go.Heatmap(
#             z=z_values,
#             x=df_hm["x_label"],
#             y=valid_columns,
#             colorscale=colorscale,
#             zmin=z_min,
#             zmax=z_max,
#             colorbar=dict(title="Intensity"),
#         )
#     )

#     fig.update_layout(
#         title=title,
#         height=height,
#         paper_bgcolor="rgba(0,0,0,0)",
#         plot_bgcolor="rgba(0,0,0,0)",
#         xaxis=dict(tickangle=-45, automargin=True, range=[-0.5, initial_window - 0.5]),
#         yaxis=dict(automargin=True),
#         annotations=annotations,
#         font_color="white",
#         title_font_color="white",
#     )

#     return fig


# Function with colorscale applied to each row of y axis in the heatmap
def build_heatmap(
    df: pd.DataFrame,
    y_columns: list,
    title: str,
    height: int = 700,
    colorscale=px.colors.sequential.Agsunset,
    initial_window: int = 20,
):
    """
    Build a heatmap with per-row dynamic color scaling and readable text overlay.
    All rows are in a single heatmap trace; text color is adjusted per cell.
    """
    df_hm = df.copy()
    df_hm["x_label"] = prepare_x_labels(df_hm)

    valid_columns = [c for c in y_columns if c in df_hm.columns]
    if not valid_columns:
        return go.Figure(go.Heatmap(z=[[0]]), layout=dict(title=f"{title} (No Data)"))

    z_values = np.array([df_hm[col].values for col in valid_columns])

    if np.isnan(z_values).all():
        fig = go.Figure(go.Heatmap(z=[[0]]))
        fig.update_layout(
            title=f"{title} (No Valid Data)",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font_color="white",
        )
        return fig

    # Normalize each row individually to [0,1] for dynamic coloring
    z_norm = np.zeros_like(z_values, dtype=float)
    for i in range(len(valid_columns)):
        row_min, row_max = np.nanmin(z_values[i]), np.nanmax(z_values[i])
        z_norm[i] = (z_values[i] - row_min) / (row_max - row_min + 1e-9)

    # Build annotations for text with dynamic color
    annotations = []
    for i, row_name in enumerate(valid_columns):
        for j, x_val in enumerate(df_hm["x_label"]):
            text_color = "white" if z_norm[i, j] < 0.5 else "black"
            annotations.append(
                dict(
                    x=x_val,
                    y=row_name,
                    text=str(round(z_values[i, j], 1)),
                    font=dict(color=text_color, size=14),
                    showarrow=False,
                    xanchor="center",
                    yanchor="middle",
                )
            )

    # Single heatmap trace for all rows
    fig = go.Figure(
        go.Heatmap(
            z=z_values,
            x=df_hm["x_label"],
            y=valid_columns,
            colorscale=colorscale,
            zmin=np.nanmin(z_values),
            zmax=np.nanmax(z_values),
            colorbar=dict(title="Intensity"),
            hovertemplate="%{y} | %{x}: %{z}<extra></extra>",
        )
    )

    fig.update_layout(
        title=title,
        height=height,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        xaxis=dict(tickangle=-45, automargin=True, range=[-0.5, initial_window - 0.5]),
        yaxis=dict(automargin=True),
        annotations=annotations,
        font_color="white",
        title_font_color="white",
    )

    return fig


def hhmmss_to_seconds(value):
    """
    Robust conversion of runtime values to seconds.
    Handles:
    - HH:MM:SS
    - 0 days HH:MM:SS
    - datetime.time
    - NaN / invalid values
    """
    if pd.isna(value):
        return np.nan

    # Handle pandas Timedelta
    if isinstance(value, pd.Timedelta):
        return value.total_seconds()

    value = str(value)

    # Handle '0 days HH:MM:SS'
    if "days" in value:
        try:
            time_part = value.split("days")[-1].strip()
            h, m, s = map(int, time_part.split(":"))
            return h * 3600 + m * 60 + s
        except Exception:
            return np.nan

    # Handle normal HH:MM:SS
    if ":" in value:
        try:
            h, m, s = map(int, value.split(":"))
            return h * 3600 + m * 60 + s
        except Exception:
            return np.nan

    return np.nan
