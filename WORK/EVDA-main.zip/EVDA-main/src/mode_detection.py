import numpy as np
import pandas as pd

# Function to detect mode and clean up some data columns


def add_mode_column(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add a 'Mode' column to the given DataFrame, classifying each record into:
    'Charging', 'Movement', 'Idle', or 'Stopped' based on device type and signals.

    Handles two major device categories:
    - Device types: ['3S', '6S']
    - Device types: ['7M', '9M', '12M', '13.5M', '55T']

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame containing telemetry data.

    Returns
    -------
    pd.DataFrame
        A new DataFrame with a 'Mode' column added.
    """

    # --- Initial validation and setup ---
    if df.empty:
        print("Input DataFrame is empty. Returning unchanged DataFrame.")
        return df

    df = df.copy()
    df.sort_values(by="timestamp", inplace=True, ascending=True)

    # Compute SOC delta (State of Charge change)
    df["soc_delta"] = df["soc"].diff().fillna(0)

    # Extract unique device types (for flexible handling if multiple exist)
    device_types = df["device_type_name"].dropna().unique()

    # --- DEVICE TYPE GROUP: 3S / 6S ---
    if np.isin(device_types, ["3S", "6S"]).all():
        # Normalize ignitionstatus
        df["ignition"] = (
            pd.to_numeric(df.get("ignition", pd.Series(0)), errors="coerce")
            .fillna(0)
            .astype(int)
        )

        # Fill or create required columns safely
        df["charger_output_vol"] = pd.to_numeric(
            df.get("charger_output_vol", pd.Series(0)), errors="coerce"
        ).fillna(0)
        df["charger_output_cur"] = pd.to_numeric(
            df.get("charger_output_cur", pd.Series(0)), errors="coerce"
        ).fillna(0)
        df["speed"] = pd.to_numeric(
            df.get("speed", pd.Series(0)), errors="coerce"
        ).fillna(0)

        # --- Mode detection logic ---

        # Charging condition: voltage/current non-zero, charger detected, SOC increased, and stationary
        charging_mask = (
            (df["charger_output_vol"] != 0) | (df["charger_output_cur"] != 0)
        ) | (df["soc_delta"] >= 1)

        # Define movement and idle conditions for readability
        moving_mask = (~charging_mask) & (df["ignition"] == 1) & (df["speed"] > 0)

        idle_mask = (~charging_mask) & (df["ignition"] == 1) & (df["speed"] == 0)

        # Assign Mode using np.select for clarity and efficiency
        df["Mode"] = np.select(
            [charging_mask, moving_mask, idle_mask],
            ["Charging", "Movement", "Idle"],
            default="Stopped",
        )

    # --- DEVICE TYPE GROUP: 7M / 9M / 12M / 13.5M / 55T ---
    elif np.isin(device_types, ["7M", "9M", "12M", "13.5M", "55T"]).all():
        df["Mode"] = "Stopped"

        # Ensure vcu_flag is numeric
        df["vcu_flag"] = (
            pd.to_numeric(df.get("vcu_flag", pd.Series(0)), errors="coerce")
            .fillna(0)
            .astype(int)
        )

        # Flag groups for clarity
        charging_flags = {85, 86, 87, 88, 89, 90, 91, 92, 99}
        movement_flags = {50, 51, 52, 60}

        # Assign modes using vectorized updates
        df.loc[df["vcu_flag"].isin(charging_flags), "Mode"] = "Charging"
        df.loc[df["vcu_flag"].isin(movement_flags), "Mode"] = "Movement"
        df.loc[(df["vcu_flag"] < 50) | (df["vcu_flag"] == 70), "Mode"] = "Idle"

    # --- UNKNOWN DEVICE TYPE ---
    else:
        device_id = df["device_id"].iloc[0] if "device_id" in df.columns else "Unknown"
        print(f"Device ID: {device_id}, Unknown device type(s): {device_types}")
        df["Mode"] = "Unknown"

    return df
