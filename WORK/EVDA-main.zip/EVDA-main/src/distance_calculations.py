# This file contains all the functions for basic data_cleaning operatons for odometer and distance calculations on a df
import pandas as pd
import numpy as np


def clean_df(df: pd.DataFrame) -> pd.DataFrame:
    """
    Apply basic cleaning operations:
    - lower-case column names
    - strip whitespace
    - drop duplicates
    """
    df = df.copy()
    df.columns = df.columns.str.strip().str.lower()
    df = df.drop_duplicates()
    return df


# Function to clean odometer column of a df. the df must have an odometer column and odo_delta column
def longest_valid_sequence(odo, max_delta=50):
    """
    Finds the subsequence with max (end - start)
    where consecutive deltas are <= max_delta.
    """

    best_start = best_end = None
    best_distance = 0

    curr_start = odo.iloc[0]
    last = curr_start

    for val in odo.iloc[1:]:
        if abs(val - last) <= max_delta:
            last = val
        else:
            distance = last - curr_start
            if distance > best_distance:
                best_start = curr_start
                best_end = last
                best_distance = distance

            curr_start = val
            last = val

    # Final check
    distance = last - curr_start
    if distance > best_distance:
        best_start = curr_start
        best_end = last

    return best_start, best_end


# Function to get Distance based on Odometer
def get_valid_odometer_range(
    df,
    max_delta=10,  # max realistic km jump between records
    max_reset_drop=5,  # negative drop considered reset
    ignition_on_values=("1", 1, "ON", "on", True),
):
    """
    Cleans odometer data by:
    - Removing ignition OFF rows
    - Removing glitch spikes (large positive jumps)
    - Handling odometer resets (large negative drops)
    - Preserving timestamp order
    """

    if df.empty:
        return 0.0, 0.0, 0.0

    # Sort by time (CRITICAL)
    df = df.sort_values("timestamp")

    # Filter ignition ON only
    if "ignition" in df.columns:
        df = df[df["ignition"].isin(ignition_on_values)]

    # Convert odometer to numeric
    df["odometer"] = pd.to_numeric(df["odometer"], errors="coerce")

    # Remove invalid values
    df = df[(df["odometer"].notna()) & (df["odometer"] > 0)]

    if df.empty:
        return 0.0, 0.0, 0.0

    odo = df["odometer"]

    # Calculate delta in time order
    delta = odo.diff()

    # ----------------------------
    # 1️⃣ Remove sensor glitch spikes
    # ----------------------------
    # Unrealistic large forward jump
    glitch_mask = delta > max_delta

    # ----------------------------
    # 2️⃣ Detect vehicle reset
    # ----------------------------
    # Large negative drop
    reset_mask = delta < -max_reset_drop

    # Mark invalid rows
    invalid_mask = glitch_mask | reset_mask

    # Remove invalid rows
    odo_clean = odo[~invalid_mask]

    if odo_clean.empty:
        return 0.0, 0.0, 0.0

    # ----------------------------
    # 3️⃣ Calculate total valid distance
    # ----------------------------
    delta_clean = odo_clean.diff()

    # Keep only valid forward increments
    valid_delta = delta_clean[(delta_clean >= 0) & (delta_clean <= max_delta)]

    total_distance = valid_delta.sum()

    start_odo = odo_clean.iloc[0]
    # end_odo = start_odo + total_distance
    end_odo = odo_clean.iloc[-1]

    return start_odo, end_odo, total_distance


# function to get distance from motor_rpm
# km per second per RPM
RPM_TO_DISTANCE = {
    "7M": 0.00824,
    "9M": 0.00809,
    "12M": 0.008895,
    "13.5M": 0.00890,
    "55T": 0.01024,
    "6S": 0.003030,
    "3S": 0.003030,
}


def get_distance_from_rpm(
    device_type_name,
    df: pd.DataFrame,
    *,
    max_rpm: int = 8000,
    max_dt: float = 180.0,
    min_dt: float = 0.02,
) -> float:
    """
    Calculate distance travelled (km) from motor RPM telemetry.

    Physics:
        distance_i = rpm_i × factor × Δt_i

    Safety guards:
    - Excludes idle RPM
    - Drops absurd RPM spikes
    - Removes telemetry gaps
    - Handles missing / malformed rows safely
    """

    # 1️⃣ Vehicle-specific conversion factor
    factor = RPM_TO_DISTANCE.get(device_type_name)
    if factor is None or df.empty:
        return 0.0

    # 2️⃣ Movement only (idle RPM ≠ distance)
    df = df.loc[df["Mode"] == "Movement"].copy()
    if df.empty:
        return 0.0

    # 3️⃣ Sanitize telemetry
    df["rpm"] = pd.to_numeric(df["rpm"], errors="coerce").abs()
    df["dt"] = pd.to_numeric(df["time_difference"], errors="coerce")

    df = df.dropna(subset=["rpm", "dt"])

    # 4️⃣ Safety guards (noise protection)
    df = df[
        (df["rpm"] > 0)
        & (df["rpm"] <= max_rpm)
        & (df["dt"] >= min_dt)
        & (df["dt"] <= max_dt)
    ]

    if df.empty:
        return 0.0

    # 5️⃣ Row-wise physical integration
    # Compute per-row distance (convert meters → km)
    df["distance_rpm"] = df["rpm"] * factor * df["dt"] / 1000.0

    # 6️⃣ Aggregate
    return round(df["distance_rpm"].sum(), 2)
