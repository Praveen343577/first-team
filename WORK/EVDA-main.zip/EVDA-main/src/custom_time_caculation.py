import numpy as np
import pandas as pd


# --- Define a fast vectorized time formatter  - for scalar value ---
def seconds_to_hhmmss_scalar(seconds):
    if seconds is None or pd.isna(seconds):
        return "00:00:00"

    seconds = int(seconds)
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


# --- Define a fast vectorized time formatter  - for dataframe series ---
def seconds_to_hhmmss_series(seconds: pd.Series) -> pd.Series:
    """Convert seconds (float/int) to HH:MM:SS string representation efficiently."""
    seconds = seconds.astype(int)
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    return (
        hours.astype(str).str.zfill(2)
        + ":"
        + minutes.astype(str).str.zfill(2)
        + ":"
        + secs.astype(str).str.zfill(2)
    )


# Add movement time and idle time columns to the dfs
def custom_time_calculate(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add movement, idle, and formatted time duration columns to a telemetry DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Input DataFrame with at least ['timestamp', 'Mode', 'Time_difference_seconds'].

    Returns
    -------
    pd.DataFrame
        A copy of the input DataFrame with additional duration and formatted time columns.
    """
    if df.empty:
        print("Input DataFrame is empty. Returning unchanged DataFrame.")
        return df

    df = df.copy()
    df.sort_values(by="timestamp", inplace=True, ascending=True)

    # --- Step 1: Ensure numeric Time_difference_seconds ---
    df["time_difference"] = pd.to_numeric(
        df.get("time_difference", pd.Series(0)), errors="coerce"
    ).fillna(0)

    # --- Step 2: Calculate idle and movement durations ---
    df["idle_duration"] = np.where(df["Mode"] == "Idle", df["time_difference"], 0)
    df["movement_duration"] = np.where(
        df["Mode"] == "Movement", df["time_difference"], 0
    )

    df["charging_duration"] = np.where(
        df["Mode"] == "Charging", df["time_difference"], 0
    )

    df["stoppage_duration"] = np.where(
        df["Mode"] == "Stopped", df["time_difference"], 0
    )

    # --- Step 3: Rename column for consistency ---
    # df.rename(columns={"time_difference": "time_duration"}, inplace=True)

    # --- Step 5: Apply formatter to all time-based columns ---
    # df["time_duration (HH:MM:SS)"] = seconds_to_hhmmss(df["time_duration"])
    # df["idle_time_duration (HH:MM:SS)"] = seconds_to_hhmmss(df["idle_duration"])
    # df["movement_time_duration (HH:MM:SS)"] = seconds_to_hhmmss(df["movement_duration"])
    # df["charging_time_duration (HH:MM:SS)"] = seconds_to_hhmmss(df["charging_duration"])
    # df["stoppage_time_duration (HH:MM:SS)"] = seconds_to_hhmmss(df["stoppage_duration"])

    return df
