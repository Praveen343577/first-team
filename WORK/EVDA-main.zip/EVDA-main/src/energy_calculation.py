import numpy as np
import pandas as pd
from typing import Dict, Any

# Functions for energy calculations

# -------------------------------------------------------------
# Helper Functions
# -------------------------------------------------------------


def _initialize_energy_metrics() -> Dict[str, Any]:
    """Return a blank energy metrics dictionary."""
    return {
        "energy_consumed": 0.0,
        "regen": 0.0,
        "energy_consumption_rate": 0.0,
        "soc_sum": 0.0,
        "distance_per_soc": 0.0,
        "charging_units": 0.0,
        "insufficient_charge": False,
        "dod": False,
        "motor_energy": 0.0,
        "motor_regen": 0.0,
        "dcdc_energy": 0.0,
        "ecomp_steering_energy": 0.0,
        "bcs_energy": 0.0,
        "tcs_energy": 0.0,
    }


def _compute_generic_energy_columns(
    device_id: str,
    df: pd.DataFrame,
    scale_voltage: float = 1.0,
    scale_current: float = 1.0,
):
    """
    Compute energy (kWh) and regen columns.
    scale_voltage, scale_current allow reuse for 3W vs 4W.
    """

    # if len(device_id) < 15:
    #     # discharge
    #     # mask = df["Mode"].isin(["Movement", "Idle"])
    #     # df.loc[mask, "battery_current"] = df.loc[mask, "battery_current"].abs()
    #     # df.loc[mask, "battery_current"] *= -1

    #     # charging
    #     mask = df["Mode"] == "Charging"
    #     df.loc[mask, "battery_current"] = df.loc[mask, "battery_current"].abs()

    df["energy"] = (
        (df["battery_voltage"] / scale_voltage)
        * (df["battery_current"] / scale_current)
        * (df["time_difference"] / 3_600_000)
    )

    # Positive energy means regeneration
    df["regen"] = df["energy"].clip(lower=0)

    # Make regen 30% of energy consumned
    # if len(device_id) < 15:
    #     df["regen"] = 0.30 * df["energy"]

    # Motor Energy
    df["motor_energy"] = (
        (df["mcu_high_power_voltage"] / scale_voltage)
        * (df["mcu_high_power_current"] / scale_current)
        * (df["time_difference"] / 3_600_000)
    )

    # DCDC Energy
    df["dcdc_energy"] = (
        (df["dcdc_input_voltage"] / scale_voltage)
        * (df["dcdc_input_current"] / scale_current)
        * (df["time_difference"] / 3_600_000)
    )

    # BCS Energy
    df["bcs_energy"] = (
        (df["bcscompressor_input_current"] / scale_current)
        * (df["bcscompressor_input_voltage"] / scale_voltage)
        * (df["time_difference"] / 3_600_000)
    )

    # TCS Energy
    df["tcs_energy"] = (df["tcs_energy"]) * (df["time_difference"] / 3_600_000)

    # Ecomp and Steering Energy
    df["ecomp_energy"] = (df["ecompressor_input_power"]) * (
        df["time_difference"] / 3_600_000
    )
    df["steering_energy"] = (df["steering_input_power"]) * (
        df["time_difference"] / 3_600_000
    )

    return df


def _compute_distance_per_soc(discharge_df: pd.DataFrame, distance: float):
    """Compute distance per SOC drop."""
    discharge_df["soc_delta"] = discharge_df["soc_delta"].abs()
    soc_sum = discharge_df["soc_delta"].sum()
    distance_per_soc = (distance / soc_sum) if soc_sum else 0.0
    return distance_per_soc, soc_sum


def _check_dod(discharge_df: pd.DataFrame) -> bool:
    """Return True if SOC drops below 20 at any point."""
    return (discharge_df["soc"].min() if not discharge_df.empty else 100) < 20


def _check_insufficient_charge(charge_df: pd.DataFrame) -> bool:
    """Flag insufficient charge if SOC never exceeded 90%."""
    return not (charge_df["soc"].max() if not charge_df.empty else 0) > 90


# -------------------------------------------------------------
# 3W VEHICLE ENERGY CALCULATION
# -------------------------------------------------------------


def energy_calculation_3w(
    device_id: str, df: pd.DataFrame, distance_odo, distance_rpm
) -> Dict[str, Any]:
    """
    Compute energy metrics for 3W vehicles.
    Voltage scaled by 10000, Current by 1000.
    """
    metrics = _initialize_energy_metrics()

    # Compute energy (kWh) and regen
    df = _compute_generic_energy_columns(
        device_id, df, scale_voltage=10_000, scale_current=1_000
    )

    # Charging energy
    charge_df = df.loc[df["Mode"] == "Charging"]
    metrics["charging_units"] = charge_df["energy"].sum()
    metrics["insufficient_charge"] = _check_insufficient_charge(charge_df)

    # Discharging rows (vehicle in use, not charging)
    discharge_df = df.loc[(df["Mode"] != "Charging") & (df["ignition"] == 1)].copy()

    # Distance per SOC drop
    metrics["distance_per_soc"], metrics["soc_sum"] = _compute_distance_per_soc(
        discharge_df, distance_odo
    )

    metrics["energy_consumed"] = discharge_df["energy"].sum()
    metrics["regen"] = discharge_df["regen"].sum()

    # Energy consumption per km
    ecr = 0.0
    distance = 0.0
    # Calculate ECR
    TARGET_ECR = 0.08

    if distance_odo > 0 or distance_rpm > 0:
        consumed = abs(metrics["energy_consumed"])
        regen = abs(metrics["regen"])
        # net_energy = max(consumed + regen, 0)

        candidates = []

        if distance_odo:
            ecr1 = round((consumed + regen) / distance_odo, 4)
            # priority 0 → preferred
            candidates.append((ecr1, distance_odo, 0))

        if distance_rpm:
            ecr2 = round((consumed + regen) / distance_rpm, 4)
            # priority 1 → less preferred
            candidates.append((ecr2, distance_rpm, 1))

        if candidates:
            ecr, distance, _ = min(
                candidates, key=lambda x: (abs(x[0] - TARGET_ECR), x[2])
            )
        else:
            ecr, distance = 0.0, 0.0

        # Get other ECR if min one is not correct
        if ecr < 0.06 or ecr > 0.29:
            if candidates:
                ecr, distance, _ = max(
                    candidates, key=lambda x: (abs(x[0] - TARGET_ECR))
                )
            else:
                ecr, distance = 0.0, 0.0

        # SOC SUM Fallback in case energy values are not proper
        if ecr < 0.06 or ecr > 0.29:
            net_energy = (metrics["soc_sum"] / 100) * 16
            # Calculate ECR
            TARGET_ECR = 0.08

            candidates = []

            if distance_odo:
                ecr1 = round((net_energy) / distance_odo, 4)
                # priority 0 → preferred
                candidates.append((ecr1, distance_odo, 0))

            if distance_rpm:
                ecr2 = round((net_energy) / distance_rpm, 4)
                # priority 1 → less preferred
                candidates.append((ecr2, distance_rpm, 1))

            if candidates:
                ecr, distance, _ = min(
                    candidates, key=lambda x: (abs(x[0] - TARGET_ECR), x[2])
                )
            else:
                ecr, distance = 0.0, 0.0

        metrics["energy_consumption_rate"] = ecr

    # Motor Energy
    metrics["motor_energy"] = discharge_df.loc[
        discharge_df["motor_energy"] > 0, "motor_energy"
    ].sum()
    metrics["motor_regen"] = discharge_df.loc[
        discharge_df["motor_energy"] < 0, "motor_energy"
    ].sum()

    # DCDC Energy
    metrics["dcdc_energy"] = discharge_df["dcdc_energy"].sum()

    # BCS Energy
    metrics["bcs_energy"] = discharge_df["bcs_energy"].sum()

    # TCS Energy
    metrics["tcs_energy"] = discharge_df["tcs_energy"].sum()

    # Ecomp and Steering Energy
    metrics["ecomp_steering_energy"] = (
        discharge_df["ecomp_energy"].sum() + discharge_df["steering_energy"].sum()
    )

    # Depth of Discharge
    metrics["dod"] = _check_dod(discharge_df)

    return metrics


# -------------------------------------------------------------
# 4W VEHICLE ENERGY CALCULATION
# -------------------------------------------------------------
from typing import Mapping

# Battery capacity (kWh) by device type
BATTERY_CAPACITY_KWH: Mapping[str, float] = {
    "12M": 240.0,
    "9M": 160.0,
    "7M": 80.0,
    "55T": 338.4,
    "13.5M": 368.8,
}


def calculate_net_energy(
    device_type_name,
    soc_sum: float,
) -> float:
    """
    Calculate net energy (kWh) based on SOC aggregation and device type.

    Args:
        device_type_name: Vehicle / device model identifier.
        soc_sum: Aggregated SOC value (0–100 scale).

    Returns:
        Net energy in kWh. Returns 0.0 for unknown device types.
    """
    capacity = BATTERY_CAPACITY_KWH.get(device_type_name)

    if capacity is None:
        # Unknown device type → fail safe
        return 0.0

    return (soc_sum / 100.0) * capacity


def energy_calculation_4w(
    device_id: str, device_type_name, df: pd.DataFrame, distance_odo, distance_rpm
) -> Dict[str, Any]:
    """
    Compute energy metrics for 4W vehicles.
    Normal scaling (no division).
    """
    metrics = _initialize_energy_metrics()

    # Compute energy & regen (no scaling for 4W)
    df = _compute_generic_energy_columns(device_id, df)

    # Charging energy
    charge_df = df.loc[df["Mode"] == "Charging"]
    metrics["charging_units"] = charge_df["energy"].sum()
    metrics["insufficient_charge"] = _check_insufficient_charge(charge_df)

    # Discharging rows — include VCU flag condition
    discharge_df = df.loc[
        (df["Mode"] != "Charging") & (df["ignition"] == 1) & (df["vcu_flag"] >= 13)
    ].copy()

    metrics["energy_consumed"] = discharge_df["energy"].sum()
    metrics["regen"] = discharge_df["regen"].sum()

    # Motor Energy
    metrics["motor_energy"] = discharge_df.loc[
        discharge_df["motor_energy"] > 0, "motor_energy"
    ].sum()
    metrics["motor_regen"] = discharge_df.loc[
        discharge_df["motor_energy"] < 0, "motor_energy"
    ].sum()

    # DCDC Energy
    metrics["dcdc_energy"] = discharge_df["dcdc_energy"].sum()

    # BCS Energy
    metrics["bcs_energy"] = discharge_df["bcs_energy"].sum()

    # TCS Energy
    metrics["tcs_energy"] = discharge_df["tcs_energy"].sum()

    # Ecomp and Steering Energy
    metrics["ecomp_steering_energy"] = (
        discharge_df["ecomp_energy"].sum() + discharge_df["steering_energy"].sum()
    )

    # Energy consumption rate
    ecr = 0.0
    distance = 0.0
    TARGET_ECR = 1.0
    consumed = abs(metrics["energy_consumed"])
    regen = abs(metrics["regen"])
    energy_component_wise = round(
        abs(
            abs(metrics["motor_energy"])
            + abs(metrics["dcdc_energy"])
            + abs(metrics["bcs_energy"])
            + abs(metrics["tcs_energy"])
            + abs(metrics["ecomp_steering_energy"])
        ),
        2,
    )

    if distance_odo > 0 or distance_rpm > 0:

        candidates = []

        if distance_odo > 0:
            ecr1 = round((consumed + regen) / distance_odo, 4)
            ecr3 = round(energy_component_wise / distance_odo, 4)

            # priority 0 → ODO (preferred)
            candidates.append((ecr1, distance_odo, 0))
            candidates.append((ecr3, distance_odo, 0))

        if distance_rpm > 0:
            ecr2 = round((consumed + regen) / distance_rpm, 4)
            ecr4 = round(energy_component_wise / distance_rpm, 4)

            # priority 1 → RPM (less preferred)
            candidates.append((ecr2, distance_rpm, 1))
            candidates.append((ecr4, distance_rpm, 1))

        if candidates:
            ecr, distance, _ = min(
                candidates, key=lambda x: (abs(x[0] - TARGET_ECR), x[2])
            )
        else:
            ecr, distance = 0.0, 0.0

        # if ecr < 0.70 or ecr > 2.5:
        #     if candidates:
        #         ecr, distance, _ = min(
        #             candidates, key=lambda x: (abs(x[0] - TARGET_ECR), x[2])
        #         )
        #     else:
        #         ecr, distance = 0.0, 0.0

        # SOC SUM Fallback in case energy values are not proper
        # Distance per SOC drop
        metrics["distance_per_soc"], metrics["soc_sum"] = _compute_distance_per_soc(
            discharge_df, distance
        )
        if ecr < 0.70 or ecr > 2.5:

            net_energy = 0.0
            net_energy = calculate_net_energy(
                device_type_name=device_type_name,
                soc_sum=metrics["soc_sum"],
            )

            candidates = []

            if distance_odo > 0:
                ecr1 = round((net_energy) / distance_odo, 4)
                ecr3 = round(energy_component_wise / distance_odo, 4)

                # priority 0 → ODO (preferred)
                candidates.append((ecr1, distance_odo, 0))
                candidates.append((ecr3, distance_odo, 0))

            if distance_rpm > 0:
                ecr2 = round((net_energy) / distance_rpm, 4)
                ecr4 = round(energy_component_wise / distance_rpm, 4)

                # priority 1 → RPM (less preferred)
                candidates.append((ecr2, distance_rpm, 1))
                candidates.append((ecr4, distance_rpm, 1))

            if candidates:
                ecr, distance, _ = min(
                    candidates, key=lambda x: (abs(x[0] - TARGET_ECR), x[2])
                )
            else:
                ecr, distance = 0.0, 0.0

        metrics["energy_consumption_rate"] = round(ecr, 4)

    # Distance per SOC drop
    metrics["distance_per_soc"], metrics["soc_sum"] = _compute_distance_per_soc(
        discharge_df, distance
    )

    # Depth of Discharge
    metrics["dod"] = _check_dod(discharge_df)

    return metrics
