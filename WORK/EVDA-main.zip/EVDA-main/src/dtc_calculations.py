import numpy as np
import pandas as pd
import re
from typing import List, Tuple, Dict


# Function to get the DTC Count and DTC List
def get_dtc_summary(df):
    dtc_pairs = [
        ("vcu_dtc", "vcu_dtc_1", "vcu_dtc_2"),
        ("bms_dtc", "bms_dtc_1", "bms_dtc_2"),
        ("mcu_dtc", "mcu_dtc_1", "mcu_dtc_2"),
        ("evcc_dtc", "evcc_dtc_1", "evcc_dtc_2"),
        ("dcdc_dtc", "dcdc_dtc_1", "dcdc_dtc_2"),
        ("tcs_dtc", "tcs_dtc_1", "tcs_dtc_2"),
        ("hvac_bcs_dtc", "hvac_bcs_dtc_1", "hvac_bcs_dtc_2"),
        ("ic_mux_dtc", "ic_mux_dtc_1", "ic_mux_dtc_2"),
    ]

    dtc_faults = []

    for prefix, col1, col2 in dtc_pairs:
        if col1 not in df.columns or col2 not in df.columns:
            continue

        pair_df = df[[col1, col2]].dropna(how="all")

        # Create "90.92" format
        combined = pair_df[col1].astype(str) + "." + pair_df[col2].astype(str)

        # Remove "00.00" or "0.0"
        combined = combined[~combined.isin(["00.00", "0.0"])]

        # Add ECU prefix
        faults = prefix + ": " + combined
        dtc_faults.extend(faults.tolist())

    # No valid DTCs found
    if not dtc_faults:
        return 0, ["00.00"]

    # Unique values
    dtc_list = sorted(set(dtc_faults))
    dtc_count = len(dtc_list)

    return dtc_count, dtc_list


# Function to get Fault list and Fault count
def get_fault_summary(df: pd.DataFrame) -> Tuple[int, List[str]]:
    """
    Detect faults based on column names and values.

    A column is considered a fault column if its name contains
    any fault-related keyword (case-insensitive).
    Any non-zero and non-null value in such columns indicates a fault.
    """

    if df.empty:
        return 0, ["NO_FAULT"]

    # Fault-related keywords (case-insensitive)
    fault_pattern = re.compile(r"(flt|fault|alarm|alert)", re.IGNORECASE)

    # Identify fault columns
    fault_cols = [col for col in df.columns if fault_pattern.search(col)]

    if not fault_cols:
        return 0, ["NO_FAULT"]

    detected_faults = []

    for col in fault_cols:
        series = pd.to_numeric(df[col], errors="coerce")

        # Any non-zero, non-null value means fault present
        if (series.fillna(0) != 0).any():
            detected_faults.append(col)

    if not detected_faults:
        return 0, ["NO_FAULT"]

    fault_list = sorted(set(detected_faults))
    return len(fault_list), fault_list


# Above two functions Combined together
def get_health_report(df: pd.DataFrame) -> Dict[str, object]:
    """
    Generate a combined DTC and Fault health report from telemetry data.
    """

    if df.empty:
        return {
            "dtc_count": 0,
            "dtc_list": ["00.00"],
            "fault_count": 0,
            "fault_list": ["NO_FAULT"],
            "total_issues": 0,
            "health_status": "HEALTHY",
        }

    # ------------------------------------------------------------------
    # DTC CONFIGURATION
    # ------------------------------------------------------------------
    dtc_pairs = [
        ("vcu_dtc", "vcu_dtc_1", "vcu_dtc_2"),
        ("bms_dtc", "bms_dtc_1", "bms_dtc_2"),
        ("mcu_dtc", "mcu_dtc_1", "mcu_dtc_2"),
        ("evcc_dtc", "evcc_dtc_1", "evcc_dtc_2"),
        ("dcdc_dtc", "dcdc_dtc_1", "dcdc_dtc_2"),
        ("tcs_dtc", "tcs_dtc_1", "tcs_dtc_2"),
        ("hvac_bcs_dtc", "hvac_bcs_dtc_1", "hvac_bcs_dtc_2"),
        ("ic_mux_dtc", "ic_mux_dtc_1", "ic_mux_dtc_2"),
    ]

    dtc_faults: List[str] = []

    for prefix, col1, col2 in dtc_pairs:
        if col1 not in df.columns or col2 not in df.columns:
            continue

        pair_df = df[[col1, col2]].dropna(how="all")
        if pair_df.empty:
            continue

        combined = pair_df[col1].astype(str) + "." + pair_df[col2].astype(str)

        combined = combined[~combined.isin({"00.00", "0.0", "0.00"})]
        dtc_faults.extend((prefix + ": " + combined).tolist())

    dtc_list = sorted(set(dtc_faults)) if dtc_faults else ["00.00"]
    dtc_count = 0 if dtc_list == ["00.00"] else len(dtc_list)

    # ------------------------------------------------------------------
    # FAULT / ALARM CONFIGURATION
    # ------------------------------------------------------------------
    fault_pattern = re.compile(r"(flt|fault|alarm|alert)", re.IGNORECASE)

    fault_cols = [col for col in df.columns if fault_pattern.search(col)]

    detected_faults: List[str] = []

    for col in fault_cols:
        series = pd.to_numeric(df[col], errors="coerce")

        if (series.fillna(0) != 0).any():
            detected_faults.append(col)

    fault_list = sorted(set(detected_faults)) if detected_faults else ["NO_FAULT"]
    fault_count = 0 if fault_list == ["NO_FAULT"] else len(fault_list)

    # ------------------------------------------------------------------
    # FINAL HEALTH STATUS
    # ------------------------------------------------------------------
    total_issues = dtc_count + fault_count
    health_status = "UNHEALTHY" if total_issues > 0 else "HEALTHY"

    return {
        "dtc_count": dtc_count,
        "dtc_list": dtc_list,
        "fault_count": fault_count,
        "fault_list": fault_list,
        "total_issues": total_issues,
        "health_status": health_status,
    }
