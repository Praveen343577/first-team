import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os

# html format for the R&D report
service_html_format = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body style="margin:0; padding:0; font-family:Arial, sans-serif; font-size:14px; color:#333333; background:#ffffff;">

<!-- Outer full-width wrapper -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="background:#ffffff;">
<tr>
<td align="center">

    <!-- Main centered container -->
    <table width="100%" border="0" cellspacing="0" cellpadding="20" style="border:1px solid #dddddd; background:#ffffff;">
    <tr>
    <td style="font-size:14px; line-height:1.6;">

        <!-- Greeting -->
        <p style="margin:0;">Hello Team,</p>
        <br>

        <p style="margin:0;">
            Please find attached the 
            <b>Daily Performance Summary Report</b> for 
            <span style="font-weight:bold; color:#007bff;">{{Report_Date}}</span>.
        </p>
        <br>

        <p style="margin:0;">
            A brief overview is provided below for your quick reference, and the comprehensive analysis is available in the attached document.
        </p>

        <br>

        <!-- ============================= -->
        <!--       TOP VEHICLES SECTION RP    -->
        <!-- ============================= -->
        <span style="font-weight:bold; color:#007bff;">ROADPOINT VTS</span>
        <p style="margin:0; font-size:16px; font-weight:bold;">Top Vehicles :</p>
        <br>

        <div style="width:100%; overflow-x:auto;">
            {{top_vehicle_table_rp}}
        </div>

        <br><br>

        <!-- ============================= -->
        <!--    TRAILING VEHICLES SECTION RP  -->
        <!-- ============================= -->
        <p style="margin:0; font-size:16px; font-weight:bold;">Trailing Vehicles: </p>
        <br>

        <div style="width:100%; overflow-x:auto;">
            {{trailing_vehicle_table_rp}}
        </div>
        <br>
        <!-- ============================= -->
        <!--       TOP VEHICLES SECTION  MMI   -->
        <!-- ============================= -->
        <span style="font-weight:bold; color:#007bff;">MAP-MY-INDIA*</span>
        <p style="margin:0;">
            NOTE: For MMI Vehicles Data may not be completely accurate due to inconsistencies in data received.
        </p>
        <p style="margin:0; font-size:16px; font-weight:bold;">Top Vehicles :</p>
        <br>

        <div style="width:100%; overflow-x:auto;">
            {{top_vehicle_table_mmi}}
        </div>

        <br><br>

        <!-- ============================= -->
        <!--    TRAILING VEHICLES SECTION MMI  -->
        <!-- ============================= -->
        <p style="margin:0; font-size:16px; font-weight:bold;">Trailing Vehicles: </p>
        <br>

        <div style="width:100%; overflow-x:auto;">
            {{trailing_vehicle_table_mmi}}
        </div>

        <br><br>

        <p style="margin:0;">
            The report highlights key operational metrics including distance covered, energy efficiency, idle durations, and overall performance indicators.
        </p>

        <br>

        <!-- Signature -->
        <p style="margin:0;">
            <b>Regards,<br>
            EKA Connect (R&D Software Development)</b>
        </p>

    </td>
    </tr>
    </table>

</td>
</tr>
</table>

</body>
</html>
"""

# html format for the service report
rd_html_format = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
</head>

<body style="margin:0; padding:0; font-family:Arial, sans-serif; font-size:16px; color:#333333; background:#ffffff;">

<!-- Outer full-width wrapper -->
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="background:#ffffff;">
<tr>
<td align="center">

    <!-- Main centered container -->
    <table width="100%" border="0" cellspacing="0" cellpadding="20" 
           style="border:1px solid #dddddd; background:#ffffff;">
    <tr>
    <td style="font-size:16px; line-height:1.6;">

        <!-- Greeting -->
        <p style="margin:0;">Dear Sir,</p>
        <br>

        <p style="margin:0;">
            Please find attached the 
            <b>Daily Performance Summary Report</b> for 
            <span style="font-weight:bold; color:#007bff;">{{Report_Date}}</span>.
        </p>
        <br>

        <p style="margin:0;">
            The report highlights key operational metrics including distance covered,
            energy efficiency, idle durations, and overall performance indicators.
        </p>

        <p style="margin:0;">
            A brief overview is provided below for your quick reference.
        </p>

        <br>

        <!-- ============================= -->
        <!--       TOP VEHICLES SECTION RP    -->
        <!-- ============================= -->
        <span style="font-weight:bold; color:#007bff;">ROADPOINT VTS</span>
        <p style="margin:0; font-size:16px; font-weight:bold;">Top Vehicles:</p>
        <br>

        <!-- Insert fully styled top table -->
        <div style="width:100%; overflow-x:auto;">
            {{top_vehicle_table_rp}}
        </div>

        <br><br>

        <!-- ============================= -->
        <!--    TRAILING VEHICLES SECTION RP  -->
        <!-- ============================= -->
        <p style="margin:0; font-size:16px; font-weight:bold;">Trailing Vehicles:</p>
        <br>

        <!-- Insert fully styled trailing table -->
        <div style="width:100%; overflow-x:auto;">
            {{trailing_vehicle_table_rp}}
        </div>
        <br>

        <!-- ============================= -->
        <!--       TOP VEHICLES SECTION  MMI   -->
        <!-- ============================= -->
        <span style="font-weight:bold; color:#007bff;">MAP-MY-INDIA*</span>
        <p style="margin:0;">
            NOTE: For MMI Vehicles Data may not be completely accurate due to inconsistencies in data received.
        </p>
        <p style="margin:0; font-size:16px; font-weight:bold;">Top Vehicles:</p>
        <br>

        <!-- Insert fully styled top table -->
        <div style="width:100%; overflow-x:auto;">
            {{top_vehicle_table_mmi}}
        </div>

        <br><br>

        <!-- ============================= -->
        <!--    TRAILING VEHICLES SECTION MMI  -->
        <!-- ============================= -->
        <p style="margin:0; font-size:16px; font-weight:bold;">Trailing Vehicles:</p>
        <br>

        <!-- Insert fully styled trailing table -->
        <div style="width:100%; overflow-x:auto;">
            {{trailing_vehicle_table_mmi}}
        </div>

        <br><br>

        <!-- Signature -->
        <p style="margin:0;">
            <b>Regards,<br>
            EKA Connect (R&D Software Development)</b>
        </p>

    </td>
    </tr>
    </table>

</td>
</tr>
</table>

</body>
</html>
"""


### For Service Email only ###
def send_email_to_service(
    html_for,
    report_name,
    report_date,
    top_vehicle_table_mmi,
    trailing_vehicle_table_mmi,
    top_vehicle_table_rp,
    trailing_vehicle_table_rp,
):
    # Create the email
    msg = MIMEMultipart()

    # Email id: notifications.ekaconnect@ekamobility.com
    # Password : Eka@2026

    msg["From"] = "notifications.ekaconnect@ekamobility.com"
    ### SERVICE TEAM EMAIL LIST ###

    to_emails = [
        "arun.jalali@ekamobility.com",
        "shrikrishna.n@ekamobility.com",
        "Amardeep.Sharma@ekamobility.com",
        "Dawood.Elluru@ekamobility.com",
        "Santosh.Namye@ekamobility.com",
        "Sanket.Domb@ekamobility.com",
        "Sairaj.Harmale@ekamobility.com",
        "yogesh.murkute@ekamobility.com",
        "MdFaizan.Ansari@ekamobility.com",
        "Manoj.Kumar@ekamobility.com",
        "Rajat.Ruhela@ekamobility.com",
        "Ankit.Upadhyay@ekamobility.com",
        "Vivek.Chaurasiya@ekamobility.com",
        "Satyaranjan.Barik@ekamobility.com",
        "Abhijit.Das@ekamobility.com",
        "Babloo.Sah@ekamobility.com",
        "rohit.k@ekamobility.com",
        "anup.kumar@ekamobility.com",
        "Hari.Banda@ekamobility.com",
        "Anirban.Hatui@ekamobility.com",
        "Himanshu.K@ekamobility.com",
        "kavya.Joshi@ekamobility.com",
        "Revananth.khule@ekamobility.com",
        "Choppa.Nagendra@ekamobility.com",
        "ramprasad.kv@ekamobility.com",
        "amol.ghodke@ekamobility.com",
        "Altaf.Kamal@ekamobility.com",
        "suresh.prudvi@ekamobility.com",
        "Deepak.Jain@ekamobility.com",
        "Prithwi.Raj@ekamobility.com",
    ]

    cc_emails = [
        "ekavehiclesoftwareanddashboardteam@pinnacleindustries.com",
        "ekaconnect@pinnacleindustries.com",
    ]

    msg["To"] = ", ".join(to_emails)

    msg["Cc"] = ", ".join(cc_emails)
    # Email body
    html_body = ""

    if html_for == "rd_html":
        msg["Subject"] = (
            f"Daily Status Report of Testing and Proto Vehicles for {report_date}"
        )
        html_body = rd_html_format

    elif html_for == "service_html":
        msg["Subject"] = f"Daily MIS Report for {report_date}"
        html_body = service_html_format

    html_body = html_body.replace("{{Report_Date}}", report_date)
    html_body = html_body.replace("{{top_vehicle_table_rp}}", top_vehicle_table_rp)
    html_body = html_body.replace(
        "{{trailing_vehicle_table_rp}}", trailing_vehicle_table_rp
    )
    html_body = html_body.replace("{{top_vehicle_table_mmi}}", top_vehicle_table_mmi)
    html_body = html_body.replace(
        "{{trailing_vehicle_table_mmi}}", trailing_vehicle_table_mmi
    )

    msg.attach(MIMEText(html_body, "html"))

    # File to attach
    file_path = report_name
    filename = os.path.basename(file_path)

    # Open file in binary mode
    with open(file_path, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())

    encoders.encode_base64(part)
    part.add_header(
        "Content-Disposition",
        f"attachment; filename= {filename}",
    )

    msg.attach(part)

    all_recipients = to_emails + cc_emails
    print("Recipients To:", msg["To"])
    print("Recipients Cc: ", msg["Cc"])
    print("All recipients:", all_recipients)

    try:
        with smtplib.SMTP("smtp.office365.com", 587) as server:
            server.starttls()
            server.login("notifications.ekaconnect@ekamobility.com", "Eka@2026")
            server.sendmail(msg["From"], all_recipients, msg.as_string())
            print("Email sent!")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {e}")


### For R&D Proto Email only ###
def send_email_to_proto(
    html_for,
    report_name,
    report_date,
    top_vehicle_table_mmi,
    trailing_vehicle_table_mmi,
    top_vehicle_table_rp,
    trailing_vehicle_table_rp,
):
    # Create the email
    msg = MIMEMultipart()

    # Email id: notifications.ekaconnect@ekamobility.com
    # Password : Eka@2026

    msg["From"] = "notifications.ekaconnect@ekamobility.com"
    to_emails = [
        "mahesh.j@ekamobility.com",
        "Vishal.Sagwal@ekamobility.com",
        "nitin.deole@ekamobility.com",
        "nitin.pandey@ekamobility.com",
        "vikram.alave@ekamobility.com",
        "prasad.chemate@ekamobility.com",
        "Mohammad.Firoz@ekamobility.com",
    ]

    # to_emails = [
    #     "arjun.bhalekar@ekamobility.com",
    #     "Ranveersingh@ekamobility.com",
    #     "advaith.m@ekamobility.com",
    # ]

    cc_emails = [
        "zoeb.k@ekamobility.com",
        "Kaustubh.Joshi@ekamobility.com",
        "sohan.raykhere@ekamobility.com",
        "avinash.j@ekamobility.com",
        "aakash.b@ekamobility.com",
        "shraddha.s@ekamobility.com",
        "ekavehiclesoftwareanddashboardteam@pinnacleindustries.com",
    ]

    msg["To"] = ", ".join(to_emails)

    msg["Cc"] = ", ".join(cc_emails)
    # Email body
    html_body = ""

    if html_for == "rd_html":
        msg["Subject"] = (
            f"Daily Status Report of Testing and Proto Vehicles for {report_date}"
        )
        html_body = rd_html_format

    elif html_for == "service_html":
        msg["Subject"] = f"Daily MIS Report for {report_date}"
        html_body = service_html_format

    html_body = html_body.replace("{{Report_Date}}", report_date)
    html_body = html_body.replace("{{top_vehicle_table_rp}}", top_vehicle_table_rp)
    html_body = html_body.replace(
        "{{trailing_vehicle_table_rp}}", trailing_vehicle_table_rp
    )
    html_body = html_body.replace("{{top_vehicle_table_mmi}}", top_vehicle_table_mmi)
    html_body = html_body.replace(
        "{{trailing_vehicle_table_mmi}}", trailing_vehicle_table_mmi
    )

    msg.attach(MIMEText(html_body, "html"))

    # File to attach
    file_path = report_name
    filename = os.path.basename(file_path)

    # Open file in binary mode
    with open(file_path, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())

    encoders.encode_base64(part)
    part.add_header(
        "Content-Disposition",
        f"attachment; filename= {filename}",
    )

    msg.attach(part)

    all_recipients = to_emails + cc_emails
    print("Recipients To:", msg["To"])
    print("Recipients Cc: ", msg["Cc"])
    print("All recipients:", all_recipients)

    try:
        with smtplib.SMTP("smtp.office365.com", 587) as server:
            server.starttls()
            server.login("notifications.ekaconnect@ekamobility.com", "Eka@2026")
            server.sendmail(msg["From"], all_recipients, msg.as_string())
            print("Email sent!")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {e}")
