import pandas as pd


def generate_html_tables(df_ranked, report_name):

    # --- Convert newlines into <br> for HTML emails ---
    df_ranked = df_ranked.copy()
    for col in df_ranked.select_dtypes(include=["object"]).columns:
        df_ranked[col] = df_ranked[col].str.replace("\n", "<br>", regex=False)

    # --- TRUE MOBILE RESPONSIVE CSS FOR EMAIL ---
    responsive_css = """
        <style>
            @media only screen and (max-width: 600px) {
                table[class="responsive-table"] td,
                table[class="responsive-table"] th {
                    display: block !important;
                    width: 100% !important;
                    box-sizing: border-box !important;
                }
            }
        </style>
    """

    # --- Inline cell styles (email safe) ---
    table_style = (
        "width:100%; border-collapse:collapse; font-size:13px; "
        "border:1px solid #cccccc;"
    )

    td_style = (
        "border:1px solid #cccccc; padding:6px; word-break:break-word;"
        "font-size:13px;"
    )

    top_header_style = (
        "border:1px solid #cccccc; padding:6px; background:#4CAF50; "
        "color:white; font-weight:bold; text-align:left;"
    )

    trailing_header_style = (
        "border:1px solid #cccccc; padding:6px; background:#A0522D; "
        "color:white; font-weight:bold; text-align:left;"
    )

    # --- Empty fallback ---
    def empty_table(message):
        return f"""
        {responsive_css}
        <table class="responsive-table" style="{table_style}">
            <thead>
                <tr><th style="{top_header_style}">{message}</th></tr>
            </thead>
            <tbody>
                <tr><td style="{td_style}">No vehicles found.</td></tr>
            </tbody>
        </table>
        """

    if df_ranked.empty:
        return empty_table("No Data Available"), empty_table("No Data Available")

    # ------------------------------------------------------------
    # TOP PERFORMER TABLE
    # ------------------------------------------------------------
    df_top = df_ranked[df_ranked["RANKING"] == "Best Performer"].drop(
        columns=["RANKING"], errors="ignore"
    )

    if df_top.empty:
        top_html = empty_table("No Top Performers")
    else:
        top_html = df_top.to_html(
            index=False,
            escape=False,
            border=0,
            justify="left",
            table_id=f"{report_name}_top",
            classes=["responsive-table"],  # IMPORTANT for mobile CSS
        )

        # Inline styles
        top_html = top_html.replace("<table", f'<table style="{table_style}"')
        top_html = top_html.replace("<th>", f'<th style="{top_header_style}">')
        top_html = top_html.replace("<td>", f'<td style="{td_style}">')

        # Inject responsive CSS
        top_html = responsive_css + top_html

    # ------------------------------------------------------------
    # TRAILING PERFORMER TABLE
    # ------------------------------------------------------------
    df_trailing = df_ranked[df_ranked["RANKING"] == "Trailing Performer"].drop(
        columns=["RANKING"], errors="ignore"
    )

    if df_trailing.empty:
        trailing_html = empty_table("No Trailing Performers")
    else:
        trailing_html = df_trailing.to_html(
            index=False,
            escape=False,
            border=0,
            justify="left",
            table_id=f"{report_name}_trailing",
            classes=["responsive-table"],
        )

        trailing_html = trailing_html.replace("<table", f'<table style="{table_style}"')
        trailing_html = trailing_html.replace(
            "<th>", f'<th style="{trailing_header_style}">'
        )
        trailing_html = trailing_html.replace("<td>", f'<td style="{td_style}">')

        trailing_html = responsive_css + trailing_html

    return top_html, trailing_html
