import pandas as pd
from typing import Dict, List
from concurrent.futures import ThreadPoolExecutor, as_completed

# -------------------------------------------------------------------
# SQL query to fetch device metadata used for vehicle identification
# -------------------------------------------------------------------
DEVICE_QUERY: str = """
SELECT
    device_id,
    device_type,
    device_type_name,
    "VRN",
    chassis_number,
    city,
    fleet
FROM public.devices_device;
"""


# Function to fetch data from Device Table of local postgres DB
def fetch_device_data(logger, engine, query=DEVICE_QUERY) -> pd.DataFrame:
    """
    Fetch device data from the Device table and return it as a cleaned DataFrame.

    - Executes a read-only SQL query
    - Logs status of data retrieval
    - Replaces NULL values with 'NA' for downstream safety

    Args:
        engine (Engine): SQLAlchemy engine for PostgreSQL connection

    Returns:
        pd.DataFrame: Cleaned device dataframe (may be empty)
    """
    try:
        device_df = pd.read_sql(query, engine)
    except Exception as e:
        logger.error("Failed to fetch data from Device table.")
        raise e

    if device_df.empty:
        logger.warning("No records found in Device table.")
        return device_df

    logger.info("Fetched %d records from Device table.", len(device_df))

    # -------------------------------------------------------------------
    # Data Cleaning
    # Replace all NULL/NaN values with 'NA' in a vectorized operation
    # -------------------------------------------------------------------
    device_df.fillna("NA", inplace=True)

    return device_df


# -------------------------------------------------------------------
# SQL query (parameterized for safety & performance)
# -------------------------------------------------------------------
DEVICE_DATA_QUERY = """
SELECT
    dd.device_id,
    dd."IMEI",
    dd.header,

    -- timestamp (raw)
    dd."timestamp" AT TIME ZONE 'Asia/Kolkata' AS timestamp,

    -- Raw ignition values
    dd.can_data ->> 'IgnitionStatus'   AS ignition_status_3w,
    dd.can_data ->> 'Ignition_Sense'   AS ignition_sense_4w,


    -- Raw VCU_Flag values
    dd.can_data ->> 'VCU_Flag' AS vcu_flag,

    -- Raw speed values
    dd.can_data ->> 'MCU_Speed_Kmph'   AS mcu_speed_kmph_3w,
    dd.can_data ->> 'WheelBasedVehicleSpeed_Rx' AS wheel_based_vehicle_speed_4w,

    -- Raw RPM values
    dd.can_data ->> 'MCU_MotorActSpeed_RPM' AS mcu_motor_speed_3w,
    dd.can_data ->> 'MCU_Motor_Speed'  AS mcu_motor_speed_4w,

    -- Raw odometer values
    dd.can_data ->> 'MCU_Odometer_Val' AS mcu_odometer_val_3w,
    dd.can_data ->> 'ODOMETER'         AS odometer_4w,
    dd.can_data ->> 'ODOMETER_CRUT'    AS odometer_crut_4w,

    -- Raw voltages & currents
    dd.can_data ->> 'Charger_Output_VOL'        AS charger_output_vol,
    dd.can_data ->> 'Charger_Output_CUR'        AS charger_output_cur,
    -- 4W Electrical
    dd.can_data ->> 'MCU_HighPowerVoltage'      AS mcu_high_power_voltage,
    dd.can_data ->> 'MCU_HighPowerCurrent'     AS mcu_high_power_current,
    dd.can_data ->> 'DCDC_Input_Voltage'        AS dcdc_input_voltage,
    dd.can_data ->> 'DCDC_Input_Current'        AS dcdc_input_current,
    dd.can_data ->> 'BCS_Compressor_Input_Voltage'        AS bcscompressor_input_voltage,
    dd.can_data ->> 'BCS_Compressor_Input_Current'        AS bcscompressor_input_current,
    dd.can_data ->> 'TCS_Energy'        AS tcs_energy,
    dd.can_data ->> 'ECompressor_Input_Power'        AS ecompressor_input_power,
    dd.can_data ->> 'Streering_Input_Power'        AS steering_input_power,


    -- Raw temperatures
    -- Battery Temperatures
    dd.can_data->>'TS1' AS ts1,
    dd.can_data->>'TS2' AS ts2,
    dd.can_data->>'TS3' AS ts3,
    dd.can_data->>'TS4' AS ts4,
    dd.can_data->>'TS5' AS ts5,
    dd.can_data->>'TS6' AS ts6,
    dd.can_data->>'A_Max_Cell_Temp' AS a_max_cell_temp,
    dd.can_data->>'B_Max_Cell_Temp' AS b_max_cell_temp,
    dd.can_data->>'C_Max_Cell_Temp' AS c_max_cell_temp,

    -- component temperatures
    dd.can_data ->> 'MCU_Motor_Temp'           AS motor_temp_3w,
    dd.can_data ->> 'Motor_Temperature'         AS motor_temp_4w,
    dd.can_data ->> 'MCU_Temperature'         AS mcu_temperature_4w,
    dd.can_data ->> 'BCS_Thermistor_1'           AS bcs_thermistor_1,
    dd.can_data ->> 'BCS_Thermistor_2'           AS bcs_thermistor_2,
    dd.can_data ->> 'BCS_Thermistor_3'           AS bcs_thermistor_3,
    dd.can_data->>'TCS_Pump_Temperature' AS tcs_temp,
    dd.can_data->>'DCDC_Temp_1' AS dcdc_temp_1,
    dd.can_data->>'DCDC_Temp_2' AS dcdc_temp_2,
    dd.can_data->>'DCDC_Temp_3' AS dcdc_temp_3,
    dd.can_data->>'DCDC_Temp_4' AS dcdc_temp_4,
    dd.can_data->>'Ecomp_Actual_Heat_Sink_Temp' AS ecomp_temp,
    dd.can_data->>'Steering_Actual_Heat_Sink_Temp' AS steering_temp,

    -- Raw SOC values
    dd.can_data ->> 'SOC'           AS soc,
    dd.can_data ->> 'A_SOC_Value'   AS a_soc,
    dd.can_data ->> 'B_SOC_Value'   AS b_soc,
    dd.can_data ->> 'C_SOC_Value'   AS c_soc,

    -- Battery Voltage
    dd.can_data->>'BatteryVoltage' AS battery_voltage_3w,
    dd.can_data->>'A_Pack_Voltage_Value' AS a_pack_voltage,
    dd.can_data->>'B_Pack_Voltage_Value' AS b_pack_voltage,
    dd.can_data->>'C_Pack_Voltage_Value' AS c_pack_voltage,

    -- Battery Current
    dd.can_data->>'BatteryCurrent' AS battery_current_3w,
    dd.can_data->>'A_Pack_Current_Value' AS a_pack_current,
    dd.can_data->>'B_Pack_Current_Value' AS b_pack_current,
    dd.can_data->>'C_Pack_Current_Value' AS c_pack_current,

    -- Raw DTCs
    dd.can_data->>'VCU_DTC_1' as "VCU_DTC_1",
    dd.can_data->>'VCU_DTC_2' as "VCU_DTC_2",
    dd.can_data->>'BMS_DTC_1' as "BMS_DTC_1",
    dd.can_data->>'BMS_DTC_2' as "BMS_DTC_2",
    dd.can_data->>'MCU_DTC_1' as "MCU_DTC_1",
    dd.can_data->>'MCU_DTC_2' as "MCU_DTC_2",
    dd.can_data->>'EVCC_DTC_1' as "EVCC_DTC_1",
    dd.can_data->>'EVCC_DTC_2' as "EVCC_DTC_2",
    dd.can_data->>'DCDC_DTC_1' as "DCDC_DTC_1",
    dd.can_data->>'DCDC_DTC_2' as "DCDC_DTC_2",
    dd.can_data->>'TCS_DTC_1' as "TCS_DTC_1",
    dd.can_data->>'TCS_DTC_2' as "TCS_DTC_2",
    dd.can_data->>'HVAC_BCS_DTC_1' as "HVAC_BCS_DTC_1",
    dd.can_data->>'HVAC_BCS_DTC_2' as "HVAC_BCS_DTC_2",
    dd.can_data->>'IC_MUX_DTC_1' as "IC_MUX_DTC_1",
    dd.can_data->>'IC_MUX_DTC_2' as "IC_MUX_DTC_2"

FROM public.devices_devicedata dd
WHERE dd.device_id = %(device_id)s
AND dd.header = '$NRM'
AND dd."timestamp" >= %(start_ts)s
AND dd."timestamp" < %(end_ts)s
ORDER BY dd.device_id, dd."timestamp" ASC;
"""


# FOR RP FROM POSTGRES
def fetch_device_data_from_devicedata(
    logger,
    engine,
    device_id: str,
    start_ts,
    end_ts,
) -> tuple[str, pd.DataFrame | None]:
    """
    Fetch device data for a single device_id within a given time range.

    Args:
        engine (Engine): SQLAlchemy engine
        device_id (str): Device identifier
        start_ts (datetime): Start timestamp (inclusive)
        end_ts (datetime): End timestamp (exclusive)

    Returns:
        tuple[str, DataFrame | None]: device_id and fetched DataFrame (or None if empty)
    """
    try:
        df = pd.read_sql(
            DEVICE_DATA_QUERY,
            engine,
            params={
                "device_id": device_id,
                "start_ts": start_ts,
                "end_ts": end_ts,
            },
        )

        if df.empty:
            logger.warning(
                "No data for device_id=%s between %s and %s",
                device_id,
                start_ts,
                end_ts,
            )
            return device_id, pd.DataFrame()

        logger.info(
            "Fetched %d rows for device_id=%s",
            len(df),
            device_id,
        )
        return device_id, df

    except Exception:
        logger.exception("Failed to fetch data for device_id=%s", device_id)
        return device_id, pd.DataFrame()


# FOR RP FROM POSTGRES
def fetch_data_from_devicedata(
    logger,
    engine,
    device_ids,
    start_ts,
    end_ts,
    max_workers: int = 12,
) -> Dict[str, pd.DataFrame]:
    """
    Fetch data for multiple devices in parallel.

    Args:
        engine (Engine): SQLAlchemy engine
        device_ids (List[str]): List of device IDs
        start_ts (datetime): Start timestamp
        end_ts (datetime): End timestamp
        max_workers (int): Max parallel threads

    Returns:
        Dict[str, DataFrame]: device_id -> DataFrame
    """
    raw_device_data: Dict[str, pd.DataFrame] = {}

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(
                fetch_device_data_from_devicedata,
                logger,
                engine,
                device_id,
                start_ts,
                end_ts,
            )
            for device_id in device_ids
        ]

        for future in as_completed(futures):
            device_id, df = future.result()
            if df is not None:
                raw_device_data[device_id] = df

    logger.info(
        "Successfully fetched data for %d/%d devices",
        len(raw_device_data),
        len(device_ids),
    )

    return raw_device_data


# FOR MMI DEVICES FETCH DATA FROM MYSQL


# GET MMI DEVICES Table Mapping
def get_mmi_table_mapping(logger, engine, device_df) -> dict:
    """Fetch MMI table metadata and return device_id → {VRN/chassis, table_name} mapping."""

    df = fetch_device_data(
        logger,
        engine,
        query="""
        SELECT *
        FROM mmi_vehicles;
        """,
    )

    df = df.loc[df["model_vrn"].notna()].copy()

    split_cols = df["model_vrn"].str.split("_")

    df["vehicle_type"] = split_cols.str[0]
    df["identifier"] = split_cols.str[-1]  # VRN OR chassis
    df["AC_NAC"] = split_cols.str[-2]
    df["fleet"] = split_cols.str[1:-2].str.join("_")

    df.rename(columns={"model_code": "table_name"}, inplace=True)

    df = df[["identifier", "table_name"]]

    # --- Prepare device_df ---
    device_df = device_df.copy()
    # Normalize first (VERY IMPORTANT)
    df["identifier"] = df["identifier"].str.strip().str.upper()

    device_df["VRN"] = device_df["VRN"].str.strip().str.upper()
    device_df["chassis_number"] = device_df["chassis_number"].str.strip().str.upper()

    # Merge on VRN
    df_vrn = df.merge(
        device_df[["VRN", "device_id"]],
        left_on="identifier",
        right_on="VRN",
        how="left",
    )

    # Merge on chassis
    df_chassis = df.merge(
        device_df[["chassis_number", "device_id"]],
        left_on="identifier",
        right_on="chassis_number",
        how="left",
    )

    # Combine results
    df["device_id"] = df_vrn["device_id"].combine_first(df_chassis["device_id"])

    # Cleanup
    df = df.dropna(subset=["identifier", "device_id"])
    df = df.loc[df["identifier"].str.strip() != ""]

    df = df.drop_duplicates()

    df = df.sort_values("device_id").drop_duplicates(subset=["device_id"], keep="first")

    df.rename(columns={"identifier": "VRN"}, inplace=True)

    return df.set_index("device_id")[["VRN", "table_name"]].to_dict(orient="index")


# Function to fetch single MMI device data
def fetch_single_mmi_device_data(
    device_id, vrn, table_name, start_date, end_date, logger, engine, device_df
):
    """
    Fetch data for a single device/table. Skip if table doesn't exist.
    """
    query = f"""
        SELECT * FROM `{table_name}`
        WHERE Server_Time >= '{start_date}' AND Server_Time <= '{end_date}';
    """
    try:
        df = fetch_device_data(logger=logger, engine=engine, query=query)
    except Exception as e:
        logger.warning(f"Skipping {table_name} for device {device_id}: {e}")
        return device_id, None

    if df.empty:
        return device_id, None

    # Add device_id and merge device_df info
    df["device_id"] = device_id
    df = df.merge(device_df, on="device_id", how="left")

    return device_id, df


# Function to fetch Data from DeviceData in the given data range
