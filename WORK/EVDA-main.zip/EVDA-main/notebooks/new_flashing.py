import threading
import os
import time
from datetime import datetime

import paho.mqtt.client as mqtt
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment

# Broker Config
BROKER   = "43.204.176.28"
PORT     = 1883
USERNAME = "Eka"
PASSWORD = "Eka@123"
QOS      = 2

IMEIS = ["861919088610109"]

# IMEIS = ["861919088597645", "861919088610109", "861919088598759", "861919088649164"]

# Flash Commands
FLASH_COMMANDS = [
    "cancfg=clear",
    "cancfg=setup,500,STDEXT",
    (
        "cancfg=add,0xa1, 0xa5, 0xb1, 0xe1, 0x300, "
        "0x1801a1f0, 0x1801a1f1, 0x1801a1f2, 0x1801a1f3, "
        "0x1801a1f4, 0x1801a1f5, 0x1801a1f6, 0x1801a1fc, 0x1801a1fd"
    ),
    (
        "cancfg=add,0x1801a1fe, 0x1801a1ff, 0x1801a200, 0x1801a201, "
        "0x1801a202, 0x1801a203, 0x1801a204, 0x1806e5f4, "
        "0x18100105, 0x18100106, 0x18100107, 0x18100108, "
        "0x18100109, 0x1810010a"
    ),
    (
        "cancfg=add,0x1810010b, 0x1810010c, 0x1810010d, 0x1810010e, "
        "0x1810010f, 0x18100110, 0x1826ff81, 0x1827ff81, "
        "0x18ff47d0, 0x18ff50e5"
    ),
    "REBOOT",
]

# Expected CAN keys
EXPECTED_CAN_KEYS = {
    "000000a1", "000000a5", "000000b1", "000000e1", "00000300",
    "1801a1f0", "1801a1f1", "1801a1f2", "1801a1f3", "1801a1f4",
    "1801a1f5", "1801a1f6", "1801a1fc", "1801a1fd", "1801a1fe",
    "1801a1ff", "1801a200", "1801a201", "1801a202", "1801a203",
    "1801a204", "1806e5f4", "18100105", "18100106", "18100107",
    "18100108", "18100109", "1810010a", "1810010b", "1810010c",
    "1810010d", "1810010e", "1810010f", "18100110", "1826ff81",
    "1827ff81", "18ff47d0", "18ff50e5"
}

# Seconds to wait for a live data packet before giving up
DATA_WAIT_TIMEOUT = 60
# Seconds to wait for device ACK after each flash command
ACK_TIMEOUT       = 30
# Seconds to wait for device to reboot before listening for verify packet
REBOOT_WAIT       = 30
# Seconds to wait for a fresh packet after reboot for post-flash verification
VERIFY_WAIT_TIMEOUT = 90

# Excel
EXCEL_FILE = "flash_report.xlsx"
HEADERS    = [
    "IMEI",
    "Check_Timestamp",
    "Flashing_Needed",
    "Flash_Timestamp",
    "Flash_Status",
    "Fail_Reason",
]
COL = {h: i for i, h in enumerate(HEADERS, 1)}   # header → column number


# Excel helpers

def format_sheet(ws):
    """Apply styling: headers, center alignment, auto-fit widths, autofilters, and fraction formatting."""
    # 1. Colors & Fonts for Headers
    hdr_fill  = PatternFill("solid", start_color="1F4E79") # Deep Blue
    hdr_font  = Font(bold=True, color="FFFFFF", name="Arial", size=11)
    hdr_align = Alignment(horizontal="center", vertical="center")
    
    # Apply header style (row 1)
    for col_idx in range(1, ws.max_column + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font      = hdr_font
        cell.fill      = hdr_fill
        cell.alignment = hdr_align
    ws.row_dimensions[1].height = 20

    # 2. Add Filters to headers
    max_col_letter = ws.cell(row=1, column=ws.max_column).column_letter
    ws.auto_filter.ref = f"A1:{max_col_letter}{ws.max_row}"

    # 3. Format cells (Center alignment, IMEI Fraction formatting)
    center_align = Alignment(horizontal="center", vertical="center")
    for r in range(2, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(row=r, column=c)
            cell.alignment = center_align
            
            # Format Column 1 (IMEI Number) to Fraction
            if c == 1:
                cell.number_format = '# ?/?'

    # 4. Auto-fit Column Widths
    for col in ws.columns:
        max_len = 0
        col_letter = col[0].column_letter
        for cell in col:
            if cell.value is not None:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)


def init_excel():
    """Return (wb, ws, row_map).  Creates a new sheet if the file exists, or a new file if not."""
    sheet_title = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
    
    if os.path.exists(EXCEL_FILE):
        wb = load_workbook(EXCEL_FILE)
        ws = wb.create_sheet(title=sheet_title)
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_title

    # Populate the sheet
    for col, h in enumerate(HEADERS, 1):
        ws.cell(row=1, column=col).value = h

    for imei in IMEIS:
        ws.append([imei, None, "PENDING", None, "NOT_RUN", None])

    format_sheet(ws)
    wb.save(EXCEL_FILE)

    row_map = {}
    for r in range(2, ws.max_row + 1):
        val = ws.cell(row=r, column=1).value
        if val:
            row_map[str(val).strip()] = r
    return wb, ws, row_map


def save_excel(wb):
    try:
        format_sheet(wb.active)
        wb.save(EXCEL_FILE)
    except PermissionError:
        print(f"  [WARNING] '{EXCEL_FILE}' is open elsewhere — close it to save.")
    except Exception as e:
        print(f"  [ERROR] Save failed: {e}")


def write_row(ws, row: int, data: dict):
    """Write data dict into the correct columns of the given row."""
    for key, val in data.items():
        if key in COL:
            ws.cell(row=row, column=COL[key]).value = val

    # Colour Flash_Status cell
    status = data.get("Flash_Status", "")
    cell   = ws.cell(row=row, column=COL["Flash_Status"])
    if status == "SUCCESS":
        cell.fill = PatternFill("solid", start_color="C6EFCE")
        cell.font = Font(color="276221", bold=True, name="Arial")
    elif status == "SKIPPED":
        cell.fill = PatternFill("solid", start_color="FFEB9C")
        cell.font = Font(color="9C5700", bold=True, name="Arial")
    elif status == "FAILED":
        cell.fill = PatternFill("solid", start_color="FFC7CE")
        cell.font = Font(color="9C0006", bold=True, name="Arial")


# CAN check

def check_flashing_needed(payload: str) -> tuple:
    """Return (needs_flash: bool, missing_keys: set)."""
    if "CAN|" not in payload:
        return True, EXPECTED_CAN_KEYS.copy()

    can_section   = payload.split("CAN|")[1]
    received_keys = set()
    for item in can_section.split("|"):
        if ":" in item:
            received_keys.add(item.split(":")[0].strip().lower())

    missing = EXPECTED_CAN_KEYS - received_keys
    return bool(missing), missing


# Per-device handler

class DeviceHandler:
    def __init__(self, imei, client, ws, wb, row_map):
        self.imei   = imei
        self.client = client
        self.ws     = ws
        self.wb     = wb
        self.row    = row_map.get(imei)

        self.data_topic = f"devicedata/{imei}"
        self.cmd_topic  = f"devicecmd/{imei}"

        self._data_event   = threading.Event()
        self._ack_event    = threading.Event()
        self._data_payload = None
        self._ack_payload  = None

    # called from MQTT network thread
    def on_data(self, payload):
        self._data_payload = payload
        self._data_event.set()

    def on_ack(self, payload):
        self._ack_payload = payload
        self._ack_event.set()

    # Step 1: subscribe devicedata, validate header/packet, check CAN keys
    def pre_check(self):
        """
        Return (needs_flash: bool|None, missing_keys: set, reason: str,
                header: str, packet: str).

        needs_flash = None  →  no valid data received (skip device)
        needs_flash = True  →  CAN keys missing  (flash required)
        needs_flash = False →  all CAN keys present (no flash needed)

        header / packet are extracted from parts[0] and parts[5].
        Caller must gate on header == "$NRM" and packet == "L" before flashing.
        """
        print(f"  Listening on {self.data_topic} (up to {DATA_WAIT_TIMEOUT}s) …")
        self.client.subscribe(self.data_topic, qos=QOS)
        self._data_event.clear()

        got = self._data_event.wait(timeout=DATA_WAIT_TIMEOUT)
        self.client.unsubscribe(self.data_topic)

        if not got:
            return None, set(), "NO_DATA_RECEIVED", "", ""

        payload = self._data_payload
        if not payload or not payload.startswith("$"):
            return None, set(), "INVALID_PAYLOAD", "", ""

        parts = payload.split(",")
        if len(parts) < 25:
            return None, set(), f"SHORT_PAYLOAD ({len(parts)} parts)", "", ""

        header = parts[0]   # $NRM or $ALT
        packet = parts[5]   # L or H

        needs, missing = check_flashing_needed(payload)
        return needs, missing, "", header, packet

    # Step 2: send a single command and wait for ACK
    def _send_and_wait(self, cmd, step):
        short = cmd if len(cmd) <= 55 else cmd[:52] + "..."
        print(f"    -> [{step + 1}/{len(FLASH_COMMANDS)}] {short}")

        self._ack_event.clear()
        self._ack_payload = None

        res = self.client.publish(self.cmd_topic, cmd, qos=QOS)
        res.wait_for_publish()

        ok = self._ack_event.wait(timeout=ACK_TIMEOUT)
        if ok:
            print(f"       ACK: {self._ack_payload!r}")
        else:
            print(f"       TIMEOUT at step {step + 1}")
        return ok

    # Step 3: post-flash verification
    def post_flash_verify(self) -> tuple:
        """
        Wait for the device to reboot, then listen for a fresh $NRM/L packet
        and re-check CAN keys.

        Returns (verified: bool, still_missing: set, reason: str).
            verified = True   → all CAN keys now present  (real SUCCESS)
            verified = False  → keys still missing or no packet received
        """
        print(f"  Waiting {REBOOT_WAIT}s for device to reboot …")
        time.sleep(REBOOT_WAIT)

        print(f"  Post-flash: listening on {self.data_topic} (up to {VERIFY_WAIT_TIMEOUT}s) …")
        self.client.subscribe(self.data_topic, qos=QOS)
        self._data_event.clear()
        self._data_payload = None

        got = self._data_event.wait(timeout=VERIFY_WAIT_TIMEOUT)
        self.client.unsubscribe(self.data_topic)

        if not got:
            return False, set(), "VERIFY_TIMEOUT — no packet after reboot"

        payload = self._data_payload
        if not payload or not payload.startswith("$"):
            return False, set(), "VERIFY_INVALID_PAYLOAD"

        parts = payload.split(",")
        if len(parts) < 25:
            return False, set(), f"VERIFY_SHORT_PAYLOAD ({len(parts)} parts)"

        header = parts[0]
        packet = parts[5]
        if header != "$NRM" or packet != "L":
            return False, set(), f"VERIFY_BAD_PACKET — Header={header}, Packet={packet}"

        still_needs, still_missing = check_flashing_needed(payload)
        if still_needs:
            missing_str = ", ".join(sorted(still_missing))
            print(f"  Post-flash check FAILED — still missing: {missing_str}")
            return False, still_missing, f"Still missing after flash: {missing_str}"

        print(f"  Post-flash check PASSED — all CAN keys present.")
        return True, set(), ""

    # Step 2: flash all commands serially
    def flash(self):
        """Return (success: bool, fail_reason: str)."""
        self.client.subscribe(self.cmd_topic, qos=QOS)

        for idx, cmd in enumerate(FLASH_COMMANDS):
            if not self._send_and_wait(cmd, idx):
                self.client.unsubscribe(self.cmd_topic)
                return False, f"Timeout at step {idx + 1}: {cmd[:40]}"

        self.client.unsubscribe(self.cmd_topic)
        return True, ""

    # Full run
    def run(self) -> dict:
        print(f"\n{'=' * 64}")
        print(f"  IMEI: {self.imei}")
        print(f"{'=' * 64}")

        check_ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        needs, missing, reason, header, packet = self.pre_check()

        missing_str = ", ".join(sorted(missing)) if missing else (reason or "")

        # No data / bad payload
        if needs is None:
            print(f"  No data received ({reason}) — SKIPPING device.")
            result = dict(
                Check_Timestamp  = check_ts,
                Flashing_Needed  = "UNKNOWN",
                Flash_Timestamp  = "",
                Flash_Status     = "SKIPPED",
                Fail_Reason      = reason,
            )

        # Header/Packet gate: only flash on $NRM + L 
        elif header != "$NRM" or packet != "L":
            skip_reason = f"Header={header}, Packet={packet} (need $NRM/L)"
            print(f"  Packet not ready for flashing ({skip_reason}) — SKIPPING.")
            result = dict(
                Check_Timestamp  = check_ts,
                Flashing_Needed  = "YES" if needs else "NO",
                Flash_Timestamp  = "",
                Flash_Status     = "SKIPPED",
                Fail_Reason      = skip_reason,
            )

        # All CAN keys already present
        elif not needs:
            print(f"  All CAN keys present — NO flash needed. Skipping.")
            result = dict(
                Check_Timestamp  = check_ts,
                Flashing_Needed  = "NO",
                Flash_Timestamp  = "",
                Flash_Status     = "SKIPPED",
                Fail_Reason      = "",
            )

        # Flash required
        else:
            print(f"  Flash REQUIRED. Missing keys: {missing_str}")
            flash_ts        = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            ack_ok, ack_why = self.flash()

            if not ack_ok:
                # Commands did not ACK — no point verifying
                flash_status = "FAILED"
                fail_reason  = ack_why
            else:
                # All commands ACK'd — now verify CAN keys came back after reboot
                verified, _, verify_reason = self.post_flash_verify()
                flash_status = "SUCCESS" if verified else "FAILED"
                fail_reason  = "" if verified else verify_reason

            result = dict(
                Check_Timestamp  = check_ts,
                Flashing_Needed  = "YES",
                Flash_Timestamp  = flash_ts,
                Flash_Status     = flash_status,
                Fail_Reason      = fail_reason,
            )
            print(f"  {flash_status} for IMEI {self.imei}")

        if self.row:
            write_row(self.ws, self.row, result)

        return result


# Flash manager

class FlashManager:
    def __init__(self):
        self.wb, self.ws, self.row_map = init_excel()
        self.handlers = {}

        self.client = mqtt.Client(client_id="vts_flasher", protocol=mqtt.MQTTv311)
        self.client.username_pw_set(USERNAME, PASSWORD)
        self.client.on_connect    = self._on_connect
        self.client.on_message    = self._on_message
        self.client.on_disconnect = self._on_disconnect
        self._connected           = threading.Event()

    def _on_connect(self, client, userdata, flags, rc):
        if rc == 0:
            print(f"Connected to {BROKER}:{PORT}\n")
            self._connected.set()
        else:
            print(f"Connection failed (rc={rc})")

    def _on_disconnect(self, client, userdata, rc):
        print(f"\nDisconnected (rc={rc})")

    def _on_message(self, client, userdata, msg):
        parts      = msg.topic.split("/")
        topic_type = parts[0]
        imei       = parts[-1]
        payload    = msg.payload.decode(errors="replace")
        handler    = self.handlers.get(imei)
        if not handler:
            return
        if topic_type == "devicedata":
            handler.on_data(payload)
        elif topic_type == "devicecmd":
            handler.on_ack(payload)

    def run(self):
        total = len(IMEIS)
        print(f"VTS Flash Tool — {total} device(s) queued")
        print(f"Connecting to {BROKER}:{PORT} …\n")

        self.client.connect(BROKER, PORT, keepalive=60)
        self.client.loop_start()

        if not self._connected.wait(timeout=15):
            print("Could not connect to broker. Check IP / credentials.")
            self.client.loop_stop()
            return

        results = {}
        for idx, imei in enumerate([i.strip() for i in IMEIS if i.strip()], 1):
            print(f"\n[Device {idx}/{total}]")
            handler = DeviceHandler(imei, self.client, self.ws, self.wb, self.row_map)
            self.handlers[imei] = handler
            results[imei] = handler.run()
            save_excel(self.wb)          # save after every device

        self.client.loop_stop()
        self.client.disconnect()

        # Summary 
        skipped = [i for i, r in results.items() if r["Flash_Status"] == "SKIPPED"]
        success = [i for i, r in results.items() if r["Flash_Status"] == "SUCCESS"]
        failed  = [i for i, r in results.items() if r["Flash_Status"] == "FAILED"]

        print(f"\n{'=' * 64}")
        print(f"  SUMMARY  —  {total} devices processed")
        print(f"  No flash / not ready (SKIPPED)  : {len(skipped)}")
        print(f"  Flashed successfully             : {len(success)}")
        print(f"  Flash failed                     : {len(failed)}")
        print(f"{'=' * 64}")
        icons = {"SKIPPED": ">>> ", "SUCCESS": "✔", "FAILED": "✖"}
        for imei, r in results.items():
            extra = f"  ({r['Fail_Reason']})" if r.get("Fail_Reason") else ""
            print(f"  {icons.get(r['Flash_Status'], '?')}  {imei}  →  {r['Flash_Status']}{extra}")
        print(f"{'=' * 64}")
        print(f"\n  Report saved to: {EXCEL_FILE}")


# Entry Point 
if __name__ == "__main__":
    FlashManager().run()