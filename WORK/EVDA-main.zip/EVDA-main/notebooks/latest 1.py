from datetime import datetime
from paho.mqtt import client as mqtt_client
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
import os
import time
import zipfile

BROKER = "43.204.176.28"
PORT = 1883
USERNAME = "Eka"
PASSWORD = "Eka@123"

IMEIS = ["861919088637029","861919088637979","867950074294073","861919088636658","861919088636369",
"861919088634240","861919088650808","861919088616056","861919088607352","861919088602619",
"861919088615918","861919088636799","861919088602189","861919088652705","861919088602536",
"861919088607709","861919088615041","861919088635155","861919088636054","861919088607287",
"861919088654966","861919088635247","861919088602056","861919088609127","861919088597777",
"861919088597272","861919088607252","861919088602304","861919088609119","861919088602783",
"861919088657878","861919088636609","861919088598981","861919088598999","861919088609473",
"861919088615108","861919088615819","861919088603096","861919088610562","861919088598882",
"861919088598593","861919088609341","861919088609895","861919088602080","861919088615561",
"861919088636195","861919088637854","861919088607725","866082076496638","861919088608293",
"861919088597751","861919088609721","861919088599161","861919088615934","861919088636278",
"861919088650634","861919088628655","861919088610505","861919088610703","866082076498733",
"866082076500363","861919088636773","861919088610117","866082076522904","861919088615595",
"860710085860743","861919088599195","861919088599088","861919088606891","861919088634364",
"861919088611412","865510081864326","869833087693051","865510081810063","865510081770945",
"865510081820955","865510081863815","865510081794432","861919088608426","869833087691089",
"861919088620744","861919088598502","860710085788936","866082076290692","861919088615447",
"861919088649651","861919088636708","867409071405836","867950074346543","861919088635205",
"861919088636948","866082076309179","861919088609747","861919088602494","861919088602205",
"861919088615892","861919088610083","861919088618029","861919088610273","861919088592778",
"861919088636989","861919088636153","861919088620785","861919088615082","861919088597645",
"861919088615967","861919088597298","861919088608343","866082076313395","861919088636351",
"861919088620793","866082076308429","866082070079802","861919084523181","861919084574960",
"861919084569184","861919084573517","861919084575959","861919084570133","861919084568871",
"861919084568954","869742081065986","861919084619658","861409075144882","861919084222529",
"861919084257236","861919084362572","861919084405215","861409075138918","861919084255107",
"861919084315414","861919084441780","861919084222123","861409075076829","861919084220002",
"861919084257210","861919084357127","861919084404796","861919084342574","861919084343770",
"861919084300705","861919084398816","861919084448181","861919084254159","861919084256477",
"861919084221471","861409075083973","861409075138322","861409075144668","861409075090127",
"861409075083775","861409075137068","861409075045584","861409075006461","861409075083783",
"861409075145103","861409075032939","861409075077215","861409075137688","861409075137837",
"861409075128323","861409075083924","861409075054867","861409075128257","861919084354694",
"861919084364271","861919084411619","861919084232502","861919084256303","861919084443935",
"861919084222768","861919084215374","861919084362945","861919084350569","861919084443422",
"861919084444156","861919084443729","861919084222792","861919084443406","861919084256832",
"861919084343648","861919084329605","861409075089301","861919084298909","861919084221414",
"861919084221240","861919084314136","861919084300622","861919084221737","861919084443539",
"861919084231173","861919084365641","861919084446151","861919084223626","861919084445138",
"861919084440113","861919084300887","861919084237691","861919084439990","861919084444255",
"861409075052655","861919084452233","861919084218196","861919084313518","861409075045592",
"861919084317188","861919084577310","861919084257095","861919084342970","861919084350833",
"861919084315109","861919084219905","865510081794382","865510081863609","865510081804306",
"869833087677815","861919084441947","861919084256725","869833087694588","865510081803753",
"865510081784805","865510081822332","865510081795884","865510081861538","865510081779623",
"865510081821607","869833087696682","869833087694968","865510081839963","865510081796452",
"869742087597131","865510081799928","865510081821110","865510081803084","869833087692723",
"865510081838189","865510081810287","865510081771919","865510081810683","865510081794168",
"865510081795058","869833087677914","865510081821334","869833087694158","869833087694794",
"865510081783732","865510081804694","865510081794218","865510081810402","869833087694349",
"869833087695049","865510082084486","865510081820112","865510081820351","869833087672642",
"869833087677278","869833087692970","865510081820328","869833087692962","865510081826069",
"865510081811590","865510081804132","869742087598410","869833087694687","865510081784029",
"869833087677583","865510081822084","865510081821078","865510081845093","869833087677419",
"869833087678151","869742087645534","865510081829063","865510081785117","865510081844914",
"865510081803860","865510081842629","865510081784680","869833087693846","869833087671388",
"869833087678532","869833087677765","869833087677336","869833087693838","869833087694737",
"865510081833610","865510081842033","861919088608384","861919088637078","861919088608335",
"861919088602544","861919088601934","861919088636336","861919088607824","861919088637938",
"861919088637060","861919088601975","861919088603104","861919088615397","861919088620652",
"861919088661599","861919088607576","861919088614838","861919088643894","861919088615959",
"861919088607626","861919088609663","861919088633036","861919088601892","861919088620876",
"861919088602288","861919088615280","861919088637664","861919088602601","861919088615298",
"861919088610745","861919088617526","861919088608269","861919088610109","861919088649339",
"861919088610489","865510081864151","865510081771828","865510081804488","861919088617567",
"861919088636526","861919088609606","861919088627905","861919088607600","861919088608947",
"861919088602346","861919088644082","861919088591804","861919088597660","861919088636690",
"861919088597074","861919088636823","861919088592745","861919088614945","861919088644058",
"861919088610307","861919088638068","861919088597546","861919088609192","861919088610349",
"861919088597363","861919088611115","861919088611503","861919088598759","861919088607147",
"861919088638043","861919088617096","866082076278424","861919088652465","861919088637623",
"866082076370122","861919088597686","861919088636302","861919088649164","861919088638050",
"861919088636898","861919088635197","861919088643597","861919088651541","861919088636286",
"861919088638035","861919088649495","861919088598585","861919088597561","861919088609143",
"861919088656011","861919088614812","861919088599146","861919088615835","861919088599138",
"861919088615165","861919088599054","861919088610182","861919088615538","861919088610208",
"861919088610448","861919088637706","861919088608665","861919088597785","861919088610356",
"861919088610661","861919088609788","861919088611461","861919088602320","861919088609168",
"861919088598296","861919088610166","861919088598916","861919088632046","861919088636997",
"861919088644371","861919088631717","861919088602122","861919088636591","861919088643233",
"861919088607535","861919088658298","861919088602593","861919088594819","861919088597595",
"861919088635460","861919088598460","861919088611511","861919088598288","861919088602114",
"861919088597470","861919088608368","861919088592752","861919088614531","861919088609309",
"861919088603286","861919088598437","861919088637847","861919088616106","861919088615355",
"861919088610299","861919088601918","861919088598767","861919088609366","861919088598361",
"861919088615611","861919088615033","861919088615900","861919088610935","861919088636633",
"861919088610265","861919088610539","861919088601868","861919088603161","861919088610901",
"861919088608301","861919088627368","861919088599179","861919088609358","861919088610174",
"866082076278978","861919088602247","861919088608350","861919088615215","861919088632962",
"861919088597355","861919088601942","861919088602684","861919088598163","861919088598684",
"861919088609085","865510081820740","861919088610877","861919088598932","861919088656508",
"861919088610257","866082076504134","861919088637045","861919088602452","861919088610919",
"866082076500397","861919088603047","866082076498758","861919088611123","861919088610968",
"861919088611206","861919088615249","861919088608640","861919088609770","861919088610067",
"861919088610752","861919088615314","861919088607634","861919088610034","861919088636955",
"861919088615330","861919088610976","865510081771661","860710085821141","861919088661300",
"861919088607543","861919088636567","861919088615017","861919088615504","861919088609903",
"861919088615520","861919088610703","861919088610505","861919088628655","861919088609572",
"861919088607295","861919088615413","861919088609622","867950074291962","861919088602130",
"861919088637086","861919088602429","861919088607550"
]

# IMEIS =["861919088637086","861919088602429","861919088607550"]


EXCEL_FILE = "6s_report.xlsx"

EXPECTED_CAN_KEYS = {
    "000000a1", "000000a5", "000000b1", "000000e1", "00000300",
    "1801a1f0", "1801a1f1", "1801a1f2", "1801a1f3", "1801a1f4",
    "1801a1f5", "1801a1f6", "1801a1fc", "1801a1fd", "1801a1fe",
    "1801a1ff", "1801a200", "1801a201", "1801a202", "1801a203",
    "1801a204", "1806e5f4", "18100105", "18100106", "18100107",
    "18100108", "18100109", "1810010a", "1810010b", "1810010c",
    "1810010d", "1810010e", "1810010f", "18100110", "1826ff81",
    "1827ff81", "18ff47d0", "18ff50e5"
}

last_packet_time: dict[str, datetime] = {}

HEADERS = [
    "IMEI", "Timestamp", "Time_Difference", "HEADER", "PACKET",
    "GPS", "IGNITION", "VTS_Device_Supply", "CAN_DATA",
    "Flashing_Needed", "Device_Status", "Scope", "Missing_Can_keys"
]

# Periodic saving state
SAVE_INTERVAL_SECONDS = 10
last_save_time = 0.0

def format_sheet(ws):
    """Apply styling: headers, center alignment, auto-fit widths, autofilters, and fraction formatting."""
    # 1. Colors & Fonts for Headers
    hdr_fill  = PatternFill("solid", start_color="1F4E79") # Deep Blue
    hdr_font  = Font(bold=True, color="FFFFFF", name="Arial", size=11)
    hdr_align = Alignment(horizontal="center", vertical="center")
    
    # Apply header style (row 1)
    for col_idx in range(1, ws.max_column + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font      = hdr_font
        cell.fill      = hdr_fill
        cell.alignment = hdr_align
    ws.row_dimensions[1].height = 20

    # 2. Add Filters to headers
    max_col_letter = ws.cell(row=1, column=ws.max_column).column_letter
    ws.auto_filter.ref = f"A1:{max_col_letter}{ws.max_row}"

    # 3. Format cells (Center alignment, IMEI Fraction formatting)
    center_align = Alignment(horizontal="center", vertical="center")
    for r in range(2, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(row=r, column=c)
            cell.alignment = center_align
            
            # Format Column 1 (IMEI Number) to Fraction
            if c == 1:
                cell.number_format = '# ?/?'

    # 4. Auto-fit Column Widths
    for col in ws.columns:
        max_len = 0
        col_letter = col[0].column_letter
        for cell in col:
            if cell.value is not None:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)


def safe_save():
    """Attempts to save the workbook, handling permission errors."""
    global last_save_time
    try:
        format_sheet(ws)
        wb.save(EXCEL_FILE)
        last_save_time = time.time()
        print(f"  [SUCCESS] Excel file '{EXCEL_FILE}' updated.")
    except PermissionError:
        print(f"  [WARNING] Could not save to '{EXCEL_FILE}'. Is it open in WPS/Excel?")
    except Exception as e:
        print(f"  [ERROR] Failed to save Excel file: {e}")

def trigger_save():
    """Saves the workbook only if the interval has passed."""
    if (time.time() - last_save_time) > SAVE_INTERVAL_SECONDS:
        safe_save()

# Excel bootstrap
sheet_title = datetime.now().strftime("%Y-%m-%d %H-%M-%S")

if not os.path.exists(EXCEL_FILE):
    print(f"Creating new Excel file: {EXCEL_FILE}")
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_title
    
    # Initialize sheet
    ws.append(HEADERS)
    for imei in IMEIS:
        ws.append([
            imei, None, None, None, None, None, None, None, None, None,
            "MQTT_Is_Blank", "RP", None
        ])
else:
    try:
        print(f"Loading existing Excel file: {EXCEL_FILE}")
        wb = load_workbook(EXCEL_FILE)
        ws = wb.create_sheet(title=sheet_title)
        
        # Initialize new sheet
        ws.append(HEADERS)
        for imei in IMEIS:
            ws.append([
                imei, None, None, None, None, None, None, None, None, None,
                "MQTT_Is_Blank", "RP", None
            ])
    except (zipfile.BadZipFile, KeyError, Exception) as e:
        print(f"Existing file '{EXCEL_FILE}' is corrupted ({e}). Recreating...")
        wb = Workbook()
        ws = wb.active
        ws.title = sheet_title
        
        # Initialize sheet
        ws.append(HEADERS)
        for imei in IMEIS:
            ws.append([
                imei, None, None, None, None, None, None, None, None, None,
                "MQTT_Is_Blank", "RP", None
            ])

safe_save()

imei_row_map: dict[str, int] = {}
for row in range(2, ws.max_row + 1):
    val = ws.cell(row=row, column=1).value
    if val is not None:
        imei_row_map[str(val).strip()] = row

TOPICS = [f"devicedata/{imei}" for imei in IMEIS]


# Helpers
def check_flashing_needed(payload: str) -> str:
    """YES if any expected CAN key is missing from the payload."""
    if "CAN|" not in payload:
        return "YES"
    can_section = payload.split("CAN|")[1]
    received_keys = set()
    for item in can_section.split("|"):
        if ":" in item:
            received_keys.add(item.split(":")[0].strip().lower())
    missing = EXPECTED_CAN_KEYS - received_keys
    if missing:
        print(f"  Missing CAN keys: {missing}")
        return "YES"
    return "NO"


def is_gps_valid(gps: str) -> bool:
    """Returns False if GPS is blank or all-zero coordinates."""
    if not gps or not gps.strip():
        return False
    # Strip direction letters and punctuation, check if only zeros remain
    digits_only = gps.replace("N","").replace("E","").replace("S","").replace("W","") \
                     .replace(",","").replace(".","").replace(" ","")
    return digits_only not in ("", "00000000000000000000")


def determine_status_and_scope(
    ignition: str,
    vts_supply: str,
    can_data: str,
    flashing_needed: str,
    header: str,
    packet: str,
    gps: str,
) -> tuple[str, str]:

    statuses = []
    scopes   = []

    # Check_DeviceConnection
    # Triggers when VTS is not supplying power to the device (vts=0),
    # OR when VTS is on and Ignition is on, but the device still reports no CAN data.
    conn_issue = (vts_supply == "0") or (vts_supply == "1" and ignition == "1" and can_data == "NO")
    if conn_issue:
        statuses.append("Check_DeviceConnection")
        scopes.append("Service")

    # Flashing Required
    if flashing_needed == "YES":
        statuses.append("Flashing Required")
        scopes.append("EKA_Connect_CommandCenter")

    # OK (Strict Definition)
    # Only when every single health indicator is green.
    is_perfect_ok = (
        header == "$NRM"
        and packet == "L"
        and is_gps_valid(gps)
        and ignition == "1"
        and vts_supply == "1"
        and can_data == "YES"
        and flashing_needed == "NO"
    )

    if is_perfect_ok and not statuses:
        statuses.append("OK")
        scopes.append("No Issue")

    # Fallback
    # If no issues were detected above, we default to "OK" / "No Issue"
    # to satisfy the "else 'No Issue'" requirement for Scope.
    if not statuses:
        statuses.append("OK")
        scopes.append("No Issue")

    return ", ".join(statuses), ", ".join(scopes)


# MQTT callbacks
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("Connected to broker")
        for topic in TOPICS:
            client.subscribe(topic)
    else:
        print(f"Connection failed, rc={rc}")


def on_message(client, userdata, msg):
    try:
        payload = msg.payload.decode().strip()
        print(f"\nTopic:   {msg.topic}")
        print(f"Payload: {payload}")

        topic_imei = msg.topic.split("/")[-1]

        # Guard: empty / non-standard payload 
        if not payload or not payload.startswith("$"):
            _write_mqtt_blank_row(topic_imei)
            return

        parts = payload.split(",")
        if len(parts) < 25:
            print(f"  Too short ({len(parts)} parts) → MQTT_Is_Blank")
            _write_mqtt_blank_row(topic_imei)
            return

        # Field extraction
        header     = parts[0]   # $ALT or $NRM
        packet     = parts[5]   # L or H
        imei       = parts[6]
        latitude   = parts[11]
        lat_dir    = parts[12]
        longitude  = parts[13]
        lon_dir    = parts[14]
        ignition   = parts[22]  # 0 or 1
        vts_supply = parts[23]  # 0 or 1

        gps = f"{latitude} {lat_dir}, {longitude} {lon_dir}"

        # CAN_DATA
        # YES = at least one CAN key has a real value (not :N)
        can_data = "NO"
        if "CAN|" in payload:
            can_section = payload.split("CAN|")[1]
            can_items = [i for i in can_section.split("|") if ":" in i]
            if any(not item.endswith(":N") for item in can_items):
                can_data = "YES"

        # Flashing_Needed & Missing_Can_keys
        flashing_needed = check_flashing_needed(payload)
        missing_can_keys = flashing_needed

        # Timestamp & Time_Difference
        now = datetime.now()
        timestamp_str = now.strftime("%Y-%m-%d %H:%M:%S")
        prev_time = last_packet_time.get(imei)
        time_diff = round((now - prev_time).total_seconds(), 1) if prev_time else None
        last_packet_time[imei] = now

        # Device_Status & Scope (multi-issue)
        device_status, scope = determine_status_and_scope(
            ignition, vts_supply, can_data, flashing_needed,
            header, packet, gps,
        )

        # Write to Excel
        if imei in imei_row_map:
            row = imei_row_map[imei]
            ws[f"A{row}"] = imei
            ws[f"B{row}"] = timestamp_str
            ws[f"C{row}"] = time_diff
            ws[f"D{row}"] = header
            ws[f"E{row}"] = packet
            ws[f"F{row}"] = gps
            ws[f"G{row}"] = ignition
            ws[f"H{row}"] = vts_supply
            ws[f"I{row}"] = can_data
            ws[f"J{row}"] = flashing_needed
            ws[f"K{row}"] = device_status
            ws[f"L{row}"] = scope
            ws[f"M{row}"] = missing_can_keys
            trigger_save()
            print(
                f"  IMEI {imei} | IGN={ignition} VTS={vts_supply} "
                f"CAN={can_data} Flash={flashing_needed} "
                f"-> [{device_status}] / [{scope}] | Δt={time_diff}s"
            )
        else:
            print(f"  IMEI {imei} not in map")

    except Exception as e:
        print(f"Error: {e}")


def _write_mqtt_blank_row(imei: str):
    """Mark IMEI with no valid payload as MQTT_Is_Blank / RP."""
    if imei not in imei_row_map:
        return
    row = imei_row_map[imei]
    ws[f"B{row}"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for col in ["C", "D", "E", "F", "G", "H", "I", "J", "M"]:
        ws[f"{col}{row}"] = None
    ws[f"K{row}"] = "MQTT_Is_Blank"
    ws[f"L{row}"] = "RP"
    trigger_save()
    print(f"  IMEI {imei} -> MQTT_Is_Blank / RP")


# Client setup
client = mqtt_client.Client(
    mqtt_client.CallbackAPIVersion.VERSION1,
    client_id="mqtt_excel_client"
)
client.username_pw_set(USERNAME, PASSWORD)
client.on_connect = on_connect
client.on_message = on_message
client.connect(BROKER, PORT)
client.loop_forever()