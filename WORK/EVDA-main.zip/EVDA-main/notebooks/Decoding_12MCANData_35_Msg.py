
# ###Tested and Validated on 13th Oct 2025

from operator import index
import pandas as pd



def to_padded_str(series):
    return pd.to_numeric(series.replace('', pd.NA), errors='coerce').fillna(0).astype(int).astype(str).str.zfill(2)

def decode_merged_signal(val, total_bits, split_sizes):
    bin_str = format(val, f'0{total_bits}b')  
    reversed_bin = bin_str[::-1]  
    results = []
    pos = 0
    for size in split_sizes:
        chunk = reversed_bin[pos:pos+size][::-1]  
        results.append(int(chunk, 2))
        pos += size
    return results

b_pack_faults = [
'BPeakRegenOverCurr30sAlarm', 'BContChargingOverCurrAlarm', 'BPeakOverDischCurr30sAlarm', 'BContOverDischCurrAlarm',
'BCellOverVoltAlarm', 'BCellUnderVoltAlarm', 'BCellOverTempAlarm', 'BCellUnderTempAlarm','BPackOverVoltAlarm',
'BPackUnderVoltAlarm','BCellvoltsamplingAlarm', 'BCelltempsamplingAlarm', 'BSOCLowAlarm', 
'BAllContactorFlt','BCellDVStaticAlarm','BLowSOHAlarm','BSlaveCommLossAlarm','BHVILAlarm',
'BNegContactorHwFlt', 'BNegContactorWeldFlt', 'BVCUBMSCommFlt','BPackVoltSamplingflt', 'BTempSensorHwFlt', 
'BPack2PackCommFlt','BPackBalancingHwFlt','BCurrSensorHwFlt', 'BThermalRunawayFlt','BThermalSensorHWFlt', 
'BCellDeltaTempertureAlarm', 'BCellBalancingHwFlt','BPackVoltMismatchFlt', 'BCellDVDynAlarm', 'BVCUBMSCRCFailureFlt', 
'BPrechargeFlt','BInsulationDetectionFlt', 'BSOHZeroFlt','BSlaveCommLossAlarm','ASlaveCommLossSlaveNo'
                  ]


def modify_columns(df):

    ac_bus = True if (df['InHVACdetection']==1).any() else False
    new_column_name_mapping={
                        'ACounterCFF8BF3':'BCS_Speed' if not ac_bus else 'HVAC_Speed',
                        'ACRCCFF8BF3': 'DerateFlag',
                        'AInsulationValue':'DTE',
                        'ACoolantLeakagesensorAlarm': 'AThermalSensorCommFlt',
                        'APosContactorHwFlt': 'ACurrentMismatchFault',
                        'ABMSCounterCFF83F3' : 'DerateLocator',
                        'BrakePedalPosition': 'CSOCValue',
                        'DCDCenablecommand': 'MinSOH',
                        'EVErrorCode2': 'BMinCellVoltNo',
                        'Breakpedalposition' : 'BrakePedalPosition',
                        'Faultbit': 'Fourfrontfaultbit',
                        'MCUAmbientTemperature': 'CMaxCellVoltNo',
                        'MCUEMITemperature': 'CMinCellVoltNo',
                        #The Below Faults are mapped differently
                        'BCoolantLeakagesensorAlarm': 'B_or_C_ThermalSensorCommFlt',
                        'BPosContactorHwFlt': 'B_or_C_CurrentMismatchFault',
                        #MCUFaults
                        'DCDCINPUTUndervolt': 'MCUNormalTraction',
                        'DCDCINPUTOvervolt':'MCU_InterlockmotorcableFlt',
                        'DCDCLowvoltpowersupplyUV':'MCU_InterlockbattcableFlt',
                        'DCDCLowvoltpowersupplyOV':'MCU_TDSOverspeedFlt',  
                        'DCDCOutputUV':'MCU_TDSOverheatSystem',
                        'DCDCOutputOvervolt':'MCU_TDSDefectiveSensorDriveFlt',
                        'DCDCEXTERNALENBFAULT': 'MCUPhasetochasisFlt',
                        'PhaseshiftfullbridgeFAULT': 'MCUDriveCoverOpenedFlt',
                        'DCDCSHIMinductorUndertemp':'MCU_TDSOverheatdriveFlt',
                        'DCDCSHIMinductorOvertemp':'MCU_TDSOverheatMachineFlt',
                        'DCDCTransformerUndertemp':'MCU_TDSDefectSensorMachineFlt',
                        'DCDCTransformerOvertemp':'MCU_TDSLimpHomeModeFlt',
                        'DCDCSecondarymosfetUndertemp' : 'TCSPumpDryRunFault',
                        'DCDCSecondarymosfetovertemp' : 'TCSPumpStallFault',
                        'DCDCPrimarymosfetUndertemp' : 'TCSPumpThermalFault',
                        'DCDCPrimarymosfetOvertemp' : 'TCSPumpUnderVoltageFault',
                        'DCDCHVILFAULT' : 'TCSPumpCommunicationFault',
                        'DCDCConAuxInterLock1' : 'RegenMode',
                        'DCDCConAuxInterLock2' : 'Pack_B_or_C_FaultFlag', # 0-No Fault , 1- Pack B Fault , 2- Pack C Fault, 3- Pack B and C Fault
                        }
    for fault_name in b_pack_faults:
        new_column_name_mapping[fault_name]=f"B_or_C_{fault_name[1:]}"
    df = df.rename(columns=new_column_name_mapping)

    fault_indication = {
    0: 'No Fault',
    1: 'Pack C',
    2: 'Pack B',
    3: 'Pack B and C'
    }

    Fourfrontfaultbit_mapping={'1': 'Input undervoltage',
                                '2': 'Input overvoltage',
                                '4': 'Input overcurrent',
                                '8': 'Output undervoltage',
                                '16': 'output overvoltage',
                                '32': 'output overcurrent',
                                '64': 'Module over temperature',
                                '128': 'Reduced power operation'}

    df['Pack_B_or_C_FaultFlag'] = df['Pack_B_or_C_FaultFlag'].replace(fault_indication)

    df['Fourfrontfaultbit'] = df['Fourfrontfaultbit'].replace(Fourfrontfaultbit_mapping)


    df['RegenMode'] = df['RegenMode'].map(lambda x:'EBS Regen' if x==1 else 'VCU Regen')



    return df 

def decode_12m_df(df):

    df['Odometer'] = (
    to_padded_str(df['TRANSFORMERTEMP']) +
    to_padded_str(df['SecondarymosfetTemperature']) +
    to_padded_str(df['PrimarymosfetTemperature'])
    )
    df = modify_columns(df)
    df = df.fillna(0)
    df[['AMaxCellVoltNo', 'AMinCellVoltNo']] = df['Speedofcompressor'].apply(
        lambda x: pd.Series(decode_merged_signal(int(x), total_bits=16, split_sizes=[8, 8]) if not pd.isna(x) else 0)
    )

    df[['TCSPumpSpeed','ACoolantLeakageAlarm','ACoolantInletTempHigh','B_or_C_CoolantLeakageAlarm','B_or_C_CoolantInletTempHigh','PTC_Activate','BMaxCellVoltNo', ]] = df['PumpSpeed'].apply(
        lambda x: pd.Series(decode_merged_signal(int(x), total_bits=16, split_sizes=[3,1,1,1,1,1,8]) if not pd.isna(x) else 0)     
    )


    tcs_speed_mapping ={
        '0': '0-900',
        '1': '900-1800',
        '2': '1800-2700',
        '3': '2700-3600',
        '4': '3600-4500',
        '5': '4500-5600',
        '6': '5600-6500'
    }
    df['TCSPumpSpeed'] = df['TCSPumpSpeed'].astype(str).map(tcs_speed_mapping)
    



    
    #Dropping the intermediate columns used for decoding
    df = df.drop(columns=[c for c in [
    'TRANSFORMERTEMP', 'SecondarymosfetTemperature', 'PrimarymosfetTemperature',
    'Speedofcompressor',  'Unnamed: 230','nan'
    ] if c in df.columns], errors='ignore')
    
    return df

'''
1.Decode Execl
file_path = ""
decoded_df = decode_df(pd.read_excel(file_path,header=5))
decoded_df.to_excel(save_file)#For Saving
2.Decode CAN Data stored in DB
df=pd.read_sql() #fetech the data
decoded_df = decode_df(df)
decoded_df.to_excel(save_file)#For Saving
'''



if __name__ == "__main__":
    file_path = r"C:\Users\Advaith Maddenapalli\Downloads\0424_Can_Data  Report_21_11_2025_00_00_00_21_11_2025_11_52_06.xlsx"
    new_file = file_path.replace('.xlsx','_decoded.xlsx')
    df = pd.read_excel(file_path,header=5,na_values='-')
    decode_12m_df(df).to_excel(new_file,index=False)