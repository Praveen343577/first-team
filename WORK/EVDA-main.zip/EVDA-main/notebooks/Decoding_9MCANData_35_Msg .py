#Final Script as per the reference for old telematics sheet on 5th Nov 2025
import traceback
import pandas as pd
from sqlalchemy import create_engine

def to_padded_str(series):
    return pd.to_numeric(series.replace('', pd.NA), errors='coerce').fillna(0).astype(int).astype(str).str.zfill(2)

def decode_merged_signal(val, total_bits, split_sizes):
    bin_str = format(val, f'0{total_bits}b')  
    reversed_bin = bin_str[::-1]  
    results = []
    pos = 0
    for size in split_sizes:
        chunk = reversed_bin[pos:pos+size][::-1]
        results.append(int(chunk, 2))
        pos += size
    return results

def modify_columns(df):

    new_column_name_mapping={
                        'trqFlag': 'DerateFlag',
                        'AInsulationValue':'DTE',
                        'BCScompressorerror' : 'Bmaxcellvoltno',
                        'EVErrorCode2' : 'Bmincellvoltno',
                        'DCDCenablecommand': 'MinSOH',
                        'EVErrorCode2': 'BMinCellVoltNo',
                        'Breakpedalposition' : 'InHVAC_CoolantTemp_T2Bin',
                        'Faultbit': 'Fourfrontfaultbit',
                        'DCDCConAuxInterLock1' : 'RegenMode',
                        'DCDCConAuxInterLock2' : 'IntHVACWorkMode',# 0-Off , 1-Chilling , 3-SelfCirculation
                        'CCSAMaxTemp' : 'TotalEnergyConsumed',
                        'TCSRadFanFB1': 'DCDCEnableCommand',
                        'ECompCutoffSW' : 'AirDryerSW',
                        'SHIMINDUCTORTEMP' : 'DCDCMaxTemperature',
                        'BMinCellTemp':'BCoolantinTemp',
                        'BMaxCellTemp':'ACoolantinTemp',
                        'BInsulationValue':'MinInsulationValue',
                        }
    
    #Use this you think some keys are missing in the dataframe
    # missing_keys = set(new_column_name_mapping.keys()) - set(df.columns)
    # print("Keys missing in DataFrame columns:", missing_keys)
    
    df = df.rename(columns=new_column_name_mapping)

    IntHVACWorkMode = {
        0: 'Off',
        1: 'Chilling',
        3: 'SelfCirculation'
    }


    Fourfrontfaultbit_mapping={'1': 'Input undervoltage',
                                '2': 'Input overvoltage',
                                '4': 'Input overcurrent',
                                '8': 'Output undervoltage',
                                '16': 'output overvoltage',
                                '32': 'output overcurrent',
                                '64': 'Module over temperature',
                                '128': 'Reduced power operation'}

    df['Fourfrontfaultbit'] = df['Fourfrontfaultbit'].astype(str).replace(Fourfrontfaultbit_mapping)
    df['IntHVACWorkMode'] = df['IntHVACWorkMode'].astype(int).replace(IntHVACWorkMode)
    df['RegenMode'] = df['RegenMode'].map(lambda x:'EBS Regen' if x==1 else 'VCU Regen')



    return df


def decode_9m_df(df):

    df['Odometer'] = (
    to_padded_str(df['TRANSFORMERTEMP']) +
    to_padded_str(df['SecondarymosfetTemperature']) +
    to_padded_str(df['PrimarymosfetTemperature'])
    )
    df = modify_columns(df)
    df = df.fillna(0)

    df['PumpSpeed'] = pd.to_numeric(df['PumpSpeed'], errors='coerce').fillna(0).astype(int)
    df['Speedofcompressor'] = pd.to_numeric(df['Speedofcompressor'], errors='coerce').fillna(0).astype(int)
    df[['AMaxCellVoltNo', 'AMinCellVoltNo']] = df['Speedofcompressor'].apply(
        lambda x: pd.Series(decode_merged_signal(x, total_bits=16, split_sizes=[8, 8]) if not pd.isna(x) else 0)
    )
    
    ac_bus = True if (df['InHVACdetection']==1).any() else False
    
    cooling_system = 'BCS' if not ac_bus else 'IntHVAC' 
    
    df[['EV_error_code_2','TCSPumpSpeed','SpeedOfCompressor_BCS',f'{cooling_system}_Error']] = df['PumpSpeed'].apply(
        lambda x: pd.Series(decode_merged_signal(x, total_bits=16, split_sizes=[5,3,3,5]) if not pd.isna(x) else 0)     
    )

    tcs_speed_mapping ={
        '0': '0-900',
        '1': '900-1800',
        '2': '1800-2700',
        '3': '2700-3600',
        '4': '3600-4500',
        '5': '4500-5600',
        '6': '5600-6500'
    }

    bcs_speed_mapping = {
        0:'0-2200'  ,
        1:'2200-2500',
        2:'2500-3000',
        3:'3000-3500',
        4:'3500-4000',
        5:'4000-4500',
        6:'4500-5000',
    }

    df['TCSPumpSpeed'] = df['TCSPumpSpeed'].astype(str).replace(tcs_speed_mapping)
    df['SpeedOfCompressor_BCS'] = df['SpeedOfCompressor_BCS'].replace(bcs_speed_mapping)
    if ac_bus:
        df['SpeedOfCompressor_BCS']=0 # Since the default value will be 0 & that corespondes to 0-2200 
    #Dropping the intermediate columns used for decoding
    df = df.drop(columns=[c for c in [
    'TRANSFORMERTEMP', 'SecondarymosfetTemperature', 'PrimarymosfetTemperature',
    'Speedofcompressor', 'PumpSpeed', 'Unnamed: 230' , 'nan'
    ] if c in df.columns], errors='ignore')

    
    return df


def get_db_engine():
    dsn = {
        'user': 'local_admin',
        'password': 'Local@12345',
        'host': '192.168.24.136',
        'port': '3306',
        'database': 'community_db'
    }
    engine = create_engine(f'mysql+mysqlconnector://', connect_args=dsn)
    return engine

if __name__ == "__main__":
    file_path = r"C:\Users\Advaith Maddenapalli\Downloads\1848_Can_Data  Report_20_11_2025_00_00_00_20_11_2025_13_32_56 (1).xlsx"
    new_file = file_path.replace('.xlsx','_decoded.xlsx')
    df = pd.read_excel(file_path,header=5,na_values='-')
    decode_9m_df(df).to_excel(new_file, index=False)
    # for i in range(1,11): 
    #     i = '0'+str(i) if i<10 else 10
    #     try:
    #         print(i)
    #         df = pd.read_sql(f"select distinct date from wti{i} ",get_db_engine())
    #         if df.empty:
    #             continue
    #         print(df)
    #     except Exception as e:
    #         print("\t--",e)
    #         print(traceback.format_exc())
