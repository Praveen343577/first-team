# %% [markdown]
# # Common Utility

# %% [markdown]
# ## To load custom modules with latest changes

# %%
# To load the custom modules with the latest changes
%load_ext autoreload
%autoreload 2
from __future__ import annotations

# %% [markdown]
# ## Logger Setup

# %%
import sys, os

# Add project root to Python path
sys.path.append(os.path.abspath(".."))

# from src.logger import setup_logger

# logger = setup_logger(log_file="daily_vehicle_stats_v2.log")

# logger.info(f"logger ready:)")

from src.logger import setup_logger

setup_logger(log_file="daily_vehicle_stats_v2.log")

import logging

logger = logging.getLogger(name="daily_vehicle_stats_v2.ipynb")

logger.info("Logger initialized")
logger.debug("Logger initialized")
# logger.info("logger.info : Logger initialized")
# logger.debug("logger.debug : Debugging details")
# logger.info("logger.info : Informational message")
# logger.warning("logger.warning : Warning message")
# logger.error("logger.error : Error happened")
# logger.critical("logger.critical : Critical issue")

# %% [markdown]
# ## Imports

# %%
# ────────────────────────────────────────────────────────────────
# Standard Library Imports
# ────────────────────────────────────────────────────────────────
import os
import time
from datetime import date, datetime, timedelta
import warnings
import json
from concurrent.futures import (
    ThreadPoolExecutor,
    as_completed,
)  # For parallel processing

# ────────────────────────────────────────────────────────────────
# Third-Party Imports
# ────────────────────────────────────────────────────────────────
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Union, Any

# For Excel operations
from openpyxl import load_workbook  # For Excel operations
from openpyxl.styles import PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.worksheet.worksheet import Worksheet

# ────────────────────────────────────────────────────────────────
# Initialization Log
# ────────────────────────────────────────────────────────────────
try:
    logger.info("Imports and configurations initialized successfully.")
except NameError:
    # If logger isn't defined yet, fall back to a print statement
    print("Imports and configurations initialized successfully (no logger found).")

# %% [markdown]
# ## Database Connection

# %%
from src.database_connection import get_postgres_connection, get_mysql_connection

# Connect to PostGres
engine_prod_pg, metadata_prod_pg, connection_prod_pg = get_postgres_connection(
    logger=logger, env="prod"
)

# Connect to MySql
engine_local_mysql, metadata_local_mysql, connection_local_mysql = get_mysql_connection(
    logger=logger
)

# %% [markdown]
# # Data Fetching

# %% [markdown]
# ## Define Date Range

# %%
# Get the proper timestamps in both ist and utc
from dataclasses import dataclass
from zoneinfo import ZoneInfo

IST_TIMEZONE = ZoneInfo("Asia/Kolkata")
UTC_TIMEZONE = ZoneInfo("UTC")


@dataclass(frozen=True)
class ReportingWindow:
    """Represents a reporting window in both IST and UTC."""

    start_date_ist: pd.Timestamp
    end_date_ist: pd.Timestamp
    start_date_utc: pd.Timestamp
    end_date_utc: pd.Timestamp
    report_date: str


def get_reporting_window(
    start_date_ist: str | None = None,
    end_date_ist: str | None = None,
) -> ReportingWindow:
    """
    Generate a reporting window based on IST calendar dates.

    Manual Mode:
        start_date_ist="YYYY-MM-DD"
        end_date_ist="YYYY-MM-DD"

    Automatic Mode:
        Previous IST day
        Example:
            Today = 2026-06-03
            Window = [2026-06-02, 2026-06-03)

    Args:
        start_date_ist:
            Inclusive IST start date.

        end_date_ist:
            Exclusive IST end date.

    Returns:
        ReportingWindow containing IST and UTC timestamps.
    """
    if bool(start_date_ist) != bool(end_date_ist):
        raise ValueError(
            "Both start_date_ist and end_date_ist must be provided together."
        )

    if start_date_ist and end_date_ist:
        start_dt_ist = datetime.strptime(
            start_date_ist,
            "%Y-%m-%d",
        ).replace(tzinfo=IST_TIMEZONE)

        end_dt_ist = datetime.strptime(
            end_date_ist,
            "%Y-%m-%d",
        ).replace(tzinfo=IST_TIMEZONE)

        if end_dt_ist <= start_dt_ist:
            raise ValueError("end_date_ist must be greater than start_date_ist.")

    else:
        end_dt_ist = datetime.now(IST_TIMEZONE).replace(
            hour=0,
            minute=0,
            second=0,
            microsecond=0,
        )

        start_dt_ist = end_dt_ist - timedelta(days=1)

    start_ts_ist = pd.Timestamp(start_dt_ist)
    end_ts_ist = pd.Timestamp(end_dt_ist)

    start_ts_utc = start_ts_ist.tz_convert(UTC_TIMEZONE)
    end_ts_utc = end_ts_ist.tz_convert(UTC_TIMEZONE)

    return ReportingWindow(
        start_date_ist=start_ts_ist,
        end_date_ist=end_ts_ist,
        start_date_utc=start_ts_utc,
        end_date_utc=end_ts_utc,
        report_date=start_ts_ist.strftime("%Y-%m-%d"),
    )


# ============================================================================
# OPTION 1: Automatic (Previous IST Day)
# ============================================================================

window = get_reporting_window()

# ============================================================================
# OPTION 2: Manual IST Date Range
# ============================================================================

# window = get_reporting_window(
#     start_date_ist="2026-05-01",
#     end_date_ist="2026-05-22",
# )


# ============================================================================
# Validation Output
# ============================================================================
start_date = window.start_date_utc
end_date = window.end_date_utc
report_date = window.report_date
print("=" * 50)
print("REPORTING WINDOW")
print("=" * 50)

print(f"Start Date (IST): {window.start_date_ist}")
print(f"End Date   (IST): {window.end_date_ist}")
print()

print(f"Start Date (UTC): {window.start_date_utc}")
print(f"End Date   (UTC): {window.end_date_utc}")
print()

print(f"Report Date     : {window.report_date}")

# %% [markdown]
# ## Fetch Device Identification Data

# %% [markdown]
# ### Fetch Device List

# %%
# Fetch device_id list with identification data from device table either local or prod postgres db.
from sqlalchemy import text

# Local DB for RP
with engine_prod_pg.connect() as connection_local_pg:
    device_id_list_rp = connection_local_pg.execute(text("""
                SELECT DISTINCT device_id
                FROM public.devices_device
                WHERE length(device_id) = '15'
                ORDER BY device_id;
            """)).scalars().all()

# Local DB for MMI
with engine_prod_pg.connect() as connection_local_pg:
    device_id_list_mmi = connection_local_pg.execute(text("""
                SELECT DISTINCT device_id
                FROM public.devices_device
                WHERE length(device_id) = '7'
                ORDER BY device_id;
            """)).scalars().all()

# Check the device_id list
logger.info(f"Total Number of devices RP: {len(device_id_list_rp)}")
logger.info(f"Device_id List: {device_id_list_rp}")

logger.info(f"Total Number of devices MMI: {len(device_id_list_mmi)}")
logger.info(f"Device_id List: {device_id_list_mmi}")

print(
    f"Total No. of Devices: {int(len(device_id_list_rp)) + int(len(device_id_list_mmi))}"
)

# %% [markdown]
# ### Fetch Device Identification Data from Device Table

# %%
from src.data_fetching import fetch_device_data

# %%
# -------------------------------------------------------------------
# GET DEVICE IDENTIFICATION DATA Usage
# -------------------------------------------------------------------
device_df = fetch_device_data(logger, engine_prod_pg)

# %%
# device_df = device_df.loc[device_df["device_id"].str.len() == 7]
display(device_df)

# %% [markdown]
# ## Fetch Data for devices from DeviceData Table

# %% [markdown]
# ### Fetch Data for RP devices from DeviceData Table

# %%
from src.data_fetching import fetch_data_from_devicedata

# %%
# -------------------------------------------------------------------
# GET DEVICE CAN DATA Usage
# -------------------------------------------------------------------
raw_device_data = fetch_data_from_devicedata(
    logger=logger,
    engine=engine_prod_pg,
    device_ids=device_id_list_rp,
    start_ts=start_date,
    end_ts=end_date,
    max_workers=20,  # Tune based on DB connection pool
)

# %%
# Remove the dfs from dict where df is empty
raw_device_data = {
    device_id: df for device_id, df in raw_device_data.items() if not df.empty
}

# %%
# Check raw_device_data
raw_device_data.keys()

# %% [markdown]
# ### Fetch Data for MMI Devices from MYSQL DB

# %%
# Fetch data for MMI devices
mmi_devices = (
    device_df.loc[device_df["device_id"].str.len() == 7]
    .set_index("device_id")["device_type_name"]
    .to_dict()
)

# %% [markdown]
# ### Get MMI vehicles table list from MYSQL

# %%
from src.data_fetching import get_mmi_table_mapping, fetch_single_mmi_device_data

# %%
# 1. Build MMI device → table mapping
mmi_tables = get_mmi_table_mapping(
    logger=logger,
    engine=engine_local_mysql,
    device_df=device_df,
)

print(mmi_tables)
print(len(mmi_tables))

# %%
mmi_raw_device_data = {}
mmi_device_id_set = set(device_id_list_mmi)
MAX_WORKERS = 20  # safe cap

with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = [
        executor.submit(
            fetch_single_mmi_device_data,
            device_id,
            info["VRN"],
            info["table_name"],
            window.start_date_ist,
            window.end_date_ist,
            logger,
            engine_local_mysql,
            device_df,
        )
        for device_id, info in mmi_tables.items()
        if device_id in mmi_device_id_set
    ]

    for future in as_completed(futures):
        device_id, df = future.result()
        if df is not None and not df.empty:
            mmi_raw_device_data[device_id] = df

# %%
# Remove the dfs from dict where df is empty
mmi_raw_device_data = {
    device_id: df for device_id, df in mmi_raw_device_data.items() if not df.empty
}

print(int(len(mmi_raw_device_data.keys())))
print(f"{mmi_raw_device_data.keys()}")

# %%
mmi_raw_device_data.keys()

# %% [markdown]
# ## Map vehicle identification data with raw device data

# %%
for device_id, raw_df in raw_device_data.items():
    raw_device_data[device_id] = raw_df.merge(device_df, on="device_id", how="left")

# %%
# Close all active DB connections

# Close active connections
if connection_prod_pg:
    connection_prod_pg.close()

if connection_local_mysql:
    connection_local_mysql.close()

# Dispose engines (recommended when shutting down app/script)
if engine_prod_pg:
    engine_prod_pg.dispose()

if engine_local_mysql:
    engine_local_mysql.dispose()

# %% [markdown]
# ### Check any df from raw_device_data

# %%
# raw_df = raw_device_data["861409075137068"]
# print(raw_df.columns.to_list())

# %%
# display(raw_df)

# %% [markdown]
# ### Check any df from mmi_raw_device_data

# %%
# mmi_raw_df = mmi_raw_device_data["2262058"]
# print(mmi_raw_df.columns.to_list())

# %%
# display(mmi_raw_df)

# %% [markdown]
# # Data Cleaning and Pre-processing

# %%
# Function to get a single value from a df column
def get_single_value(series_like) -> str | None:
    s = pd.Series(series_like).dropna()
    return s.iat[0] if not s.empty else None  # type: ignore

# %% [markdown]
# ## Clean Raw data for RP and MMI Devices

# %%
# Clean each df and pre-process to perform calculations
from src.data_cleaning import clean_raw_df, mmi_clean_raw_df, clean_individual_vehicle

# %%
cleaned_device_data = {}

# FOR RP Devices
for device_id, raw_df in raw_device_data.items():

    # print(device_id)
    cleaned_df = clean_raw_df(raw_df)

    cleaned_device_data[device_id] = cleaned_df

# FOR MMI Devices
for device_id, raw_df in mmi_raw_device_data.items():

    device_type_name = get_single_value(raw_df["device_type_name"])

    cleaned_df = mmi_clean_raw_df(raw_df, device_type_name)

    cleaned_device_data[device_id] = cleaned_df

# %% [markdown]
# ## Clean Individual Vehicles

# %%
for device_id, df in cleaned_device_data.items():

    # if df becomes empty → skip
    if df.empty:
        continue

    # Clean individual function
    df = clean_individual_vehicle(df)

    cleaned_device_data[device_id] = df

# %% [markdown]
# ### Check cleaned dfs

# %%
print(int(len(cleaned_device_data.keys())))
cleaned_device_data.keys()

# %%
# # Check cleaned DF
# cleaned_df = cleaned_device_data["861409075024134"]
# cleaned_df.columns

# %%
# display(cleaned_df)

# %% [markdown]
# # Data Processing

# %% [markdown]
# ## Mode Detection

# %%
from src.mode_detection import add_mode_column

# %% [markdown]
# ## Custom Time Format

# %%
from src.custom_time_caculation import custom_time_calculate, seconds_to_hhmmss_scalar

# %% [markdown]
# ## Energy Calculations

# %%
from src.distance_calculations import get_valid_odometer_range, get_distance_from_rpm
from src.energy_calculation import energy_calculation_4w, energy_calculation_3w
from src.session_detection import compute_session_metrics, get_top_sessions
from src.dtc_calculations import get_dtc_summary, get_fault_summary, get_health_report
from collections import Counter

# %% [markdown]
# ## Main Processing Loop

# %%
# dict to store calculated vehicles
processed_devices = {}

# List to store calculated metrics
calculated_devices_list = []

# Ensure start/end are UTC-aware
start_date = pd.Timestamp(start_date).tz_convert("UTC")
end_date = pd.Timestamp(end_date).tz_convert("UTC")

# Main loop
for current_date in pd.date_range(start=start_date, end=end_date, tz="UTC"):

    day_start = current_date.normalize()
    day_end = day_start + pd.Timedelta(days=1)

    for device_id, df in cleaned_device_data.items():

        # Ensure timestamp column is UTC-aware
        df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)

        logger.info(
            f"📅 Processing Date: {current_date.date()} " f"for Device_id: {device_id}"
        )

        # Filter daily data
        df_filtered = df.loc[
            (df["timestamp"] >= day_start) & (df["timestamp"] < day_end)
        ].copy()

        if df_filtered.empty:
            logger.warning(f"DF is empty! for DATE: {current_date.date()}")
            continue

        # sort the df as per timestamp
        df.sort_values(by="timestamp", inplace=True, ascending=True)

        # Drop NaT values
        valid_timestamps = df["timestamp"].dropna()

        # Keep timezone-aware timestamps
        start_dt = day_start
        end_dt = day_end

        valid_timestamps = df_filtered.loc[
            (df_filtered["timestamp"] >= start_dt)
            & (df_filtered["timestamp"] < end_dt),
            "timestamp",
        ]

        # Mode Detection
        df = add_mode_column(df)

        # Time formatting
        df = custom_time_calculate(df)

        processed_devices[device_id] = df

        # Get device type
        device_type = get_single_value(df["device_type"])

        # Get device type name
        device_type_name = get_single_value(df["device_type_name"])

        # Skip unknown device_type_names
        allowed = {"12M", "13.5M", "3S", "55T", "6S", "7M", "9M"}

        if device_type_name not in allowed:
            continue

        # VRN Number
        vrn = get_single_value(df["VRN"])

        # VRN Number
        chassis = get_single_value(df["chassis_number"])

        # Fleet
        fleet = get_single_value(df["fleet"])

        # City
        city = get_single_value(df["city"])

        if not valid_timestamps.empty:
            start_time = valid_timestamps.min().strftime("%H:%M:%S")
            end_time = valid_timestamps.max().strftime("%H:%M:%S")
        else:
            start_time = end_time = "00:00:00"

        # TIMES
        runtime = df["movement_duration"].sum()
        idletime = df["idle_duration"].sum()
        chargingtime = df["charging_duration"].sum()
        # stoppagetime = df["stoppage_duration"].sum()
        stoppagetime = 86400 - (runtime + idletime + chargingtime)

        # Start and end Ododmeter as well as Distance

        # --- START ODOMETER ---
        # Find the first non-null numeric value
        distance_odo = 0.0
        start_odometer, end_odometer, total_distance = get_valid_odometer_range(
            df, max_delta=10
        )

        # --------------------------------------------------
        # DISTANCE CALCULATION & SELECTION LOGIC
        # --------------------------------------------------

        # 1️⃣ Odometer-based distance
        # Use absolute delta; fall back to 0 if start reading is unavailable
        distance_odo = total_distance
        # distance_odo = (
        #     round(abs(end_odometer - start_odometer), 2)
        #     if start_odometer is not None
        #     else 0.0
        # )

        # 2️⃣ RPM-based distance (derived from telemetry)
        distance_rpm = get_distance_from_rpm(device_type_name, df) or 0.0

        # Pre-compute bounds for sanity checks
        min_distance = round(min(distance_odo, distance_rpm), 2)
        max_distance = round(max(distance_odo, distance_rpm), 2)

        # 3️⃣ Distance selection rules by vehicle type
        if device_type == "4w":
            """
            4W vehicles:
            - Prefer odometer distance when it looks reliable
            - Fall back to RPM distance for short trips
            - Cap extreme outliers using the conservative (min) estimate
            """

            # Default preference
            distance = distance_odo

            # Short trip → odometer often noisy
            if distance_odo < 100:
                distance = max_distance

            # Extreme values → use conservative estimate
            if max_distance > 650:
                distance = min_distance

        elif device_type == "3w":
            """
            3W vehicles:
            - Odometer is considered authoritative
            """
            distance = max_distance

        else:
            """
            Unknown device types:
            - Fail safely using the best available estimate
            """
            distance = max_distance

        # if len(device_id) < 15:
        #     logger.info(
        #         f"device_id: {device_id}, device_type_name: {device_type_name}, distance_odo: {distance_odo}, distance_rpm: {distance_rpm}, distance: {distance}"
        #     )

        # Total time for Average Speed
        avg_speed_time = runtime
        if runtime < 3600:
            avg_speed_time = runtime + idletime

        # Average Speed
        average_speed = (
            round((distance / (avg_speed_time / 3600)), 2) if runtime > 0 else 0
        )

        # Time format to HH:MM
        runtime = seconds_to_hhmmss_scalar(runtime)
        idletime = seconds_to_hhmmss_scalar(idletime)
        chargingtime = seconds_to_hhmmss_scalar(chargingtime)
        stoppagetime = seconds_to_hhmmss_scalar(stoppagetime)

        # START AND END SOC
        start_soc = round((df["soc"].iloc[0]), 2)
        end_soc = round((df["soc"].iloc[-1]), 2)

        energy_metrics = {
            "energy_consumed": 0.0,
            "regen": 0.0,
            "energy_consumption_rate": 0.0,
            "soc_sum": 0.0,
            "distance_per_soc": 0.0,
            "charging_units": 0.0,
            "insufficient_charge": False,
            "dod": False,
            "motor_energy": 0.0,
            "motor_regen": 0.0,
            "dcdc_energy": 0.0,
            "ecomp_steering_energy": 0.0,
            "bcs_energy": 0.0,
            "tcs_energy": 0.0,
        }
        ### Processing based of device_type_name ###
        if df["device_type_name"].isin(["3S", "6S"]).all():
            energy_metrics = energy_calculation_3w(
                device_id, df, distance_odo, distance_rpm
            )

        elif df["device_type_name"].isin(["7M", "9M", "12M", "13.5M", "55T"]).all():
            energy_metrics = energy_calculation_4w(
                device_id, device_type_name, df, distance_odo, distance_rpm
            )
        else:
            logger.info(
                f"Unknown Device: {device_id}, device_type_name: {device_type_name}"
            )

        # Getting Energy Metrics
        energy_consumed = round(abs(energy_metrics["energy_consumed"]), 2)
        regen = round(abs(energy_metrics["regen"]), 2)
        charging_units = round(abs(energy_metrics["charging_units"]), 2)
        motor_energy = round(abs(energy_metrics["motor_energy"]), 2)
        motor_regen = round(abs(energy_metrics["motor_regen"]), 2)
        dcdc_energy = round(abs(energy_metrics["dcdc_energy"]), 2)
        bcs_energy = round(abs(energy_metrics["bcs_energy"]), 2)
        tcs_energy = round(abs(energy_metrics["tcs_energy"]), 2)
        ecomp_steering_energy = round(abs(energy_metrics["ecomp_steering_energy"]), 2)

        # Validate Energy component Wise
        energy_used = round(
            abs(
                motor_energy
                + dcdc_energy
                + bcs_energy
                + tcs_energy
                + ecomp_steering_energy
            ),
            2,
        )

        soc_sum = round(
            df.loc[df["Mode"].isin(["Movement", "Idle"]), "soc_delta"].abs().sum(), 2
        )
        distance_per_soc = abs(round(distance / soc_sum, 2) if soc_sum != 0 else 0)

        # ECR
        energy_consumption_rate = abs(energy_metrics["energy_consumption_rate"])

        dod = energy_metrics["dod"]
        insufficient_charge = energy_metrics["insufficient_charge"]

        # Max Temperatures
        max_battery_temperature = round(df["battery_temperature"].max(), 2)
        max_motor_temperature = round(df["motor_temperature"].clip(lower=0).max(), 2)
        max_mcu_temperature = round(df["mcu_temperature"].clip(lower=0).max(), 2)
        max_bcs_temperature = round(df["bcs_temperature"].clip(lower=0).max(), 2)
        max_tcs_temperature = round(df["tcs_temperature"].clip(lower=0).max(), 2)
        max_dcdc_temperature = round(df["dcdc_temperature"].clip(lower=0).max(), 2)
        max_ecomp_temperature = round(df["ecomp_temperature"].clip(lower=0).max(), 2)
        max_steering_temperature = round(
            df["steering_temperature"].clip(lower=0).max(), 2
        )

        # DTC count and list
        # dtc_count, dtc_list = get_dtc_summary(df)

        # Get Vehicle Health check
        health_check = get_health_report(df)
        dtc_count = health_check["dtc_count"]
        dtc_list = health_check["dtc_list"]
        fault_count = health_check["fault_count"]
        fault_list = health_check["fault_list"]
        total_issues = health_check["total_issues"]
        health_status = health_check["health_status"]

        # Calculating sessions
        sessions = compute_session_metrics(
            df, min_duration=600
        )  # 900 seconds = 15 minutes

        sessions_pretty_json = json.dumps(sessions, indent=2, default=str)

        # Session counts
        session_counts = Counter(s["label"] for s in sessions)

        movement_count = session_counts.get("Movement", 0)
        idle_count = session_counts.get("Idle", 0)
        stopped_count = session_counts.get("Stopped", 0)
        charging_count = session_counts.get("Charging", 0)

        # Get Top sessions
        top_sessions = get_top_sessions(sessions, n=3)
        top_movement_sessions = json.dumps(
            top_sessions.get("Movement", []), indent=2, default=str
        )

        idle_sessions = top_sessions.get("Idle", [])

        # Modify sessions: keep only duration in HH:MM:SS
        for i, session in enumerate(idle_sessions):
            duration_seconds = float(session.get("duration", 0))
            hours, remainder = divmod(duration_seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            hours = int(hours if not pd.isna(hours) else 0)
            minutes = int(minutes if not pd.isna(minutes) else 0)
            seconds = int(seconds if not pd.isna(seconds) else 0)
            idle_sessions[i] = (
                f"Duration[{i+1}]: {int(hours):02d}:{int(minutes):02d}:{int(seconds):02d}\n"
            )

        # Dump to JSON
        top_idle_sessions = "".join(idle_sessions)

        top_charging_sessions = json.dumps(
            top_sessions.get("Charging", []), indent=2, default=str
        )

        # Append row for each device_id
        calculated_devices_list.append(
            {
                "device_id": device_id,
                "device_type": device_type,
                # Vehicle identifier metrics
                "VRN": vrn,
                "CHASSIS": chassis,
                "PLATFORM": device_type_name,
                "FLEET_NAME": fleet,
                "LOCATION": city,
                # Data timestamp
                "DATE": current_date.date(),
                "START_TIME_OF_DAY": start_time,
                "END_TIME_OF_DAY": end_time,
                # Vehicle Stats
                "TOTAL_DISTANCE_TRAVELLED(km)": round(distance_odo, 2),
                "TOTAL_DISTANCE_TRAVELLED_RPM(km)": round(distance_rpm, 2),
                "AVERAGE_SPEED(kmph)": average_speed,
                "START_SOC_OF_THE_DAY": start_soc,
                "END_SOC_OF_THE_DAY": end_soc,
                # Max Temperatures
                "MAX_BATTERY_TEMPERATURE(°C)": max_battery_temperature,
                "MAX_MOTOR_TEMPERATURE(°C)": max_motor_temperature,
                "MAX_MCU_TEMPERATURE(°C)": max_mcu_temperature,
                "MAX_BCS_TEMPERATURE(°C)": max_bcs_temperature,
                "MAX_TCS_TEMPERATURE(°C)": max_tcs_temperature,
                "MAX_DCDC_TEMPERATURE(°C)": max_dcdc_temperature,
                "MAX_ECOMP_TEMPERATURE(°C)": max_ecomp_temperature,
                "MAX_STEERING_TEMPERATURE(°C)": max_steering_temperature,
                # Vehicle Runtime Stats
                "RUNTIME_TIME(HH:MM)": runtime,
                "IDLE_TIME(HH:MM)": idletime,
                "CHARGING_TIME(HH:MM)": chargingtime,
                "STOPPAGE_TIME(HH:MM)": stoppagetime,
                "START_ODOMETER(km)": start_odometer,
                "END_ODOMETER(km)": end_odometer,
                # Vehicle Session Stats
                "MOVEMENT_SESSION_COUNT": movement_count,
                "IDLE_SESSION_COUNT": idle_count,
                "CHARGING_SESSION_COUNT": charging_count,
                # Vehicle Energy Metrics
                "SOC_SUM": soc_sum,
                "ENERGY_COMPONENT_WISE": energy_used,
                "ENERGY_CONSUMED(kWh)": energy_consumed,
                "REGENERATIVE_ENERGY(kWh)": regen,
                "CHARGING_UNITS(kWh)": charging_units,
                "LOW_SOC_INCIDENCE(<20%)": dod,
                "CELL_BALANCING": insufficient_charge,
                "ENERGY_CONSUMPTION_RATE(kWh/km)": energy_consumption_rate,
                "KM_PER_SOC": distance_per_soc,
                # Component Wise energy usage
                "MOTOR_EC(kWh)": motor_energy,
                "MOTOR_REGEN(kWh)": motor_regen,
                "DCDC_EC(kWh)": dcdc_energy,
                "ECOMPRESSOR_AND_STEERING_EC(kWh)": ecomp_steering_energy,
                "BCS_EC(kWh)": bcs_energy,
                "TCS_EC": tcs_energy,
                # Vehicle Health Status Check
                "DTC_COUNT": dtc_count,
                "DTC_LIST": dtc_list,
                "FAULT_COUNT": fault_count,
                "FAULT_LIST": fault_list,
                "TOTAL_ISSUES": total_issues,
                "HEALTH_STATUS": health_status,
                # Sessions
                # "TOP_MOVEMENT_SESSIONS": top_movement_sessions,
                "TOP_IDLE_SESSIONS": top_idle_sessions,
                # "TOP_CHARGING_SESSIONS": top_charging_sessions,
                # "SESSIONS": sessions_pretty_json,
            }
        )

calculated_devices_df = pd.DataFrame(calculated_devices_list)

# %% [markdown]
# ## Sort order and filter main calculation results

# %%
# calculated_devices_df = calculated_devices_df.drop(
#     calculated_devices_df[
#         (calculated_devices_df["TOTAL_DISTANCE_TRAVELLED(km)"] < 10)
#         & (calculated_devices_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"] < 10)
#     ].index
# )

# Replace 0 values in TOTAL_DISTANCE_TRAVELLED(km)
# with TOTAL_DISTANCE_TRAVELLED_RPM(km)
calculated_devices_df.loc[
    calculated_devices_df["TOTAL_DISTANCE_TRAVELLED(km)"] == 0,
    "TOTAL_DISTANCE_TRAVELLED(km)",
] = calculated_devices_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"]

# Drop rows where total distance travelled is less than 10
calculated_devices_df = calculated_devices_df[
    (calculated_devices_df["TOTAL_DISTANCE_TRAVELLED(km)"] >= 10)
    | (calculated_devices_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"] >= 10)
]

# Separate the mmi vehicles and Roadpoint vehicles based on device_id length
calculated_devices_df["device_id_length"] = (
    calculated_devices_df["device_id"].astype(str).str.len()
)

# Get result df for MMI
calculated_devices_df_mmi = calculated_devices_df.loc[
    calculated_devices_df["device_id_length"] != 15
].copy()

# Sort by distance
calculated_devices_df = calculated_devices_df.sort_values(
    by=["TOTAL_DISTANCE_TRAVELLED(km)"], ascending=[False]
)

# Get result df for RP
calculated_devices_df_rp = calculated_devices_df.loc[
    (
        ~calculated_devices_df["FLEET_NAME"].str.contains(
            "pre|dispatch", case=False, na=False
        )
    )
    & (calculated_devices_df["device_id_length"] == 15)
].copy()

# %% [markdown]
# ### Check RP and MMI calculated DFs

# %%
temp_check_df = calculated_devices_df[
    [  # Vehicle identifier metrics
        "device_id",
        # "VRN",
        # "CHASSIS",
        "PLATFORM",
        "FLEET_NAME",
        # "LOCATION",
        # Data timestamp
        "DATE",
        # "START_TIME_OF_DAY",
        # "END_TIME_OF_DAY",
        # Vehicle Stats
        "TOTAL_DISTANCE_TRAVELLED(km)",
        "TOTAL_DISTANCE_TRAVELLED_RPM(km)",
        # "AVERAGE_SPEED(kmph)",
        # "START_SOC_OF_THE_DAY",
        # "END_SOC_OF_THE_DAY",
        # # Max Temperatures
        # "MAX_BATTERY_TEMPERATURE(°C)",
        # "MAX_MOTOR_TEMPERATURE(°C)",
        # "MAX_MCU_TEMPERATURE(°C)",
        # "MAX_BCS_TEMPERATURE(°C)",
        # "MAX_TCS_TEMPERATURE(°C)",
        # "MAX_DCDC_TEMPERATURE(°C)",
        # "MAX_ECOMP_TEMPERATURE(°C)",
        # "MAX_STEERING_TEMPERATURE(°C)",
        # # Vehicle Runtime Stats
        # "RUNTIME_TIME(HH:MM)",
        # "IDLE_TIME(HH:MM)",
        # "CHARGING_TIME(HH:MM)",
        # "STOPPAGE_TIME(HH:MM)",
        # "START_ODOMETER(km)",
        # "END_ODOMETER(km)",
        # # Vehicle Session Stats
        # "MOVEMENT_SESSION_COUNT",
        # "IDLE_SESSION_COUNT",
        # "CHARGING_SESSION_COUNT",
        # # Vechicle Energy Metrics
        "SOC_SUM",
        "ENERGY_COMPONENT_WISE",
        "ENERGY_CONSUMED(kWh)",
        "REGENERATIVE_ENERGY(kWh)",
        "CHARGING_UNITS(kWh)",
        # "LOW_SOC_INCIDENCE(<20%)",
        # "CELL_BALANCING",
        "ENERGY_CONSUMPTION_RATE(kWh/km)",
        "KM_PER_SOC",
        # Component Wise energy usage
        "MOTOR_EC(kWh)",
        "MOTOR_REGEN(kWh)",
        "DCDC_EC(kWh)",
        "ECOMPRESSOR_AND_STEERING_EC(kWh)",
        "BCS_EC(kWh)",
        "TCS_EC",
        # # Vehicle DTC and Faults
        # "DTC_COUNT",
        # "DTC_LIST",
        # "FAULT_COUNT",
        # "FAULT_LIST",
        # # Sessions
        # "TOP_IDLE_SESSIONS",
    ]
].copy()

# Ensure numeric columns first
temp_check_df["TOTAL_DISTANCE_TRAVELLED(km)"] = pd.to_numeric(
    temp_check_df["TOTAL_DISTANCE_TRAVELLED(km)"], errors="coerce"
)

temp_check_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"] = pd.to_numeric(
    temp_check_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"], errors="coerce"
)

temp_check_df["distance_diff"] = abs(
    temp_check_df["TOTAL_DISTANCE_TRAVELLED(km)"]
    - temp_check_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"]
)

# Calculate percentage safely
temp_check_df["distance_diff_pct"] = (
    abs(
        temp_check_df["TOTAL_DISTANCE_TRAVELLED(km)"]
        - temp_check_df["TOTAL_DISTANCE_TRAVELLED_RPM(km)"]
    )
    / temp_check_df["TOTAL_DISTANCE_TRAVELLED(km)"].replace(0, np.nan)
    * 100
).round(2)

# %%
# display(temp_check_df)

# %%
display(calculated_devices_df)

# %%
# display(calculated_devices_df_mmi)

# %%
# # Check any processed df
# check_processed = processed_devices["861919084423614"]
# display(check_processed)

# %% [markdown]
# # Create Final and Service DFs

# %%
final_col_list = [
    # Vehicle identifier metrics
    "device_id",
    "VRN",
    "CHASSIS",
    "PLATFORM",
    "FLEET_NAME",
    "LOCATION",
    # Data timestamp
    "DATE",
    "START_TIME_OF_DAY",
    "END_TIME_OF_DAY",
    # Vehicle Stats
    "TOTAL_DISTANCE_TRAVELLED(km)",
    "TOTAL_DISTANCE_TRAVELLED_RPM(km)",
    "AVERAGE_SPEED(kmph)",
    "START_SOC_OF_THE_DAY",
    "END_SOC_OF_THE_DAY",
    # Max Temperatures
    "MAX_BATTERY_TEMPERATURE(°C)",
    "MAX_MOTOR_TEMPERATURE(°C)",
    "MAX_MCU_TEMPERATURE(°C)",
    "MAX_BCS_TEMPERATURE(°C)",
    "MAX_TCS_TEMPERATURE(°C)",
    "MAX_DCDC_TEMPERATURE(°C)",
    "MAX_ECOMP_TEMPERATURE(°C)",
    "MAX_STEERING_TEMPERATURE(°C)",
    # Vehicle Runtime Stats
    "RUNTIME_TIME(HH:MM)",
    "IDLE_TIME(HH:MM)",
    "CHARGING_TIME(HH:MM)",
    "STOPPAGE_TIME(HH:MM)",
    "START_ODOMETER(km)",
    "END_ODOMETER(km)",
    # Vehicle Session Stats
    "MOVEMENT_SESSION_COUNT",
    "IDLE_SESSION_COUNT",
    "CHARGING_SESSION_COUNT",
    # Vechicle Energy Metrics
    "ENERGY_CONSUMED(kWh)",
    "REGENERATIVE_ENERGY(kWh)",
    "CHARGING_UNITS(kWh)",
    "LOW_SOC_INCIDENCE(<20%)",
    "CELL_BALANCING",
    "ENERGY_CONSUMPTION_RATE(kWh/km)",
    "KM_PER_SOC",
    # Component Wise energy usage
    "MOTOR_EC(kWh)",
    "MOTOR_REGEN(kWh)",
    "DCDC_EC(kWh)",
    "ECOMPRESSOR_AND_STEERING_EC(kWh)",
    "BCS_EC(kWh)",
    "TCS_EC",
    # Vehicle DTC and Faults
    "DTC_COUNT",
    "DTC_LIST",
    "FAULT_COUNT",
    "FAULT_LIST",
    # Sessions
    "TOP_IDLE_SESSIONS",
]

final_df = calculated_devices_df[final_col_list]
service_df = final_df.loc[
    ~final_df["FLEET_NAME"].str.contains(r"pre|dispatch|proto", case=False, na=False)
].copy()

# create separate dfs for mmi and rp vehicles for getting ranked dfs
final_df_mmi = calculated_devices_df_mmi[final_col_list]
service_df_mmi = final_df_mmi.loc[
    ~final_df_mmi["FLEET_NAME"].str.contains(
        r"pre|dispatch|proto", case=False, na=False
    )
].copy()


final_df_rp = calculated_devices_df_rp[final_col_list]
service_df_rp = final_df_rp.loc[
    ~final_df_rp["FLEET_NAME"].str.contains(r"pre|dispatch|proto", case=False, na=False)
].copy()

# final_df keep only proto vehicles
final_df = final_df.loc[
    final_df["FLEET_NAME"].str.contains(r"testing|proto|Proto", case=False, na=False)
].copy()

# For Proto only get only Proto in final dfs
final_df_mmi = pd.DataFrame()
final_df_rp = final_df[final_col_list]

# %%
display(final_df)

# %%
display(service_df)

# %% [markdown]
# ## Ranked DFs

# %%
from src.ranked_df import get_ranked

# %%
# ---------------------------
# Columns lists
# ---------------------------
rd_cols = [
    "PLATFORM",
    "VRN",
    "CHASSIS",
    "RUNTIME_TIME(HH:MM)",
    "IDLE_TIME(HH:MM)",
    "CHARGING_TIME(HH:MM)",
    "STOPPAGE_TIME(HH:MM)",
    "TOTAL_DISTANCE_TRAVELLED(km)",
    "KM_PER_SOC",
    "ENERGY_CONSUMPTION_RATE(kWh/km)",
    "TOP_IDLE_SESSIONS",
]

service_cols = [
    "PLATFORM",
    "FLEET_NAME",
    "VRN",
    "CHASSIS",
    "RUNTIME_TIME(HH:MM)",
    "IDLE_TIME(HH:MM)",
    "CHARGING_TIME(HH:MM)",
    "STOPPAGE_TIME(HH:MM)",
    "TOTAL_DISTANCE_TRAVELLED(km)",
    "AVERAGE_SPEED(kmph)",
    "DEPTH_OF_DISCHARGE",
    "INSUFFICIENT_CHARGE",
    "MAX_BATTERY_TEMPERATURE(°C)",
    "KM_PER_SOC",
    "ENERGY_CONSUMPTION_RATE(kWh/km)",
    "TOP_IDLE_SESSIONS",
]

# ---------------------------
# Generate ranked reports
# ---------------------------
# MMI
rd_ranked_df_mmi = get_ranked(final_df_mmi, rd_cols)
service_ranked_df_mmi = get_ranked(service_df_mmi, service_cols)
# RP
rd_ranked_df_rp = get_ranked(final_df_rp, rd_cols)
service_ranked_df_rp = get_ranked(service_df_rp, service_cols)

# %%
display(rd_ranked_df_rp)

# %%
display(rd_ranked_df_mmi)

# %% [markdown]
# # Report Generation

# %% [markdown]
# ## Custom Column width spacing for Report

# %%
from src.custom_excel_formatting import (
    highlight_threshold_cells_with_comments,
    apply_custom_column_widths,
    apply_autofilter_and_freeze,
    format_header_row,
    apply_zebra_rows,
    apply_threshold_highlighting,
)

# %% [markdown]
# ### Specify custom widths for each column

# %%
# Specify custom column widths
COLUMN_WIDTHS = {
    "device_id": 16,
    "VRN": 13,
    "CHASSIS": 19,
    "PLATFORM": 10,
    "FLEET_NAME": 20,
    "LOCATION": 14,
    "DATE": 10,
    "START_TIME_OF_DAY": 11,
    "END_TIME_OF_DAY": 10,
    "TOTAL_DISTANCE_TRAVELLED(km)": 16.55,
    "TOTAL_DISTANCE_TRAVELLED_RPM(km)": 18,
    "AVERAGE_SPEED(kmph)": 14.18,
    "START_SOC_OF_THE_DAY": 12.82,
    "END_SOC_OF_THE_DAY": 11.18,
    "MAX_BATTERY_TEMPERATURE(°C)": 13,
    "MAX_MOTOR_TEMPERATURE(°C)": 12.36,
    "MAX_MCU_TEMPERATURE(°C)": 10.64,
    "MAX_BCS_TEMPERATURE(°C)": 9.55,
    "MAX_TCS_TEMPERATURE(°C)": 9.55,
    "MAX_DCDC_TEMPERATURE(°C)": 11.18,
    "MAX_ECOMP_TEMPERATURE(°C)": 12.64,
    "MAX_STEERING_TEMPERATURE(°C)": 14,
    "RUNTIME_TIME(HH:MM)": 13.64,
    "IDLE_TIME(HH:MM)": 9.45,
    "CHARGING_TIME(HH:MM)": 14.55,
    "STOPPAGE_TIME(HH:MM)": 14.64,
    "START_ODOMETER(km)": 16.55,
    "END_ODOMETER(km)": 14.91,
    "MOVEMENT_SESSION_COUNT": 18.82,
    "IDLE_SESSION_COUNT": 12,
    "CHARGING_SESSION_COUNT": 17.36,
    "ENERGY_CONSUMED(kWh)": 17.55,
    "REGENERATIVE_ENERGY(kWh)": 20.55,
    "CHARGING_UNITS(kWh)": 15.36,
    "LOW_SOC_INCIDENCE(<20%)": 18.91,
    "CELL_BALANCING": 15,
    "ENERGY_CONSUMPTION_RATE(kWh/km)": 21,
    "KM_PER_SOC": 12,
    "DTC_COUNT": 11,
    "DTC_LIST": 70,
    "FAULT_COUNT": 14,
    "FAULT_LIST": 70,
    "TOP_IDLE_SESSIONS": 20,
    "TOP_CHARGING_SESSIONS": 20,
    # "SESSIONS": 20,
}

# %% [markdown]
# ### Energy Thresholds 

# %%
energy_thresholds = {
    "TOTAL_DISTANCE_TRAVELLED(km)": {"value": 700, "operator": ">"},
    "ENERGY_CONSUMPTION_RATE(kWh/km)": {"value": 2.5, "operator": ">"},
    "KM_PER_SOC": {"value": 4, "operator": ">"},
}

comment_columns = {
    "distance": "TOTAL_DISTANCE_TRAVELLED(km)",
    "energy": "ENERGY_CONSUMED(kWh)",
    "regen": "REGENERATIVE_ENERGY(kWh)",
}

# temperature columns
temp_cols = [c for c in df.columns if "TEMP" in c.upper()]

thresholds = {
    "MAX_BATTERY_TEMPERATURE(°C)": 40,
    "MAX_MOTOR_TEMPERATURE(°C)": 150,
    "MAX_MCU_TEMPERATURE(°C)": 70,
    "MAX_BCS_TEMPERATURE(°C)": 40,
    "MAX_TCS_TEMPERATURE(°C)": 50,
    "MAX_DCDC_TEMPERATURE(°C)": 78,
    "MAX_ECOMP_TEMPERATURE(°C)": 73,
    "MAX_STEERING_TEMPERATURE(°C)": 73,
}

# %% [markdown]
# ## Generate Reports

# %%
# Copy dataframes
rddf = final_df.copy()
service_df = service_df.copy()


output_file = rf"E:\DA_work\EVDA\results\excel_reports\daily_reports\Daily_RAW_Report_({report_date}).xlsx"
output_file_rd = rf"E:\DA_work\EVDA\results\excel_reports\daily_reports\Daily_Report_({report_date}).xlsx"
output_file_service = rf"E:\DA_work\EVDA\results\excel_reports\daily_reports\Daily_Service_Report_({report_date}).xlsx"

output_dict = {
    output_file: calculated_devices_df,
    output_file_rd: rddf,
    output_file_service: service_df,
}

# ──────────────────────────────
# 🎨 Styles
# ──────────────────────────────
header_fill = PatternFill("solid", fgColor="4BACC6")
odd_row_fill = PatternFill("solid", fgColor="B7DEE8")
even_row_fill = PatternFill("solid", fgColor="F2F2F2")
red_fill = PatternFill("solid", fgColor="FF0000")

thin_border = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)

for output_file, df in output_dict.items():

    temp_cols = [c for c in df.columns if "TEMP" in c.upper()]

    # 1️⃣ Write DataFrame
    with pd.ExcelWriter(output_file, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name=report_date, index=False)
        writer.book.save(output_file)

    # 2️⃣ Reload workbook for formatting
    wb = load_workbook(output_file)
    ws = wb[report_date]

    max_row = ws.max_row
    max_col = ws.max_column

    # 3️⃣ Autofilter + Freeze
    apply_autofilter_and_freeze(
        ws=ws,
        max_col=max_col,
        freeze_cell="K2",
    )

    # 4️⃣ Column widths
    apply_custom_column_widths(
        worksheet=ws,
        column_widths=COLUMN_WIDTHS,
        default_width=20,
        strict=False,
    )

    # 5️⃣ Header formatting
    format_header_row(
        ws=ws,
        max_col=max_col,
        header_fill=header_fill,
        thin_border=thin_border,
    )

    # 6️⃣ Zebra striping
    apply_zebra_rows(
        ws=ws,
        max_row=max_row,
        max_col=max_col,
        odd_row_fill=odd_row_fill,
        even_row_fill=even_row_fill,
        thin_border=thin_border,
    )

    # 7️⃣ Temperature threshold highlighting (overrides zebra)
    apply_threshold_highlighting(
        ws=ws,
        df=df,
        temp_cols=temp_cols,
        thresholds=thresholds,
        red_fill=red_fill,
    )

    highlight_threshold_cells_with_comments(
        ws=ws,
        thresholds=energy_thresholds,
        comment_columns=comment_columns,
        start_row=2,
        fill_color="FF0000",
        comment_author="AutoCheck",
    )

    wb.save(output_file)
    logger.info(f"Output saved at {output_file}")

# %% [markdown]
# # Send Mails with Reports

# %% [markdown]
# ## Generate HTML for email body
# 

# %%
from src.daily_report_mail_html import generate_html_tables

# 1. Generate R&D HTML Strings
rd_top_html_mmi, rd_trailing_html_mmi = generate_html_tables(rd_ranked_df_mmi, "rd")
rd_top_html_rp, rd_trailing_html_rp = generate_html_tables(rd_ranked_df_rp, "rd")

# 2. Generate Service HTML Strings
service_top_html_mmi, service_trailing_html_mmi = generate_html_tables(
    service_ranked_df_mmi, "service"
)
service_top_html_rp, service_trailing_html_rp = generate_html_tables(
    service_ranked_df_rp, "service"
)

# %% [markdown]
# ## Send Mails

# %%
from src.mail_script import send_email_to_service, send_email_to_proto

# %%
rd_file_name = f"Daily_Report_({report_date})"
service_file_name = f"Daily_Service_Report_({report_date})"


if len(rd_ranked_df_mmi) > 0 or len(rd_ranked_df_rp) > 0:
    send_email_to_proto(
        "rd_html",
        output_file_rd,
        report_date,
        rd_top_html_mmi,
        rd_trailing_html_mmi,
        rd_top_html_rp,
        rd_trailing_html_rp,
    )

if len(service_ranked_df_mmi) > 0 or len(service_ranked_df_rp) > 0:
    send_email_to_service(
        "service_html",
        output_file_service,
        report_date,
        service_top_html_mmi,
        service_trailing_html_mmi,
        service_top_html_rp,
        service_trailing_html_rp,
    )


