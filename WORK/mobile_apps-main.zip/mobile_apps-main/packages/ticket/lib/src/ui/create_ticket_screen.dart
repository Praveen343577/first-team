import 'package:flutter/material.dart';

class CreateTicketScreen extends StatefulWidget {
  // final TicketApi ticketApi;

  const CreateTicketScreen({super.key});

  @override
  State<CreateTicketScreen> createState() => _CreateTicketScreenState();
}

class _CreateTicketScreenState extends State<CreateTicketScreen> {
  final _formKey = GlobalKey<FormState>();

  final vehicleIdController = TextEditingController();
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final componentController = TextEditingController();
  final faultCodeController = TextEditingController();

  String type = "maintenance";
  String severity = "medium";

  bool isLoading = false;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => isLoading = true);

    try {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Ticket created successfully")),
        );
        Navigator.pop(context);
      }
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Failed: $e")));
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  InputDecoration _dec(String label) {
    return InputDecoration(
      labelText: label,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create Ticket")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Text(
                    "New Ticket",
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 20),

                  TextFormField(
                    controller: vehicleIdController,
                    decoration: _dec("Vehicle ID"),
                    validator: (v) =>
                        v == null || v.isEmpty ? "Required" : null,
                  ),

                  const SizedBox(height: 12),

                  TextFormField(
                    controller: titleController,
                    decoration: _dec("Title"),
                    validator: (v) =>
                        v == null || v.isEmpty ? "Required" : null,
                  ),

                  const SizedBox(height: 12),

                  TextFormField(
                    controller: descriptionController,
                    maxLines: 3,
                    decoration: _dec("Description"),
                    validator: (v) =>
                        v == null || v.isEmpty ? "Required" : null,
                  ),

                  const SizedBox(height: 12),

                  TextFormField(
                    controller: componentController,
                    decoration: _dec("Component"),
                  ),

                  const SizedBox(height: 12),

                  TextFormField(
                    controller: faultCodeController,
                    decoration: _dec("Fault Code"),
                  ),

                  const SizedBox(height: 16),

                  DropdownButtonFormField<String>(
                    initialValue: type,
                    decoration: _dec("Type"),
                    items: const [
                      DropdownMenuItem(
                        value: "maintenance",
                        child: Text("Maintenance"),
                      ),
                      DropdownMenuItem(
                        value: "breakdown",
                        child: Text("Breakdown"),
                      ),
                      DropdownMenuItem(
                        value: "inspection",
                        child: Text("Inspection"),
                      ),
                    ],
                    onChanged: (v) => setState(() => type = v!),
                  ),

                  const SizedBox(height: 12),

                  DropdownButtonFormField<String>(
                    initialValue: severity,
                    decoration: _dec("Severity"),
                    items: const [
                      DropdownMenuItem(value: "low", child: Text("Low")),
                      DropdownMenuItem(value: "medium", child: Text("Medium")),
                      DropdownMenuItem(value: "high", child: Text("High")),
                      DropdownMenuItem(
                        value: "critical",
                        child: Text("Critical"),
                      ),
                    ],
                    onChanged: (v) => setState(() => severity = v!),
                  ),

                  const SizedBox(height: 24),

                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: isLoading ? null : _submit,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                      child: isLoading
                          ? const CircularProgressIndicator()
                          : const Text("Create Ticket"),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
