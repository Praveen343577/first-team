import 'package:flutter/material.dart';
import 'package:ticket/src/cubit/ticket_list_cubit.dart';
import 'package:ticket/src/models/ticket.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ticket/src/ui/create_ticket_screen.dart';
import 'package:ticket/src/ui/widgets/ticket_card.dart';
import 'package:ticket/ticket.dart';

class TickerListScreen extends StatelessWidget {
  final TicketRepository repository;
  const TickerListScreen(this.repository, {super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => TicketListCubit(repository),
      child: const _TickerListScreen(),
    );
  }
}

class _TickerListScreen extends FetchScreen<TicketListCubit, List<Ticket>> {
  const _TickerListScreen();

  @override
  void onInit(BuildContext context) {
    context.read<TicketListCubit>().load();
  }

  @override
  Widget buildSuccess(BuildContext context, List<Ticket> tickets) {
    // final cs = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text("Driver")),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => const CreateTicketScreen()),
          );
        },
        child: const Icon(Icons.add),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: tickets.length,
        itemBuilder: (context, index) {
          final ticket = tickets[index];
          return TicketCard(ticket: ticket);
        },
      ),
    );
  }
}
