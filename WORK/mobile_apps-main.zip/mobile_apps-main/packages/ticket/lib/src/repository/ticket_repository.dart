import 'package:injectable/injectable.dart';
import 'package:ticket/src/api/ticket_api.dart';
import 'package:ticket/src/models/dto/create_ticket_request_dto.dart';
import 'package:ticket/src/models/dto/ticket_response_dto.dart';
import 'package:ticket/src/models/mapper/ticket_mapper.dart';
import 'package:ticket/src/models/ticket.dart';

@LazySingleton()
class TicketRepository {
  final TicketApi _api;
  final _mapper = TicketMapper();

  TicketRepository(this._api);

  Future<List<Ticket>> getTickets() async {
    final tickets = <Ticket>[];
    final response = await _api.getTickets();
    for (var item in response.items) {
      tickets.add(_mapper.convert<TicketResponseDto, Ticket>(item));
    }
    return tickets;
  }

  Future<dynamic> createTicket(CreateTicketRequestDto dto) => _api.create(dto);
}
