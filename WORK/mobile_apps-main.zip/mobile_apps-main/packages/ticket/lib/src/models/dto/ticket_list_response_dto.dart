import 'package:freezed_annotation/freezed_annotation.dart';

import 'ticket_response_dto.dart';

part 'ticket_list_response_dto.freezed.dart';
part 'ticket_list_response_dto.g.dart';

@freezed
abstract class TicketListResponseDto with _$TicketListResponseDto {
  const factory TicketListResponseDto({
    required List<TicketResponseDto> items,
    required int total,
    required int page,
    required int size,
    required int pages,
  }) = _TicketListResponseDto;

  factory TicketListResponseDto.fromJson(Map<String, dynamic> json) =>
      _$TicketListResponseDtoFromJson(json);
}
