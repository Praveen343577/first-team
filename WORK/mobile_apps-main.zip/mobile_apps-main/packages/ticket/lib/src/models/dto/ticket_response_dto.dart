import 'package:freezed_annotation/freezed_annotation.dart';

part 'ticket_response_dto.freezed.dart';
part 'ticket_response_dto.g.dart';

@freezed
abstract class TicketResponseDto with _$TicketResponseDto {
  const factory TicketResponseDto({
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    required String type,
    required String severity,
    required String title,
    required String description,
    required String component,
    @JsonKey(name: 'fault_code') required String faultCode,
    @JsonKey(name: 'ticket_metadata')
    required Map<String, dynamic> ticketMetadata,
    required String id,
    required String status,
    @JsonKey(name: 'created_by') required String createdBy,
    @JsonKey(name: 'updated_by') String? updatedBy,
    @JsonKey(name: 'created_at') required DateTime createdAt,
    @JsonKey(name: 'updated_at') required DateTime updatedAt,
    @JsonKey(name: 'resolved_at') DateTime? resolvedAt,
    @JsonKey(name: 'is_active') required bool isActive,
  }) = _TicketResponseDto;

  factory TicketResponseDto.fromJson(Map<String, dynamic> json) =>
      _$TicketResponseDtoFromJson(json);
}
