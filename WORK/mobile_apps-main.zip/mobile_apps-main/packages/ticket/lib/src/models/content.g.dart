// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'content.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_Content _$ContentFromJson(Map<String, dynamic> json) => _Content(
  title: json['title'] as String,
  description: json['description'] as String,
);

Map<String, dynamic> _$ContentToJson(_Content instance) => <String, dynamic>{
  'title': instance.title,
  'description': instance.description,
};
