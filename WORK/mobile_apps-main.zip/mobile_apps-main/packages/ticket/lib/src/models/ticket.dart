import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:ticket/src/models/content.dart';
import 'package:ticket/src/models/fault.dart';

part 'ticket.freezed.dart';
part 'ticket.g.dart';

@freezed
abstract class Ticket with _$Ticket {
  const factory Ticket({
    required String id,
    required String vehicleId,
    required Content content,
    required Fault fault,
    required String type,
    required String severity,
    required String status,
    required Map<String, dynamic> metadata,
    required String createdBy,
    String? updatedBy,
    required DateTime createdAt,
    required DateTime updatedAt,
    DateTime? resolvedAt,
    required bool isActive,
  }) = _Ticket;

  factory Ticket.fromJson(Map<String, dynamic> json) => _$TicketFromJson(json);
}
