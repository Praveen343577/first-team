// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fault.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_Fault _$FaultFromJson(Map<String, dynamic> json) => _Fault(
  component: json['component'] as String,
  faultCode: json['fault_code'] as String,
);

Map<String, dynamic> _$FaultToJson(_Fault instance) => <String, dynamic>{
  'component': instance.component,
  'fault_code': instance.faultCode,
};
