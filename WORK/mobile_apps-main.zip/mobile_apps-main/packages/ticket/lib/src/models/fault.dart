import 'package:freezed_annotation/freezed_annotation.dart';

part 'fault.freezed.dart';
part 'fault.g.dart';

@freezed
abstract class Fault with _$Fault {
  const factory Fault({
    required String component,
    @JsonKey(name: 'fault_code') required String faultCode,
  }) = _Fault;

  factory Fault.fromJson(Map<String, dynamic> json) => _$FaultFromJson(json);
}
