// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticket_list_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_TicketListResponseDto _$TicketListResponseDtoFromJson(
  Map<String, dynamic> json,
) => _TicketListResponseDto(
  items: (json['items'] as List<dynamic>)
      .map((e) => TicketResponseDto.fromJson(e as Map<String, dynamic>))
      .toList(),
  total: (json['total'] as num).toInt(),
  page: (json['page'] as num).toInt(),
  size: (json['size'] as num).toInt(),
  pages: (json['pages'] as num).toInt(),
);

Map<String, dynamic> _$TicketListResponseDtoToJson(
  _TicketListResponseDto instance,
) => <String, dynamic>{
  'items': instance.items,
  'total': instance.total,
  'page': instance.page,
  'size': instance.size,
  'pages': instance.pages,
};
