// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ticket_list_response_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$TicketListResponseDto {

 List<TicketResponseDto> get items; int get total; int get page; int get size; int get pages;
/// Create a copy of TicketListResponseDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TicketListResponseDtoCopyWith<TicketListResponseDto> get copyWith => _$TicketListResponseDtoCopyWithImpl<TicketListResponseDto>(this as TicketListResponseDto, _$identity);

  /// Serializes this TicketListResponseDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TicketListResponseDto&&const DeepCollectionEquality().equals(other.items, items)&&(identical(other.total, total) || other.total == total)&&(identical(other.page, page) || other.page == page)&&(identical(other.size, size) || other.size == size)&&(identical(other.pages, pages) || other.pages == pages));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,const DeepCollectionEquality().hash(items),total,page,size,pages);

@override
String toString() {
  return 'TicketListResponseDto(items: $items, total: $total, page: $page, size: $size, pages: $pages)';
}


}

/// @nodoc
abstract mixin class $TicketListResponseDtoCopyWith<$Res>  {
  factory $TicketListResponseDtoCopyWith(TicketListResponseDto value, $Res Function(TicketListResponseDto) _then) = _$TicketListResponseDtoCopyWithImpl;
@useResult
$Res call({
 List<TicketResponseDto> items, int total, int page, int size, int pages
});




}
/// @nodoc
class _$TicketListResponseDtoCopyWithImpl<$Res>
    implements $TicketListResponseDtoCopyWith<$Res> {
  _$TicketListResponseDtoCopyWithImpl(this._self, this._then);

  final TicketListResponseDto _self;
  final $Res Function(TicketListResponseDto) _then;

/// Create a copy of TicketListResponseDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? items = null,Object? total = null,Object? page = null,Object? size = null,Object? pages = null,}) {
  return _then(_self.copyWith(
items: null == items ? _self.items : items // ignore: cast_nullable_to_non_nullable
as List<TicketResponseDto>,total: null == total ? _self.total : total // ignore: cast_nullable_to_non_nullable
as int,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as int,size: null == size ? _self.size : size // ignore: cast_nullable_to_non_nullable
as int,pages: null == pages ? _self.pages : pages // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [TicketListResponseDto].
extension TicketListResponseDtoPatterns on TicketListResponseDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TicketListResponseDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TicketListResponseDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TicketListResponseDto value)  $default,){
final _that = this;
switch (_that) {
case _TicketListResponseDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TicketListResponseDto value)?  $default,){
final _that = this;
switch (_that) {
case _TicketListResponseDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( List<TicketResponseDto> items,  int total,  int page,  int size,  int pages)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TicketListResponseDto() when $default != null:
return $default(_that.items,_that.total,_that.page,_that.size,_that.pages);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( List<TicketResponseDto> items,  int total,  int page,  int size,  int pages)  $default,) {final _that = this;
switch (_that) {
case _TicketListResponseDto():
return $default(_that.items,_that.total,_that.page,_that.size,_that.pages);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( List<TicketResponseDto> items,  int total,  int page,  int size,  int pages)?  $default,) {final _that = this;
switch (_that) {
case _TicketListResponseDto() when $default != null:
return $default(_that.items,_that.total,_that.page,_that.size,_that.pages);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _TicketListResponseDto implements TicketListResponseDto {
  const _TicketListResponseDto({required final  List<TicketResponseDto> items, required this.total, required this.page, required this.size, required this.pages}): _items = items;
  factory _TicketListResponseDto.fromJson(Map<String, dynamic> json) => _$TicketListResponseDtoFromJson(json);

 final  List<TicketResponseDto> _items;
@override List<TicketResponseDto> get items {
  if (_items is EqualUnmodifiableListView) return _items;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_items);
}

@override final  int total;
@override final  int page;
@override final  int size;
@override final  int pages;

/// Create a copy of TicketListResponseDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TicketListResponseDtoCopyWith<_TicketListResponseDto> get copyWith => __$TicketListResponseDtoCopyWithImpl<_TicketListResponseDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$TicketListResponseDtoToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _TicketListResponseDto&&const DeepCollectionEquality().equals(other._items, _items)&&(identical(other.total, total) || other.total == total)&&(identical(other.page, page) || other.page == page)&&(identical(other.size, size) || other.size == size)&&(identical(other.pages, pages) || other.pages == pages));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,const DeepCollectionEquality().hash(_items),total,page,size,pages);

@override
String toString() {
  return 'TicketListResponseDto(items: $items, total: $total, page: $page, size: $size, pages: $pages)';
}


}

/// @nodoc
abstract mixin class _$TicketListResponseDtoCopyWith<$Res> implements $TicketListResponseDtoCopyWith<$Res> {
  factory _$TicketListResponseDtoCopyWith(_TicketListResponseDto value, $Res Function(_TicketListResponseDto) _then) = __$TicketListResponseDtoCopyWithImpl;
@override @useResult
$Res call({
 List<TicketResponseDto> items, int total, int page, int size, int pages
});




}
/// @nodoc
class __$TicketListResponseDtoCopyWithImpl<$Res>
    implements _$TicketListResponseDtoCopyWith<$Res> {
  __$TicketListResponseDtoCopyWithImpl(this._self, this._then);

  final _TicketListResponseDto _self;
  final $Res Function(_TicketListResponseDto) _then;

/// Create a copy of TicketListResponseDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? items = null,Object? total = null,Object? page = null,Object? size = null,Object? pages = null,}) {
  return _then(_TicketListResponseDto(
items: null == items ? _self._items : items // ignore: cast_nullable_to_non_nullable
as List<TicketResponseDto>,total: null == total ? _self.total : total // ignore: cast_nullable_to_non_nullable
as int,page: null == page ? _self.page : page // ignore: cast_nullable_to_non_nullable
as int,size: null == size ? _self.size : size // ignore: cast_nullable_to_non_nullable
as int,pages: null == pages ? _self.pages : pages // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
