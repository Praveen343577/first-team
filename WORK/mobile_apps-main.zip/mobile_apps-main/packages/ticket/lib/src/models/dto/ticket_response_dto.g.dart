// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticket_response_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_TicketResponseDto _$TicketResponseDtoFromJson(Map<String, dynamic> json) =>
    _TicketResponseDto(
      vehicleId: json['vehicle_id'] as String,
      type: json['type'] as String,
      severity: json['severity'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      component: json['component'] as String,
      faultCode: json['fault_code'] as String,
      ticketMetadata: json['ticket_metadata'] as Map<String, dynamic>,
      id: json['id'] as String,
      status: json['status'] as String,
      createdBy: json['created_by'] as String,
      updatedBy: json['updated_by'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      resolvedAt: json['resolved_at'] == null
          ? null
          : DateTime.parse(json['resolved_at'] as String),
      isActive: json['is_active'] as bool,
    );

Map<String, dynamic> _$TicketResponseDtoToJson(_TicketResponseDto instance) =>
    <String, dynamic>{
      'vehicle_id': instance.vehicleId,
      'type': instance.type,
      'severity': instance.severity,
      'title': instance.title,
      'description': instance.description,
      'component': instance.component,
      'fault_code': instance.faultCode,
      'ticket_metadata': instance.ticketMetadata,
      'id': instance.id,
      'status': instance.status,
      'created_by': instance.createdBy,
      'updated_by': instance.updatedBy,
      'created_at': instance.createdAt.toIso8601String(),
      'updated_at': instance.updatedAt.toIso8601String(),
      'resolved_at': instance.resolvedAt?.toIso8601String(),
      'is_active': instance.isActive,
    };
