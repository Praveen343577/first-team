// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'fault.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$Fault {

 String get component;@JsonKey(name: 'fault_code') String get faultCode;
/// Create a copy of Fault
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$FaultCopyWith<Fault> get copyWith => _$FaultCopyWithImpl<Fault>(this as Fault, _$identity);

  /// Serializes this Fault to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is Fault&&(identical(other.component, component) || other.component == component)&&(identical(other.faultCode, faultCode) || other.faultCode == faultCode));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,component,faultCode);

@override
String toString() {
  return 'Fault(component: $component, faultCode: $faultCode)';
}


}

/// @nodoc
abstract mixin class $FaultCopyWith<$Res>  {
  factory $FaultCopyWith(Fault value, $Res Function(Fault) _then) = _$FaultCopyWithImpl;
@useResult
$Res call({
 String component,@JsonKey(name: 'fault_code') String faultCode
});




}
/// @nodoc
class _$FaultCopyWithImpl<$Res>
    implements $FaultCopyWith<$Res> {
  _$FaultCopyWithImpl(this._self, this._then);

  final Fault _self;
  final $Res Function(Fault) _then;

/// Create a copy of Fault
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? component = null,Object? faultCode = null,}) {
  return _then(_self.copyWith(
component: null == component ? _self.component : component // ignore: cast_nullable_to_non_nullable
as String,faultCode: null == faultCode ? _self.faultCode : faultCode // ignore: cast_nullable_to_non_nullable
as String,
  ));
}

}


/// Adds pattern-matching-related methods to [Fault].
extension FaultPatterns on Fault {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _Fault value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _Fault() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _Fault value)  $default,){
final _that = this;
switch (_that) {
case _Fault():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _Fault value)?  $default,){
final _that = this;
switch (_that) {
case _Fault() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String component, @JsonKey(name: 'fault_code')  String faultCode)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _Fault() when $default != null:
return $default(_that.component,_that.faultCode);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String component, @JsonKey(name: 'fault_code')  String faultCode)  $default,) {final _that = this;
switch (_that) {
case _Fault():
return $default(_that.component,_that.faultCode);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String component, @JsonKey(name: 'fault_code')  String faultCode)?  $default,) {final _that = this;
switch (_that) {
case _Fault() when $default != null:
return $default(_that.component,_that.faultCode);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _Fault implements Fault {
  const _Fault({required this.component, @JsonKey(name: 'fault_code') required this.faultCode});
  factory _Fault.fromJson(Map<String, dynamic> json) => _$FaultFromJson(json);

@override final  String component;
@override@JsonKey(name: 'fault_code') final  String faultCode;

/// Create a copy of Fault
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$FaultCopyWith<_Fault> get copyWith => __$FaultCopyWithImpl<_Fault>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$FaultToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _Fault&&(identical(other.component, component) || other.component == component)&&(identical(other.faultCode, faultCode) || other.faultCode == faultCode));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,component,faultCode);

@override
String toString() {
  return 'Fault(component: $component, faultCode: $faultCode)';
}


}

/// @nodoc
abstract mixin class _$FaultCopyWith<$Res> implements $FaultCopyWith<$Res> {
  factory _$FaultCopyWith(_Fault value, $Res Function(_Fault) _then) = __$FaultCopyWithImpl;
@override @useResult
$Res call({
 String component,@JsonKey(name: 'fault_code') String faultCode
});




}
/// @nodoc
class __$FaultCopyWithImpl<$Res>
    implements _$FaultCopyWith<$Res> {
  __$FaultCopyWithImpl(this._self, this._then);

  final _Fault _self;
  final $Res Function(_Fault) _then;

/// Create a copy of Fault
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? component = null,Object? faultCode = null,}) {
  return _then(_Fault(
component: null == component ? _self.component : component // ignore: cast_nullable_to_non_nullable
as String,faultCode: null == faultCode ? _self.faultCode : faultCode // ignore: cast_nullable_to_non_nullable
as String,
  ));
}


}

// dart format on
