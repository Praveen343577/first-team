// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ticket.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_Ticket _$TicketFromJson(Map<String, dynamic> json) => _Ticket(
  id: json['id'] as String,
  vehicleId: json['vehicleId'] as String,
  content: Content.fromJson(json['content'] as Map<String, dynamic>),
  fault: Fault.fromJson(json['fault'] as Map<String, dynamic>),
  type: json['type'] as String,
  severity: json['severity'] as String,
  status: json['status'] as String,
  metadata: json['metadata'] as Map<String, dynamic>,
  createdBy: json['createdBy'] as String,
  updatedBy: json['updatedBy'] as String?,
  createdAt: DateTime.parse(json['createdAt'] as String),
  updatedAt: DateTime.parse(json['updatedAt'] as String),
  resolvedAt: json['resolvedAt'] == null
      ? null
      : DateTime.parse(json['resolvedAt'] as String),
  isActive: json['isActive'] as bool,
);

Map<String, dynamic> _$TicketToJson(_Ticket instance) => <String, dynamic>{
  'id': instance.id,
  'vehicleId': instance.vehicleId,
  'content': instance.content,
  'fault': instance.fault,
  'type': instance.type,
  'severity': instance.severity,
  'status': instance.status,
  'metadata': instance.metadata,
  'createdBy': instance.createdBy,
  'updatedBy': instance.updatedBy,
  'createdAt': instance.createdAt.toIso8601String(),
  'updatedAt': instance.updatedAt.toIso8601String(),
  'resolvedAt': instance.resolvedAt?.toIso8601String(),
  'isActive': instance.isActive,
};
