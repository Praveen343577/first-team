import 'package:freezed_annotation/freezed_annotation.dart';

part 'create_ticket_request_dto.freezed.dart';

@freezed
abstract class CreateTicketRequestDto with _$CreateTicketRequestDto {
  const factory CreateTicketRequestDto({
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    required String type,
    required String severity,
    required String title,
    required String description,
    required String component,
    @JsonKey(name: 'fault_code') required String faultCode,
    @JsonKey(name: 'ticket_metadata') Map<String, dynamic>? ticketMetadata,
  }) = _CreateTicketRequestDto;
}
