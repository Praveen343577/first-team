// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'ticket_response_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$TicketResponseDto {

@JsonKey(name: 'vehicle_id') String get vehicleId; String get type; String get severity; String get title; String get description; String get component;@JsonKey(name: 'fault_code') String get faultCode;@JsonKey(name: 'ticket_metadata') Map<String, dynamic> get ticketMetadata; String get id; String get status;@JsonKey(name: 'created_by') String get createdBy;@JsonKey(name: 'updated_by') String? get updatedBy;@JsonKey(name: 'created_at') DateTime get createdAt;@JsonKey(name: 'updated_at') DateTime get updatedAt;@JsonKey(name: 'resolved_at') DateTime? get resolvedAt;@JsonKey(name: 'is_active') bool get isActive;
/// Create a copy of TicketResponseDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TicketResponseDtoCopyWith<TicketResponseDto> get copyWith => _$TicketResponseDtoCopyWithImpl<TicketResponseDto>(this as TicketResponseDto, _$identity);

  /// Serializes this TicketResponseDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TicketResponseDto&&(identical(other.vehicleId, vehicleId) || other.vehicleId == vehicleId)&&(identical(other.type, type) || other.type == type)&&(identical(other.severity, severity) || other.severity == severity)&&(identical(other.title, title) || other.title == title)&&(identical(other.description, description) || other.description == description)&&(identical(other.component, component) || other.component == component)&&(identical(other.faultCode, faultCode) || other.faultCode == faultCode)&&const DeepCollectionEquality().equals(other.ticketMetadata, ticketMetadata)&&(identical(other.id, id) || other.id == id)&&(identical(other.status, status) || other.status == status)&&(identical(other.createdBy, createdBy) || other.createdBy == createdBy)&&(identical(other.updatedBy, updatedBy) || other.updatedBy == updatedBy)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.updatedAt, updatedAt) || other.updatedAt == updatedAt)&&(identical(other.resolvedAt, resolvedAt) || other.resolvedAt == resolvedAt)&&(identical(other.isActive, isActive) || other.isActive == isActive));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,vehicleId,type,severity,title,description,component,faultCode,const DeepCollectionEquality().hash(ticketMetadata),id,status,createdBy,updatedBy,createdAt,updatedAt,resolvedAt,isActive);

@override
String toString() {
  return 'TicketResponseDto(vehicleId: $vehicleId, type: $type, severity: $severity, title: $title, description: $description, component: $component, faultCode: $faultCode, ticketMetadata: $ticketMetadata, id: $id, status: $status, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, resolvedAt: $resolvedAt, isActive: $isActive)';
}


}

/// @nodoc
abstract mixin class $TicketResponseDtoCopyWith<$Res>  {
  factory $TicketResponseDtoCopyWith(TicketResponseDto value, $Res Function(TicketResponseDto) _then) = _$TicketResponseDtoCopyWithImpl;
@useResult
$Res call({
@JsonKey(name: 'vehicle_id') String vehicleId, String type, String severity, String title, String description, String component,@JsonKey(name: 'fault_code') String faultCode,@JsonKey(name: 'ticket_metadata') Map<String, dynamic> ticketMetadata, String id, String status,@JsonKey(name: 'created_by') String createdBy,@JsonKey(name: 'updated_by') String? updatedBy,@JsonKey(name: 'created_at') DateTime createdAt,@JsonKey(name: 'updated_at') DateTime updatedAt,@JsonKey(name: 'resolved_at') DateTime? resolvedAt,@JsonKey(name: 'is_active') bool isActive
});




}
/// @nodoc
class _$TicketResponseDtoCopyWithImpl<$Res>
    implements $TicketResponseDtoCopyWith<$Res> {
  _$TicketResponseDtoCopyWithImpl(this._self, this._then);

  final TicketResponseDto _self;
  final $Res Function(TicketResponseDto) _then;

/// Create a copy of TicketResponseDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? vehicleId = null,Object? type = null,Object? severity = null,Object? title = null,Object? description = null,Object? component = null,Object? faultCode = null,Object? ticketMetadata = null,Object? id = null,Object? status = null,Object? createdBy = null,Object? updatedBy = freezed,Object? createdAt = null,Object? updatedAt = null,Object? resolvedAt = freezed,Object? isActive = null,}) {
  return _then(_self.copyWith(
vehicleId: null == vehicleId ? _self.vehicleId : vehicleId // ignore: cast_nullable_to_non_nullable
as String,type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as String,severity: null == severity ? _self.severity : severity // ignore: cast_nullable_to_non_nullable
as String,title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,description: null == description ? _self.description : description // ignore: cast_nullable_to_non_nullable
as String,component: null == component ? _self.component : component // ignore: cast_nullable_to_non_nullable
as String,faultCode: null == faultCode ? _self.faultCode : faultCode // ignore: cast_nullable_to_non_nullable
as String,ticketMetadata: null == ticketMetadata ? _self.ticketMetadata : ticketMetadata // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>,id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as String,createdBy: null == createdBy ? _self.createdBy : createdBy // ignore: cast_nullable_to_non_nullable
as String,updatedBy: freezed == updatedBy ? _self.updatedBy : updatedBy // ignore: cast_nullable_to_non_nullable
as String?,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,updatedAt: null == updatedAt ? _self.updatedAt : updatedAt // ignore: cast_nullable_to_non_nullable
as DateTime,resolvedAt: freezed == resolvedAt ? _self.resolvedAt : resolvedAt // ignore: cast_nullable_to_non_nullable
as DateTime?,isActive: null == isActive ? _self.isActive : isActive // ignore: cast_nullable_to_non_nullable
as bool,
  ));
}

}


/// Adds pattern-matching-related methods to [TicketResponseDto].
extension TicketResponseDtoPatterns on TicketResponseDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TicketResponseDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TicketResponseDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TicketResponseDto value)  $default,){
final _that = this;
switch (_that) {
case _TicketResponseDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TicketResponseDto value)?  $default,){
final _that = this;
switch (_that) {
case _TicketResponseDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function(@JsonKey(name: 'vehicle_id')  String vehicleId,  String type,  String severity,  String title,  String description,  String component, @JsonKey(name: 'fault_code')  String faultCode, @JsonKey(name: 'ticket_metadata')  Map<String, dynamic> ticketMetadata,  String id,  String status, @JsonKey(name: 'created_by')  String createdBy, @JsonKey(name: 'updated_by')  String? updatedBy, @JsonKey(name: 'created_at')  DateTime createdAt, @JsonKey(name: 'updated_at')  DateTime updatedAt, @JsonKey(name: 'resolved_at')  DateTime? resolvedAt, @JsonKey(name: 'is_active')  bool isActive)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TicketResponseDto() when $default != null:
return $default(_that.vehicleId,_that.type,_that.severity,_that.title,_that.description,_that.component,_that.faultCode,_that.ticketMetadata,_that.id,_that.status,_that.createdBy,_that.updatedBy,_that.createdAt,_that.updatedAt,_that.resolvedAt,_that.isActive);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function(@JsonKey(name: 'vehicle_id')  String vehicleId,  String type,  String severity,  String title,  String description,  String component, @JsonKey(name: 'fault_code')  String faultCode, @JsonKey(name: 'ticket_metadata')  Map<String, dynamic> ticketMetadata,  String id,  String status, @JsonKey(name: 'created_by')  String createdBy, @JsonKey(name: 'updated_by')  String? updatedBy, @JsonKey(name: 'created_at')  DateTime createdAt, @JsonKey(name: 'updated_at')  DateTime updatedAt, @JsonKey(name: 'resolved_at')  DateTime? resolvedAt, @JsonKey(name: 'is_active')  bool isActive)  $default,) {final _that = this;
switch (_that) {
case _TicketResponseDto():
return $default(_that.vehicleId,_that.type,_that.severity,_that.title,_that.description,_that.component,_that.faultCode,_that.ticketMetadata,_that.id,_that.status,_that.createdBy,_that.updatedBy,_that.createdAt,_that.updatedAt,_that.resolvedAt,_that.isActive);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function(@JsonKey(name: 'vehicle_id')  String vehicleId,  String type,  String severity,  String title,  String description,  String component, @JsonKey(name: 'fault_code')  String faultCode, @JsonKey(name: 'ticket_metadata')  Map<String, dynamic> ticketMetadata,  String id,  String status, @JsonKey(name: 'created_by')  String createdBy, @JsonKey(name: 'updated_by')  String? updatedBy, @JsonKey(name: 'created_at')  DateTime createdAt, @JsonKey(name: 'updated_at')  DateTime updatedAt, @JsonKey(name: 'resolved_at')  DateTime? resolvedAt, @JsonKey(name: 'is_active')  bool isActive)?  $default,) {final _that = this;
switch (_that) {
case _TicketResponseDto() when $default != null:
return $default(_that.vehicleId,_that.type,_that.severity,_that.title,_that.description,_that.component,_that.faultCode,_that.ticketMetadata,_that.id,_that.status,_that.createdBy,_that.updatedBy,_that.createdAt,_that.updatedAt,_that.resolvedAt,_that.isActive);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _TicketResponseDto implements TicketResponseDto {
  const _TicketResponseDto({@JsonKey(name: 'vehicle_id') required this.vehicleId, required this.type, required this.severity, required this.title, required this.description, required this.component, @JsonKey(name: 'fault_code') required this.faultCode, @JsonKey(name: 'ticket_metadata') required final  Map<String, dynamic> ticketMetadata, required this.id, required this.status, @JsonKey(name: 'created_by') required this.createdBy, @JsonKey(name: 'updated_by') this.updatedBy, @JsonKey(name: 'created_at') required this.createdAt, @JsonKey(name: 'updated_at') required this.updatedAt, @JsonKey(name: 'resolved_at') this.resolvedAt, @JsonKey(name: 'is_active') required this.isActive}): _ticketMetadata = ticketMetadata;
  factory _TicketResponseDto.fromJson(Map<String, dynamic> json) => _$TicketResponseDtoFromJson(json);

@override@JsonKey(name: 'vehicle_id') final  String vehicleId;
@override final  String type;
@override final  String severity;
@override final  String title;
@override final  String description;
@override final  String component;
@override@JsonKey(name: 'fault_code') final  String faultCode;
 final  Map<String, dynamic> _ticketMetadata;
@override@JsonKey(name: 'ticket_metadata') Map<String, dynamic> get ticketMetadata {
  if (_ticketMetadata is EqualUnmodifiableMapView) return _ticketMetadata;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableMapView(_ticketMetadata);
}

@override final  String id;
@override final  String status;
@override@JsonKey(name: 'created_by') final  String createdBy;
@override@JsonKey(name: 'updated_by') final  String? updatedBy;
@override@JsonKey(name: 'created_at') final  DateTime createdAt;
@override@JsonKey(name: 'updated_at') final  DateTime updatedAt;
@override@JsonKey(name: 'resolved_at') final  DateTime? resolvedAt;
@override@JsonKey(name: 'is_active') final  bool isActive;

/// Create a copy of TicketResponseDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TicketResponseDtoCopyWith<_TicketResponseDto> get copyWith => __$TicketResponseDtoCopyWithImpl<_TicketResponseDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$TicketResponseDtoToJson(this, );
}

@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _TicketResponseDto&&(identical(other.vehicleId, vehicleId) || other.vehicleId == vehicleId)&&(identical(other.type, type) || other.type == type)&&(identical(other.severity, severity) || other.severity == severity)&&(identical(other.title, title) || other.title == title)&&(identical(other.description, description) || other.description == description)&&(identical(other.component, component) || other.component == component)&&(identical(other.faultCode, faultCode) || other.faultCode == faultCode)&&const DeepCollectionEquality().equals(other._ticketMetadata, _ticketMetadata)&&(identical(other.id, id) || other.id == id)&&(identical(other.status, status) || other.status == status)&&(identical(other.createdBy, createdBy) || other.createdBy == createdBy)&&(identical(other.updatedBy, updatedBy) || other.updatedBy == updatedBy)&&(identical(other.createdAt, createdAt) || other.createdAt == createdAt)&&(identical(other.updatedAt, updatedAt) || other.updatedAt == updatedAt)&&(identical(other.resolvedAt, resolvedAt) || other.resolvedAt == resolvedAt)&&(identical(other.isActive, isActive) || other.isActive == isActive));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode => Object.hash(runtimeType,vehicleId,type,severity,title,description,component,faultCode,const DeepCollectionEquality().hash(_ticketMetadata),id,status,createdBy,updatedBy,createdAt,updatedAt,resolvedAt,isActive);

@override
String toString() {
  return 'TicketResponseDto(vehicleId: $vehicleId, type: $type, severity: $severity, title: $title, description: $description, component: $component, faultCode: $faultCode, ticketMetadata: $ticketMetadata, id: $id, status: $status, createdBy: $createdBy, updatedBy: $updatedBy, createdAt: $createdAt, updatedAt: $updatedAt, resolvedAt: $resolvedAt, isActive: $isActive)';
}


}

/// @nodoc
abstract mixin class _$TicketResponseDtoCopyWith<$Res> implements $TicketResponseDtoCopyWith<$Res> {
  factory _$TicketResponseDtoCopyWith(_TicketResponseDto value, $Res Function(_TicketResponseDto) _then) = __$TicketResponseDtoCopyWithImpl;
@override @useResult
$Res call({
@JsonKey(name: 'vehicle_id') String vehicleId, String type, String severity, String title, String description, String component,@JsonKey(name: 'fault_code') String faultCode,@JsonKey(name: 'ticket_metadata') Map<String, dynamic> ticketMetadata, String id, String status,@JsonKey(name: 'created_by') String createdBy,@JsonKey(name: 'updated_by') String? updatedBy,@JsonKey(name: 'created_at') DateTime createdAt,@JsonKey(name: 'updated_at') DateTime updatedAt,@JsonKey(name: 'resolved_at') DateTime? resolvedAt,@JsonKey(name: 'is_active') bool isActive
});




}
/// @nodoc
class __$TicketResponseDtoCopyWithImpl<$Res>
    implements _$TicketResponseDtoCopyWith<$Res> {
  __$TicketResponseDtoCopyWithImpl(this._self, this._then);

  final _TicketResponseDto _self;
  final $Res Function(_TicketResponseDto) _then;

/// Create a copy of TicketResponseDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? vehicleId = null,Object? type = null,Object? severity = null,Object? title = null,Object? description = null,Object? component = null,Object? faultCode = null,Object? ticketMetadata = null,Object? id = null,Object? status = null,Object? createdBy = null,Object? updatedBy = freezed,Object? createdAt = null,Object? updatedAt = null,Object? resolvedAt = freezed,Object? isActive = null,}) {
  return _then(_TicketResponseDto(
vehicleId: null == vehicleId ? _self.vehicleId : vehicleId // ignore: cast_nullable_to_non_nullable
as String,type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as String,severity: null == severity ? _self.severity : severity // ignore: cast_nullable_to_non_nullable
as String,title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,description: null == description ? _self.description : description // ignore: cast_nullable_to_non_nullable
as String,component: null == component ? _self.component : component // ignore: cast_nullable_to_non_nullable
as String,faultCode: null == faultCode ? _self.faultCode : faultCode // ignore: cast_nullable_to_non_nullable
as String,ticketMetadata: null == ticketMetadata ? _self._ticketMetadata : ticketMetadata // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>,id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as String,createdBy: null == createdBy ? _self.createdBy : createdBy // ignore: cast_nullable_to_non_nullable
as String,updatedBy: freezed == updatedBy ? _self.updatedBy : updatedBy // ignore: cast_nullable_to_non_nullable
as String?,createdAt: null == createdAt ? _self.createdAt : createdAt // ignore: cast_nullable_to_non_nullable
as DateTime,updatedAt: null == updatedAt ? _self.updatedAt : updatedAt // ignore: cast_nullable_to_non_nullable
as DateTime,resolvedAt: freezed == resolvedAt ? _self.resolvedAt : resolvedAt // ignore: cast_nullable_to_non_nullable
as DateTime?,isActive: null == isActive ? _self.isActive : isActive // ignore: cast_nullable_to_non_nullable
as bool,
  ));
}


}

// dart format on
