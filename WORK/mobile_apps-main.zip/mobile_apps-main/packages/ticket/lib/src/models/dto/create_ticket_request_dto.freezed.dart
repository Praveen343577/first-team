// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'create_ticket_request_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// dart format off
T _$identity<T>(T value) => value;
/// @nodoc
mixin _$CreateTicketRequestDto {

@JsonKey(name: 'vehicle_id') String get vehicleId; String get type; String get severity; String get title; String get description; String get component;@JsonKey(name: 'fault_code') String get faultCode;@JsonKey(name: 'ticket_metadata') Map<String, dynamic>? get ticketMetadata;
/// Create a copy of CreateTicketRequestDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CreateTicketRequestDtoCopyWith<CreateTicketRequestDto> get copyWith => _$CreateTicketRequestDtoCopyWithImpl<CreateTicketRequestDto>(this as CreateTicketRequestDto, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is CreateTicketRequestDto&&(identical(other.vehicleId, vehicleId) || other.vehicleId == vehicleId)&&(identical(other.type, type) || other.type == type)&&(identical(other.severity, severity) || other.severity == severity)&&(identical(other.title, title) || other.title == title)&&(identical(other.description, description) || other.description == description)&&(identical(other.component, component) || other.component == component)&&(identical(other.faultCode, faultCode) || other.faultCode == faultCode)&&const DeepCollectionEquality().equals(other.ticketMetadata, ticketMetadata));
}


@override
int get hashCode => Object.hash(runtimeType,vehicleId,type,severity,title,description,component,faultCode,const DeepCollectionEquality().hash(ticketMetadata));

@override
String toString() {
  return 'CreateTicketRequestDto(vehicleId: $vehicleId, type: $type, severity: $severity, title: $title, description: $description, component: $component, faultCode: $faultCode, ticketMetadata: $ticketMetadata)';
}


}

/// @nodoc
abstract mixin class $CreateTicketRequestDtoCopyWith<$Res>  {
  factory $CreateTicketRequestDtoCopyWith(CreateTicketRequestDto value, $Res Function(CreateTicketRequestDto) _then) = _$CreateTicketRequestDtoCopyWithImpl;
@useResult
$Res call({
@JsonKey(name: 'vehicle_id') String vehicleId, String type, String severity, String title, String description, String component,@JsonKey(name: 'fault_code') String faultCode,@JsonKey(name: 'ticket_metadata') Map<String, dynamic>? ticketMetadata
});




}
/// @nodoc
class _$CreateTicketRequestDtoCopyWithImpl<$Res>
    implements $CreateTicketRequestDtoCopyWith<$Res> {
  _$CreateTicketRequestDtoCopyWithImpl(this._self, this._then);

  final CreateTicketRequestDto _self;
  final $Res Function(CreateTicketRequestDto) _then;

/// Create a copy of CreateTicketRequestDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? vehicleId = null,Object? type = null,Object? severity = null,Object? title = null,Object? description = null,Object? component = null,Object? faultCode = null,Object? ticketMetadata = freezed,}) {
  return _then(_self.copyWith(
vehicleId: null == vehicleId ? _self.vehicleId : vehicleId // ignore: cast_nullable_to_non_nullable
as String,type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as String,severity: null == severity ? _self.severity : severity // ignore: cast_nullable_to_non_nullable
as String,title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,description: null == description ? _self.description : description // ignore: cast_nullable_to_non_nullable
as String,component: null == component ? _self.component : component // ignore: cast_nullable_to_non_nullable
as String,faultCode: null == faultCode ? _self.faultCode : faultCode // ignore: cast_nullable_to_non_nullable
as String,ticketMetadata: freezed == ticketMetadata ? _self.ticketMetadata : ticketMetadata // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>?,
  ));
}

}


/// Adds pattern-matching-related methods to [CreateTicketRequestDto].
extension CreateTicketRequestDtoPatterns on CreateTicketRequestDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _CreateTicketRequestDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _CreateTicketRequestDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _CreateTicketRequestDto value)  $default,){
final _that = this;
switch (_that) {
case _CreateTicketRequestDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _CreateTicketRequestDto value)?  $default,){
final _that = this;
switch (_that) {
case _CreateTicketRequestDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function(@JsonKey(name: 'vehicle_id')  String vehicleId,  String type,  String severity,  String title,  String description,  String component, @JsonKey(name: 'fault_code')  String faultCode, @JsonKey(name: 'ticket_metadata')  Map<String, dynamic>? ticketMetadata)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _CreateTicketRequestDto() when $default != null:
return $default(_that.vehicleId,_that.type,_that.severity,_that.title,_that.description,_that.component,_that.faultCode,_that.ticketMetadata);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function(@JsonKey(name: 'vehicle_id')  String vehicleId,  String type,  String severity,  String title,  String description,  String component, @JsonKey(name: 'fault_code')  String faultCode, @JsonKey(name: 'ticket_metadata')  Map<String, dynamic>? ticketMetadata)  $default,) {final _that = this;
switch (_that) {
case _CreateTicketRequestDto():
return $default(_that.vehicleId,_that.type,_that.severity,_that.title,_that.description,_that.component,_that.faultCode,_that.ticketMetadata);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function(@JsonKey(name: 'vehicle_id')  String vehicleId,  String type,  String severity,  String title,  String description,  String component, @JsonKey(name: 'fault_code')  String faultCode, @JsonKey(name: 'ticket_metadata')  Map<String, dynamic>? ticketMetadata)?  $default,) {final _that = this;
switch (_that) {
case _CreateTicketRequestDto() when $default != null:
return $default(_that.vehicleId,_that.type,_that.severity,_that.title,_that.description,_that.component,_that.faultCode,_that.ticketMetadata);case _:
  return null;

}
}

}

/// @nodoc


class _CreateTicketRequestDto implements CreateTicketRequestDto {
  const _CreateTicketRequestDto({@JsonKey(name: 'vehicle_id') required this.vehicleId, required this.type, required this.severity, required this.title, required this.description, required this.component, @JsonKey(name: 'fault_code') required this.faultCode, @JsonKey(name: 'ticket_metadata') final  Map<String, dynamic>? ticketMetadata}): _ticketMetadata = ticketMetadata;
  

@override@JsonKey(name: 'vehicle_id') final  String vehicleId;
@override final  String type;
@override final  String severity;
@override final  String title;
@override final  String description;
@override final  String component;
@override@JsonKey(name: 'fault_code') final  String faultCode;
 final  Map<String, dynamic>? _ticketMetadata;
@override@JsonKey(name: 'ticket_metadata') Map<String, dynamic>? get ticketMetadata {
  final value = _ticketMetadata;
  if (value == null) return null;
  if (_ticketMetadata is EqualUnmodifiableMapView) return _ticketMetadata;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableMapView(value);
}


/// Create a copy of CreateTicketRequestDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$CreateTicketRequestDtoCopyWith<_CreateTicketRequestDto> get copyWith => __$CreateTicketRequestDtoCopyWithImpl<_CreateTicketRequestDto>(this, _$identity);



@override
bool operator ==(Object other) {
  return identical(this, other) || (other.runtimeType == runtimeType&&other is _CreateTicketRequestDto&&(identical(other.vehicleId, vehicleId) || other.vehicleId == vehicleId)&&(identical(other.type, type) || other.type == type)&&(identical(other.severity, severity) || other.severity == severity)&&(identical(other.title, title) || other.title == title)&&(identical(other.description, description) || other.description == description)&&(identical(other.component, component) || other.component == component)&&(identical(other.faultCode, faultCode) || other.faultCode == faultCode)&&const DeepCollectionEquality().equals(other._ticketMetadata, _ticketMetadata));
}


@override
int get hashCode => Object.hash(runtimeType,vehicleId,type,severity,title,description,component,faultCode,const DeepCollectionEquality().hash(_ticketMetadata));

@override
String toString() {
  return 'CreateTicketRequestDto(vehicleId: $vehicleId, type: $type, severity: $severity, title: $title, description: $description, component: $component, faultCode: $faultCode, ticketMetadata: $ticketMetadata)';
}


}

/// @nodoc
abstract mixin class _$CreateTicketRequestDtoCopyWith<$Res> implements $CreateTicketRequestDtoCopyWith<$Res> {
  factory _$CreateTicketRequestDtoCopyWith(_CreateTicketRequestDto value, $Res Function(_CreateTicketRequestDto) _then) = __$CreateTicketRequestDtoCopyWithImpl;
@override @useResult
$Res call({
@JsonKey(name: 'vehicle_id') String vehicleId, String type, String severity, String title, String description, String component,@JsonKey(name: 'fault_code') String faultCode,@JsonKey(name: 'ticket_metadata') Map<String, dynamic>? ticketMetadata
});




}
/// @nodoc
class __$CreateTicketRequestDtoCopyWithImpl<$Res>
    implements _$CreateTicketRequestDtoCopyWith<$Res> {
  __$CreateTicketRequestDtoCopyWithImpl(this._self, this._then);

  final _CreateTicketRequestDto _self;
  final $Res Function(_CreateTicketRequestDto) _then;

/// Create a copy of CreateTicketRequestDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? vehicleId = null,Object? type = null,Object? severity = null,Object? title = null,Object? description = null,Object? component = null,Object? faultCode = null,Object? ticketMetadata = freezed,}) {
  return _then(_CreateTicketRequestDto(
vehicleId: null == vehicleId ? _self.vehicleId : vehicleId // ignore: cast_nullable_to_non_nullable
as String,type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as String,severity: null == severity ? _self.severity : severity // ignore: cast_nullable_to_non_nullable
as String,title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,description: null == description ? _self.description : description // ignore: cast_nullable_to_non_nullable
as String,component: null == component ? _self.component : component // ignore: cast_nullable_to_non_nullable
as String,faultCode: null == faultCode ? _self.faultCode : faultCode // ignore: cast_nullable_to_non_nullable
as String,ticketMetadata: freezed == ticketMetadata ? _self._ticketMetadata : ticketMetadata // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>?,
  ));
}


}

// dart format on
