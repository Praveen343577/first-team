import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:ticket/src/models/content.dart';
import 'package:ticket/src/models/fault.dart';
import 'package:ticket/src/models/mapper/ticket_mapper.auto_mappr.dart';
import 'package:ticket/src/models/ticket.dart';

import '../dto/ticket_response_dto.dart';

@AutoMappr([
  MapType<TicketResponseDto, Ticket>(
    fields: [
      Field('content', custom: TicketMapper.mapContent),
      Field('fault', custom: TicketMapper.mapFault),
      Field('metadata', from: 'ticketMetadata'),
    ],
  ),
])
class TicketMapper extends $TicketMapper {
  static Content mapContent(TicketResponseDto dto) {
    return Content(title: dto.title, description: dto.description);
  }

  static Fault mapFault(TicketResponseDto dto) {
    return Fault(component: dto.component, faultCode: dto.faultCode);
  }
}
