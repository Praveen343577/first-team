import 'package:state_handler/state_handler.dart';

class CreateTicketCubit extends BaseCubit<void> {
  CreateTicketCubit();

  @override
  Future<void> performSubmit() async {}
}
