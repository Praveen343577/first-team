import 'package:state_handler/state_handler.dart';
import 'package:ticket/src/models/ticket.dart';
import 'package:ticket/src/repository/ticket_repository.dart';

class TicketListCubit extends BaseCubit<List<Ticket>> {
  final TicketRepository _ticketRepository;

  TicketListCubit(this._ticketRepository);

  @override
  Future<List<Ticket>> performSubmit() => _ticketRepository.getTickets();
}
