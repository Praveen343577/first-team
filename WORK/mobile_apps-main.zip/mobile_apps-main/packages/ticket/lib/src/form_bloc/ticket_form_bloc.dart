import 'dart:async';

import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';

class TicketFormBloc extends FormBloc<String, String> {
  final title = TextFieldBloc();
  final description = TextFieldBloc();
  final vehicleId = TextFieldBloc();
  final type = SelectFieldBloc<String, void>(
    items: ['maintenance', 'Breakdown', 'Inspection'],
  );
  final severity = SelectFieldBloc<String, void>(
    items: ['Low', 'Medium', 'High', 'Critical'],
  );

  final faultCode = SelectFieldBloc<String, void>(
    items: ['FC001', 'FC002', 'FC003', 'FC004'],
  );
  final component = SelectFieldBloc<String, void>(
    items: ['FC001', 'FC002', 'FC003', 'FC004'],
  );
  final assignee = TextFieldBloc();

  TicketFormBloc() {
    addFieldBlocs(
      fieldBlocs: [title, description, severity, assignee, vehicleId, type],
    );
  }

  @override
  FutureOr<void> onSubmitting() {}
}
