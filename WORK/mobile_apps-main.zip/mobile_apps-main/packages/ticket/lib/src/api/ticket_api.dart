import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';
import 'package:ticket/src/models/dto/create_ticket_request_dto.dart';
import 'package:ticket/src/models/dto/ticket_list_response_dto.dart';
import 'package:ticket/src/models/dto/ticket_response_dto.dart';
part 'ticket_api.g.dart';

@RestApi()
abstract class TicketApi {
  factory TicketApi(@Named('authDio') Dio dio) = _TicketApi;

  @POST('/tickets')
  Future<TicketResponseDto> create(@Body() CreateTicketRequestDto request);

  @GET('/tickets')
  Future<TicketListResponseDto> getTickets({
    @Query('vehicle_id') String? vehicleId,
    @Query('status') String? status,
    @Query('severity') String? severity,
    @Query('skip') int? skip,
    @Query('limit') int? limit,
  });
}
