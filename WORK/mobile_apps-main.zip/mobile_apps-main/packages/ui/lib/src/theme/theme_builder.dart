import 'package:flutter/material.dart';
import 'package:ui/src/theme/theme.dart';

class ThemeBuilder extends StatelessWidget {
  final Widget Function(
    BuildContext,
    ThemeData theme,
  ) builder;
  static final ValueNotifier<ThemeMode> theme = ValueNotifier(ThemeMode.light);

  const ThemeBuilder({super.key, required this.builder});

  static void switchTheme() {
    theme.value =
        theme.value == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: theme,
      builder: (context, themeMode, childWidget) {
        return builder(context,
            themeMode == ThemeMode.light ? ekaLightTheme() : ekaDarkTheme());
      },
    );
  }

  static (IconData, Color) getThemeSettingData() =>
      theme.value == ThemeMode.light
          ? (Icons.light_mode_outlined, Colors.amber)
          : (Icons.dark_mode_outlined, Colors.indigo);
}
