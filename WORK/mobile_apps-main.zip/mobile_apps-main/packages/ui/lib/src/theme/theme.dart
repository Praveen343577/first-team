// eka_colors.dart
import 'package:flutter/material.dart';
import 'package:ui/src/colors.dart';

ThemeData ekaLightTheme() {
  final titleLarge = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: EkaColors.gray800,
  );

  final colorScheme = ColorScheme.light(
      primary: EkaColors.primaryBlue,
      secondary: EkaColors.successGreen,
      error: EkaColors.dangerRed,
      surface: EkaColors.white,
      onPrimary: EkaColors.white,
      onSecondary: EkaColors.white,
      onSurface: EkaColors.gray800,
      onError: EkaColors.white,
      outline: EkaColors.borderColor);

  return ThemeData(
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: EkaColors.primaryBlue,
      foregroundColor: EkaColors.white,
    ),
    useMaterial3: true,
    colorScheme: colorScheme,
    scaffoldBackgroundColor: EkaColors.scaffoldColorLight,
    fontFamily: 'Inter',
    dividerColor: EkaColors.gray200,
    dividerTheme: const DividerThemeData(
        color: EkaColors.borderColor, thickness: 1, space: 0),
    // -------- TEXT --------
    textTheme: TextTheme(
      headlineLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w600,
        color: EkaColors.gray800,
      ),
      headlineMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w600,
        color: EkaColors.gray800,
      ),
      // titleMedium: titleMedium,
      bodyLarge: TextStyle(fontSize: 16, color: EkaColors.gray800),
      bodyMedium: TextStyle(fontSize: 14, color: EkaColors.gray800),
      bodySmall: TextStyle(fontSize: 12, color: EkaColors.gray500),
      labelLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      labelMedium: TextStyle(
          fontSize: 12, fontWeight: FontWeight.w300, color: EkaColors.gray500),
    ),

    // -------- APP BAR --------
    appBarTheme: AppBarTheme(
      centerTitle: true,
      titleTextStyle: titleLarge,
      backgroundColor: EkaColors.scaffoldColorLight,
      elevation: 0,
    ),

    // -------- BUTTONS --------
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: EkaColors.primaryBlue,
        foregroundColor: EkaColors.white,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    ),

    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: EkaColors.primaryBlue,
        side: const BorderSide(color: EkaColors.gray200),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    ),

    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: EkaColors.primaryBlue),
    ),

    // -------- INPUTS --------
    inputDecorationTheme: InputDecorationTheme(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      labelStyle: const TextStyle(color: EkaColors.gray500),
      hintStyle: const TextStyle(
          color: EkaColors.gray500, fontWeight: FontWeight.w300),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: EkaColors.borderColor),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: EkaColors.primaryBlue),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: EkaColors.dangerRed),
      ),
    ),

    // -------- CARDS --------
    cardTheme: CardThemeData(
      color: EkaColors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: EkaColors.gray200),
      ),
    ),
  );
}

ThemeData ekaDarkTheme() {
  final appBarTextStyle = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
    color: EkaColors.gray100,
  );
  final colorScheme = ColorScheme.dark(
      primary: const Color(0xFF60A5FA),
      secondary: EkaColors.successGreen,
      error: EkaColors.dangerRed,
      surface: EkaColors.gray800,
      onPrimary: EkaColors.white,
      onSecondary: EkaColors.white,
      onSurface: EkaColors.gray100,
      onError: EkaColors.white,
      outline: EkaColors.gray600);

  return ThemeData(
    useMaterial3: true,
    colorScheme: colorScheme,
    scaffoldBackgroundColor: EkaColors.darkBackground,
    dividerColor: colorScheme.outline,
    dividerTheme:
        DividerThemeData(color: colorScheme.outline, thickness: 1, space: 0),
    fontFamily: 'Inter',
    textTheme: TextTheme(
      headlineLarge: TextStyle(
        fontSize: 32,
        fontWeight: FontWeight.w600,
        color: EkaColors.gray100,
      ),
      headlineMedium: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w600,
        color: EkaColors.gray100,
      ),
      titleMedium: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.normal,
          color: EkaColors.gray100),
      bodyLarge: TextStyle(fontSize: 16, color: EkaColors.gray100),
      bodyMedium: TextStyle(fontSize: 14, color: EkaColors.gray100),
      bodySmall: TextStyle(fontSize: 12, color: EkaColors.gray500),
    ),
    appBarTheme: AppBarTheme(
      centerTitle: true,
      titleTextStyle: appBarTextStyle,
      backgroundColor: EkaColors.darkBackground,
      // foregroundColor: EkaColors.gray100,
      elevation: 0,
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: colorScheme.primary,
        side: BorderSide(color: colorScheme.outline),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    ),
    cardTheme: CardThemeData(
      color: EkaColors.gray800,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: colorScheme.outline),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      labelStyle: const TextStyle(color: EkaColors.gray500),
      hintStyle: const TextStyle(
          color: EkaColors.gray500, fontWeight: FontWeight.w300),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: EkaColors.gray600),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: colorScheme.primary),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(color: EkaColors.dangerRed),
      ),
    ),
  );
}
