import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:ui/ui.dart';

class DriverCompact extends StatelessWidget {
  final Driver? driver;
  final VoidCallback? onTap;

  factory DriverCompact.empty() {
    return const DriverCompact._(
      driver: null,
      onTap: null,
    );
  }
  factory DriverCompact({
    required Driver driver,
    VoidCallback? onTap,
  }) {
    return DriverCompact._(
      driver: driver,
      onTap: onTap,
    );
  }
  const DriverCompact._({
    required this.driver,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.hardEdge,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: EkaColors.gray300,
                backgroundImage: driver?.profileImageUrl.isNotEmpty == true
                    ? NetworkImage(driver!.profileImageUrl)
                    : null,
                child: driver?.profileImageUrl.isEmpty == true
                    ? const Icon(Icons.person)
                    : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (driver != null)
                      SizedBox(
                        child: Text(
                          driver!.name,
                          maxLines: 2,
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium!
                              .copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SvgPicture.asset('assets/svg/truck.svg',
                            // ignore: deprecated_member_use
                            color:
                                Theme.of(context).textTheme.bodySmall!.color!,
                            package: 'ui',
                            width: 16,
                            height: 16),
                        SizedBox(width: 4),
                        Text(driver?.vehicleNumber ?? 'No Driver Assigned',
                            style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward, size: 18, color: Colors.grey[600]),
            ],
          ),
        ),
      ),
    );
  }
}
