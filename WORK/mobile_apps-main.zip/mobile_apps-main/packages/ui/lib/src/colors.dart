import 'package:flutter/material.dart';

class EkaColors {
  // Primary
  static const primaryBlue = Color(0xFF0B5ED7);
  static const sidebarBlue = Color.fromARGB(255, 58, 141, 243);
  static const sidebarBlueBACKUP = Color(0xFF1447E6);
  static const successGreen = Color.fromARGB(255, 28, 191, 93);
  static const successGreen2 = Color(0xFF22C55E);

  // Status
  static const dangerRed = Color(0xFFDC2626);
  static const warningAmber = Color(0xFFF59E0B);
  static const infoBlue = Color(0xFF0EA5E9);

  // Text
  static const textPrimary = Color(0xFF1F2937);
  static const textSecondary = Color(0xFF6B7280);

  // Backgrounds
  static const pageBackground = Color(0xFFF8FAFC);
  static const cardBackground = Color(0xFFFFFFFF);

  // Borders
  static const borderColor = Color(0xFFE5E7EB);

  // Neutral scale
  static const gray900 = Color(0xFF111827);
  static const gray800 = Color(0xFF1F2937);
  static const gray600 = Color(0xFF4B5563);
  static const gray500 = Color(0xFF6B7280);
  static const gray300 = Color(0xFFD1D5DB);
  static const gray200 = Color(0xFFE5E7EB);
  static const gray100 = Color(0xFFF3F4F6);
  static const white = Color(0xFFFFFFFF);
  // static const black = Color(0xFF000000);
  static const scaffoldColorLight = Color(0xFFF8F9FA);
  static const darkBackground = Color(0xFF0F1117);
}

extension ColorExtension on Color {
  Color get a20 => withValues(alpha: 0.2);
}
