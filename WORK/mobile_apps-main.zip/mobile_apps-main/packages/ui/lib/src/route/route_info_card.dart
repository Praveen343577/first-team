import 'package:flutter/material.dart';
import 'package:ui/ui.dart';

class RouteInfoCard extends StatelessWidget {
  final String name;
  final Status status;
  final TimelineModel start;
  final TimelineModel end;
  final Driver? driver;
  final VoidCallback? onTap;
  const RouteInfoCard({
    super.key,
    required this.name,
    required this.start,
    required this.status,
    required this.end,
    this.driver,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) => Card(
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: Theme.of(
                        context,
                      ).textTheme.titleMedium!.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    status.chip(),
                  ],
                ),
                const Icon(Icons.arrow_forward),
              ],
            ),
          ),
          const Divider(),
          const SizedBox(height: 8),
          ProgressTimeline.compact(start: start, end: end),
          const Divider(),
          Padding(
            padding: const EdgeInsets.all(8),
            child: driver != null ? DriverCompact(driver: driver!) : DriverCompact.empty(),
          ),
        ],
      ),
    ),
  );
}
