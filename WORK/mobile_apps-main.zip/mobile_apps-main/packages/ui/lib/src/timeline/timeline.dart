import 'package:dotted_line/dotted_line.dart';
import 'package:flutter/material.dart';
import 'package:ui/src/colors.dart';
import 'package:ui/src/misc/formats.dart';
import 'package:ui/src/model/timeline_model.dart';

class ProgressTimeline extends StatelessWidget {
  final List<TimelineModel> timelineList;
  final bool _compact; // private flag

  const ProgressTimeline._({
    super.key,
    required this.timelineList,
    required bool compact,
  }) : _compact = compact;

  /// Default constructor (compact = false)
  factory ProgressTimeline({
    Key? key,
    required List<TimelineModel> timelineList,
  }) {
    assert(timelineList.length >= 2,
        'At least 2 items are required in timelineList');
    return ProgressTimeline._(
      key: key,
      timelineList: timelineList,
      compact: false,
    );
  }

  /// Compact factory (compact = true)
  factory ProgressTimeline.compact({
    Key? key,
    required TimelineModel start,
    required TimelineModel end,
  }) {
    return ProgressTimeline._(
      key: key,
      timelineList: [start, end],
      compact: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(maxHeight: 400),
      child: Padding(
        padding: EdgeInsetsGeometry.all(16),
        child: _compact
            ? _buildTimelineItemCompact(context)
            : _buildDefaultView(context),
      ),
    );
  }

  Widget _buildDefaultView(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(timelineList.length, (index) {
        return _buildTimelineItem(context, index);
      }),
    );
  }

  Widget _buildTimelineItem(BuildContext context, int index) {
    final model = timelineList[index];
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 120),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _indicator(
                model.dateTime.isBefore(DateTime.now())
                    ? Theme.of(context).colorScheme.primary
                    : model.status.color,
              ),
              if (index < timelineList.length - 1 && !_compact) _line(context),
            ],
          ),
          const SizedBox(width: 8.0),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _location(model, context),
                      if (model.description != null)
                        Text(model.description!,
                            style: Theme.of(context).textTheme.bodyMedium),
                      model.status.chip(),
                    ],
                  ),
                ),
                _dateTime(model, context)
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTimelineItemCompact(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            _indicator(
              timelineList.first.dateTime.isBefore(DateTime.now())
                  ? Theme.of(context).colorScheme.primary
                  : timelineList.first.status.color,
            ),
            const SizedBox(width: 4.0),
            _line(
              context,
            ),
            const SizedBox(width: 4.0),
            _indicator(
              timelineList.last.dateTime.isBefore(DateTime.now())
                  ? Theme.of(context).colorScheme.primary
                  : timelineList.last.status.color,
            ),
          ],
        ),
        const SizedBox(height: 8.0),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: timelineList
              .map((model) => Flexible(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment:
                          timelineList.indexOf(model) == timelineList.length - 1
                              ? CrossAxisAlignment.end
                              : CrossAxisAlignment.start,
                      children: [
                        _location(
                          model,
                          context,
                          textAlign: timelineList.indexOf(model) ==
                                  timelineList.length - 1
                              ? TextAlign.end
                              : TextAlign.start,
                        ),
                        if (model.description != null)
                          Text(model.description!,
                              style: Theme.of(context).textTheme.bodyMedium),
                        _dateTime(model, context)
                      ],
                    ),
                  ))
              .toList(),
        ),
      ],
    );
  }

  Expanded _line(BuildContext context) {
    return Expanded(
      child: DottedLine(
        lineThickness: 2,
        dashColor: Theme.of(context).colorScheme.outline,
        dashGapLength: 0,
        direction: _compact ? Axis.horizontal : Axis.vertical,
      ),
    );
  }

  Text _dateTime(TimelineModel model, BuildContext context) {
    return Text(DateFormats.formatDate(model.dateTime),
        style: Theme.of(context).textTheme.labelMedium!);
  }

  Widget _location(TimelineModel model, BuildContext context,
      {TextAlign textAlign = TextAlign.start}) {
    return Text(
      model.title,
      style: Theme.of(context).textTheme.bodyLarge,
      textAlign: textAlign,
    );
  }

  Container _indicator(Color color) {
    return Container(
      width: 16.0,
      height: 16.0,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2.0),
        boxShadow: [
          BoxShadow(
            color: Colors.black.a20,
            blurRadius: 4.0,
            offset: const Offset(0, 2),
          ),
        ],
      ),
    );
  }
}
