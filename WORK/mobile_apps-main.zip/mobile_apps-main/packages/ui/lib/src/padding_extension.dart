import 'package:flutter/material.dart';

/// Standard padding for row items with horizontal 16 and vertical 8
const kPadding8_16 = EdgeInsets.symmetric(horizontal: 16, vertical: 8);

/// Redundant alias if user specifically wants 'PaddingExtension' as a constant

class AppPadding {
  static const p8 = EdgeInsets.all(8.0);
  static const p12 = EdgeInsets.all(12.0);
  static const p16 = EdgeInsets.all(16.0);
  static const p24 = EdgeInsets.all(24.0);

  static const h16 = EdgeInsets.symmetric(horizontal: 16.0);
  static const h24 = EdgeInsets.symmetric(horizontal: 24.0);
  static const v8 = EdgeInsets.symmetric(vertical: 8.0);
  static const v16 = EdgeInsets.symmetric(vertical: 16.0);

  /// Symmetric padding: horizontal 16, vertical 8
  static const h16v8 = kPadding8_16;

  /// Symmetric padding: horizontal 8, vertical 16
  static const h8v16 = EdgeInsets.symmetric(horizontal: 8, vertical: 16);
  static const gutter = EdgeInsets.symmetric(horizontal: 16, vertical: 8);
}

extension PaddingX on num {
  EdgeInsets get allPadding => EdgeInsets.all(toDouble());
  EdgeInsets get horizontalPadding =>
      EdgeInsets.symmetric(horizontal: toDouble());
  EdgeInsets get verticalPadding => EdgeInsets.symmetric(vertical: toDouble());
}
