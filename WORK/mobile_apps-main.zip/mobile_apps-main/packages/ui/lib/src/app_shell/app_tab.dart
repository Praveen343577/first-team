import 'package:flutter/material.dart';

abstract class AppTabBase extends StatefulWidget {
  const AppTabBase({super.key});

  Widget buildScreen(BuildContext context);
  BottomNavigationBarItem tabItem();
  @override
  State<AppTabBase> createState() => _AppTabBaseState();
}

class _AppTabBaseState extends State<AppTabBase> {
  @override
  Widget build(BuildContext context) => widget.buildScreen(context);
}
