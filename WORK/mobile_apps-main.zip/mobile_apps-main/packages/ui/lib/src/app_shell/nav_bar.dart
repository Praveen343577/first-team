import 'package:flutter/material.dart';

class Navbar extends StatefulWidget {
  const Navbar({
    super.key,
    required this.tabController,
    required this.items,
  });

  final TabController tabController;
  final List<BottomNavigationBarItem> items;

  @override
  State<Navbar> createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.tabController,
      builder: (context, _) {
        return BottomNavigationBar(
          currentIndex: widget.tabController.index,
          onTap: (index) => widget.tabController.animateTo(index),
          items: widget.items,
        );
      },
    );
  }
}
