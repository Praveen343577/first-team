import 'package:flutter/material.dart';
import 'package:ui/ui.dart';

enum Status {
  inprogress('In-Progress', color: EkaColors.sidebarBlue),
  completed('Completed', color: EkaColors.successGreen),
  sceduled(
    'Scheduled',
    color: EkaColors.gray500,
  ),
  cancelled('Cancelled', color: EkaColors.dangerRed),
  delayed('Delayed', color: EkaColors.dangerRed);

  final String name;
  final Color color;

  const Status(this.name, {required this.color});

  Widget chip() => Chip(
      label: Text(name, style: TextStyle(fontSize: 12, color: color)),
      backgroundColor: color.withValues(alpha: 0.05),
      padding: EdgeInsets.zero,
      visualDensity: VisualDensity.compact,
      side: BorderSide(color: color, width: 1.5),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)));
}
