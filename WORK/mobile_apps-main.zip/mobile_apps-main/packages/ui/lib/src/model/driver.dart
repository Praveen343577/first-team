class Driver {
  final String name;
  final String vehicleNumber;
  final String profileImageUrl;

  Driver(
      {required this.name,
      required this.vehicleNumber,
      required this.profileImageUrl});
}
