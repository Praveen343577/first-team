import 'package:ui/src/model/status.dart';

class TimelineModel {
  final String title;
  final String? description;
  final Status status;
  final DateTime dateTime;

  TimelineModel({
    required this.title,
    this.description,
    this.status = Status.sceduled,
    required this.dateTime,
  });
}
