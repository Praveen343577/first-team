import 'package:flutter/material.dart';

class SearchCard extends StatelessWidget {
  final String hintText;
  final TextEditingController controller;
  final FocusNode? focusNode;
  final ValueChanged<String>? onChanged;
  final VoidCallback? onClear;
  final bool hasQuery;
  final bool showFilter;
  final bool showSort;
  final bool isFilterActive;
  final VoidCallback? onFilterTap;
  final VoidCallback? onSortTap;

  const SearchCard({
    super.key,
    required this.hintText,
    required this.controller,
    this.focusNode,
    this.onChanged,
    this.onClear,
    this.hasQuery = false,
    this.showFilter = false,
    this.showSort = false,
    this.isFilterActive = false,
    this.onFilterTap,
    this.onSortTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final isDark = theme.brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? colorScheme.surface : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(
            color: colorScheme.outline.withValues(alpha: 0.1),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            children: [
              Icon(Icons.search, color: colorScheme.primary.withValues(alpha: 0.7)),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: controller,
                  focusNode: focusNode,
                  onChanged: onChanged,
                  onEditingComplete: () {
                    focusNode?.unfocus();
                  },
                  decoration: InputDecoration(
                    hintText: hintText,
                    hintStyle: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.textTheme.bodySmall?.color,
                    ),
                    border: InputBorder.none,
                    enabledBorder: InputBorder.none,
                    focusedBorder: InputBorder.none,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              if (hasQuery)
                IconButton(
                  icon: const Icon(Icons.close, size: 20),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: onClear,
                ),
              if (showFilter || showSort) ...[
                const SizedBox(width: 8),
                Container(
                  width: 1,
                  height: 24,
                  color: colorScheme.outline.withValues(alpha: 0.1),
                ),
                if (showFilter)
                  Stack(
                    children: [
                      IconButton(
                        tooltip: 'Filter',
                        icon: Icon(Icons.tune_outlined, color: colorScheme.primary),
                        onPressed: onFilterTap,
                      ),
                      if (isFilterActive)
                        Positioned(
                          right: 8,
                          top: 8,
                          child: Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: colorScheme.secondary,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 1.5),
                            ),
                          ),
                        ),
                    ],
                  ),
                if (showSort)
                  IconButton(
                    tooltip: 'Sort',
                    icon: Icon(Icons.sort_outlined, color: colorScheme.primary),
                    onPressed: onSortTap,
                  ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
