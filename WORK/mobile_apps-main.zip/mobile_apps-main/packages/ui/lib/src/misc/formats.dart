import 'package:intl/intl.dart';

const dateFormat = 'dd MMM';

class DateFormats {
  static String formatDate(DateTime date) {
    final today = DateTime.now();
    final timeFormat = DateFormat('h:mm a').format(date);

    if (date.year == today.year &&
        date.month == today.month &&
        date.day == today.day) {
      return 'Today $timeFormat';
    }
    return '${DateFormat(dateFormat).format(date)} $timeFormat';
  }
}
