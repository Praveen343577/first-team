import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

extension CopyableTextExtension on Text {
  Widget withCopy(BuildContext context, String textToCopy) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        this,
        const SizedBox(width: 4),
        InkWell(
          onTap: () {
            Clipboard.setData(ClipboardData(text: textToCopy));
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Copied to clipboard'),
                duration: Duration(seconds: 1),
                behavior: SnackBarBehavior.floating,
              ),
            );
          },
          child: const Icon(
            Icons.copy_rounded,
            size: 8,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
}

class CopyableText extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final String? textToCopy;

  const CopyableText({
    super.key,
    required this.text,
    this.style,
    this.textToCopy,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(text, style: style),
        const SizedBox(width: 4),
        InkWell(
          onTap: () {
            Clipboard.setData(ClipboardData(text: textToCopy ?? text));
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Copied to clipboard'),
                duration: Duration(seconds: 1),
                behavior: SnackBarBehavior.floating,
              ),
            );
          },
          child: const Icon(
            Icons.copy_rounded,
            size: 16,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
}
