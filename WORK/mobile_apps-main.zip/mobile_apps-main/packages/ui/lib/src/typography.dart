import 'package:flutter/material.dart';
import 'colors.dart';

class EkaTextStyles {
  static const pageTitle = TextStyle(
    fontSize: 32,
    fontWeight: FontWeight.w600,
    color: EkaColors.textPrimary,
  );

  static const sectionHeader = TextStyle(
    fontSize: 28,
    fontWeight: FontWeight.w600,
  );

  static const cardTitle = TextStyle(fontSize: 18, fontWeight: FontWeight.w600);

  static const bodyLarge = TextStyle(fontSize: 16, fontWeight: FontWeight.w400);

  static const bodyRegular = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w400,
  );

  static const bodySmall = TextStyle(fontSize: 12, fontWeight: FontWeight.w400);

  static const caption = TextStyle(
    fontSize: 12,
    fontWeight: FontWeight.w400,
    color: EkaColors.textSecondary,
  );

  static const buttonText = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.w600,
  );

  static const inputLabel = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.w500,
  );
}
