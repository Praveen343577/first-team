import 'package:flutter/material.dart';
import 'package:ui/ui.dart';

void main() {
  runApp(const MyApp());
}

ValueNotifier<ThemeMode> theme = ValueNotifier(ThemeMode.light);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ThemeBuilder(
      // valueListenable: theme,
      builder: (context, themeMode) {
        return MaterialApp(
          title: 'Flutter Demo',
          theme: themeMode,
          home: const MyHomePage(title: 'Flutter Demo Home Page'),
        );
      },
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  void _incrementCounter() {
    setState(() {
      // This call to setState tells the Flutter framework that something has
      // changed in this State, which causes it to rerun the build method below
      // so that the display can reflect the updated values. If we changed
      // _counter without calling setState(), then the build method would not be
      // called again, and so nothing would appear to happen.
    });

    theme.value = theme.value == ThemeMode.light
        ? ThemeMode.dark
        : ThemeMode.light;
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: AppBar(
        // TRY THIS: Try changing the color here to a specific color (to
        // Colors.amber, perhaps?) and trigger a hot reload to see the AppBar
        // change color while the other colors stay the same.
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          children: [
            RouteInfoCard(
              status: Status.inprogress,
              name: 'Airport Road',
              start: TimelineModel(title: 'Home', dateTime: DateTime.now()),
              end: TimelineModel(
                title: 'Home',
                dateTime: DateTime.now().add(Duration(days: 2)),
              ),
            ),
            DriverCompact.empty(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: EkaColors.dangerRed,
        onPressed: _incrementCounter,
        tooltip: 'Increment',
        child: const Icon(Icons.add),
      ),
    );
  }
}

// class EkaColors {
//   // Brand
//   static const primaryBlue = Color(0xFF0B5ED7);
//   static const sidebarBlue = Color(0xFF174AE4);
//   static const accentGreen = Color(0xFF22C55E);

//   // Status
//   static const dangerRed = Color(0xFFDC2626);
//   static const warningAmber = Color(0xFFF59E0B);
//   static const infoBlue = Color(0xFF0EA5E9);

//   // Neutral scale
//   static const gray900 = Color(0xFF111827);
//   static const gray800 = Color(0xFF1F2937);
//   static const gray600 = Color(0xFF4B5563);
//   static const gray500 = Color(0xFF6B7280);
//   static const gray300 = Color(0xFFD1D5DB);
//   static const gray200 = Color(0xFFE5E7EB);
//   static const gray100 = Color(0xFFF3F4F6);
//   static const white = Color(0xFFFFFFFF);
//   static const black = Color(0xFF000000);
//   static const scaffoldColorLight = Color(0xFFF8F9FA);
//   static const borderColor = Color(0xFFDEE2E6);
// }

// ThemeData ekaLightTheme() {
//   final colorScheme = ColorScheme.light(
//     primary: EkaColors.primaryBlue,
//     secondary: EkaColors.accentGreen,
//     error: EkaColors.dangerRed,
//     surface: EkaColors.scaffoldColorLight,
//     onPrimary: EkaColors.white,
//     onSecondary: EkaColors.white,
//     onSurface: EkaColors.gray800,
//     onError: EkaColors.white,
//   );

//   return ThemeData(
//     useMaterial3: true,
//     colorScheme: colorScheme,
//     scaffoldBackgroundColor: EkaColors.scaffoldColorLight,
//     dividerColor: EkaColors.gray200,
//     fontFamily: 'Inter',

//     // -------- TEXT --------
//     textTheme: const TextTheme(
//       headlineLarge: TextStyle(
//         fontSize: 32,
//         fontWeight: FontWeight.w600,
//         color: EkaColors.gray800,
//       ),
//       headlineMedium: TextStyle(
//         fontSize: 28,
//         fontWeight: FontWeight.w600,
//         color: EkaColors.gray800,
//       ),
//       titleMedium: TextStyle(
//         fontSize: 18,
//         fontWeight: FontWeight.w600,
//         color: EkaColors.gray800,
//       ),
//       bodyLarge: TextStyle(fontSize: 16, color: EkaColors.gray800),
//       bodyMedium: TextStyle(fontSize: 14, color: EkaColors.gray800),
//       bodySmall: TextStyle(fontSize: 12, color: EkaColors.gray500),
//       labelLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
//     ),

//     // -------- APP BAR --------
//     appBarTheme: const AppBarTheme(
//       backgroundColor: EkaColors.white,
//       foregroundColor: EkaColors.gray800,
//       elevation: 0,
//     ),

//     // -------- BUTTONS --------
//     elevatedButtonTheme: ElevatedButtonThemeData(
//       style: ElevatedButton.styleFrom(
//         backgroundColor: EkaColors.primaryBlue,
//         foregroundColor: EkaColors.white,
//         padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//       ),
//     ),

//     outlinedButtonTheme: OutlinedButtonThemeData(
//       style: OutlinedButton.styleFrom(
//         foregroundColor: EkaColors.primaryBlue,
//         side: const BorderSide(color: EkaColors.gray200),
//         shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
//       ),
//     ),

//     textButtonTheme: TextButtonThemeData(
//       style: TextButton.styleFrom(foregroundColor: EkaColors.primaryBlue),
//     ),

//     // -------- INPUTS --------
//     inputDecorationTheme: InputDecorationTheme(
//       filled: true,
//       fillColor: EkaColors.white,
//       contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
//       labelStyle: const TextStyle(color: EkaColors.gray500),
//       hintStyle: const TextStyle(color: EkaColors.gray500),
//       border: OutlineInputBorder(
//         borderRadius: BorderRadius.circular(8),
//         borderSide: const BorderSide(color: EkaColors.gray200),
//       ),
//       focusedBorder: OutlineInputBorder(
//         borderRadius: BorderRadius.circular(8),
//         borderSide: const BorderSide(color: EkaColors.primaryBlue),
//       ),
//       errorBorder: OutlineInputBorder(
//         borderRadius: BorderRadius.circular(8),
//         borderSide: const BorderSide(color: EkaColors.dangerRed),
//       ),
//     ),

//     // -------- CARDS --------
//     cardTheme: CardThemeData(
//       color: EkaColors.white,
//       elevation: 0,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(12),
//         side: const BorderSide(color: EkaColors.borderColor),
//       ),
//     ),
//   );
// }

// ThemeData ekaDarkTheme() {
//   final colorScheme = ColorScheme.dark(
//     primary: EkaColors.primaryBlue,
//     secondary: EkaColors.accentGreen,
//     error: EkaColors.dangerRed,
//     surface: EkaColors.black,
//     onPrimary: EkaColors.white,
//     onSecondary: EkaColors.white,
//     onBackground: EkaColors.gray100,
//     onSurface: EkaColors.gray100,
//     onError: EkaColors.white,
//   );

//   return ThemeData(
//     useMaterial3: true,
//     colorScheme: colorScheme,
//     scaffoldBackgroundColor: EkaColors.black,
//     dividerColor: EkaColors.gray600,
//     fontFamily: 'Inter',

//     textTheme: const TextTheme(
//       headlineLarge: TextStyle(
//         fontSize: 32,
//         fontWeight: FontWeight.w600,
//         color: EkaColors.gray100,
//       ),
//       headlineMedium: TextStyle(
//         fontSize: 28,
//         fontWeight: FontWeight.w600,
//         color: EkaColors.gray100,
//       ),
//       titleMedium: TextStyle(
//         fontSize: 18,
//         fontWeight: FontWeight.w600,
//         color: EkaColors.gray100,
//       ),
//       bodyLarge: TextStyle(fontSize: 16, color: EkaColors.gray100),
//       bodyMedium: TextStyle(fontSize: 14, color: EkaColors.gray100),
//       bodySmall: TextStyle(fontSize: 12, color: EkaColors.gray500),
//     ),

//     appBarTheme: const AppBarTheme(
//       backgroundColor: EkaColors.gray900,
//       foregroundColor: EkaColors.gray100,
//       elevation: 0,
//     ),

//     cardTheme: CardThemeData(
//       color: EkaColors.gray900,
//       elevation: 0,
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(12),
//         side: const BorderSide(color: EkaColors.gray600),
//       ),
//     ),

//     inputDecorationTheme: InputDecorationTheme(
//       filled: true,
//       fillColor: EkaColors.gray800,
//       labelStyle: const TextStyle(color: EkaColors.gray500),
//       hintStyle: const TextStyle(color: EkaColors.gray500),
//       border: OutlineInputBorder(
//         borderRadius: BorderRadius.circular(8),
//         borderSide: const BorderSide(color: EkaColors.gray600),
//       ),
//       focusedBorder: OutlineInputBorder(
//         borderRadius: BorderRadius.circular(8),
//         borderSide: const BorderSide(color: EkaColors.primaryBlue),
//       ),
//     ),
//   );
// }
