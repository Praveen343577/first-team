ui_theme/
    ├─ lib/
    │  ├─ eka_theme.dart
    │  ├─ src/
    │  │  ├─ colors.dart
    │  │  ├─ typography.dart
    │  │  ├─ buttons.dart
    │  │  ├─ inputs.dart
    │  │  └─ cards.dart
    │  └─ ui_theme.dart
    └─ pubspec.yaml