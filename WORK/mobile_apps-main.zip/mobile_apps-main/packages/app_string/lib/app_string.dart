import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/widgets.dart';
export 'app_string.dart';

class AppString {
  AppString._(); // private constructor

  static final String addToCart = 'add_to_cart';
  static final String checkout = 'checkout';
}

class LocaleLoader extends StatelessWidget {
  final Widget child;
  const LocaleLoader({required this.child, super.key});

  @override
  Widget build(BuildContext context) => EasyLocalization(
    supportedLocales: const [Locale('en'), Locale('hi')],
    path: 'assets/translations',
    fallbackLocale: const Locale('en'),
    child: child,
  );
}

extension AppStringsX on String {
  String trs() => tr(this);
}
