import 'dart:async';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';

/// Base cubit for forms that optionally fetches data
abstract class FormBaseCubit<TBaseCubit extends Cubit?, TData, TFormBloc>
    extends Cubit<FormBaseState> {
  final TBaseCubit? baseCubit;
  final TFormBloc formBloc;

  FormBaseCubit({
    this.baseCubit, // Now optional
    required this.formBloc,
  }) : super(const FormBaseState.initial());

  /// Override this only if you have data to populate
  void populateForm(TData data) {}

  /// Override this for submit logic
  Future<void> onSubmit(TData data);
}

class FormBaseState {
  final FormBaseStatus status;
  final String? errorMessage;

  const FormBaseState._({required this.status, this.errorMessage});

  const FormBaseState.initial() : this._(status: FormBaseStatus.initial);
  const FormBaseState.loading() : this._(status: FormBaseStatus.loading);
  const FormBaseState.success() : this._(status: FormBaseStatus.success);
  const FormBaseState.error(String msg)
    : this._(status: FormBaseStatus.error, errorMessage: msg);
}

enum FormBaseStatus { initial, loading, success, error }
