import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// Base cubit for screens that only fetch/display data (no form submission)
abstract class FetchOnlyCubit<TData> extends Cubit<FetchOnlyState<TData>> {
  FetchOnlyCubit() : super(const FetchOnlyState.initial());

  /// Override to implement your fetch logic
  @protected
  Future<TData> fetchData();

  /// Call this to fetch/refresh the data
  Future<void> load() async {
    emit(const FetchOnlyState.loading());
    try {
      final data = await fetchData();
      emit(FetchOnlyState.loaded(data));
    } catch (e) {
      if (e is DioException) {
        final message = e.response?.data is Map
            ? (e.response?.data['detail'] ?? e.response?.data['message'] ?? e.message)
            : e.message;
        emit(FetchOnlyState.error(message ?? 'Connection error'));
      } else {
        emit(FetchOnlyState.error(e.toString()));
      }
    }
  }

  /// Reset to initial state
  void reset() {
    emit(const FetchOnlyState.initial());
  }
}

class FetchOnlyState<TData> {
  final FetchOnlyStatus status;
  final TData? data;
  final String? errorMessage;

  const FetchOnlyState._({required this.status, this.data, this.errorMessage});

  const FetchOnlyState.initial() : this._(status: FetchOnlyStatus.initial);

  const FetchOnlyState.loading() : this._(status: FetchOnlyStatus.loading);

  FetchOnlyState.loaded(TData data)
    : this._(status: FetchOnlyStatus.loaded, data: data);

  FetchOnlyState.error(String message)
    : this._(status: FetchOnlyStatus.error, errorMessage: message);

  bool get isInitial => status == FetchOnlyStatus.initial;
  bool get isLoading => status == FetchOnlyStatus.loading;
  bool get isLoaded => status == FetchOnlyStatus.loaded;
  bool get isError => status == FetchOnlyStatus.error;
}

enum FetchOnlyStatus { initial, loading, loaded, error }
