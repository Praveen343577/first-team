import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:state_handler/cubit/base_cubit.dart';
import 'package:state_handler/cubit/base_state.dart';

/// Base cubit for screens that fetch data AND submit (edit flows)
abstract class FetchAndSubmitCubit<TBaseCubit extends BaseCubit<TData>, TData>
    extends Cubit<FetchAndSubmitState<TData>> {
  final TBaseCubit baseCubit;
  late final StreamSubscription<BaseState<TData>> _subscription;

  FetchAndSubmitCubit({required this.baseCubit})
    : super(const FetchAndSubmitState.initial()) {
    _listenToBaseCubit();

    // Check current state immediately
    final current = baseCubit.state;
    if (current is BaseSuccess<TData>) {
      populateForm(current.data);
      emit(FetchAndSubmitState.loaded(current.data));
    } else if (current is BaseError<TData>) {
      emit(FetchAndSubmitState.fetchError(current.message));
    } else if (current is BaseLoading) {
      emit(const FetchAndSubmitState.loading());
    }
  }

  void _listenToBaseCubit() {
    _subscription = baseCubit.stream.listen((state) {
      if (state is BaseSuccess<TData>) {
        populateForm(state.data);
        emit(FetchAndSubmitState.loaded(state.data));
      } else if (state is BaseError<TData>) {
        emit(FetchAndSubmitState.fetchError(state.message));
      } else if (state is BaseLoading) {
        emit(const FetchAndSubmitState.loading());
      }
    });
  }

  /// Override to populate form fields with fetched data
  @protected
  void populateForm(TData data);

  /// Override to implement your submit logic
  @protected
  Future<void> onSubmit();

  /// Call this to submit the form
  Future<void> submit() async {
    final currentData = state.data;
    emit(FetchAndSubmitState.submitting(currentData));
    try {
      await onSubmit();
      emit(FetchAndSubmitState.success(currentData));
    } catch (e) {
      emit(FetchAndSubmitState.submitError(e.toString(), currentData));
    }
  }

  @override
  Future<void> close() {
    _subscription.cancel();
    return super.close();
  }
}

class FetchAndSubmitState<TData> {
  final FetchAndSubmitStatus status;
  final TData? data;
  final String? errorMessage;

  const FetchAndSubmitState._({
    required this.status,
    this.data,
    this.errorMessage,
  });

  const FetchAndSubmitState.initial()
    : this._(status: FetchAndSubmitStatus.initial);

  const FetchAndSubmitState.loading()
    : this._(status: FetchAndSubmitStatus.loading);

  FetchAndSubmitState.loaded(TData data)
    : this._(status: FetchAndSubmitStatus.loaded, data: data);

  FetchAndSubmitState.fetchError(String message)
    : this._(status: FetchAndSubmitStatus.fetchError, errorMessage: message);

  FetchAndSubmitState.submitting(TData? data)
    : this._(status: FetchAndSubmitStatus.submitting, data: data);

  FetchAndSubmitState.success(TData? data)
    : this._(status: FetchAndSubmitStatus.success, data: data);

  FetchAndSubmitState.submitError(String message, TData? data)
    : this._(
        status: FetchAndSubmitStatus.submitError,
        errorMessage: message,
        data: data,
      );

  bool get isInitial => status == FetchAndSubmitStatus.initial;
  bool get isLoading => status == FetchAndSubmitStatus.loading;
  bool get isLoaded => status == FetchAndSubmitStatus.loaded;
  bool get isFetchError => status == FetchAndSubmitStatus.fetchError;
  bool get isSubmitting => status == FetchAndSubmitStatus.submitting;
  bool get isSuccess => status == FetchAndSubmitStatus.success;
  bool get isSubmitError => status == FetchAndSubmitStatus.submitError;
}

enum FetchAndSubmitStatus {
  initial,
  loading,
  loaded,
  fetchError,
  submitting,
  success,
  submitError,
}
