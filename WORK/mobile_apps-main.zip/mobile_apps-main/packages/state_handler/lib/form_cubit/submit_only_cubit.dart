import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/foundation.dart';

abstract class SubmitOnlyCubit extends Cubit<SubmitOnlyState> {
  SubmitOnlyCubit() : super(SubmitOnlyState.initial());

  @protected
  Future<void> onSubmit();

  Future<void> submit() async {
    emit(const SubmitOnlyState.submitting());
    try {
      await onSubmit();
      emit(const SubmitOnlyState.success());
    } catch (e) {
      emit(SubmitOnlyState.error(e.toString()));
    }
  }
}

class SubmitOnlyState {
  final SubmitOnlyStatus status;
  final String? errorMessage;

  const SubmitOnlyState._({required this.status, this.errorMessage});

  SubmitOnlyState.initial() : this._(status: SubmitOnlyStatus.initial);
  const SubmitOnlyState.submitting() : this._(status: SubmitOnlyStatus.submitting);
  const SubmitOnlyState.success() : this._(status: SubmitOnlyStatus.success);
  SubmitOnlyState.error(String message)
    : this._(status: SubmitOnlyStatus.error, errorMessage: message);

  bool get isInitial => status == SubmitOnlyStatus.initial;
  bool get isSubmitting => status == SubmitOnlyStatus.submitting;
  bool get isSuccess => status == SubmitOnlyStatus.success;
  bool get isError => status == SubmitOnlyStatus.error;
}

enum SubmitOnlyStatus { initial, submitting, success, error }
