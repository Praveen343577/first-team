import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:state_handler/cubit/base_state.dart';

abstract class BaseCubit<T> extends Cubit<BaseState<T>> {
  BaseCubit() : super(BaseInitial<T>());

  Future<void> submit() async {
    emit(BaseLoading<T>());

    try {
      final data = await performSubmit();
      emit(BaseSuccess<T>(data));
    } catch (e, stack) {
      if (e is DioException) {
        emit(BaseError<T>(e.response?.data?.toString() ?? e.message ?? e.toString()));
        log(e.response?.data?.toString() ?? e.message ?? e.toString(), stackTrace: stack);
      } else {
        emit(BaseError<T>(e.toString()));
      }
    }
  }

  Future<void> load() => submit();

  @protected
  Future<T> performSubmit();
}
