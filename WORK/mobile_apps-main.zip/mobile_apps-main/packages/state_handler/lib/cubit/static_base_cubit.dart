import 'package:state_handler/state_handler.dart';

class StaticBaseCubit<T> extends BaseCubit<T> {
  final T data;
  StaticBaseCubit(this.data);

  @override
  Future<T> performSubmit() async => data;
}
