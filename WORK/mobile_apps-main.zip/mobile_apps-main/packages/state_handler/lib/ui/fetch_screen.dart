import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';

/// Base screen for fetch flows using BaseCubit and BaseState
abstract class FetchScreen<C extends BaseCubit<T>, T> extends StatefulWidget {
  const FetchScreen({super.key});

  /// INIT HOOK 👇
  @protected
  void onInit(BuildContext context) {}

  @override
  State<FetchScreen<C, T>> createState() => _FetchScreenState<C, T>();

  /// UI Hooks 👇
  Widget buildLoading(BuildContext context) =>
      const Center(child: CircularProgressIndicator());

  Widget buildError(BuildContext context, String message) =>
      Center(child: Text('Error: $message'));

  Widget buildSuccess(BuildContext context, T data);

  /// LISTENER HOOK 👇
  @protected
  void onListener(BuildContext context, BaseState<T> state) {}
}

class _FetchScreenState<C extends BaseCubit<T>, T>
    extends State<FetchScreen<C, T>> {
  @override
  void initState() {
    super.initState();
    widget.onInit(context);
    // Automatically trigger load on init
    context.read<C>().load();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<C, BaseState<T>>(
      listener: widget.onListener,
      builder: (context, state) {
        if (state is BaseLoading<T>) {
          return widget.buildLoading(context);
        } else if (state is BaseError<T>) {
          return widget.buildError(context, state.message);
        } else if (state is BaseSuccess<T>) {
          return widget.buildSuccess(context, state.data);
        } else if (state is BaseInitial<T>) {
          return widget.buildLoading(context);
        }
        return const SizedBox.shrink();
      },
    );
  }
}
