import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:state_handler/form_cubit/fetch_only_cubit.dart';

/// Base screen for fetch-only flows (display data, no form)
abstract class FetchOnlyScreen<TCubit extends FetchOnlyCubit<TData>, TData>
    extends StatefulWidget {
  const FetchOnlyScreen({super.key});

  /// Build your UI when data is loaded
  Widget buildContent(BuildContext context, TCubit cubit, TData data);

  /// Build loading widget (optional override)
  Widget buildLoading(BuildContext context) {
    return const Center(child: CircularProgressIndicator());
  }

  /// Build error widget (optional override)
  Widget buildError(BuildContext context, String message) {
    return Center(child: Text('Error: $message'));
  }

  /// Whether to enable pull to refresh (defaults to true)
  bool get enablePullToRefresh => true;

  @override
  State<FetchOnlyScreen<TCubit, TData>> createState() =>
      _FetchOnlyScreenState<TCubit, TData>();
}

class _FetchOnlyScreenState<TCubit extends FetchOnlyCubit<TData>, TData>
    extends State<FetchOnlyScreen<TCubit, TData>> {
  final RefreshController _refreshController = RefreshController();

  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TCubit, FetchOnlyState<TData>>(
      listener: (context, state) {
        if (!widget.enablePullToRefresh) return;

        if (state.status == FetchOnlyStatus.loaded) {
          _refreshController.refreshCompleted();
        } else if (state.status == FetchOnlyStatus.error) {
          _refreshController.refreshFailed();
        }
      },
      builder: (context, state) {
        final cubit = context.read<TCubit>();

        // We wrap the entire content area, but only if it's not a loading state
        // Initial loading shows the standard buildLoading.
        if (state.status == FetchOnlyStatus.initial ||
            state.status == FetchOnlyStatus.loading) {
          return widget.buildLoading(context);
        }

        if (state.status == FetchOnlyStatus.error) {
          return widget.buildError(
            context,
            state.errorMessage ?? 'Unknown error',
          );
        }

        final content = widget.buildContent(
          context,
          cubit,
          state.data as TData,
        );

        if (!widget.enablePullToRefresh) return content;

        return SmartRefresher(
          controller: _refreshController,
          onRefresh: () => cubit.load(),
          // header: const WaterDropHeader(),
          child: content,
        );
      },
    );
  }
}
