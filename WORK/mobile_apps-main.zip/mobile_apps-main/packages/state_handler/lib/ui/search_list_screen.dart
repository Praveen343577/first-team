import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:state_handler/form_cubit/fetch_only_cubit.dart';
import 'package:state_handler/ui/fetch_only_screen.dart';

/// A mixin for cubits that support search functionality.
/// Apply this to your [FetchOnlyCubit] to enable search in [SearchListScreen].
mixin SearchableCubit {
  String get searchQuery;
  void setSearchQuery(String query);
}

/// Abstract base screen that provides search + filter + sort + list.
///
/// `TCubit` must extend `FetchOnlyCubit<List<TItem>>`.
/// Subclasses only need to override [buildItem] for a single list item.
///
/// ```dart
/// class DriverListScreen
///     extends SearchListScreen<DriverListCubit, DriverModel> {
///   const DriverListScreen({super.key});
///
///   @override
///   String get title => 'Drivers';
///
///   @override
///   Widget buildItem(BuildContext context, DriverModel item, int index) {
///     return ListTile(title: Text(item.fullName));
///   }
/// }
/// ```
abstract class SearchListScreen<TCubit extends FetchOnlyCubit<List<TItem>>,
    TItem> extends StatefulWidget {
  final void Function(TItem item)? onItemTap;
  final bool useScaffold;

  const SearchListScreen({
    super.key,
    this.onItemTap,
    this.useScaffold = true,
  });

  // ── Required ──

  /// AppBar title
  String get title;

  /// Build a single list item widget
  Widget buildItem(BuildContext context, TItem item, int index);

  // ── Search ──

  /// Search field hint text
  String get searchHint => 'Search…';

  /// Whether the search bar is visible
  bool get showSearch => true;

  // ── Filter & Sort ──

  /// Whether to show the filter button. Override to return `true`.
  bool get showFilter => false;

  /// Whether to show the sort button. Override to return `true`.
  bool get showSort => false;

  /// Whether a filter is currently active (shows a dot indicator).
  bool isFilterActive(TCubit cubit) => false;

  /// Called when the filter button is tapped.
  void onFilterTap(BuildContext context, TCubit cubit) {}

  /// Called when the sort button is tapped.
  void onSortTap(BuildContext context, TCubit cubit) {}

  // ── Optional overrides ──

  /// Build the empty state (when the list is empty)
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No items found'));
  }

  /// Padding around each list item
  EdgeInsets get itemPadding =>
      const EdgeInsets.symmetric(horizontal: 16, vertical: 8);

  /// Build optional floating action button
  Widget? buildFloatingActionButton(BuildContext context) => null;

  /// Build optional AppBar actions
  List<Widget>? buildAppBarActions(BuildContext context) => null;

  @override
  State<SearchListScreen<TCubit, TItem>> createState() =>
      _SearchListScreenState<TCubit, TItem>();
}

class _SearchListScreenState<TCubit extends FetchOnlyCubit<List<TItem>>, TItem>
    extends State<SearchListScreen<TCubit, TItem>>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final content = Column(
      children: [
        if (widget.showSearch)
          _SearchSection<TCubit, TItem>(
            searchHint: widget.searchHint,
            showFilter: widget.showFilter,
            showSort: widget.showSort,
            isFilterActive: widget.isFilterActive,
            onFilterTap: widget.onFilterTap,
            onSortTap: widget.onSortTap,
          ),
        Expanded(
          child: _ListContent<TCubit, TItem>(
            itemBuilder: widget.buildItem,
            emptyBuilder: widget.buildEmpty,
            itemPadding: widget.itemPadding,
            onItemTap: widget.onItemTap,
          ),
        ),
      ],
    );

    if (!widget.useScaffold) return content;

    return Scaffold(
      floatingActionButton: widget.buildFloatingActionButton(context),
      appBar: AppBar(
        title: Text(widget.title),
        actions: widget.buildAppBarActions(context),
      ),
      body: content,
    );
  }
}

// ── Private implementation widgets ──

class _SearchSection<TCubit extends FetchOnlyCubit<List<TItem>>, TItem>
    extends StatefulWidget {
  final String searchHint;
  final bool showFilter;
  final bool showSort;
  final bool Function(TCubit cubit) isFilterActive;
  final void Function(BuildContext context, TCubit cubit) onFilterTap;
  final void Function(BuildContext context, TCubit cubit) onSortTap;

  const _SearchSection({
    required this.searchHint,
    required this.showFilter,
    required this.showSort,
    required this.isFilterActive,
    required this.onFilterTap,
    required this.onSortTap,
  });

  @override
  State<_SearchSection<TCubit, TItem>> createState() =>
      _SearchSectionState<TCubit, TItem>();
}

class _SearchSectionState<TCubit extends FetchOnlyCubit<List<TItem>>, TItem>
    extends State<_SearchSection<TCubit, TItem>> {
  late final TextEditingController _searchController;
  late final FocusNode _focusNode;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    final cubit = context.read<TCubit>();
    final initialQuery =
        cubit is SearchableCubit ? (cubit as SearchableCubit).searchQuery : '';
    _searchController = TextEditingController(text: initialQuery);
    _focusNode = FocusNode();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    _debounce?.cancel();
    super.dispose();
  }

  void _onSearchChanged(String value) {
    if (_debounce?.isActive ?? false) _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      if (value.length >= 3 || value.isEmpty) {
        final cubit = context.read<TCubit>();
        if (cubit is SearchableCubit) {
          (cubit as SearchableCubit).setSearchQuery(value);
        }
      }
    });
  }

  void _clearSearch() {
    _searchController.clear();
    _debounce?.cancel();
    final cubit = context.read<TCubit>();
    if (cubit is SearchableCubit) {
      (cubit as SearchableCubit).setSearchQuery('');
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TCubit, FetchOnlyState<List<TItem>>>(
      builder: (context, state) {
        final theme = Theme.of(context);
        final colorScheme = theme.colorScheme;
        final cubit = context.read<TCubit>();
        final hasQuery = cubit is SearchableCubit &&
            (cubit as SearchableCubit).searchQuery.isNotEmpty;

        return Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
          child: Container(
            decoration: BoxDecoration(
              color: theme.brightness == Brightness.dark
                  ? colorScheme.surface
                  : Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(
                    alpha: theme.brightness == Brightness.dark ? 0.2 : 0.05,
                  ),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
              border: Border.all(
                color: colorScheme.outline.withValues(alpha: 0.1),
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: Row(
                children: [
                  Icon(
                    Icons.search,
                    color: colorScheme.primary.withValues(alpha: 0.7),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      focusNode: _focusNode,
                      onChanged: _onSearchChanged,
                      onEditingComplete: () {
                        _debounce?.cancel();
                        _onSearchChanged(_searchController.text);
                        _focusNode.unfocus();
                      },
                      decoration: InputDecoration(
                        hintText: widget.searchHint,
                        hintStyle: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.textTheme.bodySmall?.color,
                        ),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        isDense: true,
                        contentPadding:
                            const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  if (hasQuery)
                    IconButton(
                      icon: const Icon(Icons.close, size: 20),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                      onPressed: _clearSearch,
                    ),
                  if (widget.showFilter || widget.showSort) ...[
                    const SizedBox(width: 8),
                    Container(
                      width: 1,
                      height: 24,
                      color: colorScheme.outline.withValues(alpha: 0.1),
                    ),
                    if (widget.showFilter)
                      Stack(
                        children: [
                          IconButton(
                            tooltip: 'Filter',
                            icon: Icon(
                              Icons.tune_outlined,
                              color: colorScheme.primary,
                            ),
                            onPressed: () => widget.onFilterTap(context, cubit),
                          ),
                          if (widget.isFilterActive(cubit))
                            Positioned(
                              right: 8,
                              top: 8,
                              child: Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: colorScheme.secondary,
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 1.5,
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                    if (widget.showSort)
                      IconButton(
                        tooltip: 'Sort',
                        icon: Icon(
                          Icons.sort_outlined,
                          color: colorScheme.primary,
                        ),
                        onPressed: () => widget.onSortTap(context, cubit),
                      ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _ListContent<TCubit extends FetchOnlyCubit<List<TItem>>, TItem>
    extends FetchOnlyScreen<TCubit, List<TItem>> {
  final Widget Function(BuildContext context, TItem item, int index)
      itemBuilder;
  final Widget Function(BuildContext context) emptyBuilder;
  final EdgeInsets itemPadding;
  final void Function(TItem item)? onItemTap;

  const _ListContent({
    required this.itemBuilder,
    required this.emptyBuilder,
    required this.itemPadding,
    this.onItemTap,
  });

  @override
  Widget buildContent(
    BuildContext context,
    TCubit cubit,
    List<TItem> data,
  ) {
    if (data.isEmpty) return emptyBuilder(context);

    return ListView.builder(
      itemCount: data.length,
      itemBuilder: (context, index) {
        final item = data[index];
        return Padding(
          padding: itemPadding,
          child: InkWell(
            onTap: onItemTap != null ? () => onItemTap!(item) : null,
            child: itemBuilder(context, item, index),
          ),
        );
      },
    );
  }
}
