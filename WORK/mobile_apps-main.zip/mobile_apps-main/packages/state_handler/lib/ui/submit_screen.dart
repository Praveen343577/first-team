import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:state_handler/cubit/base_cubit.dart';
import 'package:state_handler/cubit/base_state.dart';

abstract class SubmitScreen<C extends BaseCubit<T>, T> extends StatefulWidget {
  const SubmitScreen({super.key});

  /// INIT HOOK 👇
  @protected
  void onInit(BuildContext context) {}

  @override
  State<SubmitScreen<C, T>> createState() => _SubmitScreenState<C, T>();

  Widget buildForm(BuildContext context);

  void onSubmitSuccess(BuildContext context, T data) {}

  void onSubmitError(BuildContext context, String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  Widget buildSubmittingOverlay(BuildContext context) {
    return const Center(child: CircularProgressIndicator());
  }
}

class _SubmitScreenState<C extends BaseCubit<T>, T>
    extends State<SubmitScreen<C, T>> {
  @override
  void initState() {
    widget.onInit(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<C, BaseState<T>>(
      listener: (context, state) {
        if (state is BaseSuccess<T>) {
          widget.onSubmitSuccess(context, state.data);
        } else if (state is BaseError<T>) {
          widget.onSubmitError(context, state.message);
        }
      },
      builder: (context, state) {
        return Stack(
          children: [
            widget.buildForm(context),
            if (state is BaseLoading<T>)
              Container(
                color: Colors.black26,
                child: widget.buildSubmittingOverlay(context),
              ),
          ],
        );
      },
    );
  }
}
