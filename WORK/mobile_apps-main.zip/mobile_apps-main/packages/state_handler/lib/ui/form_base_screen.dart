import 'package:flutter/material.dart';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:state_handler/state_handler.dart';

abstract class FormFetchScreen<
  C extends BaseCubit<T>,
  T,
  FC extends Cubit,
  F extends FormBloc<String, String>
>
    extends FetchScreen<C, T> {
  const FormFetchScreen({super.key});

  FC formCubit(BuildContext context);
  F formBloc(BuildContext context);

  void onBaseState(BuildContext context, dynamic state) {}

  @override
  Widget buildSuccess(BuildContext context, T data) {
    final fc = formCubit(context);
    final fb = formBloc(context);

    return BlocListener<FC, dynamic>(
      bloc: fc,
      listener: (context, state) => onBaseState(context, state),
      child: BlocBuilder<F, FormBlocState>(
        bloc: fb,
        builder: (context, state) {
          return buildForm(context, data, fc, fb);
        },
      ),
    );
  }

  Widget buildForm(BuildContext context, T data, FC formCubit, F formBloc);
}
