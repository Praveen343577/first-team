import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:state_handler/form_cubit/submit_only_cubit.dart';

/// Base screen for submit-only flows (create forms, no fetch)
abstract class SubmitOnlyScreen<TCubit extends SubmitOnlyCubit>
    extends StatefulWidget {
  const SubmitOnlyScreen({super.key});

  /// Optional: Create the cubit for this screen.
  /// If provided, the screen will wrap itself in a BlocProvider.
  TCubit? createCubit(BuildContext context) => null;

  /// Build your form UI
  Widget buildForm(BuildContext context, TCubit cubit);

  /// Optional: Use a Scaffold with this AppBar
  PreferredSizeWidget? get appBar => null;

  /// Optional: Use a Scaffold with this BottomNavigationBar
  Widget? get bottomNavigationBar => null;

  /// Called when submission is successful (optional override)
  void onSubmitSuccess(BuildContext context, TCubit cubit) {}

  /// Called when submission fails (optional override)
  void onSubmitError(BuildContext context, String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Error: $message')));
  }

  /// Build submitting overlay (optional override)
  Widget buildSubmittingOverlay(BuildContext context) {
    return const Center(child: CircularProgressIndicator());
  }

  @override
  State<SubmitOnlyScreen<TCubit>> createState() =>
      _SubmitOnlyScreenState<TCubit>();
}

class _SubmitOnlyScreenState<TCubit extends SubmitOnlyCubit>
    extends State<SubmitOnlyScreen<TCubit>> {
  TCubit? _createdCubit;

  @override
  Widget build(BuildContext context) {
    _createdCubit ??= widget.createCubit(context);

    Widget content = Scaffold(
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: widget.appBar,
      body: _buildBody(context),
      bottomNavigationBar: widget.bottomNavigationBar,
    );

    if (_createdCubit != null) {
      return BlocProvider.value(value: _createdCubit!, child: content);
    }

    return content;
  }

  Widget _buildBody(BuildContext context) {
    return BlocConsumer<TCubit, SubmitOnlyState>(
      listener: (context, state) {
        final cubit = context.read<TCubit>();
        if (state.isSuccess) {
          widget.onSubmitSuccess(context, cubit);
        } else if (state.isError) {
          widget.onSubmitError(context, state.errorMessage ?? 'Unknown error');
        }
      },
      builder: (context, state) {
        final cubit = context.read<TCubit>();

        return Stack(
          children: [
            widget.buildForm(context, cubit),
            if (state.isSubmitting)
              Container(
                color: Colors.black26,
                child: widget.buildSubmittingOverlay(context),
              ),
          ],
        );
      },
    );
  }
}
