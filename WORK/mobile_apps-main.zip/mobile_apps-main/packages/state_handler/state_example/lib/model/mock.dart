class Mock {
  final int id;
  final String title;
  final String body;

  Mock({required this.id, required this.title, required this.body});

  factory Mock.fromJson(Map<String, dynamic> json) {
    return Mock(id: json['id'], title: json['title'], body: json['body']);
  }
}
