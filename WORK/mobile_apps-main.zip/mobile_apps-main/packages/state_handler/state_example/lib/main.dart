import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:state_handler/state_handler.dart';

/// =========================
/// MODEL
/// =========================

class Vehicle {
  final String id;
  final String name;
  final String brand;

  Vehicle({required this.id, required this.name, required this.brand});
}

/// =========================
/// VEHICLE API CUBIT
/// =========================

class VehicleCubit extends BaseCubit<Vehicle> {
  @override
  Future<Vehicle> performSubmit() async {
    await Future.delayed(const Duration(seconds: 1));

    return Vehicle(id: "1", name: "Xpulse 210", brand: "Hero");
  }
}

/// =========================
/// FORM BLOC
/// =========================

class VehicleFormBloc extends FormBloc<String, String> {
  final name = TextFieldBloc();
  final brand = TextFieldBloc();

  VehicleFormBloc() {
    addFieldBlocs(fieldBlocs: [name, brand]);
  }

  @override
  FutureOr<void> onSubmitting() {}
}

/// =========================
/// FORM CUBIT
/// =========================

class VehicleFormCubit
    extends FormBaseCubit<VehicleCubit, Vehicle, VehicleFormBloc> {
  VehicleFormCubit({required super.baseCubit, required super.formBloc});

  @override
  void populateForm(Vehicle data) {
    formBloc.name.updateValue(data.name);
    formBloc.brand.updateValue(data.brand);
  }

  @override
  Future<void> onSubmit(Vehicle data) async {
    await Future.delayed(const Duration(seconds: 2));
  }
}

class VehicleScreen
    extends
        FormFetchScreen<
          VehicleCubit,
          Vehicle,
          VehicleFormCubit,
          VehicleFormBloc
        > {
  const VehicleScreen({super.key});

  @override
  void onInit(BuildContext context) {
    context.read<VehicleCubit>().load();
  }

  @override
  VehicleFormCubit formCubit(BuildContext context) =>
      context.read<VehicleFormCubit>();

  @override
  VehicleFormBloc formBloc(BuildContext context) =>
      context.read<VehicleFormCubit>().formBloc;

  @override
  Widget buildForm(
    BuildContext context,
    Vehicle data,
    VehicleFormCubit fc,
    VehicleFormBloc fb,
  ) {
    return Column(
      children: [
        TextFieldBlocBuilder(
          textFieldBloc: fb.name,
          decoration: const InputDecoration(labelText: "Name"),
        ),
      ],
    );
  }
}

/// =========================
/// APP
/// =========================

void main() {
  final vehicleCubit = VehicleCubit();
  final formBloc = VehicleFormBloc();

  runApp(
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => vehicleCubit),
        BlocProvider(
          create: (_) =>
              VehicleFormCubit(baseCubit: vehicleCubit, formBloc: formBloc),
        ),
      ],
      child: MaterialApp(
        home: Scaffold(
          appBar: AppBar(title: const Text("Vehicle Form")),
          body: const VehicleScreen(),
        ),
      ),
    ),
  );
}
