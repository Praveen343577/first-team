import 'package:http/http.dart' as http;
import 'package:state_example/model/mock.dart';
import 'package:state_handler/state_handler.dart';

class MockCubit extends BaseCubit<Mock> {
  @override
  Future<Mock> performSubmit() {
    final res = http.get(
      Uri.parse('https://jsonplaceholder.typicode.com/posts'),
    );
    return res.then((value) {
      if (value.statusCode == 200) {
        return Mock.fromJson({
          "id": 1,
          "title": "mock title",
          "body": "mock body",
        });
      } else {
        throw Exception('Failed to load data');
      }
    });
  }
}
