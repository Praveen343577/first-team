class AppEnvironment {
  final AppFlavor flavor;

  const AppEnvironment(this.flavor);

  String get envFile {
    switch (flavor) {
      case AppFlavor.dev:
        return 'env/.env.dev';
      case AppFlavor.uat:
        return 'env/.uat.env';
      case AppFlavor.prod:
        return 'env/.prod.env';
    }
  }

  bool get isDev => flavor == AppFlavor.dev;
}

enum AppFlavor {
  dev,
  uat,
  prod;

  static AppFlavor fromString(String flavorString) {
    switch (flavorString.toLowerCase()) {
      case 'dev':
        return AppFlavor.dev;
      case 'uat':
        return AppFlavor.uat;
      case 'prod':
        return AppFlavor.prod;
      default:
        throw ArgumentError('Unknown flavor: $flavorString');
    }
  }
}
