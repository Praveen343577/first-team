enum NetworkStatus { online, offline }
