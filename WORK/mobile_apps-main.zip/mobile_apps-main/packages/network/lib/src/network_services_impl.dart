import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';

import 'network_services.dart';
import 'network_status.dart';

class NetworkServiceImpl implements NetworkService {
  NetworkServiceImpl() {
    _subscription = _connectivity.onConnectivityChanged.listen(_onChanged);
  }

  final Connectivity _connectivity = Connectivity();
  final _controller = StreamController<NetworkStatus>.broadcast();
  late final StreamSubscription _subscription;
  @override
  bool isOnline = false;

  void _onChanged(List<ConnectivityResult> results) {
    isOnline = results.any((r) => r != ConnectivityResult.none);

    _controller.add(isOnline ? NetworkStatus.online : NetworkStatus.offline);
  }

  @override
  Stream<NetworkStatus> get status$ => _controller.stream;

  @override
  Future<NetworkStatus> checkStatus() async {
    final results = await _connectivity.checkConnectivity();
    return results.contains(ConnectivityResult.none)
        ? NetworkStatus.offline
        : NetworkStatus.online;
  }

  void dispose() {
    _subscription.cancel();
    _controller.close();
  }
}