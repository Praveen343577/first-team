import 'dart:async';

import 'network_status.dart';

abstract class NetworkService {
  Stream<NetworkStatus> get status$;
  Future<NetworkStatus> checkStatus();
  bool isOnline = false;
}
