<!-- fleet-monorepo/
│
├── apps/
│   ├── admin_app/
│   ├── fleet_owner_app/
│   |__ driver_app/
│
├── packages/
│   ├── core/
│   ├── auth/
│   ├── network/
│   ├── realtime/
│   ├── models/
        ├── vehicle.dart
        ├── driver.dart
        ├── trip.dart
        ├── telemetry.dart
        └── user.dart

│   ├── map/
│   ├── notifications/
│   ├── storage/
│   ├── ui_kit/
│   └── utils/
│
├── melos.yaml
└── pubspec.yaml -->

[]- setup apk pipelines
[]- setup logger
[]- setup crashlytics
[]- setup api service
[]- setup auth checker
[]- setup UI components
[]- setup string for localizations
[]- setup formblocs into state handler with architecture



## Development Roadmap

### Month 1 — Foundation
**Goal:** Establish shared core infrastructure and authentication

**Shared Packages:**
- state handling
- Multi-language support
- Theme and UI setup with mock cards
- scaffold setup for screens
- Hive
- Network package with connectivity stream
- API client (Dio)
- Basic error handling

**App Features:**
- Navigation shell
- Mock UI

**Deliverables:**
- ✓ Apps authenticated and backend-connected
- ✓ Reusable core packages

### Month 2 — Fleet Owner 
**Goal:** Core fleet management features

**Features:**
- Dashboard (vehicle count, active trips)
- Vehicle management (CRUD)
- Driver management (CRUD)
- Trip assignment
- Full API integration

**Deliverables:**
- ✓ Fleet and driver management
- ✓ Functional trip assignment
- ✓ All API calls operational

### Month 3 — Driver
**Features:**
- Driver: View vehicle/trip, start/end trips, real-time location tracking
- In-app notifications

**Deliverables:**
- ✓ Driver trip acceptance workflow
- ✓ Real-time passenger ride visibility

### Month 4 and 5 — Rickshaw Owner App & Passanger App
**Features:**
- Rickshaw Owner: Vehicle management (CRUD), booking management, ride history
- Passenger: Request ride, live tracking, ride history
- Error reporting and logging
- App settings (theme, language)

**Deliverables:**
- ✓ Rickshaw owner workflow
- ✓ Consistent features across all apps

### Month 6 — Notifications & Analytics , Release
**Features:**
- Push notifications (assignments, updates)
- Geofence and speed alerts
- Bug fixes and testing
- UI refinements and performance optimization

**Deliverables:**
- ✓ Alert system functional
- ✓ Owner reporting available



**Deliverables:**
- ✓ MVP production-ready across all apps
- ✓ Stable, tested shared packages
