import os

def fix_imports():
    dirs = ['apps', 'packages']
    
    for dir_name in dirs:
        for root, _, files in os.walk(dir_name):
            for file in files:
                if file.endswith('.dart'):
                    path = os.path.join(root, file)
                    with open(path, 'r') as f:
                        content = f.read()
                        
                    new_content = content
                    
                    if "import 'package:state_handler/cubit/fetch_cubit.dart';" in new_content and "import 'package:state_handler/cubit/submit_cubit.dart';" not in new_content:
                        new_content = new_content.replace(
                            "import 'package:state_handler/cubit/fetch_cubit.dart';",
                            "import 'package:state_handler/cubit/fetch_cubit.dart';\nimport 'package:state_handler/cubit/submit_cubit.dart';"
                        )

                    if "import 'package:state_handler/cubit/fetch_state.dart';" in new_content and "import 'package:state_handler/cubit/submit_state.dart';" not in new_content:
                        new_content = new_content.replace(
                            "import 'package:state_handler/cubit/fetch_state.dart';",
                            "import 'package:state_handler/cubit/fetch_state.dart';\nimport 'package:state_handler/cubit/submit_state.dart';"
                        )
                        
                    if new_content != content:
                        with open(path, 'w') as f:
                            f.write(new_content)
                            print(f"Fixed imports in {path}")

if __name__ == '__main__':
    fix_imports()
