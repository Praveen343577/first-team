import 'package:app_string/app_string.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:env/env.dart';
import 'package:admin/di/service_locator.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/repository/recent_activity_repository.dart';
import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/ui/driver/ui/app_shell.dart';
import 'package:admin/ui/driver/cubit/fleet_list_cubit.dart';
import 'package:admin/ui/driver/ui/screens/sign_in/sign_in_cubit.dart';
import 'package:admin/ui/dashboards/cubit/fleet_status_cubit.dart';
import 'package:admin/ui/dashboards/cubit/distance_chart_cubit.dart';
import 'package:admin/ui/dashboards/cubit/sustainability_cubit.dart';
import 'package:admin/ui/dashboards/cubit/trip_stats_cubit.dart';
import 'package:admin/ui/dashboards/cubit/vehicle_status_map_cubit.dart';
import 'package:admin/ui/fleet/cubit/aggregated_vehicles_cubit.dart';
import 'package:admin/ui/driver/ui/screens/sign_in/sign_in.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:network/network.dart';
import 'package:ui/ui.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:go_router/go_router.dart';
import 'package:admin/models/token/token_store.dart';
import 'package:admin/ui/driver/ui/screens/sign_in/reset_password_screen.dart';
import 'package:admin/ui/common/widgets/eka_snack_bar.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting();

  // Initialize Hive
  await Hive.initFlutter();
  Hive.registerAdapter(RecentActivityItemAdapter());

  await Firebase.initializeApp();

  // Pass all uncaught "fatal" errors from the framework to Crashlytics
  FlutterError.onError = (errorDetails) {
    FirebaseCrashlytics.instance.recordFlutterFatalError(errorDetails);
  };

  // Pass all uncaught asynchronous errors that aren't handled by the Flutter framework to Crashlytics
  PlatformDispatcher.instance.onError = (error, stack) {
    FirebaseCrashlytics.instance.recordError(error, stack, fatal: true);
    return true;
  };

  EasyLocalization.logger.enableBuildModes = [];
  EasyLocalization.ensureInitialized();
  const env = AppEnvironment(AppFlavor.dev);
  await dotenv.load(fileName: 'assets/${env.envFile}');
  setupDI(env.flavor, dotenv.env);
  await getIt<NetworkService>().checkStatus();
  await getIt<RecentActivityRepository>().init();

  final authRepo = getIt<AuthRepository>();
  final isAutoLoggedIn = await authRepo.tryAutoLogin();

  runApp(LocaleLoader(child: MyApp(isAutoLoggedIn: isAutoLoggedIn)));
}

final GoRouter _router = GoRouter(
  initialLocation: '/',
  refreshListenable: getIt<TokenStore>(),
  redirect: (BuildContext context, GoRouterState state) {
    final token = getIt<TokenStore>().token;
    final location = state.matchedLocation;
    
    // Allow reset-password to bypass auth check
    if (location.startsWith('/reset-password')) {
      return null;
    }
    
    final loggingIn = location == '/login';
    
    if (token == null || token.isEmpty) {
      return '/login';
    }
    
    if (loggingIn) {
      return '/';
    }
    
    return null;
  },
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const AppShell(),
    ),
    GoRoute(
      path: '/login',
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/reset-password',
      builder: (context, state) {
        final token = state.uri.queryParameters['token'] ?? '';
        return ResetPasswordScreen(token: token);
      },
    ),
  ],
);

class MyApp extends StatelessWidget {
  final bool isAutoLoggedIn;
  const MyApp({super.key, required this.isAutoLoggedIn});

  @override
  Widget build(BuildContext context) {
    return ThemeBuilder(
      builder: (context, theme) {
        return MultiBlocProvider(
          providers: [
            BlocProvider<SignInCubit>(
              create: (context) => getIt<SignInCubit>(),
            ),
            BlocProvider<FleetListCubit>(
              create: (context) => getIt<FleetListCubit>()..load(),
            ),
            BlocProvider<FleetStatusCubit>(
              create: (context) => getIt<FleetStatusCubit>()..load(),
            ),
            BlocProvider<DistanceChartCubit>(
              create: (context) => getIt<DistanceChartCubit>()..load(),
            ),
            BlocProvider<SustainabilityCubit>(
              create: (context) => getIt<SustainabilityCubit>()..load(),
            ),
            BlocProvider<TripStatsCubit>(
              create: (context) => getIt<TripStatsCubit>()..load(),
            ),
            BlocProvider<VehicleStatusMapCubit>(
              create: (context) => getIt<VehicleStatusMapCubit>()..load(),
            ),
            BlocProvider<AggregatedVehiclesCubit>(
              create: (context) => getIt<AggregatedVehiclesCubit>()..load(),
            ),
          ],
          child: MaterialApp.router(
            title: 'Flutter Demo',
            theme: theme,
            routerConfig: _router,
            scaffoldMessengerKey: EkaSnackBar.messengerKey,
          ),
        );
      },
    );
  }
}
