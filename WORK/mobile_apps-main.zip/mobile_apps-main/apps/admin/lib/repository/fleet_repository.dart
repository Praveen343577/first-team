import 'package:admin/models/fleet/dto/fleet_list_request_dto.dart';
import 'package:admin/models/fleet/dto/fleet_list_response_dto.dart';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/models/fleet/mapper.dart';
import 'package:admin/service/api/fleet_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class FleetRepository {
  final FleetApi _api;
  final FleetMapper _mapper = FleetMapper();
  final ExceptionLogger _exceptionLogger;

  FleetRepository(this._api, this._exceptionLogger);

  Future<List<FleetModel>> getFleets({
    FleetListRequestDto request = const FleetListRequestDto(),
  }) async {
    try {
      final dtos = await _api.getFleets(request.skip, request.limit);
      return dtos
          .map((dto) => _mapper.convert<FleetListResponseDto, FleetModel>(dto))
          .toList();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<FleetModel> getFleetDetails(String id) async {
    try {
      final dto = await _api.getFleetDetails(id);
      return _mapper.convert<FleetListResponseDto, FleetModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
