import 'package:admin/models/fleet_manager/fleet_manager_model.dart';
import 'package:admin/models/fleet_manager/dto/fleet_manager_dto.dart';
import 'package:admin/models/fleet_manager/mapper.dart';
import 'package:admin/service/api/fleet_manager_api.dart';
import 'package:injectable/injectable.dart';

abstract class FleetManagerRepository {
  Future<List<FleetManagerModel>> getFleetManagers();
  Future<FleetManagerModel> getFleetManagerDetails(String id);
}

@LazySingleton(as: FleetManagerRepository)
class FleetManagerRepositoryImpl implements FleetManagerRepository {
  final FleetManagerApi _api;
  final FleetManagerMapper _mapper = FleetManagerMapper();

  FleetManagerRepositoryImpl(this._api);

  @override
  Future<List<FleetManagerModel>> getFleetManagers() async {
    final dtos = await _api.getFleetManagers();
    return dtos.map((dto) => _mapper.convert<FleetManagerDto, FleetManagerModel>(dto)).toList();
  }

  @override
  Future<FleetManagerModel> getFleetManagerDetails(String id) async {
    final dto = await _api.getFleetManagerDetails(id);
    return _mapper.convert<FleetManagerDto, FleetManagerModel>(dto);
  }
}
