import 'package:admin/models/dashboard/dto/fleet_status_response_dto.dart';
import 'package:admin/models/dashboard/fleet_status_model.dart';
import 'package:admin/models/dashboard/dto/distance_chart_response_dto.dart';
import 'package:admin/models/dashboard/distance_chart_model.dart';
import 'package:admin/models/dashboard/dto/sustainability_response_dto.dart';
import 'package:admin/models/dashboard/sustainability_model.dart';
import 'package:admin/models/dashboard/dto/trip_stats_response_dto.dart';
import 'package:admin/models/dashboard/trip_stats_model.dart';
import 'package:admin/models/dashboard/dto/vehicle_status_map_response_dto.dart';
import 'package:admin/models/dashboard/vehicle_status_map_model.dart';
import 'package:admin/models/dashboard/mapper.dart';
import 'package:admin/service/api/dashboard_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class DashboardRepository {
  final DashboardApi _api;
  final DashboardMapper _mapper = DashboardMapper();
  final ExceptionLogger _exceptionLogger;

  DashboardRepository(this._api, this._exceptionLogger);

  Future<FleetStatusModel> getFleetStatus() async {
    try {
      final dto = await _api.getFleetStatus();
      return _mapper.convert<FleetStatusResponseDto, FleetStatusModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<DistanceChartModel> getDistanceChart(String period) async {
    try {
      final dto = await _api.getDistanceChart(period);
      return _mapper.convert<DistanceChartResponseDto, DistanceChartModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<SustainabilityModel> getSustainability() async {
    try {
      final dto = await _api.getSustainability();
      return _mapper.convert<SustainabilityResponseDto, SustainabilityModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<TripStatsModel> getTripStats(String period) async {
    try {
      final dto = await _api.getTripStats(period);
      return _mapper.convert<TripStatsResponseDto, TripStatsModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<VehicleStatusMapModel> getVehicleStatusMap(double clusterDistanceKm) async {
    try {
      final dto = await _api.getVehicleStatusMap(clusterDistanceKm);
      return _mapper.convert<VehicleStatusMapResponseDto, VehicleStatusMapModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
