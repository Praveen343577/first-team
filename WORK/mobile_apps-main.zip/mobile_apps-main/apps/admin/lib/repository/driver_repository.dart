import 'package:dio/dio.dart';
import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/models/driver/dto/create_driver_profile_request_dto.dart';
import 'package:admin/models/driver/dto/driver_list_request_dto.dart';
import 'package:admin/models/driver/dto/driver_list_response_dto.dart';
import 'package:admin/models/driver/dto/driver_profile_response_dto.dart';
import 'package:admin/models/driver/dto/upload_profile_pic_response_dto.dart';
import 'package:admin/models/driver/mapper.dart';
import 'package:admin/models/driver/dto/driver_scorecard_response_dto.dart';
import 'package:admin/service/api/driver_api.dart';
import 'package:admin/service/api/scorecard_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class DriverRepository {
  final DriverApi _api;
  final ScorecardApi _scorecardApi;
  final DriverMapper _mapper = DriverMapper();
  final ExceptionLogger _exceptionLogger;

  DriverRepository(this._api, this._scorecardApi, this._exceptionLogger);

  Future<DriverProfileResponseDto> createDriverProfile({
    required CreateDriverProfileRequestDto request,
  }) async {
    try {
      return await _api.createDriverProfile(request);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<DriverModel> getDriverProfile(String driverId) async {
    try {
      final dto = await _api.getDriverProfile(driverId);
      return _mapper.convert<DriverProfileResponseDto, DriverModel>(dto);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<DriverProfileResponseDto> updateDriverProfile({
    required String driverId,
    required CreateDriverProfileRequestDto request,
  }) async {
    try {
      return await _api.updateDriverProfile(driverId, request);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<List<DriverModel>> getDrivers({
    DriverListRequestDto request = const DriverListRequestDto(),
  }) async {
    try {
      final dtos = await _api.getDrivers(
        request.skip,
        request.limit,
        request.search,
        request.sortBy,
        request.sortOrder,
      );
      return dtos
          .map(
            (dto) => _mapper.convert<DriverListResponseDto, DriverModel>(dto),
          )
          .toList();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<void> deleteDriver(String driverId) async {
    try {
      await _api.deleteDriver(driverId);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<UploadProfilePicResponseDto> uploadProfilePic({
    required String driverId,
    required MultipartFile file,
  }) async {
    try {
      return await _api.uploadProfilePic(driverId, file);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<DriverScorecardResponseDto> getScorecard({
    required String driverId,
    required String period,
  }) async {
    try {
      return await _scorecardApi.getScorecard(driverId, period);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
