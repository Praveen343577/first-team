import 'package:admin/models/telemetry/dto/telemetry_history_request_dto.dart';
import 'package:admin/models/telemetry/dto/telemetry_history_response_dto.dart';
import 'package:admin/models/telemetry/mapper.dart';
import 'package:admin/models/telemetry/telemetry_model.dart';
import 'package:admin/service/api/telemetry_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class TelemetryRepository {
  final TelemetryApi _api;
  final TelemetryMapper _mapper = TelemetryMapper();
  final ExceptionLogger _exceptionLogger;

  TelemetryRepository(this._api, this._exceptionLogger);

  Future<List<TelemetryModel>> getHistory(
    TelemetryHistoryRequestDto request,
  ) async {
    try {
      final dtos = await _api.getHistory(
        request.deviceId,
        request.startTime,
        request.endTime,
      );
      return dtos
          .map(
            (dto) =>
                _mapper.convert<TelemetryHistoryResponseDto, TelemetryModel>(
              dto,
            ),
          )
          .toList();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
