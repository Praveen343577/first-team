import 'package:admin/models/route/dto/create_route_request_dto.dart';
import 'package:admin/models/route/dto/route_list_request_dto.dart';
import 'package:admin/models/route/dto/update_route_request_dto.dart';
import 'package:admin/models/route/mapper.dart';
import 'package:admin/models/route/route_model.dart';
import 'package:admin/service/api/route_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class RouteRepository {
  final RouteApi _api;
  final RouteMapper _mapper = RouteMapper();
  final ExceptionLogger _exceptionLogger;

  RouteRepository(this._api, this._exceptionLogger);

  Future<List<RouteModel>> getRoutes({
    String? fleetId,
    RouteListRequestDto request = const RouteListRequestDto(),
  }) async {
    try {
      final response = await _api.getRoutes(
        fleetId ?? request.fleetId,
        request.search,
        request.skip,
        request.limit,
      );
      return response.items.map(_mapper.fromDto).toList();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<RouteModel> createRoute(CreateRouteRequestDto request) async {
    try {
      final response = await _api.createRoute(request);
      return _mapper.fromResponseDto(response);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<RouteModel> updateRoute(
    String id,
    UpdateRouteRequestDto request,
  ) async {
    try {
      final response = await _api.updateRoute(id, request);
      return _mapper.fromResponseDto(response);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<void> deleteRoute(String id) async {
    try {
      await _api.deleteRoute(id);
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
