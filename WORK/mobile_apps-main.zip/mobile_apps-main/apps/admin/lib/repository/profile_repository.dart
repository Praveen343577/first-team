import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

import '../service/api/client_api.dart';

@LazySingleton()
class ProfileRepository {
  final ClientApi _api;
  final ExceptionLogger _exceptionLogger;

  ProfileRepository(this._api, this._exceptionLogger);

  Future<dynamic> getProfile() async {
    try {
      return await _api.getMe();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
