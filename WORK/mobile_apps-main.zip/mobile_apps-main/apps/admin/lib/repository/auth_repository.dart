import 'package:admin/models/login/dto/login_response_dto.dart';
import 'package:admin/models/login/mapper.dart';
import 'package:admin/models/refresh/refresh_token_request_dto.dart';
import 'package:admin/models/register/dto/register_request_dto.dart';
import 'package:admin/models/login/dto/forgot_password_request.dart';
import 'package:admin/models/login/dto/forgot_password_response.dart';
import 'package:admin/models/login/dto/reset_password_request.dart';
import 'package:admin/models/login/dto/reset_password_response.dart';
import 'package:admin/models/token/auth_token.dart';
import 'package:admin/models/token/token_store.dart';
import 'package:admin/service/analytics_service.dart';
import 'package:admin/service/api/auth_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

import '../models/login/dto/login_request_dto.dart';

@LazySingleton()
class AuthRepository {
  final AuthApi _api;
  final AuthMapper _mapper = AuthMapper();
  final TokenStore _tokenStore;
  final ExceptionLogger _exceptionLogger;
  final AnalyticsService _analyticsService;

  AuthRepository(
    this._api,
    this._tokenStore,
    this._exceptionLogger,
    this._analyticsService,
  );

  Future<LoginResponseDto> login(LoginRequestDto request) async {
    try {
      final response = saveToken(
        await _api.login(
          request.grantType,
          request.username,
          request.password,
          request.scope,
          request.clientId,
          request.clientSecret,
        ),
      );
      await _analyticsService.logLogin(method: 'email');
      return response;
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<LoginResponseDto> refreshToken(RefreshTokenRequestDto request) async {
    try {
      return saveToken(await _api.refreshToken(request));
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<LoginResponseDto> register(
    RegisterRequestDto request, {
    String role = 'driver',
  }) async {
    try {
      return saveToken(await _api.register(request, role));
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  LoginResponseDto saveToken(LoginResponseDto response) {
    final tokens = _mapper.convert<LoginResponseDto, AuthToken>(response);

    final newRefreshToken = (tokens.refreshToken != null && tokens.refreshToken!.isNotEmpty)
        ? tokens.refreshToken!
        : _tokenStore.refreshToken ?? '';

    _tokenStore.saveToken(tokens.accessToken, newRefreshToken);

    return response.copyWith(refreshToken: newRefreshToken);
  }

  Future<bool> tryAutoLogin() async {
    try {
      await _tokenStore.loadToken();

      if (_tokenStore.token == null) {
        return false;
      }

      /// optionally validate token with API
      return true;
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      return false;
    }
  }

  Future<void> logout() async {
    _analyticsService.logLogout();
    await _tokenStore.clear();
  }
  Future<ForgotPasswordResponse> forgotPassword(String email) async {
    try {
      return await _api.forgotPassword(ForgotPasswordRequest(email: email));
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<ResetPasswordResponse> resetPassword(String token, String newPassword) async {
    try {
      return await _api.resetPassword(ResetPasswordRequest(token: token, newPassword: newPassword));
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
