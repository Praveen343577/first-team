import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:hive/hive.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class RecentActivityRepository {
  static const String _boxName = 'recent_activity';
  static const int _maxItems = 20;

  Box<RecentActivityItem>? _box;

  Future<void> init() async {
    _box = await Hive.openBox<RecentActivityItem>(_boxName);
  }

  Box<RecentActivityItem> get _safeBox {
    assert(_box != null, 'RecentActivityRepository.init() must be called first');
    return _box!;
  }

  List<RecentActivityItem> getRecentItems({int limit = 5, List<String>? filterTypes}) {
    var items = _safeBox.values.toList();
    if (filterTypes != null && filterTypes.isNotEmpty) {
      items = items.where((item) => filterTypes.contains(item.type)).toList();
    }
    items.sort((a, b) => b.viewedAt.compareTo(a.viewedAt));
    return items.take(limit).toList();
  }

  Stream<List<RecentActivityItem>> watchRecentItems({int limit = 5, List<String>? filterTypes}) async* {
    yield getRecentItems(limit: limit, filterTypes: filterTypes);
    await for (final _ in _safeBox.watch()) {
      yield getRecentItems(limit: limit, filterTypes: filterTypes);
    }
  }

  Future<void> addItem(RecentActivityItem item) async {
    final box = _safeBox;

    // Remove existing entry with same id + type (upsert)
    final existingKey = box.keys.cast<dynamic>().firstWhere(
      (key) {
        final existing = box.get(key);
        return existing != null &&
            existing.id == item.id &&
            existing.type == item.type;
      },
      orElse: () => null,
    );

    if (existingKey != null) {
      await box.delete(existingKey);
    }

    await box.add(item);

    // Trim to max items (oldest first)
    if (box.length > _maxItems) {
      final allItems = box.values.toList();
      allItems.sort((a, b) => a.viewedAt.compareTo(b.viewedAt));
      final toRemove = allItems.take(box.length - _maxItems);
      for (final old in toRemove) {
        await old.delete();
      }
    }
  }

  Future<void> clear() async {
    await _safeBox.clear();
  }
}
