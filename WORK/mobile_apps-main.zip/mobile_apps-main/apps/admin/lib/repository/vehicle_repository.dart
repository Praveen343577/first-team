import 'package:admin/models/vehicle/dto/vehicle_list_request_dto.dart';
import 'package:admin/models/vehicle/dto/vehicle_list_response_dto.dart';
import 'package:admin/models/vehicle/dto/aggregated_vehicle_dto.dart';
import 'package:admin/models/vehicle/aggregated_vehicle.dart';
import 'package:admin/models/vehicle/mapper.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/service/api/vehicle_api.dart';
import 'package:admin/service/exception_logger.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class VehicleRepository {
  final VehicleApi _api;
  final VehicleMapper _mapper = VehicleMapper();
  final ExceptionLogger _exceptionLogger;

  VehicleRepository(this._api, this._exceptionLogger);

  Future<List<VehicleModel>> getVehicles(VehicleListRequestDto request) async {
    try {
      final dtos = await _api.getVehicles(request.fleetId);
      return dtos
          .map(
            (dto) => _mapper.convert<VehicleListResponseDto, VehicleModel>(dto),
          )
          .toList();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }

  Future<List<AggregatedVehicle>> getAggregatedVehicles({String? fleetId}) async {
    try {
      final dtos = await _api.getAggregatedVehicles(fleetId);
      return dtos
          .map(
            (dto) => _mapper.convert<AggregatedVehicleDto, AggregatedVehicle>(dto),
          )
          .toList();
    } catch (e, stack) {
      _exceptionLogger.logException(e, stack);
      rethrow;
    }
  }
}
