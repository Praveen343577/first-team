import 'package:flutter_dotenv/flutter_dotenv.dart';

class AppConfig {
  static String get appName => dotenv.env['APP_NAME']!;
  // static String get baseUrl => dotenv.env['BASE_URL']!;
  // static String get socketUrl => dotenv.env['SOCKET_URL']!;
  // static String get logLevel => dotenv.env['LOG_LEVEL']!;
}
