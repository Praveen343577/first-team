import 'package:env/env.dart';
import 'package:admin/di/service_locator.config.dart';
import 'package:get_it/get_it.dart';
import 'package:injectable/injectable.dart';
import 'package:network/network.dart';

final getIt = GetIt.instance;

@InjectableInit()
Future<void> setupDI(AppFlavor flavor, Map<String, String> envMap) async {
  getIt.registerLazySingleton<NetworkService>(() => NetworkServiceImpl());
  for (var entry in envMap.entries) {
    // getIt.registerSingleton<AppFlavor>(flavor);
    getIt.registerLazySingleton<String>(
      () => entry.value,
      instanceName: entry.key,
    );
  }

  await getIt.init();
}
