import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:admin/models/vehicle/dto/vehicle_list_response_dto.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/models/vehicle/dto/aggregated_vehicle_dto.dart';
import 'package:admin/models/vehicle/aggregated_vehicle.dart';
import 'package:admin/models/vehicle/mapper.auto_mappr.dart';

@AutoMappr([
  MapType<VehicleListResponseDto, VehicleModel>(),
  MapType<AggregatedVehicleDto, AggregatedVehicle>(),
])
class VehicleMapper extends $VehicleMapper {}
