import 'package:freezed_annotation/freezed_annotation.dart';

part 'vehicle_model.freezed.dart';

@freezed
abstract class VehicleModel with _$VehicleModel {
  const factory VehicleModel({
    required String id,
    required String vehicleRegNo,
    required String vehicleType,
    required String fleetId,
    required String deviceId,
    required String createdAt,
  }) = _VehicleModel;
}
