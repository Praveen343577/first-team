class VehicleListRequestDto {
  final String? fleetId;

  const VehicleListRequestDto({this.fleetId});
}
