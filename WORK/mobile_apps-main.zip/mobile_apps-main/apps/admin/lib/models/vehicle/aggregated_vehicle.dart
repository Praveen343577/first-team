import 'package:freezed_annotation/freezed_annotation.dart';

part 'aggregated_vehicle.freezed.dart';

@freezed
abstract class AggregatedVehicle with _$AggregatedVehicle {
  const factory AggregatedVehicle({
    required String vehicleId,
    required String name,
    required String type,
    required String registrationNumber,
    required String status,
    required double charge,
    required double rangeKm,
    required double latitude,
    required double longitude,
    required String lastUpdated,
  }) = _AggregatedVehicle;
}
