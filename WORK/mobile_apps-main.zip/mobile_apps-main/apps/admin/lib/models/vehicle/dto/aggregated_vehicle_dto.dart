import 'package:freezed_annotation/freezed_annotation.dart';

part 'aggregated_vehicle_dto.freezed.dart';
part 'aggregated_vehicle_dto.g.dart';

@Freezed(toJson: false)
abstract class AggregatedVehicleDto with _$AggregatedVehicleDto {
  const factory AggregatedVehicleDto({
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    required String name,
    required String type,
    @JsonKey(name: 'registration_number') required String registrationNumber,
    required String status,
    required double charge,
    @JsonKey(name: 'range_km') required double rangeKm,
    required double latitude,
    required double longitude,
    @JsonKey(name: 'last_updated') required String lastUpdated,
  }) = _AggregatedVehicleDto;

  factory AggregatedVehicleDto.fromJson(Map<String, dynamic> json) =>
      _$AggregatedVehicleDtoFromJson(json);
}
