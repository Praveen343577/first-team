import 'package:freezed_annotation/freezed_annotation.dart';

part 'vehicle_list_response_dto.freezed.dart';
part 'vehicle_list_response_dto.g.dart';

@Freezed(toJson: false)
abstract class VehicleListResponseDto with _$VehicleListResponseDto {
  const factory VehicleListResponseDto({
    required String id,
    @JsonKey(name: 'vehicle_reg_no') required String vehicleRegNo,
    @JsonKey(name: 'vehicle_type') required String vehicleType,
    @JsonKey(name: 'fleet_id') required String fleetId,
    @JsonKey(name: 'device_id') required String deviceId,
    @JsonKey(name: 'created_at') required String createdAt,
  }) = _VehicleListResponseDto;

  factory VehicleListResponseDto.fromJson(Map<String, dynamic> json) =>
      _$VehicleListResponseDtoFromJson(json);
}
