import 'package:freezed_annotation/freezed_annotation.dart';

part 'fleet_status_model.freezed.dart';

@freezed
abstract class FleetStatusModel with _$FleetStatusModel {
  const factory FleetStatusModel({
    required int active,
    required int inactive,
    required int charging,
    required int idle,
    required int maintenance,
    required int total,
    required String timestamp,
  }) = _FleetStatusModel;
}
