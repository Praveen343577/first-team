import 'package:freezed_annotation/freezed_annotation.dart';

part 'sustainability_response_dto.freezed.dart';
part 'sustainability_response_dto.g.dart';

@Freezed(toJson: false)
abstract class CalculationPeriodDto with _$CalculationPeriodDto {
  const factory CalculationPeriodDto({
    required String start,
    required String end,
  }) = _CalculationPeriodDto;

  factory CalculationPeriodDto.fromJson(Map<String, dynamic> json) =>
      _$CalculationPeriodDtoFromJson(json);
}

@Freezed(toJson: false)
abstract class SustainabilityResponseDto with _$SustainabilityResponseDto {
  const factory SustainabilityResponseDto({
    @JsonKey(name: 'co2_saved_kg') required double co2SavedKg,
    @JsonKey(name: 'co2_saved_tons') required double co2SavedTons,
    @JsonKey(name: 'trees_equivalent') required int treesEquivalent,
    @JsonKey(name: 'cost_saved_inr') required double costSavedInr,
    @JsonKey(name: 'total_distance_km') required double totalDistanceKm,
    @JsonKey(name: 'calculation_period') required CalculationPeriodDto calculationPeriod,
  }) = _SustainabilityResponseDto;

  factory SustainabilityResponseDto.fromJson(Map<String, dynamic> json) =>
      _$SustainabilityResponseDtoFromJson(json);
}
