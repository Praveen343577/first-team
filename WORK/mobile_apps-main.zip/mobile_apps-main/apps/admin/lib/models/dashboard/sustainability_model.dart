import 'package:freezed_annotation/freezed_annotation.dart';

part 'sustainability_model.freezed.dart';

@freezed
abstract class CalculationPeriod with _$CalculationPeriod {
  const factory CalculationPeriod({
    required String start,
    required String end,
  }) = _CalculationPeriod;
}

@freezed
abstract class SustainabilityModel with _$SustainabilityModel {
  const factory SustainabilityModel({
    required double co2SavedKg,
    required double co2SavedTons,
    required int treesEquivalent,
    required double costSavedInr,
    required double totalDistanceKm,
    required CalculationPeriod calculationPeriod,
  }) = _SustainabilityModel;
}
