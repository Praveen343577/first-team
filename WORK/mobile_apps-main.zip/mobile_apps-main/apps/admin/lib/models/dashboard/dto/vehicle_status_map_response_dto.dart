import 'package:freezed_annotation/freezed_annotation.dart';

part 'vehicle_status_map_response_dto.freezed.dart';
part 'vehicle_status_map_response_dto.g.dart';

@Freezed(toJson: false)
abstract class VehicleStatusClusterDto with _$VehicleStatusClusterDto {
  const factory VehicleStatusClusterDto({
    required double lat,
    required double lng,
    required int count,
    @JsonKey(name: 'status_breakdown') required Map<String, int> statusBreakdown,
  }) = _VehicleStatusClusterDto;

  factory VehicleStatusClusterDto.fromJson(Map<String, dynamic> json) =>
      _$VehicleStatusClusterDtoFromJson(json);
}

@Freezed(toJson: false)
abstract class IndividualVehicleDto with _$IndividualVehicleDto {
  const factory IndividualVehicleDto({
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    @JsonKey(name: 'vehicle_reg_no') required String vehicleRegNo,
    required double lat,
    required double lng,
    required String status,
    double? soc,
    double? speed,
    @JsonKey(name: 'device_id') String? deviceId,
  }) = _IndividualVehicleDto;

  factory IndividualVehicleDto.fromJson(Map<String, dynamic> json) =>
      _$IndividualVehicleDtoFromJson(json);
}

@Freezed(toJson: false)
abstract class VehicleStatusMapResponseDto with _$VehicleStatusMapResponseDto {
  const factory VehicleStatusMapResponseDto({
    required List<VehicleStatusClusterDto> clusters,
    @JsonKey(name: 'individual_vehicles') required List<IndividualVehicleDto> individualVehicles,
    @JsonKey(name: 'total_vehicles') required int totalVehicles,
  }) = _VehicleStatusMapResponseDto;

  factory VehicleStatusMapResponseDto.fromJson(Map<String, dynamic> json) =>
      _$VehicleStatusMapResponseDtoFromJson(json);
}
