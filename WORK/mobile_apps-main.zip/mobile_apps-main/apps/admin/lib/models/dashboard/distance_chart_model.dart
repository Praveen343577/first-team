import 'package:freezed_annotation/freezed_annotation.dart';

part 'distance_chart_model.freezed.dart';

@freezed
abstract class DistanceChartModel with _$DistanceChartModel {
  const factory DistanceChartModel({
    required List<Map<String, dynamic>> data,
    required double totalDistanceKm,
    required String period,
    required String startDate,
    required String endDate,
  }) = _DistanceChartModel;
}
