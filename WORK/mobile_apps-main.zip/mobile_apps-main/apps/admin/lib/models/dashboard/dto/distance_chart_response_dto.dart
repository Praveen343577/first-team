import 'package:freezed_annotation/freezed_annotation.dart';

part 'distance_chart_response_dto.freezed.dart';
part 'distance_chart_response_dto.g.dart';

@Freezed(toJson: false)
abstract class DistanceChartResponseDto with _$DistanceChartResponseDto {
  const factory DistanceChartResponseDto({
    required List<Map<String, dynamic>> data,
    @JsonKey(name: 'total_distance_km') required double totalDistanceKm,
    required String period,
    @JsonKey(name: 'start_date') required String startDate,
    @JsonKey(name: 'end_date') required String endDate,
  }) = _DistanceChartResponseDto;

  factory DistanceChartResponseDto.fromJson(Map<String, dynamic> json) =>
      _$DistanceChartResponseDtoFromJson(json);
}
