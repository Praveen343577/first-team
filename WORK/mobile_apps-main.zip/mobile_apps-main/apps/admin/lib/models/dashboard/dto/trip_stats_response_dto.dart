import 'package:freezed_annotation/freezed_annotation.dart';

part 'trip_stats_response_dto.freezed.dart';
part 'trip_stats_response_dto.g.dart';

@Freezed(toJson: false)
abstract class TripStatsResponseDto with _$TripStatsResponseDto {
  const factory TripStatsResponseDto({
    required int planned,
    required int ongoing,
    required int completed,
    required int cancelled,
    required int total,
    required String period,
  }) = _TripStatsResponseDto;

  factory TripStatsResponseDto.fromJson(Map<String, dynamic> json) =>
      _$TripStatsResponseDtoFromJson(json);
}
