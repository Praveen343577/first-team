import 'package:freezed_annotation/freezed_annotation.dart';

part 'vehicle_status_map_model.freezed.dart';

@freezed
abstract class VehicleStatusCluster with _$VehicleStatusCluster {
  const factory VehicleStatusCluster({
    required double lat,
    required double lng,
    required int count,
    required Map<String, int> statusBreakdown,
  }) = _VehicleStatusCluster;
}

@freezed
abstract class IndividualVehicle with _$IndividualVehicle {
  const factory IndividualVehicle({
    required String vehicleId,
    required String vehicleRegNo,
    required double lat,
    required double lng,
    required String status,
    double? soc,
    double? speed,
    String? deviceId,
  }) = _IndividualVehicle;
}

@freezed
abstract class VehicleStatusMapModel with _$VehicleStatusMapModel {
  const factory VehicleStatusMapModel({
    required List<VehicleStatusCluster> clusters,
    required List<IndividualVehicle> individualVehicles,
    required int totalVehicles,
  }) = _VehicleStatusMapModel;
}
