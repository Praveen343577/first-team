import 'package:freezed_annotation/freezed_annotation.dart';

part 'fleet_status_response_dto.freezed.dart';
part 'fleet_status_response_dto.g.dart';

@Freezed(toJson: false)
abstract class FleetStatusResponseDto with _$FleetStatusResponseDto {
  const factory FleetStatusResponseDto({
    required int active,
    required int inactive,
    required int charging,
    required int idle,
    required int maintenance,
    required int total,
    required String timestamp,
  }) = _FleetStatusResponseDto;

  factory FleetStatusResponseDto.fromJson(Map<String, dynamic> json) =>
      _$FleetStatusResponseDtoFromJson(json);
}
