import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:admin/models/dashboard/dto/fleet_status_response_dto.dart';
import 'package:admin/models/dashboard/fleet_status_model.dart';
import 'package:admin/models/dashboard/dto/distance_chart_response_dto.dart';
import 'package:admin/models/dashboard/distance_chart_model.dart';
import 'package:admin/models/dashboard/dto/sustainability_response_dto.dart';
import 'package:admin/models/dashboard/sustainability_model.dart';
import 'package:admin/models/dashboard/dto/trip_stats_response_dto.dart';
import 'package:admin/models/dashboard/trip_stats_model.dart';
import 'package:admin/models/dashboard/dto/vehicle_status_map_response_dto.dart';
import 'package:admin/models/dashboard/vehicle_status_map_model.dart';
import 'package:admin/models/dashboard/mapper.auto_mappr.dart';

@AutoMappr([
  MapType<FleetStatusResponseDto, FleetStatusModel>(),
  MapType<DistanceChartResponseDto, DistanceChartModel>(),
  MapType<CalculationPeriodDto, CalculationPeriod>(),
  MapType<SustainabilityResponseDto, SustainabilityModel>(),
  MapType<TripStatsResponseDto, TripStatsModel>(),
  MapType<VehicleStatusClusterDto, VehicleStatusCluster>(),
  MapType<IndividualVehicleDto, IndividualVehicle>(),
  MapType<VehicleStatusMapResponseDto, VehicleStatusMapModel>(),
])
class DashboardMapper extends $DashboardMapper {}
