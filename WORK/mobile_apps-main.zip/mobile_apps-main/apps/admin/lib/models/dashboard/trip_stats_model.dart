import 'package:freezed_annotation/freezed_annotation.dart';

part 'trip_stats_model.freezed.dart';

@freezed
abstract class TripStatsModel with _$TripStatsModel {
  const factory TripStatsModel({
    required int planned,
    required int ongoing,
    required int completed,
    required int cancelled,
    required int total,
    required String period,
  }) = _TripStatsModel;
}
