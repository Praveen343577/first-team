class LoginRequestDto {
  final String username;
  final String password;
  final String grantType;
  final String scope;
  final String clientId;
  final String clientSecret;

  const LoginRequestDto({
    required this.username,
    required this.password,
    this.grantType = 'password',
    this.scope = '',
    this.clientId = 'string',
    this.clientSecret = '',
  });
}
