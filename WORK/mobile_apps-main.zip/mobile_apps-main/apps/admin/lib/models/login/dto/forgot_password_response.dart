class ForgotPasswordResponse {
  final String message;
  final String? token;

  ForgotPasswordResponse({required this.message, this.token});

  factory ForgotPasswordResponse.fromJson(Map<String, dynamic> json) =>
      ForgotPasswordResponse(
        message: json['message'] as String,
        token: json['token'] as String?,
      );
}
