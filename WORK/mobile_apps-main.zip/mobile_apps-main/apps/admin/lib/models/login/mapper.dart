import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:admin/models/login/dto/login_response_dto.dart';
import 'package:admin/models/login/mapper.auto_mappr.dart';
import 'package:admin/models/token/auth_token.dart';

@AutoMappr([MapType<LoginResponseDto, AuthToken>()])
class AuthMapper extends $AuthMapper {}
