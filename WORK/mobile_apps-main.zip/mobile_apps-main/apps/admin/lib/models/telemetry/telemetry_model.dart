import 'package:freezed_annotation/freezed_annotation.dart';

part 'telemetry_model.freezed.dart';

@freezed
abstract class TelemetryModel with _$TelemetryModel {
  const factory TelemetryModel({
    required String ts,
    required String deviceId,
    required String vehicleRegNo,
    required double latitude,
    required double longitude,
    required double speed,
    required double odometer,
    required double heading,
    required double altitude,
    int? ignition,
    int? mainPowerStatus,
    double? mainInputVoltage,
    double? internalBatteryVoltage,
    int? gsmStrength,
    String? operatorName,
    int? gpsFix,
    int? noOfSatellites,
  }) = _TelemetryModel;
}
