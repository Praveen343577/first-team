import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:admin/models/telemetry/dto/telemetry_history_response_dto.dart';
import 'package:admin/models/telemetry/mapper.auto_mappr.dart';
import 'package:admin/models/telemetry/telemetry_model.dart';

@AutoMappr([MapType<TelemetryHistoryResponseDto, TelemetryModel>()])
class TelemetryMapper extends $TelemetryMapper {}
