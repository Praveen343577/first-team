import 'package:freezed_annotation/freezed_annotation.dart';

part 'telemetry_history_response_dto.freezed.dart';
part 'telemetry_history_response_dto.g.dart';

double _toDouble(dynamic v) => (v as num).toDouble();
double? _toDoubleOrNull(dynamic v) => v == null ? null : (v as num).toDouble();

@Freezed(toJson: false)
abstract class TelemetryHistoryResponseDto with _$TelemetryHistoryResponseDto {
  const factory TelemetryHistoryResponseDto({
    required String ts,
    @JsonKey(name: 'device_id') required String deviceId,
    required String imei,
    @JsonKey(name: 'vehicle_reg_no') required String vehicleRegNo,
    @JsonKey(name: 'vendor_id') String? vendorId,
    String? version,
    @JsonKey(name: 'packet_type') String? packetType,
    @JsonKey(name: 'packet_status') String? packetStatus,
    @JsonKey(name: 'alert_id') String? alertId,
    @JsonKey(name: 'frame_number') String? frameNumber,
    String? header,
    String? nmr,
    @JsonKey(name: 'digital_input_status') int? digitalInputStatus,
    @JsonKey(name: 'digital_output_status') int? digitalOutputStatus,
    @JsonKey(name: 'analog_input_1') int? analogInput1,
    @JsonKey(name: 'analog_input_2') int? analogInput2,
    @JsonKey(name: 'odometer', fromJson: _toDouble) required double odometer,
    @JsonKey(name: 'speed', fromJson: _toDouble) required double speed,
    @JsonKey(name: 'heading', fromJson: _toDouble) required double heading,
    @JsonKey(name: 'altitude', fromJson: _toDouble) required double altitude,
    @JsonKey(name: 'latitude', fromJson: _toDouble) required double latitude,
    @JsonKey(name: 'longitude', fromJson: _toDouble) required double longitude,
    @JsonKey(name: 'gps_fix') int? gpsFix,
    @JsonKey(name: 'no_of_satellites') int? noOfSatellites,
    @JsonKey(name: 'pdop', fromJson: _toDoubleOrNull) double? pdop,
    @JsonKey(name: 'hdop', fromJson: _toDoubleOrNull) double? hdop,
    int? ignition,
    @JsonKey(name: 'emergency_status') int? emergencyStatus,
    @JsonKey(name: 'temper_alert') String? temperAlert,
    @JsonKey(name: 'main_power_status') int? mainPowerStatus,
    @JsonKey(name: 'main_input_voltage', fromJson: _toDoubleOrNull)
    double? mainInputVoltage,
    @JsonKey(name: 'internal_battery_voltage', fromJson: _toDoubleOrNull)
    double? internalBatteryVoltage,
    @JsonKey(name: 'operator') String? operatorName,
    @JsonKey(name: 'gsm_strength') int? gsmStrength,
    String? mcc,
    String? mnc,
    String? lac,
    @JsonKey(name: 'cell_id') String? cellId,
    @JsonKey(name: 'debug_info') String? debugInfo,
    @JsonKey(name: 'extra_data') dynamic extraData,
    @JsonKey(name: 'can_data') Map<String, dynamic>? canData,
  }) = _TelemetryHistoryResponseDto;

  factory TelemetryHistoryResponseDto.fromJson(Map<String, dynamic> json) =>
      _$TelemetryHistoryResponseDtoFromJson(json);
}
