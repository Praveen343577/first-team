class TelemetryHistoryRequestDto {
  final String deviceId;
  final String startTime;
  final String endTime;

  const TelemetryHistoryRequestDto({
    required this.deviceId,
    required this.startTime,
    required this.endTime,
  });
}
