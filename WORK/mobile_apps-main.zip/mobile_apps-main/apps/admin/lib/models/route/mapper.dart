import 'package:admin/models/route/dto/route_list_response_dto.dart';
import 'package:admin/models/route/dto/route_response_dto.dart';
import 'package:admin/models/route/dto/route_stop_response_dto.dart';
import 'package:admin/models/route/route_model.dart';
import 'package:admin/models/route/route_stop_model.dart';

class RouteMapper {
  RouteModel fromDto(RouteItemDto dto) {
    return RouteModel(
      id: dto.id,
      name: dto.name,
      fleetId: dto.fleetId,
      createdBy: dto.createdBy,
      isActive: dto.isActive,
      createdAt: dto.createdAt ?? DateTime.now(),
      stops: dto.stops.map(_mapStop).toList(),
    );
  }

  RouteStopModel _mapStop(RouteStopItemDto dto) {
    return RouteStopModel(
      id: dto.id,
      routeId: dto.routeId,
      stopOrder: dto.stopOrder,
      latitude: dto.latitude,
      longitude: dto.longitude,
      stopName: dto.stopName,
      stopType: dto.stopType,
      expectedArrivalOffsetMinutes: dto.expectedArrivalOffsetMinutes,
      expectedDepartureOffsetMinutes: dto.expectedDepartureOffsetMinutes,
      createdAt: dto.createdAt ?? DateTime.now(),
    );
  }

  RouteModel fromResponseDto(RouteResponseDto dto) {
    return RouteModel(
      id: dto.id,
      name: dto.name,
      fleetId: dto.fleetId,
      createdBy: dto.createdBy,
      isActive: dto.isActive,
      createdAt: dto.createdAt ?? DateTime.now(),
      stops: dto.stops.map(_mapResponseStop).toList(),
    );
  }

  RouteStopModel _mapResponseStop(RouteStopResponseDto dto) {
    return RouteStopModel(
      id: dto.id,
      routeId: dto.routeId,
      stopOrder: dto.stopOrder,
      latitude: dto.latitude,
      longitude: dto.longitude,
      stopName: dto.stopName,
      stopType: dto.stopType,
      expectedArrivalOffsetMinutes: dto.expectedArrivalOffsetMinutes,
      expectedDepartureOffsetMinutes: dto.expectedDepartureOffsetMinutes,
      createdAt: dto.createdAt ?? DateTime.now(),
    );
  }
}
