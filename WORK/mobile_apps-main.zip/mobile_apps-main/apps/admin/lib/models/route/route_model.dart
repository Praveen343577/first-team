import 'package:admin/models/route/route_stop_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'route_model.freezed.dart';

@freezed
abstract class RouteModel with _$RouteModel {
  const factory RouteModel({
    required String id,
    required String name,
    required String fleetId,
    String? createdBy,
    required bool isActive,
    required DateTime createdAt,
    required List<RouteStopModel> stops,
    String? polyline,
    double? totalDistance,
    double? totalDuration,
  }) = _RouteModel;
}
