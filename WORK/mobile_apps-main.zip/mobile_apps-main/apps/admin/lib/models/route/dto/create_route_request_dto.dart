import 'package:freezed_annotation/freezed_annotation.dart';

part 'create_route_request_dto.freezed.dart';
part 'create_route_request_dto.g.dart';

@freezed
abstract class CreateRouteRequestDto with _$CreateRouteRequestDto {
  const factory CreateRouteRequestDto({
    required String name,
    @JsonKey(name: 'fleet_id') required String fleetId,
    @JsonKey(name: 'vehicle_id') String? vehicleId,
    @JsonKey(name: 'driver_id') String? driverId,
    @JsonKey(name: 'trip_type') String? tripType,
    required List<CreateRouteStopRequestDto> stops,
  }) = _CreateRouteRequestDto;

  factory CreateRouteRequestDto.fromJson(Map<String, dynamic> json) =>
      _$CreateRouteRequestDtoFromJson(json);
}

@freezed
abstract class CreateRouteStopRequestDto with _$CreateRouteStopRequestDto {
  const factory CreateRouteStopRequestDto({
    @JsonKey(name: 'stop_order') required int stopOrder,
    required double latitude,
    required double longitude,
    @JsonKey(name: 'stop_name') required String stopName,
    @JsonKey(name: 'expected_arrival_offset_minutes')
    required int expectedArrivalOffsetMinutes,
    @JsonKey(name: 'expected_departure_offset_minutes')
    required int expectedDepartureOffsetMinutes,
    @JsonKey(name: 'stop_type') required String stopType,
  }) = _CreateRouteStopRequestDto;

  factory CreateRouteStopRequestDto.fromJson(Map<String, dynamic> json) =>
      _$CreateRouteStopRequestDtoFromJson(json);
}
