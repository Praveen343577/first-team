import 'package:freezed_annotation/freezed_annotation.dart';

part 'route_stop_response_dto.freezed.dart';
part 'route_stop_response_dto.g.dart';

@Freezed(toJson: false)
abstract class RouteStopResponseDto with _$RouteStopResponseDto {
  const factory RouteStopResponseDto({
    required String id,
    @JsonKey(name: 'route_id') required String routeId,
    @JsonKey(name: 'stop_order') required int stopOrder,
    required double latitude,
    required double longitude,
    @JsonKey(name: 'stop_name') required String stopName,
    @JsonKey(name: 'stop_type') String? stopType,
    @JsonKey(name: 'expected_arrival_offset_minutes')
    int? expectedArrivalOffsetMinutes,
    @JsonKey(name: 'expected_departure_offset_minutes')
    int? expectedDepartureOffsetMinutes,
    @JsonKey(name: 'created_at') DateTime? createdAt,
  }) = _RouteStopResponseDto;

  factory RouteStopResponseDto.fromJson(Map<String, dynamic> json) =>
      _$RouteStopResponseDtoFromJson(json);
}
