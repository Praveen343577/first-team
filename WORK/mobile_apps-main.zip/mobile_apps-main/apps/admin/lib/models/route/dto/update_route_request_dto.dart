import 'package:admin/models/route/dto/create_route_request_dto.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'update_route_request_dto.freezed.dart';
part 'update_route_request_dto.g.dart';

@freezed
abstract class UpdateRouteRequestDto with _$UpdateRouteRequestDto {
  const factory UpdateRouteRequestDto({
    required String name,
    required List<CreateRouteStopRequestDto> stops,
  }) = _UpdateRouteRequestDto;

  factory UpdateRouteRequestDto.fromJson(Map<String, dynamic> json) =>
      _$UpdateRouteRequestDtoFromJson(json);
}
