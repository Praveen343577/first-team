import 'package:admin/models/route/dto/route_stop_response_dto.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'route_response_dto.freezed.dart';
part 'route_response_dto.g.dart';

@Freezed(toJson: false)
abstract class RouteResponseDto with _$RouteResponseDto {
  const factory RouteResponseDto({
    required String id,
    required String name,
    @JsonKey(name: 'fleet_id') required String fleetId,
    @JsonKey(name: 'created_by') String? createdBy,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'created_at') DateTime? createdAt,
    @Default([]) List<RouteStopResponseDto> stops,
  }) = _RouteResponseDto;

  factory RouteResponseDto.fromJson(Map<String, dynamic> json) =>
      _$RouteResponseDtoFromJson(json);
}
