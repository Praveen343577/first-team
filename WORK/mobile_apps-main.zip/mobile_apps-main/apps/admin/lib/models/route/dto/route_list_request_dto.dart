import 'package:freezed_annotation/freezed_annotation.dart';

part 'route_list_request_dto.freezed.dart';

@freezed
abstract class RouteListRequestDto with _$RouteListRequestDto {
  const factory RouteListRequestDto({
    @JsonKey(name: 'fleet_id') String? fleetId,
    String? search,
    @Default(0) int skip,
    @Default(100) int limit,
  }) = _RouteListRequestDto;
}
