import 'package:freezed_annotation/freezed_annotation.dart';

part 'route_stop_model.freezed.dart';

@freezed
abstract class RouteStopModel with _$RouteStopModel {
  const factory RouteStopModel({
    required String id,
    required String routeId,
    required int stopOrder,
    required double latitude,
    required double longitude,
    required String stopName,
    String? stopType,
    int? expectedArrivalOffsetMinutes,
    int? expectedDepartureOffsetMinutes,
    required DateTime createdAt,
  }) = _RouteStopModel;
}
