import 'package:freezed_annotation/freezed_annotation.dart';

part 'route_list_response_dto.freezed.dart';
part 'route_list_response_dto.g.dart';

@Freezed(toJson: false)
abstract class RouteListResponseDto with _$RouteListResponseDto {
  const factory RouteListResponseDto({
    required int total,
    @Default([]) List<RouteItemDto> items,
  }) = _RouteListResponseDto;

  factory RouteListResponseDto.fromJson(Map<String, dynamic> json) =>
      _$RouteListResponseDtoFromJson(json);
}

@Freezed(toJson: false)
abstract class RouteItemDto with _$RouteItemDto {
  const factory RouteItemDto({
    required String id,
    required String name,
    @JsonKey(name: 'fleet_id') required String fleetId,
    @JsonKey(name: 'created_by') String? createdBy,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'created_at') DateTime? createdAt,
    @Default([]) List<RouteStopItemDto> stops,
  }) = _RouteItemDto;

  factory RouteItemDto.fromJson(Map<String, dynamic> json) =>
      _$RouteItemDtoFromJson(json);
}

@Freezed(toJson: false)
abstract class RouteStopItemDto with _$RouteStopItemDto {
  const factory RouteStopItemDto({
    required String id,
    @JsonKey(name: 'route_id') required String routeId,
    @JsonKey(name: 'stop_order') required int stopOrder,
    required double latitude,
    required double longitude,
    @JsonKey(name: 'stop_name') required String stopName,
    @JsonKey(name: 'stop_type') String? stopType,
    @JsonKey(name: 'expected_arrival_offset_minutes')
    int? expectedArrivalOffsetMinutes,
    @JsonKey(name: 'expected_departure_offset_minutes')
    int? expectedDepartureOffsetMinutes,
    @JsonKey(name: 'created_at') DateTime? createdAt,
  }) = _RouteStopItemDto;

  factory RouteStopItemDto.fromJson(Map<String, dynamic> json) =>
      _$RouteStopItemDtoFromJson(json);
}
