class DirectionsResult {
  final String polyline;
  final double totalDistanceKm;
  final double totalDurationMinutes;

  DirectionsResult({
    required this.polyline,
    required this.totalDistanceKm,
    required this.totalDurationMinutes,
  });
}
