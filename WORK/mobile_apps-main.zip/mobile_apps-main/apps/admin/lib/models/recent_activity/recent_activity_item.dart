import 'package:hive/hive.dart';

class RecentActivityItem extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String type; // 'route', 'vehicle', 'driver', 'fleet'

  @HiveField(2)
  final String title;

  @HiveField(3)
  final String? subtitle;

  @HiveField(4)
  final DateTime viewedAt;

  RecentActivityItem({
    required this.id,
    required this.type,
    required this.title,
    this.subtitle,
    required this.viewedAt,
  });
}

class RecentActivityItemAdapter extends TypeAdapter<RecentActivityItem> {
  @override
  final int typeId = 0;

  @override
  RecentActivityItem read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{};
    for (var i = 0; i < numOfFields; i++) {
      final key = reader.readByte();
      final value = reader.read();
      fields[key] = value;
    }
    return RecentActivityItem(
      id: fields[0] as String,
      type: fields[1] as String,
      title: fields[2] as String,
      subtitle: fields[3] as String?,
      viewedAt: fields[4] as DateTime,
    );
  }

  @override
  void write(BinaryWriter writer, RecentActivityItem obj) {
    writer
      ..writeByte(5) // number of fields
      ..writeByte(0)
      ..write(obj.id)
      ..writeByte(1)
      ..write(obj.type)
      ..writeByte(2)
      ..write(obj.title)
      ..writeByte(3)
      ..write(obj.subtitle)
      ..writeByte(4)
      ..write(obj.viewedAt);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RecentActivityItemAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
