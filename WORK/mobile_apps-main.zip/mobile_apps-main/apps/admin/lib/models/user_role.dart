enum UserRole { manager, admin }

class AppRoleState {
  static UserRole currentRole = UserRole.admin;

  static bool get isAdmin => currentRole == UserRole.admin;
  static bool get isManager => currentRole == UserRole.manager;
}
