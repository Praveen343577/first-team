import 'package:freezed_annotation/freezed_annotation.dart';

part 'driver_scorecard_response_dto.freezed.dart';
part 'driver_scorecard_response_dto.g.dart';

@freezed
abstract class DriverScorecardResponseDto with _$DriverScorecardResponseDto {
  const factory DriverScorecardResponseDto({
    @JsonKey(name: 'driver_id') required String driverId,
    @JsonKey(name: 'driver_name') required String driverName,
    @JsonKey(name: 'driver_email') required String driverEmail,
    @JsonKey(name: 'current_period') required String currentPeriod,
    @JsonKey(name: 'rating_score') required double ratingScore,
    @JsonKey(name: 'total_trips') required int totalTrips,
    @JsonKey(name: 'completed_trips') required int completedTrips,
    @JsonKey(name: 'completion_rate') required double completionRate,
    @JsonKey(name: 'on_time_delivery_rate') required double onTimeDeliveryRate,
    @JsonKey(name: 'total_distance_km') required double totalDistanceKm,
    @JsonKey(name: 'avg_speed') required double avgSpeed,
    @JsonKey(name: 'total_runtime_hours') required double totalRuntimeHours,
    @JsonKey(name: 'harsh_braking_count') required int harshBrakingCount,
    @JsonKey(name: 'harsh_acceleration_count') required int harshAccelerationCount,
    @JsonKey(name: 'overspeed_count') required int overspeedCount,
    @JsonKey(name: 'safety_score') required double safetyScore,
    @JsonKey(name: 'idle_time_minutes') required double idleTimeMinutes,
    @JsonKey(name: 'idle_time_percentage') required double idleTimePercentage,
  }) = _DriverScorecardResponseDto;

  factory DriverScorecardResponseDto.fromJson(Map<String, dynamic> json) =>
      _$DriverScorecardResponseDtoFromJson(json);
}
