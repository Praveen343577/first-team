import 'package:freezed_annotation/freezed_annotation.dart';

part 'driver_list_response_dto.freezed.dart';
part 'driver_list_response_dto.g.dart';

@Freezed(toJson: false)
abstract class DriverListResponseDto with _$DriverListResponseDto {
  const factory DriverListResponseDto({
    required String id,
    required String email,
    @JsonKey(name: 'full_name') required String fullName,
    String? mobile,
    required String role,
    @JsonKey(name: 'fleet_id') String? fleetId,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'is_staff') required bool isStaff,
    @JsonKey(name: 'is_superuser') required bool isSuperuser,
    @JsonKey(name: 'created_at') DateTime? createdAt,
    @JsonKey(name: 'updated_at') DateTime? updatedAt,
  }) = _DriverListResponseDto;

  factory DriverListResponseDto.fromJson(Map<String, dynamic> json) =>
      _$DriverListResponseDtoFromJson(json);
}
