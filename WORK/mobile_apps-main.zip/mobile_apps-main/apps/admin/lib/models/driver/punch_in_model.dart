import 'package:freezed_annotation/freezed_annotation.dart';

part 'punch_in_model.freezed.dart';

@freezed
abstract class PunchInModel with _$PunchInModel {
  const factory PunchInModel({
    required String id,
    required String driverId,
    required String date,
    required String punchInTime,
    String? punchOutTime,
    required DateTime createdAt,
  }) = _PunchInModel;
}
