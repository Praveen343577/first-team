import 'package:freezed_annotation/freezed_annotation.dart';

part 'driver_model.freezed.dart';

@freezed
abstract class DriverModel with _$DriverModel {
  const factory DriverModel({
    required String id,
    required String email,
    required String fullName,
    String? mobile,
    required String role,
    String? fleetId,
    required bool isActive,
    String? profilePicUrl,
    String? dob,
    String? bloodGroup,
    String? address,
    String? emergencyContactNumber,
    String? emergencyContactName,
    required bool isStaff,
    required bool isSuperuser,
    required DateTime createdAt,
    DateTime? updatedAt,
    List<dynamic>? permissions,
  }) = _DriverModel;
}
