import 'package:freezed_annotation/freezed_annotation.dart';

part 'driver_profile_response_dto.freezed.dart';
part 'driver_profile_response_dto.g.dart';

@freezed
abstract class DriverProfileResponseDto with _$DriverProfileResponseDto {
  const factory DriverProfileResponseDto({
    required String id,
    required String email,
    @JsonKey(name: 'full_name') required String fullName,
    String? mobile,
    required String role,
    @JsonKey(name: 'fleet_id') String? fleetId,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'profile_pic_url') String? profilePicUrl,
    String? dob,
    @JsonKey(name: 'blood_group') String? bloodGroup,
    String? address,
    @JsonKey(name: 'emergency_contact_number') String? emergencyContactNumber,
    @JsonKey(name: 'emergency_contact_name') String? emergencyContactName,
    @JsonKey(name: 'is_staff') required bool isStaff,
    @JsonKey(name: 'is_superuser') required bool isSuperuser,
    @JsonKey(name: 'created_at') DateTime? createdAt,
    @JsonKey(name: 'updated_at') DateTime? updatedAt,
    List<dynamic>? permissions,
  }) = _DriverProfileResponseDto;

  factory DriverProfileResponseDto.fromJson(Map<String, dynamic> json) =>
      _$DriverProfileResponseDtoFromJson(json);
}
