import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:admin/models/driver/assign_driver_model.dart';
import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/models/driver/punch_in_model.dart';
import 'package:admin/models/driver/dto/assign_driver_response_dto.dart';
import 'package:admin/models/driver/dto/driver_list_response_dto.dart';
import 'package:admin/models/driver/dto/driver_profile_response_dto.dart';
import 'package:admin/models/driver/dto/punch_in_response_dto.dart';
import 'package:admin/models/driver/mapper.auto_mappr.dart';

@AutoMappr([
  MapType<DriverListResponseDto, DriverModel>(
    fields: [Field('createdAt', custom: DriverMapper.mapCreatedAt)],
  ),
  MapType<DriverProfileResponseDto, DriverModel>(
    fields: [Field('createdAt', custom: DriverMapper.mapCreatedAt)],
  ),
  MapType<AssignDriverResponseDto, AssignDriverModel>(),
  MapType<PunchInResponseDto, PunchInModel>(
    fields: [Field('createdAt', custom: DriverMapper.mapCreatedAt)],
  ),
])
class DriverMapper extends $DriverMapper {
  static DateTime mapCreatedAt(dynamic dto) => dto.createdAt ?? DateTime.now();

  PunchInModel mapPunchInResponseDtoToPunchInModel(PunchInResponseDto dto) {
    return PunchInModel(
      id: dto.id,
      driverId: dto.driverId,
      date: dto.date,
      punchInTime: dto.punchInTime,
      punchOutTime: dto.punchOutTime,
      createdAt: dto.createdAt ?? DateTime.now(),
    );
  }
}
