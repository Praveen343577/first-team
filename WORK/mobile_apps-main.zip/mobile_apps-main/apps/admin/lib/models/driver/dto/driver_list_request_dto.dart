import 'package:freezed_annotation/freezed_annotation.dart';

part 'driver_list_request_dto.freezed.dart';

@freezed
abstract class DriverListRequestDto with _$DriverListRequestDto {
  const factory DriverListRequestDto({
    @Default(0) int skip,
    @Default(100) int limit,
    String? search,
    @JsonKey(name: 'sort_by') String? sortBy,
    @JsonKey(name: 'sort_order') String? sortOrder,
  }) = _DriverListRequestDto;
}
