import 'package:freezed_annotation/freezed_annotation.dart';

part 'create_driver_profile_request_dto.freezed.dart';
part 'create_driver_profile_request_dto.g.dart';

@freezed
abstract class CreateDriverProfileRequestDto
    with _$CreateDriverProfileRequestDto {
  const factory CreateDriverProfileRequestDto({
    required String email,
    @JsonKey(name: 'full_name') required String fullName,
    required String mobile,
    required String role,
    @JsonKey(name: 'fleet_id') required String fleetId,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'profile_pic_url') required String profilePicUrl,
    required String dob,
    @JsonKey(name: 'blood_group') required String bloodGroup,
    required String address,
    @JsonKey(name: 'emergency_contact_number') required String emergencyContactNumber,
    @JsonKey(name: 'emergency_contact_name') required String emergencyContactName,
    required String password,
  }) = _CreateDriverProfileRequestDto;

  factory CreateDriverProfileRequestDto.fromJson(Map<String, dynamic> json) =>
      _$CreateDriverProfileRequestDtoFromJson(json);
}
