import 'package:freezed_annotation/freezed_annotation.dart';

part 'punch_out_request_dto.freezed.dart';
part 'punch_out_request_dto.g.dart';

@freezed
abstract class PunchOutRequestDto with _$PunchOutRequestDto {
  const factory PunchOutRequestDto({
    @JsonKey(name: 'driver_id') required String driverId,
    required String date,
  }) = _PunchOutRequestDto;

  factory PunchOutRequestDto.fromJson(Map<String, dynamic> json) =>
      _$PunchOutRequestDtoFromJson(json);
}
