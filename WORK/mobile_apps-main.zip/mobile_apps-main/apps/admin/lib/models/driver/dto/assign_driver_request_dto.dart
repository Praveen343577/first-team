import 'package:freezed_annotation/freezed_annotation.dart';

part 'assign_driver_request_dto.freezed.dart';
part 'assign_driver_request_dto.g.dart';

@freezed
abstract class AssignDriverRequestDto with _$AssignDriverRequestDto {
  const factory AssignDriverRequestDto({
    @JsonKey(name: 'driver_id') required String driverId,
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    @JsonKey(name: 'assigned_date') required String assignedDate,
  }) = _AssignDriverRequestDto;

  factory AssignDriverRequestDto.fromJson(Map<String, dynamic> json) =>
      _$AssignDriverRequestDtoFromJson(json);
}
