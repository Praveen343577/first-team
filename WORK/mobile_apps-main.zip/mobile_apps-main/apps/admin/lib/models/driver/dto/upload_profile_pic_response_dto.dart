import 'package:freezed_annotation/freezed_annotation.dart';

part 'upload_profile_pic_response_dto.freezed.dart';
part 'upload_profile_pic_response_dto.g.dart';

@freezed
abstract class UploadProfilePicResponseDto with _$UploadProfilePicResponseDto {
  const factory UploadProfilePicResponseDto({
    @JsonKey(name: 'profile_pic_url') required String profilePicUrl,
  }) = _UploadProfilePicResponseDto;

  factory UploadProfilePicResponseDto.fromJson(Map<String, dynamic> json) =>
      _$UploadProfilePicResponseDtoFromJson(json);
}
