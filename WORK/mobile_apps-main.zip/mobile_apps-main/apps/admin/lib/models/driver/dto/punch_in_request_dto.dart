import 'package:freezed_annotation/freezed_annotation.dart';

part 'punch_in_request_dto.freezed.dart';
part 'punch_in_request_dto.g.dart';

@freezed
abstract class PunchInRequestDto with _$PunchInRequestDto {
  const factory PunchInRequestDto({
    @JsonKey(name: 'driver_id') required String driverId,
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    required String date,
  }) = _PunchInRequestDto;

  factory PunchInRequestDto.fromJson(Map<String, dynamic> json) =>
      _$PunchInRequestDtoFromJson(json);
}
