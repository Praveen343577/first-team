import 'package:freezed_annotation/freezed_annotation.dart';

part 'assign_driver_response_dto.freezed.dart';
part 'assign_driver_response_dto.g.dart';

@freezed
abstract class AssignDriverResponseDto with _$AssignDriverResponseDto {
  const factory AssignDriverResponseDto({
    required String id,
    @JsonKey(name: 'driver_id') required String driverId,
    @JsonKey(name: 'vehicle_id') required String vehicleId,
    @JsonKey(name: 'assigned_date') required String assignedDate,
    @JsonKey(name: 'created_at') required DateTime createdAt,
  }) = _AssignDriverResponseDto;

  factory AssignDriverResponseDto.fromJson(Map<String, dynamic> json) =>
      _$AssignDriverResponseDtoFromJson(json);
}
