import 'package:freezed_annotation/freezed_annotation.dart';

part 'punch_in_response_dto.freezed.dart';
part 'punch_in_response_dto.g.dart';

@freezed
abstract class PunchInResponseDto with _$PunchInResponseDto {
  const factory PunchInResponseDto({
    required String id,
    @JsonKey(name: 'driver_id') required String driverId,
    required String date,
    @JsonKey(name: 'punch_in_time') required String punchInTime,
    @JsonKey(name: 'punch_out_time') String? punchOutTime,
    @JsonKey(name: 'created_at') DateTime? createdAt,
  }) = _PunchInResponseDto;

  factory PunchInResponseDto.fromJson(Map<String, dynamic> json) =>
      _$PunchInResponseDtoFromJson(json);
}
