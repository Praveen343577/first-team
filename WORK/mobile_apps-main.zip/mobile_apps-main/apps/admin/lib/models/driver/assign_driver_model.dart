import 'package:freezed_annotation/freezed_annotation.dart';

part 'assign_driver_model.freezed.dart';

@freezed
abstract class AssignDriverModel with _$AssignDriverModel {
  const factory AssignDriverModel({
    required String id,
    required String driverId,
    required String vehicleId,
    required String assignedDate,
    required DateTime createdAt,
  }) = _AssignDriverModel;
}
