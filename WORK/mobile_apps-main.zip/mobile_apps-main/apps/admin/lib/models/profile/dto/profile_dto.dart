import 'package:admin/models/driver/driver_model.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'profile_dto.freezed.dart';
part 'profile_dto.g.dart';

@Freezed(toJson: false)
abstract class ProfileDTO with _$ProfileDTO {
  const factory ProfileDTO({
    required String email,
    @JsonKey(name: 'full_name') required String fullName,
    String? mobile,
    required String id,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'is_staff') required bool isStaff,
    @JsonKey(name: 'is_superuser') required bool isSuperuser,
    @JsonKey(name: 'date_joined') String? dateJoined,
    @JsonKey(name: 'last_login') String? lastLogin,
    @JsonKey(name: 'updated_at') String? updatedAt,
    String? role,
    required List<String> permissions,
    required List<String> groups,
  }) = _ProfileDTO;

  factory ProfileDTO.fromJson(Map<String, dynamic> json) =>
      _$ProfileDTOFromJson(json);

  factory ProfileDTO.fromDriverModel(DriverModel driver) => ProfileDTO(
        id: driver.id,
        email: driver.email,
        fullName: driver.fullName,
        mobile: driver.mobile,
        isActive: driver.isActive,
        isStaff: false,
        isSuperuser: false,
        permissions: [],
        groups: [],
      );
}
