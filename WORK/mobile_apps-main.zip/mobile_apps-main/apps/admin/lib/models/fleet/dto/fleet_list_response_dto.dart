import 'package:freezed_annotation/freezed_annotation.dart';

part 'fleet_list_response_dto.freezed.dart';
part 'fleet_list_response_dto.g.dart';

@Freezed(toJson: false)
abstract class FleetListResponseDto with _$FleetListResponseDto {
  const factory FleetListResponseDto({
    required String id,
    required String name,
    @JsonKey(name: 'company_name') String? companyName,
    @JsonKey(name: 'created_by') String? createdBy,
    @JsonKey(name: 'created_at') String? createdAt,
    @JsonKey(name: 'updated_at') String? updatedAt,
  }) = _FleetListResponseDto;

  factory FleetListResponseDto.fromJson(Map<String, dynamic> json) =>
      _$FleetListResponseDtoFromJson(json);
}
