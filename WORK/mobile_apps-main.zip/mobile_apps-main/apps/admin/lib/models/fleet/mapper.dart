import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'package:admin/models/fleet/dto/fleet_list_response_dto.dart';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/models/fleet/mapper.auto_mappr.dart';

@AutoMappr([MapType<FleetListResponseDto, FleetModel>()])
class FleetMapper extends $FleetMapper {}
