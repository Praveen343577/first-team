class FleetListRequestDto {
  final int skip;
  final int limit;

  const FleetListRequestDto({this.skip = 0, this.limit = 100});
}
