import 'package:freezed_annotation/freezed_annotation.dart';

part 'fleet_model.freezed.dart';

@freezed
abstract class FleetModel with _$FleetModel {
  const factory FleetModel({
    required String id,
    required String name,
    String? companyName,
    String? createdBy,
    String? createdAt,
    String? updatedAt,
  }) = _FleetModel;
}
