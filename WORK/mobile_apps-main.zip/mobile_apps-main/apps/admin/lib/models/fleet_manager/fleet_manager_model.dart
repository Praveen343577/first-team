import 'package:freezed_annotation/freezed_annotation.dart';

part 'fleet_manager_model.freezed.dart';

@freezed
abstract class FleetManagerModel with _$FleetManagerModel {
  const factory FleetManagerModel({
    required String id,
    required String email,
    required String fullName,
    String? mobile,
    String? role,
    String? fleetId,
    @Default(true) bool isActive,
    String? profilePicUrl,
    String? dob,
    String? bloodGroup,
    String? address,
    String? emergencyContactNumber,
    String? emergencyContactName,
  }) = _FleetManagerModel;
}
