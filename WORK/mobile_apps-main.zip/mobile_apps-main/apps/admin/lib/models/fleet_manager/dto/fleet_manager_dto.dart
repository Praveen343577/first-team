import 'package:freezed_annotation/freezed_annotation.dart';

part 'fleet_manager_dto.freezed.dart';
part 'fleet_manager_dto.g.dart';

@freezed
abstract class FleetManagerDto with _$FleetManagerDto {
  const factory FleetManagerDto({
    required String id,
    required String email,
    @JsonKey(name: 'full_name') required String fullName,
    String? mobile,
    String? role,
    @JsonKey(name: 'fleet_id') String? fleetId,
    @JsonKey(name: 'is_active') required bool isActive,
    @JsonKey(name: 'profile_pic_url') String? profilePicUrl,
    String? dob,
    @JsonKey(name: 'blood_group') String? bloodGroup,
    String? address,
    @JsonKey(name: 'emergency_contact_number') String? emergencyContactNumber,
    @JsonKey(name: 'emergency_contact_name') String? emergencyContactName,
  }) = _FleetManagerDto;

  factory FleetManagerDto.fromJson(Map<String, dynamic> json) =>
      _$FleetManagerDtoFromJson(json);
}
