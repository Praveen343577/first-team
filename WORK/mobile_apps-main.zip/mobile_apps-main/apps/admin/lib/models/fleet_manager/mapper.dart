import 'package:admin/models/fleet_manager/dto/fleet_manager_dto.dart';
import 'package:admin/models/fleet_manager/fleet_manager_model.dart';
import 'package:auto_mappr_annotation/auto_mappr_annotation.dart';
import 'mapper.auto_mappr.dart';

@AutoMappr([
  MapType<FleetManagerDto, FleetManagerModel>(),
])
class FleetManagerMapper extends $FleetManagerMapper {}
