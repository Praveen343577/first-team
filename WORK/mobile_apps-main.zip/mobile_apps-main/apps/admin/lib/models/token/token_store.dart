import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:injectable/injectable.dart';

@LazySingleton()
class TokenStore extends ChangeNotifier {
  final _storage = const FlutterSecureStorage();

  String? _token;
  String? refreshToken;
  String? get token => _token;

  Future<void> saveToken(String token, String refreshToken) async {
    _token = token;
    this.refreshToken = refreshToken;
    await _storage.write(key: 'token', value: token);
    await _storage.write(key: 'refreshToken', value: refreshToken);
    notifyListeners();
  }

  Future<void> loadToken() async {
    _token = await _storage.read(key: 'token');
    refreshToken = await _storage.read(key: 'refreshToken');
    notifyListeners();
  }

  Future<void> clear() async {
    _token = null;
    refreshToken = null;
    await _storage.delete(key: 'token');
    await _storage.delete(key: 'refreshToken');
    notifyListeners();
  }
}
