import 'package:dio/dio.dart';

class DioModule {
  Dio dio([String? baseUrl]) {
    final dio = Dio(
      BaseOptions(
        baseUrl: baseUrl ?? '',
        connectTimeout: const Duration(seconds: 30),
        receiveTimeout: const Duration(seconds: 30),
        contentType: "application/json",
        headers: {"accept": "application/json"},
      ),
    );

    return dio;
  }
}
