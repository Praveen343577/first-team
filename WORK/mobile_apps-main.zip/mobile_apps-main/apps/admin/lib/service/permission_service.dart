import 'package:geolocator/geolocator.dart';
import 'package:injectable/injectable.dart';
import 'dart:developer' as dev;

@lazySingleton
class PermissionService {
  /// Requests location permission and returns true if granted.
  /// Handles service status, permission status, and exceptions.
  Future<bool> requestLocationPermission() async {
    try {
      // 1. Check if location services are enabled
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        dev.log('Location services are disabled.');
        // Optional: Show a dialog to enable service if needed
        return false;
      }

      // 2. Check current permission status
      LocationPermission permission = await Geolocator.checkPermission();
      
      if (permission == LocationPermission.denied) {
        // 3. Request permission
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          dev.log('Location permissions are denied.');
          return false;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        dev.log('Location permissions are permanently denied.');
        // User needs to enable it from settings
        return false;
      }

      // 4. Permission is granted (whileInUse or always)
      return true;
    } catch (e, stack) {
      dev.log(
        'Exception while requesting location permission',
        error: e,
        stackTrace: stack,
      );
      return false;
    }
  }

  /// Checks if location permission is already granted without requesting.
  Future<bool> hasLocationPermission() async {
    try {
      final permission = await Geolocator.checkPermission();
      return permission == LocationPermission.always ||
          permission == LocationPermission.whileInUse;
    } catch (e) {
      return false;
    }
  }
}
