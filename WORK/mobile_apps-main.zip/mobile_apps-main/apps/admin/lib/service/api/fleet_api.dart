import 'package:dio/dio.dart';
import 'package:admin/models/fleet/dto/fleet_list_response_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'fleet_api.g.dart';

@RestApi()
abstract class FleetApi {
  factory FleetApi(@Named('authDio') Dio dio) = _FleetApi;

  @GET('/fleets/')
  Future<List<FleetListResponseDto>> getFleets(
    @Query('skip') int skip,
    @Query('limit') int limit,
  );

  @GET('/fleets/{id}')
  Future<FleetListResponseDto> getFleetDetails(@Path('id') String id);
}
