import 'package:dio/dio.dart';
import 'package:admin/models/dashboard/dto/fleet_status_response_dto.dart';
import 'package:admin/models/dashboard/dto/distance_chart_response_dto.dart';
import 'package:admin/models/dashboard/dto/sustainability_response_dto.dart';
import 'package:admin/models/dashboard/dto/trip_stats_response_dto.dart';
import 'package:admin/models/dashboard/dto/vehicle_status_map_response_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'dashboard_api.g.dart';

@RestApi()
abstract class DashboardApi {
  factory DashboardApi(@Named('authDio') Dio dio, {String baseUrl}) = _DashboardApi;

  @GET('/dashboard/fleet-status')
  Future<FleetStatusResponseDto> getFleetStatus();

  @GET('/dashboard/distance-chart')
  Future<DistanceChartResponseDto> getDistanceChart(
    @Query('period') String period,
  );

  @GET('/dashboard/sustainability')
  Future<SustainabilityResponseDto> getSustainability();

  @GET('/dashboard/trip-stats')
  Future<TripStatsResponseDto> getTripStats(
    @Query('period') String period,
  );

  @GET('/dashboard/vehicle-status-map')
  Future<VehicleStatusMapResponseDto> getVehicleStatusMap(
    @Query('cluster_distance_km') double clusterDistanceKm,
  );
}
