import 'package:dio/dio.dart';
import 'package:admin/models/driver/dto/assign_driver_request_dto.dart';
import 'package:admin/models/driver/dto/assign_driver_response_dto.dart';
import 'package:admin/models/driver/dto/create_driver_profile_request_dto.dart';
import 'package:admin/models/driver/dto/driver_list_response_dto.dart';
import 'package:admin/models/driver/dto/driver_profile_response_dto.dart';
import 'package:admin/models/driver/dto/punch_in_request_dto.dart';
import 'package:admin/models/driver/dto/punch_in_response_dto.dart';
import 'package:admin/models/driver/dto/punch_out_request_dto.dart';
import 'package:admin/models/driver/dto/upload_profile_pic_response_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'driver_api.g.dart';

@RestApi()
abstract class DriverApi {
  factory DriverApi(@Named('authDio') Dio dio) = _DriverApi;

  @POST('/drivers/')
  Future<DriverProfileResponseDto> createDriverProfile(
    @Body() CreateDriverProfileRequestDto request,
  );

  @GET('/drivers/{driverId}')
  Future<DriverProfileResponseDto> getDriverProfile(
    @Path('driverId') String driverId,
  );

  @PUT('/drivers/{driverId}')
  Future<DriverProfileResponseDto> updateDriverProfile(
    @Path('driverId') String driverId,
    @Body() CreateDriverProfileRequestDto request,
  );

  @GET('/drivers/')
  Future<List<DriverListResponseDto>> getDrivers(
    @Query('skip') int skip,
    @Query('limit') int limit,
    @Query('search') String? search,
    @Query('sort_by') String? sortBy,
    @Query('sort_order') String? sortOrder,
  );

  @POST('/drivers/assign-driver')
  Future<AssignDriverResponseDto> assignDriver(
    @Body() AssignDriverRequestDto request,
  );

  @POST('/drivers/punch-in')
  Future<PunchInResponseDto> punchIn(@Body() PunchInRequestDto request);

  @POST('/drivers/punch-out')
  Future<PunchInResponseDto> punchOut(@Body() PunchOutRequestDto request);

  @POST('/drivers/upload-profile-pic')
  @MultiPart()
  Future<UploadProfilePicResponseDto> uploadProfilePic(
    @Part(name: 'driver_id') String driverId,
    @Part(name: 'file') MultipartFile file,
  );

  @DELETE('/drivers/{driverId}')
  Future<void> deleteDriver(@Path('driverId') String driverId);
}
