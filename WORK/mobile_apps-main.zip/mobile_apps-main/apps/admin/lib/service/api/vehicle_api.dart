import 'package:dio/dio.dart';
import 'package:admin/models/vehicle/dto/vehicle_list_response_dto.dart';
import 'package:admin/models/vehicle/dto/aggregated_vehicle_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'vehicle_api.g.dart';

@RestApi()
abstract class VehicleApi {
  factory VehicleApi(@Named('authDio') Dio dio, {String baseUrl}) = _VehicleApi;

  @GET('/vehicles/')
  Future<List<VehicleListResponseDto>> getVehicles(
    @Query('fleet_id') String? fleetId,
  );

  @GET('/vehicles/aggregated')
  Future<List<AggregatedVehicleDto>> getAggregatedVehicles(
    @Query('fleet_id') String? fleetId,
  );
}
