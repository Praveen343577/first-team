import 'package:dio/dio.dart';
import 'package:admin/models/login/dto/login_response_dto.dart';
import 'package:admin/models/refresh/refresh_token_request_dto.dart';
import 'package:admin/models/register/dto/register_request_dto.dart';
import 'package:admin/models/login/dto/forgot_password_request.dart';
import 'package:admin/models/login/dto/forgot_password_response.dart';
import 'package:admin/models/login/dto/reset_password_request.dart';
import 'package:admin/models/login/dto/reset_password_response.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';
part 'auth_api.g.dart';

@RestApi()
abstract class AuthApi {
  factory AuthApi(@Named('noAuthDio') Dio dio) = _AuthApi;

  @POST('/auth/login')
  @FormUrlEncoded()
  Future<LoginResponseDto> login(
    @Field('grant_type') String grantType,
    @Field('username') String username,
    @Field('password') String password,
    @Field('scope') String scope,
    @Field('client_id') String clientId,
    @Field('client_secret') String clientSecret,
  );
  @POST('/auth/refresh')
  Future<LoginResponseDto> refreshToken(@Body() RefreshTokenRequestDto request);
  @POST('/auth/register')
  Future<LoginResponseDto> register(
    @Body() RegisterRequestDto request,
    @Query('role') String role,
  );
  @POST('/auth/forgot-password')
  Future<ForgotPasswordResponse> forgotPassword(@Body() ForgotPasswordRequest request);
  @POST('/auth/reset-password')
  Future<ResetPasswordResponse> resetPassword(@Body() ResetPasswordRequest request);
}
