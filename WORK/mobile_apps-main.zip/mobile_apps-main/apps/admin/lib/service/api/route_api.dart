import 'package:admin/models/route/dto/create_route_request_dto.dart';
import 'package:admin/models/route/dto/route_list_response_dto.dart';
import 'package:admin/models/route/dto/route_response_dto.dart';
import 'package:admin/models/route/dto/update_route_request_dto.dart';
import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'route_api.g.dart';

@RestApi()
abstract class RouteApi {
  factory RouteApi(@Named('authDio') Dio dio, {String baseUrl}) = _RouteApi;

  @GET('/routes/')
  Future<RouteListResponseDto> getRoutes(
    @Query('fleet_id') String? fleetId,
    @Query('search') String? search,
    @Query('skip') int skip,
    @Query('limit') int limit,
  );

  @POST('/routes/')
  Future<RouteResponseDto> createRoute(@Body() CreateRouteRequestDto request);

  @PUT('/routes/{id}')
  Future<RouteResponseDto> updateRoute(
    @Path('id') String id,
    @Body() UpdateRouteRequestDto request,
  );

  @DELETE('/routes/{id}')
  Future<void> deleteRoute(@Path('id') String id);
}
