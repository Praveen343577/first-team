import 'package:dio/dio.dart';
import 'package:admin/models/profile/dto/profile_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'client_api.g.dart';

@RestApi()
abstract class ClientApi {
  factory ClientApi(@Named('authDio') Dio dio) = _ClientApi;

  @GET('/users/me')
  Future<ProfileDTO> getMe();
}
