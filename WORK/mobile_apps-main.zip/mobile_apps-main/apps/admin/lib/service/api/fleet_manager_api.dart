import 'package:admin/models/fleet_manager/dto/fleet_manager_dto.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

part 'fleet_manager_api.g.dart';

@RestApi()
abstract class FleetManagerApi {
  factory FleetManagerApi(Dio dio, {String baseUrl}) = _FleetManagerApi;

  @GET('/fleet-managers/')
  Future<List<FleetManagerDto>> getFleetManagers({
    @Query('skip') int skip = 0,
    @Query('limit') int limit = 100,
    @Query('sort_by') String sortBy = 'created_at',
    @Query('sort_order') String sortOrder = 'desc',
  });

  @GET('/fleet-managers/{id}')
  Future<FleetManagerDto> getFleetManagerDetails(@Path('id') String id);
}
