import 'package:dio/dio.dart';
import 'package:admin/models/telemetry/dto/telemetry_history_response_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'telemetry_api.g.dart';

@RestApi()
abstract class TelemetryApi {
  factory TelemetryApi(@Named('authDio') Dio dio, {String baseUrl}) =
      _TelemetryApi;

  @GET('/telemetry/{device_id}/history')
  Future<List<TelemetryHistoryResponseDto>> getHistory(
    @Path('device_id') String deviceId,
    @Query('start_time') String startTime,
    @Query('end_time') String endTime,
  );
}
