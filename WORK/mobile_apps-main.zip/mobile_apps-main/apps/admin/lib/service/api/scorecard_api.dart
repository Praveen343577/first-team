import 'package:dio/dio.dart';
import 'package:admin/models/driver/dto/driver_scorecard_response_dto.dart';
import 'package:injectable/injectable.dart';
import 'package:retrofit/retrofit.dart';

part 'scorecard_api.g.dart';

@RestApi()
abstract class ScorecardApi {
  factory ScorecardApi(@Named('authDio') Dio dio, {String baseUrl}) = _ScorecardApi;

  @GET('/drivers/{driverId}/scorecard')
  Future<DriverScorecardResponseDto> getScorecard(
    @Path('driverId') String driverId,
    @Query('period') String period,
  );
}
