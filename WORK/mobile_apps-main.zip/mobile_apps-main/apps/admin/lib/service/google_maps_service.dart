import 'package:admin/models/directions_result.dart';
import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';

abstract class GoogleMapsService {
  Future<List<Map<String, dynamic>>> searchPlaces(String query);
  Future<Map<String, dynamic>?> getPlaceDetails(String placeId);
  Future<DirectionsResult?> getDirections(List<dynamic> points);
}

@LazySingleton(as: GoogleMapsService)
class GoogleMapsServiceImpl implements GoogleMapsService {
  final Dio _dio;
  final String _apiKey;

  GoogleMapsServiceImpl(
    @Named('noAuthDio') this._dio,
    @Named('GOOGLE_MAPS_API_KEY') this._apiKey,
  );

  @override
  Future<List<Map<String, dynamic>>> searchPlaces(String query) async {
    try {
      final response = await _dio.get(
        'https://maps.googleapis.com/maps/api/place/autocomplete/json',
        queryParameters: {
          'input': query,
          'key': _apiKey,
        },
      );

      if (response.data['status'] == 'OK') {
        return List<Map<String, dynamic>>.from(response.data['predictions']);
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  @override
  Future<Map<String, dynamic>?> getPlaceDetails(String placeId) async {
    try {
      final response = await _dio.get(
        'https://maps.googleapis.com/maps/api/place/details/json',
        queryParameters: {
          'place_id': placeId,
          'key': _apiKey,
        },
      );

      if (response.data['status'] == 'OK') {
        return response.data['result'];
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  @override
  Future<DirectionsResult?> getDirections(List<dynamic> points) async {
    if (points.length < 2) return null;

    try {
      final origin = points.first;
      final destination = points.last;
      String waypoints = '';
      if (points.length > 2) {
        waypoints = 'optimize:true|';
        for (int i = 1; i < points.length - 1; i++) {
          waypoints += '${points[i].latitude},${points[i].longitude}|';
        }
      }

      final response = await _dio.get(
        'https://maps.googleapis.com/maps/api/directions/json',
        queryParameters: {
          'origin': '${origin.latitude},${origin.longitude}',
          'destination': '${destination.latitude},${destination.longitude}',
          if (waypoints.isNotEmpty) 'waypoints': waypoints,
          'key': _apiKey,
        },
      );

      if (response.data['status'] == 'OK') {
        final route = response.data['routes'][0];
        final polyline = route['overview_polyline']['points'];
        final legs = List<Map<String, dynamic>>.from(route['legs']);

        double totalDistance = 0;
        double totalDuration = 0;

        for (var leg in legs) {
          totalDistance += (leg['distance']['value'] as num).toDouble();
          totalDuration += (leg['duration']['value'] as num).toDouble();
        }

        return DirectionsResult(
          polyline: polyline,
          totalDistanceKm: totalDistance / 1000,
          totalDurationMinutes: totalDuration / 60,
        );
      }
      return null;
    } catch (e) {
      return null;
    }
  }
}
