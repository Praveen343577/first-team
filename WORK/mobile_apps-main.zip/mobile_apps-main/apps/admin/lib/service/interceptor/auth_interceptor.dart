import 'package:dio/dio.dart';
import 'package:admin/models/token/token_store.dart';

class AuthInterceptor extends Interceptor {
  final TokenStore tokenStore;

  AuthInterceptor(this.tokenStore);

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    if (tokenStore.token != null) {
      options.headers['Authorization'] = 'Bearer ${tokenStore.token}';
    }

    handler.next(options);
  }
}
