import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:admin/models/refresh/refresh_token_request_dto.dart';
import 'package:admin/models/token/token_store.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/ui/common/widgets/eka_snack_bar.dart';

class TokenExpirationInterceptor extends Interceptor {
  final TokenStore tokenStore;
  final AuthRepository repository;
  final Dio dio;

  TokenExpirationInterceptor({
    required this.repository,
    required this.tokenStore,
    required this.dio,
  });

  // Cached future to handle concurrent 401 requests without duplicate refresh calls.
  Future<String?>? _refreshTokenFuture;

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) async {
    final statusCode = err.response?.statusCode;
    final isRetry = err.requestOptions.extra['retry'] == true;

    debugPrint('[TokenExpirationInterceptor] onError: statusCode=$statusCode, isRetry=$isRetry, path=${err.requestOptions.path}');

    if (statusCode == 401 && !isRetry) {
      debugPrint('[TokenExpirationInterceptor] 401 detected, attempting to refresh token...');
      try {
        final newToken = await _refreshToken();
        debugPrint('[TokenExpirationInterceptor] Token refresh completed. New token is null: ${newToken == null}');

        if (newToken != null) {
          final requestOptions = err.requestOptions;
          requestOptions.headers['Authorization'] = 'Bearer $newToken';
          requestOptions.extra['retry'] = true;
          
          debugPrint('[TokenExpirationInterceptor] Retrying request: ${requestOptions.path}');
          final response = await dio.fetch(requestOptions);
          return handler.resolve(response);
        }
      } catch (e, stack) {
        debugPrint('[TokenExpirationInterceptor] Exception during token refresh: $e\n$stack');
      }
    }
    handler.next(err);
  }

  Future<String?> _refreshToken() async {
    if (_refreshTokenFuture != null) {
      debugPrint('[TokenExpirationInterceptor] Token refresh already in progress, awaiting existing future.');
      return _refreshTokenFuture;
    }

    _refreshTokenFuture = () async {
      try {
        await tokenStore.loadToken();
        final refreshToken = tokenStore.refreshToken;
        debugPrint('[TokenExpirationInterceptor] _refreshToken: refreshToken has value: ${refreshToken != null && refreshToken.isNotEmpty}');

        if (refreshToken == null || refreshToken.isEmpty) return null;

        final response = await repository.refreshToken(
          RefreshTokenRequestDto(refreshToken: refreshToken),
        );

        return response.accessToken;
      } finally {
        _refreshTokenFuture = null;
      }
    }();

    return _refreshTokenFuture;
  }
}
