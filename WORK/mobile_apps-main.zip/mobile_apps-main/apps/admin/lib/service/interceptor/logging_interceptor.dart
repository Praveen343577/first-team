import 'package:dio/dio.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:logger/logger.dart';

class LoggingInterceptor extends Interceptor {
  final Logger _logger;

  LoggingInterceptor(this._logger);

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    FirebaseCrashlytics.instance.log('HTTP REQUEST: ${options.method} ${options.uri}');
    _logger.i('''
┌──────────────────────── REQUEST ────────────────────────
│ ${options.method} ${options.uri}
│ Headers: ${options.headers}
│ Query: ${options.queryParameters}
│ Body: ${options.data}
└─────────────────────────────────────────────────────────
''');

    handler.next(options);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    FirebaseCrashlytics.instance.log('HTTP RESPONSE: [${response.statusCode}] ${response.requestOptions.method} ${response.requestOptions.uri}');
    _logger.i('''
┌──────────────────────── RESPONSE ───────────────────────
│ ${response.requestOptions.method} ${response.requestOptions.uri}
│ Status: ${response.statusCode}
│ Data: ${response.data}
└────────────────────────────────────────────────────────
''');

    handler.next(response);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    FirebaseCrashlytics.instance.log('HTTP ERROR: [${err.response?.statusCode}] ${err.requestOptions.method} ${err.requestOptions.uri}');
    FirebaseCrashlytics.instance.recordError(err, err.stackTrace, fatal: false);
    _logger.e('''
┌──────────────────────── ERROR ──────────────────────────
│ ${err.requestOptions.method} ${err.requestOptions.uri}
│ Type: ${err.type}
│ Message: ${err.message}
│ Status: ${err.response?.statusCode}
│ Response: ${err.response?.data}
└────────────────────────────────────────────────────────
''');

    handler.next(err);
  }
}
