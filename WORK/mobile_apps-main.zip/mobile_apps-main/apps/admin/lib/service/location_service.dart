import 'package:admin/models/directions_result.dart';
import 'package:admin/service/permission_service.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:injectable/injectable.dart';

@singleton
class LocationService {
  final PermissionService _permissionService;

  LatLng _currentLocation = const LatLng(20.5937, 78.9629); // Default to India
  LatLng get currentLocation => _currentLocation;

  bool _isLocationReady = false;
  bool get isLocationReady => _isLocationReady;

  LocationService(this._permissionService);

  @postConstruct
  Future<void> init() async {
    final granted = await _permissionService.requestLocationPermission();
    if (granted) {
      try {
        // Try to get last known position first for speed
        final lastPosition = await Geolocator.getLastKnownPosition();
        if (lastPosition != null) {
          _currentLocation = LatLng(
            lastPosition.latitude,
            lastPosition.longitude,
          );
          _isLocationReady = true;
        }

        // Get fresh position in background
        final position = await Geolocator.getCurrentPosition(
          locationSettings: LocationSettings(
            accuracy: LocationAccuracy.bestForNavigation,
          ),
        );
        _currentLocation = LatLng(position.latitude, position.longitude);
        _isLocationReady = true;
      } catch (e) {
        // Keep default or last known if error
      }
    }
  }

  /// Manually refresh location
  Future<void> refreshLocation() async {
    if (await _permissionService.hasLocationPermission()) {
      try {
        final position = await Geolocator.getCurrentPosition();
        _currentLocation = LatLng(position.latitude, position.longitude);
        _isLocationReady = true;
      } catch (e) {
        // Handle error
      }
    }
  }

  /// Calculates a straight-line distance between points for quick estimation.
  DirectionsResult calculatePathDistance(List<LatLng> points) {
    double totalDistance = 0;
    for (int i = 0; i < points.length - 1; i++) {
      totalDistance += Geolocator.distanceBetween(
        points[i].latitude,
        points[i].longitude,
        points[i + 1].latitude,
        points[i + 1].longitude,
      );
    }

    final distanceKm = totalDistance / 1000;
    // Estimate duration assuming 40 km/h average speed
    final durationMinutes = (distanceKm / 40) * 60;

    return DirectionsResult(
      polyline: '', // No polyline for rough estimation
      totalDistanceKm: distanceKm,
      totalDurationMinutes: durationMinutes,
    );
  }
}
