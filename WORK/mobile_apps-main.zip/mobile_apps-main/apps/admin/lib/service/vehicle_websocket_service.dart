import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:injectable/injectable.dart';
import 'package:web_socket_channel/web_socket_channel.dart';

@lazySingleton
class VehicleWebSocketService {
  final String _deviceBaseUrl;
  WebSocketChannel? _channel;
  final _messageController = StreamController<dynamic>.broadcast();

  VehicleWebSocketService(@Named('DEVICE_BASE_URL') this._deviceBaseUrl);

  String get _wsUrl {
    final uri = Uri.parse(_deviceBaseUrl);
    final scheme = uri.scheme == 'https' ? 'wss' : 'ws';
    final path = uri.path.endsWith('/') ? '${uri.path}ws/vehicles' : '${uri.path}/ws/vehicles';
    return uri.replace(scheme: scheme, path: path).toString();
  }

  Stream<dynamic> get messages => _messageController.stream;

  Future<void> connect({
    required String token,
    String? fleetId,
    String? deviceId,
  }) async {
    try {
      final baseUri = Uri.parse(_wsUrl);
      final queryParams = <String, String>{
        'token': token,
      };
      if (fleetId != null) {
        queryParams['fleet_id'] = fleetId;
      }
      if (deviceId != null) {
        queryParams['device_id'] = deviceId;
      }
      final url = baseUri.replace(queryParameters: queryParams);
      _channel = WebSocketChannel.connect(url);

      // Listen to messages
      _channel!.stream.listen(
        (message) {
          _onMessage(message);
        },
        onError: (error) {
          _onError(error);
        },
        onDone: () {
          _onDone();
        },
      );
    } catch (e) {
      _onError(e);
    }
  }

  void sendMessage(dynamic message) {
    if (_channel != null) {
      _channel!.sink.add(message);
    }
  }

  void disconnect() {
    _channel?.sink.close();
    _channel = null;
  }

  bool get isConnected => _channel != null;

  void _onMessage(dynamic message) {
    debugPrint('WebSocket message received: $message');
    _messageController.add(message);
  }

  void _onError(dynamic error) {
    debugPrint('WebSocket error: $error');
    _messageController.addError(error);
  }

  void _onDone() {
    debugPrint('WebSocket connection closed');
  }
}
