import 'package:dio/dio.dart';
import 'package:admin/models/token/token_store.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/service/api/auth_api.dart';
import 'package:admin/service/api/dashboard_api.dart';
import 'package:admin/service/api/driver_api.dart';
import 'package:admin/service/api/scorecard_api.dart';
import 'package:admin/service/api/fleet_api.dart';
import 'package:admin/service/api/route_api.dart';
import 'package:admin/service/api/telemetry_api.dart';
import 'package:admin/service/api/vehicle_api.dart';
import 'package:admin/service/api/fleet_manager_api.dart';
import 'package:admin/service/dio_module.dart';
import 'package:admin/service/interceptor/auth_interceptor.dart';
import 'package:admin/service/interceptor/token_expiration_interceptor.dart';
import 'package:admin/service/interceptor/logging_interceptor.dart';
import 'package:injectable/injectable.dart';
import 'package:logger/logger.dart';
import 'package:ticket/ticket.dart';

import 'api/client_api.dart';

@module
abstract class ApiModule {
  @lazySingleton
  @Named('authDio')
  Dio dio(
    AuthInterceptor authInterceptor,
    LoggingInterceptor interceptor,
    TokenExpirationInterceptor exceptionInterceptor,
    @Named('BASE_URL') String baseUrl,
  ) {
    final dio = DioModule().dio(baseUrl);
    dio.interceptors.addAll([
      authInterceptor,
      interceptor,
      exceptionInterceptor,
    ]);
    return dio;
  }

  @Named('noAuthDio')
  Dio noAuthdio(
    LoggingInterceptor interceptor,
    @Named('BASE_URL') String baseUrl,
  ) {
    final dio = DioModule().dio(baseUrl);
    dio.interceptors.add(interceptor);
    return dio;
  }

  @lazySingleton
  AuthInterceptor authInterceptor(TokenStore storage) =>
      AuthInterceptor(storage);
  @lazySingleton
  TokenExpirationInterceptor exceptionInterceptor(
    AuthRepository repo,
    TokenStore token,
    @Named('noAuthDio') Dio dio,
  ) =>
      TokenExpirationInterceptor(
        repository: repo,
        tokenStore: token,
        dio: dio,
      );

  @lazySingleton
  LoggingInterceptor loggingInterceptor(Logger logger) =>
      LoggingInterceptor(logger);
  @lazySingleton
  Logger logger() => Logger(
    printer: PrettyPrinter(
      methodCount: 0,
      errorMethodCount: 5,
      lineLength: 120,
      colors: true,
      printEmojis: true,
    ),
  );

  @lazySingleton
  AuthApi authApi(@Named('noAuthDio') Dio dio) => AuthApi(dio);

  @lazySingleton
  ClientApi profileApi(@Named('authDio') Dio dio) => ClientApi(dio);

  @lazySingleton
  TicketApi ticketApi(@Named('authDio') Dio dio) => TicketApi(dio);

  @lazySingleton
  DriverApi driverApi(@Named('authDio') Dio dio) => DriverApi(dio);

  @lazySingleton
  ScorecardApi scorecardApi(
    @Named('authDio') Dio dio,
    @Named('DEVICE_BASE_URL') String baseUrl,
  ) => ScorecardApi(dio, baseUrl: baseUrl);

  @lazySingleton
  FleetApi fleetApi(@Named('authDio') Dio dio) => FleetApi(dio);

  @lazySingleton
  VehicleApi vehicleApi(
    @Named('authDio') Dio dio,
    @Named('DEVICE_BASE_URL') String baseUrl,
  ) => VehicleApi(dio, baseUrl: baseUrl);

  @lazySingleton
  TelemetryApi telemetryApi(
    @Named('authDio') Dio dio,
    @Named('DEVICE_BASE_URL') String baseUrl,
  ) => TelemetryApi(dio, baseUrl: baseUrl);

  @lazySingleton
  RouteApi routeApi(
    @Named('authDio') Dio dio,
    @Named('DEVICE_BASE_URL') String baseUrl,
  ) => RouteApi(dio, baseUrl: baseUrl);

  @lazySingleton
  FleetManagerApi fleetManagerApi(
    @Named('authDio') Dio dio,
    @Named('BASE_URL') String baseUrl,
  ) => FleetManagerApi(dio, baseUrl: baseUrl);

  @lazySingleton
  DashboardApi dashboardApi(
    @Named('authDio') Dio dio,
    @Named('DEVICE_BASE_URL') String baseUrl,
  ) => DashboardApi(dio, baseUrl: baseUrl);
}
