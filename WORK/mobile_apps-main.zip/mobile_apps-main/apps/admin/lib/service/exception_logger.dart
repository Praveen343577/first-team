import 'dart:developer' as developer;
import 'package:dio/dio.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class ExceptionLogger {
  void logException(dynamic e, [StackTrace? stackTrace]) {
    FirebaseCrashlytics.instance.recordError(e, stackTrace, fatal: false);

    if (e is DioException) {
      final response = e.response;
      final statusCode = response?.statusCode;
      final data = response?.data;
      final message = e.message;

      developer.log(
        'DIO_EXCEPTION [$statusCode]: $message',
        name: 'API_ERROR',
        error: e,
        stackTrace: stackTrace,
      );

      if (data != null) {
        developer.log('RESPONSE_DATA: $data', name: 'API_ERROR');
      }
    } else {
      developer.log(
        'UNHANDLED_EXCEPTION: ${e.toString()}',
        name: 'RUNTIME_ERROR',
        error: e,
        stackTrace: stackTrace,
      );
    }
  }
}
