import 'package:admin/di/service_locator.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:admin/repository/fleet_manager_repository.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/ui/driver/cubit/driver_list_cubit.dart';
import 'package:admin/ui/driver/cubit/create_driver_profile_cubit.dart';
import 'package:admin/ui/driver/cubit/get_fleet_cubit.dart';
import 'package:admin/ui/driver/ui/screens/driver/driver_list_screen.dart';
import 'package:admin/ui/driver/ui/screens/driver/create_driver_profile_screen.dart';
import 'package:admin/ui/users/cubit/fleet_manager_list_cubit.dart';
import 'package:admin/ui/users/ui/fleet_manager_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class UsersManagementScreen extends StatefulWidget {
  const UsersManagementScreen({super.key});

  @override
  State<UsersManagementScreen> createState() => _UsersManagementScreenState();
}

class _UsersManagementScreenState extends State<UsersManagementScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _activeTab = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) return;
      setState(() {
        _activeTab = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _navigateToCreateDriver(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => CreateDriverProfileCubit(
                authRepository: getIt<AuthRepository>(),
                driverRepository: getIt<DriverRepository>(),
              ),
            ),
            BlocProvider(
              create: (context) => GetFleetCubit(
                fleetRepository: getIt<FleetRepository>(),
              )..load(),
            ),
          ],
          child: const CreateDriverProfileScreen(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("User Management"),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Fleet Managers'),
            Tab(text: 'Drivers'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          BlocProvider(
            create: (context) => FleetManagerListCubit(
              getIt<FleetManagerRepository>(),
            )..load(),
            child: const FleetManagerListScreen(useScaffold: false),
          ),
          BlocProvider(
            create: (context) => DriverListCubit(
              getIt<DriverRepository>(),
            )..load(),
            child: const DriverListScreen(useScaffold: false),
          ),
        ],
      ),
      floatingActionButton: _activeTab == 1
          ? FloatingActionButton.extended(
              onPressed: () => _navigateToCreateDriver(context),
              label: const Text('Add Driver'),
              icon: const Icon(Icons.add),
            )
          : null,
    );
  }
}
