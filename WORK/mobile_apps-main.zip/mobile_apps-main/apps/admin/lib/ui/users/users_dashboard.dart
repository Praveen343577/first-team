import 'package:admin/ui/driver/ui/screens/routes/dashboard_base.dart';
import 'package:admin/ui/driver/ui/widgets/detailed_navigation_card.dart';
import 'package:admin/ui/users/users_management_screen.dart';
import 'package:flutter/material.dart';
import 'package:admin/ui/common/widgets/recent_activity_section.dart';

class UsersDashboard extends DashboardBase {
  @override
  Tab get tab => const Tab(icon: Icon(Icons.people), text: 'Users');

  const UsersDashboard({super.key})
      : super(
          title: "Users",
          description: "Monitor and manage your personnel and drivers.",
        );

  @override
  Widget buildStickyHeader(BuildContext context) => DetailedNavigationCard(
        title: 'Users',
        subtitle: 'Manage fleet managers and drivers',
        onTap: () {
          Navigator.of(context, rootNavigator: true).push(
            MaterialPageRoute(
              builder: (context) => const UsersManagementScreen(),
            ),
          );
        },
        leadingIcon: Icons.people,
      );

  @override
  List<Widget> buildContent(BuildContext context) => [
        const Padding(
          padding: EdgeInsets.all(16.0),
          child: RecentActivitySection(filterTypes: ['driver', 'fleet_manager']), // Added fleet manager and driver as users
        ),
      ];
}
