import 'package:admin/models/fleet_manager/fleet_manager_model.dart';
import 'package:admin/repository/fleet_manager_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class FleetManagerDetailCubit extends BaseCubit<FleetManagerModel> {
  final FleetManagerRepository _repository;
  final String managerId;

  FleetManagerDetailCubit(
    this._repository, {
    @factoryParam required this.managerId,
  });

  @override
  Future<FleetManagerModel> performSubmit() async {
    return await _repository.getFleetManagerDetails(managerId);
  }
}
