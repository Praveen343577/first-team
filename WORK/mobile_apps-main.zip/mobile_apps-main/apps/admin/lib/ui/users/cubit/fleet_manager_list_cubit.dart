import 'package:admin/models/fleet_manager/fleet_manager_model.dart';
import 'package:admin/repository/fleet_manager_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class FleetManagerListCubit extends FetchOnlyCubit<List<FleetManagerModel>>
    with SearchableCubit {
  final FleetManagerRepository _repository;

  FleetManagerListCubit(this._repository);

  String _searchQuery = '';

  @override
  String get searchQuery => _searchQuery;

  @override
  void setSearchQuery(String query) {
    _searchQuery = query;
    load();
  }

  @override
  Future<List<FleetManagerModel>> fetchData() async {
    final managers = await _repository.getFleetManagers();
    
    if (_searchQuery.isEmpty) return managers;
    
    return managers
        .where((m) => m.fullName.toLowerCase().contains(_searchQuery.toLowerCase()) || 
                      m.email.toLowerCase().contains(_searchQuery.toLowerCase()))
        .toList();
  }
}
