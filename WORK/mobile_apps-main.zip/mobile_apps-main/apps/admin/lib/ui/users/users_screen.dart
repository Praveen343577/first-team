import 'package:flutter/material.dart';

class UsersScreen extends StatelessWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('User Management'),
          bottom: const TabBar(
            tabs: [
              Tab(text: 'Fleet Managers'),
              Tab(text: 'Drivers'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            Center(child: Text('Manager Management Coming Soon')),
            Center(child: Text('Driver Roster Coming Soon')),
          ],
        ),
      ),
    );
  }
}
