import 'package:admin/di/service_locator.dart';
import 'package:admin/models/fleet_manager/fleet_manager_model.dart';
import 'package:admin/repository/fleet_manager_repository.dart';
import 'package:admin/ui/users/cubit/fleet_manager_detail_cubit.dart';
import 'package:admin/ui/users/cubit/fleet_manager_list_cubit.dart';
import 'package:admin/ui/users/ui/fleet_manager_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class FleetManagerListScreen
    extends SearchListScreen<FleetManagerListCubit, FleetManagerModel> {
  const FleetManagerListScreen({super.key, super.useScaffold = true});

  @override
  String get title => 'Fleet Managers';

  @override
  String get searchHint => 'Search managers…';

  @override
  EdgeInsets get itemPadding => AppPadding.gutter;

  @override
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No fleet managers found'));
  }

  @override
  Widget buildItem(BuildContext context, FleetManagerModel manager, int index) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => BlocProvider(
                create: (context) => FleetManagerDetailCubit(
                  getIt<FleetManagerRepository>(),
                  managerId: manager.id,
                ),
                child: const FleetManagerDetailScreen(),
              ),
            ),
          );
        },
        child: Padding(
          padding: AppPadding.p16,
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                child: Text(
                  manager.fullName.isNotEmpty ? manager.fullName[0].toUpperCase() : '?',
                  style: TextStyle(color: Theme.of(context).primaryColor),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      manager.fullName,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    Text(
                      manager.email,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    if (manager.mobile != null)
                      Text(
                        manager.mobile!,
                        style: Theme.of(context).textTheme.labelSmall,
                      ),
                  ],
                ),
              ),
              StatusBadge(
                status: manager.isActive ? Status.inprogress : Status.completed,
                label: manager.isActive ? 'Active' : 'Inactive',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final Status status;
  final String label;

  const StatusBadge({super.key, required this.status, required this.label});

  @override
  Widget build(BuildContext context) {
    final color = _getStatusColor(context, status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: 0.5)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Color _getStatusColor(BuildContext context, Status status) {
    switch (status) {
      case Status.inprogress:
        return Colors.green;
      case Status.completed:
        return Colors.grey;
      case Status.sceduled:
        return Colors.blue;
      case Status.cancelled:
        return Colors.red;
      case Status.delayed:
        return Colors.orange;
    }
  }
}
