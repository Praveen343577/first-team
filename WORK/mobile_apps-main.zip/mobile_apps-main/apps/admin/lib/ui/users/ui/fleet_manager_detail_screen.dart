import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/repository/recent_activity_repository.dart';
import 'package:admin/di/service_locator.dart';
import 'package:admin/models/fleet_manager/fleet_manager_model.dart';
import 'package:admin/ui/common/mixin/common_form_mixin.dart';
import 'package:admin/ui/users/cubit/fleet_manager_detail_cubit.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class FleetManagerDetailScreen
    extends FetchScreen<FleetManagerDetailCubit, FleetManagerModel>
    with CommonFormMixin {
  const FleetManagerDetailScreen({super.key});

  @override
  Widget buildSuccess(BuildContext context, FleetManagerModel manager) {
    // Record this fleet manager in recent activity
    getIt<RecentActivityRepository>().addItem(
      RecentActivityItem(
        id: manager.id,
        type: 'fleet_manager',
        title: manager.fullName,
        subtitle: manager.role ?? 'Fleet Manager',
        viewedAt: DateTime.now(),
      ),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text("Fleet Manager Details"),
      ),
      body: SingleChildScrollView(
        padding: AppPadding.p16,
        child: Column(
          children: [
            /// PROFILE HEADER
            CircleAvatar(
              radius: 50,
              backgroundColor: Theme.of(context).primaryColor.withValues(alpha: 0.1),
              backgroundImage: manager.profilePicUrl != null
                  ? NetworkImage(manager.profilePicUrl!)
                  : null,
              child: manager.profilePicUrl == null
                  ? Text(
                      manager.fullName.isNotEmpty
                          ? manager.fullName[0].toUpperCase()
                          : '?',
                      style: TextStyle(
                        fontSize: 32,
                        color: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    )
                  : null,
            ),
            const SizedBox(height: 16),
            Text(
              manager.fullName,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            Text(
              manager.email,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: 24),

            /// ACTION BUTTONS
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.call),
                    label: const Text("Call Manager"),
                    onPressed: manager.mobile != null
                        ? () => launchDialer(manager.mobile!)
                        : null,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.email_outlined),
                    label: const Text("Email"),
                    onPressed: () {}, // TODO: Implement email launch
                  ),
                ),
              ],
            ),

            const SizedBox(height: 24),

            /// BASIC INFO
            buildSectionCard(
              context: context,
              icon: Icons.person_outline,
              title: "Basic Information",
              children: [
                buildField(context, "FULL NAME", manager.fullName),
                buildField(context, "EMAIL", manager.email),
                buildField(context, "ROLE", manager.role ?? "Fleet Manager"),
                buildField(context, "BLOOD GROUP", manager.bloodGroup),
              ],
            ),

            const SizedBox(height: 16),

            /// CONTACT INFO
            buildSectionCard(
              context: context,
              icon: Icons.contact_phone_outlined,
              title: "Contact Information",
              children: [
                buildField(
                  context,
                  "PHONE NUMBER",
                  manager.mobile,
                  trailing: manager.mobile != null
                      ? IconButton(
                          icon: const Icon(Icons.call, size: 20),
                          onPressed: () => launchDialer(manager.mobile!),
                        )
                      : null,
                ),
                buildField(context, "ADDRESS", manager.address),
              ],
            ),

            const SizedBox(height: 16),

            /// EMERGENCY CONTACT
            if (manager.emergencyContactName != null ||
                manager.emergencyContactNumber != null)
              buildSectionCard(
                context: context,
                icon: Icons.health_and_safety_outlined,
                title: "Emergency Contact",
                children: [
                  buildField(
                    context,
                    "CONTACT NAME",
                    manager.emergencyContactName,
                  ),
                  buildField(
                    context,
                    "PHONE NUMBER",
                    manager.emergencyContactNumber,
                    trailing: manager.emergencyContactNumber != null
                        ? IconButton(
                            icon: const Icon(Icons.call, size: 20),
                            onPressed: () =>
                                launchDialer(manager.emergencyContactNumber!),
                          )
                        : null,
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget buildField(
    BuildContext context,
    String label,
    String? value, {
    Widget? trailing,
  }) {
    final cs = Theme.of(context).colorScheme;
    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: cs.onSurfaceVariant,
              ),
        ),
        const SizedBox(height: 4),
        Text(
          value ?? "-",
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
      ],
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(child: body),
          ?trailing,
        ],
      ),
    );
  }
}
