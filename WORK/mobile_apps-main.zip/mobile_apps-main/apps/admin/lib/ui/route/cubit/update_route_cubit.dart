import 'package:admin/models/route/route_model.dart';
import 'package:admin/ui/route/cubit/route_base_cubit.dart';

class UpdateRouteCubit extends RouteBaseCubit {
  final RouteModel route;

  UpdateRouteCubit(
    this.route,
    super.repository,
    super.locationService,
  ) : super(
          initialRoute: route,
          fleetId: route.fleetId,
        );

  @override
  Future<void> onSubmit() async {
    validateForm();
    await repository.updateRoute(route.id, getUpdateDto());
  }
}
