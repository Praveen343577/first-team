import 'package:admin/ui/route/cubit/route_base_cubit.dart';

class CreateRouteCubit extends RouteBaseCubit {
  CreateRouteCubit(
    super.repository,
    super.locationService, {
    super.fleetId,
    super.selectedFleet,
  });

  @override
  Future<void> onSubmit() async {
    validateForm();
    await repository.createRoute(getRequestDto());
  }
}
