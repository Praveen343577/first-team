import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/models/route/route_model.dart';

class CreateRouteFormBloc extends FormBloc<String, String> {
  final name = TextFieldBloc(
    name: 'Route Name',
    validators: [FieldBlocValidators.required],
  );

  final String? initialFleetId;
  final fleet = SelectFieldBloc<FleetModel, dynamic>(name: 'Fleet');

  final vehicle = TextFieldBloc(
    name: 'Vehicle',
    validators: [FieldBlocValidators.required],
  );
  final driver = TextFieldBloc(
    name: 'Driver',
    validators: [FieldBlocValidators.required],
  );
  final tripType = SelectFieldBloc<String, dynamic>(
    name: 'Trip Type',
    initialValue: 'Passenger',
  );

  final stops = ListFieldBloc<CreateRouteStopFormBloc, dynamic>(name: 'Stops');

  CreateRouteFormBloc({
    this.initialFleetId,
    FleetModel? selectedFleet,
    RouteModel? initialRoute,
  }) {
    addFieldBlocs(fieldBlocs: [
      name,
      fleet,
      vehicle,
      driver,
      tripType,
      stops,
    ]);

    if (selectedFleet != null) {
      fleet.updateItems([selectedFleet]);
      fleet.updateValue(selectedFleet);
    }

    if (initialRoute != null) {
      name.updateValue(initialRoute.name);
      // Prefill stops
      for (final stop in initialRoute.stops) {
        stops.addFieldBloc(
          CreateRouteStopFormBloc(stopType: stop.stopType ?? 'WAYPOINT')
            ..stopName.updateValue(stop.stopName)
            ..latitude.updateValue(stop.latitude.toString())
            ..longitude.updateValue(stop.longitude.toString())
            ..arrivalOffset.updateValue(
              (stop.expectedArrivalOffsetMinutes ?? 0).toString(),
            )
            ..departureOffset.updateValue(
              (stop.expectedDepartureOffsetMinutes ?? 0).toString(),
            ),
        );
      }
    } else {
      // Add initial start and end stops only if not prefilling
      _addInitialStop(stopType: 'START');
      _addInitialStop(stopType: 'END');
    }
  }

  void _addInitialStop({required String stopType}) {
    stops.addFieldBloc(CreateRouteStopFormBloc(stopType: stopType));
  }

  void addWaypoint() {
    if (stops.value.length < 7) {
      // 1 (START) + 5 (WAYPOINTS) + 1 (END) = 7
      // Insert before the last element (which is the END stop)
      stops.insertFieldBloc(
        CreateRouteStopFormBloc(stopType: 'WAYPOINT'),
        stops.value.length - 1,
      );
    }
  }

  void removeStop(int index) {
    if (stops.value.length > 2) {
      stops.removeFieldBlocAt(index);
    }
  }

  @override
  void onSubmitting() {
    // This will be handled by the Cubit
  }
}

class CreateRouteStopFormBloc extends GroupFieldBloc<FieldBloc, dynamic> {
  final String stopType;

  CreateRouteStopFormBloc({required this.stopType})
      : super(
          fieldBlocs: [
            TextFieldBloc(
              name: 'stopName',
              validators: [FieldBlocValidators.required],
            ),
            TextFieldBloc(
              name: 'latitude',
              validators: [FieldBlocValidators.required],
            ),
            TextFieldBloc(
              name: 'longitude',
              validators: [FieldBlocValidators.required],
            ),
            TextFieldBloc(
              name: 'arrivalOffset',
              validators: [FieldBlocValidators.required],
              initialValue: '0',
            ),
            TextFieldBloc(
              name: 'departureOffset',
              validators: [FieldBlocValidators.required],
              initialValue: '0',
            ),
          ],
        );

  TextFieldBloc get stopName =>
      state.fieldBlocs.values.elementAt(0) as TextFieldBloc;
  TextFieldBloc get latitude =>
      state.fieldBlocs.values.elementAt(1) as TextFieldBloc;
  TextFieldBloc get longitude =>
      state.fieldBlocs.values.elementAt(2) as TextFieldBloc;
  TextFieldBloc get arrivalOffset =>
      state.fieldBlocs.values.elementAt(3) as TextFieldBloc;
  TextFieldBloc get departureOffset =>
      state.fieldBlocs.values.elementAt(4) as TextFieldBloc;
}

