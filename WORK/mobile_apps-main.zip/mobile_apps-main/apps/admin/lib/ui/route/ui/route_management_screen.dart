import 'package:admin/di/service_locator.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/ui/driver/ui/screens/routes/dashboard_base.dart';
import 'package:admin/ui/driver/ui/screens/routes/route_list_screen.dart';
import 'package:admin/ui/route/cubit/route_list_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class RouteManagementScreen extends DashboardBase {
  @override
  Tab get tab => const Tab(icon: Icon(Icons.route), text: 'Routes');

  const RouteManagementScreen({super.key})
      : super(
          title: "Route Management",
          description: "Configure and monitor your service routes.",
        );

  @override
  bool get showHeader => false;

  @override
  Widget buildSingleContent(BuildContext context) => BlocProvider(
        create: (context) => RouteListCubit(
          getIt<RouteRepository>(),
        )..load(),
        child: const RouteListScreen(useScaffold: false),
      );
}
