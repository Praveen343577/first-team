import 'package:admin/models/route/route_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

enum RouteSortOption { nameAsc, nameDesc, newest, oldest }

@injectable
class RouteListCubit extends FetchOnlyCubit<List<RouteModel>>
    with SearchableCubit {
  final RouteRepository _repository;
  final String? fleetId;

  RouteListCubit(this._repository, {this.fleetId});

  String _searchQuery = '';
  RouteSortOption _sortOption = RouteSortOption.nameAsc;
  bool? _activeFilter;

  @override
  String get searchQuery => _searchQuery;
  RouteSortOption get sortOption => _sortOption;
  bool? get activeFilter => _activeFilter;

  @override
  void setSearchQuery(String query) {
    _searchQuery = query;
    load();
  }

  void updateFiltersAndSort({
    bool? activeFilter,
    RouteSortOption? sortOption,
    bool clearAll = false,
  }) {
    if (clearAll) {
      _activeFilter = null;
      _sortOption = RouteSortOption.nameAsc;
    } else {
      if (activeFilter != null || activeFilter == null) {
        _activeFilter = activeFilter;
      }
      if (sortOption != null) _sortOption = sortOption;
    }
    load();
  }

  @override
  Future<List<RouteModel>> fetchData() async {
    final routes = await _repository.getRoutes(fleetId: fleetId);
    return _applyFiltersAndSort(routes);
  }

  List<RouteModel> _applyFiltersAndSort(List<RouteModel> routes) {
    var result = routes.where((r) {
      final matchesSearch =
          _searchQuery.isEmpty ||
          r.name.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesFilter =
          _activeFilter == null || r.isActive == _activeFilter;
      return matchesSearch && matchesFilter;
    }).toList();

    switch (_sortOption) {
      case RouteSortOption.nameAsc:
        result.sort((a, b) => a.name.compareTo(b.name));
      case RouteSortOption.nameDesc:
        result.sort((a, b) => b.name.compareTo(a.name));
      case RouteSortOption.newest:
        result.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      case RouteSortOption.oldest:
        result.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    }
    return result;
  }
}
