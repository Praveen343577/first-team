import 'dart:async';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/models/route/dto/update_route_request_dto.dart';
import 'package:admin/models/route/route_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/service/location_service.dart';
import 'package:admin/ui/route/form_bloc/create_route_form_bloc.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/models/route/dto/create_route_request_dto.dart';

abstract class RouteBaseCubit extends SubmitOnlyCubit {
  late final CreateRouteFormBloc formBloc;
  final RouteRepository repository;
  final LocationService locationService;

  double totalDistance = 0;
  double totalDurationMinutes = 0;
  final List<StreamSubscription> _subscriptions = [];

  RouteBaseCubit(
    this.repository,
    this.locationService, {
    String? fleetId,
    FleetModel? selectedFleet,
    RouteModel? initialRoute,
  }) {
    formBloc = CreateRouteFormBloc(
      selectedFleet: selectedFleet,
      initialFleetId: fleetId,
      initialRoute: initialRoute,
    );
    _setupStopsListener();
  }

  void _setupStopsListener() {
    _calculateTotalDistance();
    _subscriptions.add(
      formBloc.stops.stream.listen((state) {
        _calculateTotalDistance();
        _listenToStopFields();
      }),
    );
    _listenToStopFields();
  }

  void _listenToStopFields() {
    for (final stop in formBloc.stops.value) {
      _subscriptions.add(
        stop.latitude.stream.listen((_) => _calculateTotalDistance()),
      );
      _subscriptions.add(
        stop.longitude.stream.listen((_) => _calculateTotalDistance()),
      );
    }
  }

  void _calculateTotalDistance() {
    final points = <LatLng>[];
    for (final stop in formBloc.stops.value) {
      final lat = double.tryParse(stop.latitude.value);
      final lng = double.tryParse(stop.longitude.value);
      if (lat != null && lng != null) {
        points.add(LatLng(lat, lng));
      }
    }

    if (points.length >= 2) {
      final result = locationService.calculatePathDistance(points);
      totalDistance = result.totalDistanceKm;
      totalDurationMinutes = result.totalDurationMinutes;
    } else {
      totalDistance = 0;
      totalDurationMinutes = 0;
    }

    if (state.isInitial) {
      emit(SubmitOnlyState.initial());
    } else {
      emit(state);
    }
  }

  @override
  Future<void> close() {
    for (var sub in _subscriptions) {
      sub.cancel();
    }
    return super.close();
  }

  List<CreateRouteStopRequestDto> getStopsDto() {
    final stops = <CreateRouteStopRequestDto>[];
    for (var i = 0; i < formBloc.stops.value.length; i++) {
      final stopForm = formBloc.stops.value[i];
      stops.add(
        CreateRouteStopRequestDto(
          stopOrder: i,
          stopName: stopForm.stopName.value,
          latitude: double.parse(stopForm.latitude.value),
          longitude: double.parse(stopForm.longitude.value),
          expectedArrivalOffsetMinutes: int.parse(stopForm.arrivalOffset.value),
          expectedDepartureOffsetMinutes:
              int.parse(stopForm.departureOffset.value),
          stopType: stopForm.stopType,
        ),
      );
    }
    return stops;
  }

  CreateRouteRequestDto getRequestDto() {
    return CreateRouteRequestDto(
      name: formBloc.name.value,
      fleetId: formBloc.fleet.value?.id ?? formBloc.initialFleetId ?? '',
      vehicleId: formBloc.vehicle.state.extraData as String?,
      driverId: formBloc.driver.state.extraData as String?,
      tripType: formBloc.tripType.value,
      stops: getStopsDto(),
    );
  }

  UpdateRouteRequestDto getUpdateDto() {
    return UpdateRouteRequestDto(
      name: formBloc.name.value,
      stops: getStopsDto(),
    );
  }

  void validateForm() {
    formBloc.submit();
    if (!formBloc.state.isValid()) {
      final invalidFields =
          (formBloc.state.fieldBlocs() ?? {}).entries
              .where((e) => !e.value.state.isValid)
              .map((e) => e.key)
              .toList();
      throw Exception('Please fill: ${invalidFields.join(', ')}');
    }
  }
}
