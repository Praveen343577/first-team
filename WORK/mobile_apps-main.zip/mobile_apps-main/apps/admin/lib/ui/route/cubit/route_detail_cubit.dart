import 'package:admin/models/route/route_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/service/google_maps_service.dart';
import 'package:dio/dio.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class RouteDetailCubit extends BaseCubit<RouteModel> {
  final RouteRepository _repository;
  final GoogleMapsService _googleMapsService;
  final String routeId;

  RouteDetailCubit(
    this._repository,
    this._googleMapsService, {
    @factoryParam required this.routeId,
  });

  @override
  Future<RouteModel> performSubmit() async {
    final routes = await _repository.getRoutes();
    final route = routes.firstWhere((r) => r.id == routeId);

    try {
      final result = await _googleMapsService.getDirections(
        route.stops,
      );
      if (result != null) {
        return route.copyWith(
          polyline: result.polyline,
          totalDistance: result.totalDistanceKm,
          totalDuration: result.totalDurationMinutes,
        );
      }
      return route;
    } catch (e) {
      return route;
    }
  }

  Future<void> deleteRoute() async {
    final currentState = state;
    if (currentState is BaseSuccess<RouteModel>) {
      emit(BaseSuccess<RouteModel>(currentState.data, isLoading: true));
    }

    try {
      await _repository.deleteRoute(routeId);
      emit(const RouteDeleted());
    } catch (e) {
      if (currentState is BaseSuccess<RouteModel>) {
        emit(BaseSuccess<RouteModel>(currentState.data, isLoading: false));
      }
      if (e is DioException) {
        emit(BaseError<RouteModel>(
          e.response?.data?.toString() ?? e.message ?? e.toString(),
        ));
      } else {
        emit(BaseError<RouteModel>(e.toString()));
      }
    }
  }
}

class RouteDeleted extends BaseState<RouteModel> {
  const RouteDeleted();
}
