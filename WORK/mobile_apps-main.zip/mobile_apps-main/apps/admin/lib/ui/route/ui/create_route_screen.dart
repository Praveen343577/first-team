import 'package:admin/di/service_locator.dart';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/service/location_service.dart';
import 'package:admin/ui/route/cubit/create_route_cubit.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/ui/common/form_base_screen.dart';
import 'package:admin/ui/route/mixin/route_form_mixin.dart';

class CreateRouteScreen extends FormBaseScreen<CreateRouteCubit>
    with RouteFormMixin {
  final FleetModel? fleet;
  final String? fleetId;
  const CreateRouteScreen({super.key, this.fleet, this.fleetId});

  @override
  String get headerTitle => 'Create New Route';

  @override
  String get headerSubtitle =>
      'Define route stops, verify distances, and assign driver/vehicle resources.';

  @override
  CreateRouteCubit createCubit(BuildContext context) {
    return CreateRouteCubit(
      getIt<RouteRepository>(),
      getIt<LocationService>(),
      selectedFleet: fleet,
      fleetId: fleetId,
    );
  }

  @override
  void onSubmitSuccess(BuildContext context, CreateRouteCubit cubit) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Route created successfully!')),
      );
      Navigator.of(context).pop();
    }
  }

  @override
  Widget? get bottomNavigationBar => Builder(
    builder:
        (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: BlocBuilder<CreateRouteCubit, SubmitOnlyState>(
              builder: (context, state) {
                return ElevatedButton(
                  onPressed:
                      state.isSubmitting
                          ? null
                          : () => context.read<CreateRouteCubit>().submit(),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(state.isSubmitting ? 'Creating...' : 'Create Route'),
                );
              },
            ),
          ),
        ),
  );

  @override
  Widget buildFormContent(BuildContext context, CreateRouteCubit cubit) {
    final formBloc = cubit.formBloc;

    return Column(
      children: [
        buildInfoSection(context, formBloc),
        const SizedBox(height: 16),
        buildResourceAssignmentSection(context, formBloc),
        const SizedBox(height: 16),
        buildStopsSection(context, formBloc),
        const SizedBox(height: 16),
        buildSummarySection(context, cubit),
      ],
    );
  }
}
