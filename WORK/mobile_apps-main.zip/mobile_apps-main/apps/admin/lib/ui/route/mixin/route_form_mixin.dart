import 'package:admin/ui/driver/cubit/driver_list_cubit.dart';
import 'package:admin/ui/driver/cubit/vehicle_list_cubit.dart';
import 'package:admin/di/service_locator.dart';
import 'package:admin/ui/driver/ui/screens/driver/driver_list_screen.dart';
import 'package:admin/ui/driver/ui/screens/vehicle/vehicle_list_screen.dart';
import 'package:admin/ui/driver/ui/widgets/card_panel.dart';
import 'package:admin/ui/route/cubit/route_base_cubit.dart';
import 'package:admin/ui/route/form_bloc/create_route_form_bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:admin/models/location_result.dart';
import 'package:admin/service/permission_service.dart';
import 'package:admin/ui/common/location_picker_screen.dart';
import 'package:ui/ui.dart';
import 'package:state_handler/state_handler.dart';

mixin RouteFormMixin {
  Widget buildSummarySection(BuildContext context, RouteBaseCubit cubit) {
    return BlocBuilder<RouteBaseCubit, SubmitOnlyState>(
      bloc: cubit,
      builder: (context, state) {
        final totalDistance = cubit.totalDistance;
        final totalDuration = cubit.totalDurationMinutes;
        final stopsCount = cubit.formBloc.stops.value.length;

        return CardPanel.compact(
          'Trip Summary',
          margin: EdgeInsets.zero,
          items: [
            _buildSummaryRow(
              'Total Distance (Est.)',
              '${totalDistance.toStringAsFixed(2)} km',
            ),
            _buildSummaryRow(
              'Total Duration (Est.)',
              _formatDuration(totalDuration),
            ),
            _buildSummaryRow(
              'Stops',
              '',
              trailing: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  stopsCount.toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const Divider(),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFFBE6), // Light yellow
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: const Color(0xFFFFE58F),
                  ), // Yellow accent
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Note: ',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.brown.shade800,
                        fontSize: 13,
                      ),
                    ),
                    const Expanded(
                      child: Text(
                        'Actual distance may vary based on real-time traffic conditions.',
                        style: TextStyle(fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatDuration(double totalMinutes) {
    if (totalMinutes <= 0) return '0 min';
    final hours = totalMinutes ~/ 60;
    final minutes = (totalMinutes % 60).round();

    final parts = <String>[];
    if (hours > 0) parts.add('$hours hr');
    if (minutes > 0) parts.add('$minutes min');

    return parts.isEmpty ? '0 min' : parts.join(' ');
  }

  Widget _buildSummaryRow(String label, String value, {Widget? trailing}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Color(0xFF595959), // Grey text
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          trailing ??
              Text(
                value,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  color: Colors.black87,
                ),
              ),
        ],
      ),
    );
  }

  Widget buildResourceAssignmentSection(
    BuildContext context,
    CreateRouteFormBloc formBloc,
  ) {
    return CardPanel.compact(
      'Resource Assignment',
      margin: EdgeInsets.zero,
      items: [
        // Assign Vehicle
        Padding(
          padding: AppPadding.gutter,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Assign Vehicle',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  TextButton(onPressed: () {}, child: const Text('View Map')),
                ],
              ),
              const SizedBox(height: 8),
              TextFieldBlocBuilder(
                textFieldBloc: formBloc.vehicle,
                readOnly: true,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BlocProvider(
                        create: (context) => getIt<VehicleListCubit>()..load(),
                        child: VehicleListScreen(
                          onItemTap: (vehicle) {
                            formBloc.vehicle.updateValue(vehicle.vehicleRegNo);
                            // Store ID in extra data
                            formBloc.vehicle.updateExtraData(vehicle.id);
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ),
                  );
                },
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.directions_bus_outlined),
                  suffixIcon: const Icon(Icons.search, color: Colors.grey),
                  hintText: 'Select Vehicle',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        ),

        // Assign Driver
        Padding(
          padding: AppPadding.gutter,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Assign Driver',
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text('Check Availability'),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              TextFieldBlocBuilder(
                textFieldBloc: formBloc.driver,
                readOnly: true,
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => BlocProvider(
                        create: (context) => getIt<DriverListCubit>()..load(),
                        child: DriverListScreen(
                          onItemTap: (driver) {
                            formBloc.driver.updateValue(driver.fullName);
                            // Store ID in extra data
                            formBloc.driver.updateExtraData(driver.id);
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ),
                  );
                },
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.person_outline),
                  suffixIcon: const Icon(Icons.search, color: Colors.grey),
                  hintText: 'Select Driver',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ],
          ),
        ),

        // Trip Type
        Padding(
          padding: AppPadding.gutter,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Trip Type',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
              ),
              const SizedBox(height: 12),
              BlocBuilder<
                SelectFieldBloc<String, dynamic>,
                SelectFieldBlocState<String, dynamic>
              >(
                bloc: formBloc.tripType,
                builder: (context, state) {
                  final value = state.value;
                  return Row(
                    children: [
                      Expanded(
                        child: buildTripTypeButton(
                          context: context,
                          label: 'Passenger',
                          isSelected: value == 'Passenger',
                          onTap: () =>
                              formBloc.tripType.updateValue('Passenger'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: buildTripTypeButton(
                          context: context,
                          label: 'Delivery',
                          isSelected: value == 'Delivery',
                          onTap: () =>
                              formBloc.tripType.updateValue('Delivery'),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildTripTypeButton({
    required BuildContext context,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).primaryColor.withValues(alpha: 0.05)
              : Colors.white,
          border: Border.all(
            color: isSelected
                ? Theme.of(context).primaryColor
                : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 12,
              height: 12,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? Theme.of(context).primaryColor : null,
                border: isSelected
                    ? null
                    : Border.all(color: Colors.grey.shade400, width: 2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                color: isSelected ? Theme.of(context).primaryColor : null,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildInfoSection(BuildContext context, CreateRouteFormBloc formBloc) {
    return CardPanel(
      'Route Information',
      margin: EdgeInsets.zero,
      items: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: TextFieldBlocBuilder(
            textFieldBloc: formBloc.name,
            decoration: InputDecoration(
              labelText: 'Route Name',
              prefixIcon: const Icon(Icons.route),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget buildStopsSection(
    BuildContext context,
    CreateRouteFormBloc formBloc,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        BlocBuilder<
          ListFieldBloc<CreateRouteStopFormBloc, dynamic>,
          ListFieldBlocState<CreateRouteStopFormBloc, dynamic>
        >(
          bloc: formBloc.stops,
          builder: (context, state) {
            if (state.fieldBlocs.isEmpty) {
              return const Center(child: Text('No stops added yet'));
            }

            final origin = state.fieldBlocs.first;
            final destination = state.fieldBlocs.last;
            final waypoints = state.fieldBlocs.length > 2
                ? state.fieldBlocs.sublist(1, state.fieldBlocs.length - 1)
                : <CreateRouteStopFormBloc>[];

            return CardPanel.compact(
              'Route Configuration',
              margin: EdgeInsets.zero,
              items: [
                buildStopField(
                  context,
                  formBloc,
                  origin,
                  0,
                  state.fieldBlocs.length,
                  label: 'Enter Origin',
                ),

                const SizedBox(height: 16),

                // Waypoints List
                if (waypoints.isNotEmpty)
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: waypoints.length,
                    itemBuilder: (context, index) {
                      return buildStopField(
                        context,
                        formBloc,
                        waypoints[index],
                        index + 1,
                        state.fieldBlocs.length,
                        label: 'Waypoint ${index + 1}',
                      );
                    },
                  ),

                // Add Waypoint Button
                if (waypoints.length < 5)
                  Align(
                    alignment: Alignment.center,
                    child: TextButton.icon(
                      onPressed: () => formBloc.addWaypoint(),
                      icon: const Icon(Icons.add_circle_outline),
                      label: Text('Add Stop (${waypoints.length}/5)'),
                      style: TextButton.styleFrom(
                        foregroundColor: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ),

                buildStopField(
                  context,
                  formBloc,
                  destination,
                  state.fieldBlocs.length - 1,
                  state.fieldBlocs.length,
                  label: 'Enter Destination',
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget buildStopField(
    BuildContext context,
    CreateRouteFormBloc formBloc,
    CreateRouteStopFormBloc stopBloc,
    int index,
    int total, {
    String? label,
  }) {
    final isStart = index == 0;
    final isEnd = index == total - 1;

    return Padding(
      padding: AppPadding.gutter,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: TextFieldBlocBuilder(
              textFieldBloc: stopBloc.stopName,
              onTap: () async {
                final isPermissionGranted = await getIt<PermissionService>()
                    .requestLocationPermission();

                if (!isPermissionGranted) return;

                if (context.mounted) {
                  final result = await Navigator.push<LocationResult>(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const LocationPickerScreen(),
                    ),
                  );

                  if (result != null) {
                    stopBloc.stopName.updateValue(result.name);
                    stopBloc.latitude.updateValue(result.latitude.toString());
                    stopBloc.longitude.updateValue(result.longitude.toString());
                  }
                }
              },
              decoration: InputDecoration(
                labelText: label ?? 'Stop Name',
                isDense: true,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                suffixIcon: const Icon(Icons.location_on_outlined),
              ),
            ),
          ),
          if (!isStart && !isEnd)
            Padding(
              padding: const EdgeInsets.only(top: 4, left: 8),
              child: IconButton(
                icon: const Icon(
                  Icons.remove_circle_outline,
                  color: Colors.redAccent,
                ),
                onPressed: () => formBloc.removeStop(index),
              ),
            ),
        ],
      ),
    );
  }
}
