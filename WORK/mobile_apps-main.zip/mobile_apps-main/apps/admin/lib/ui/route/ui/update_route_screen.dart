import 'package:admin/di/service_locator.dart';
import 'package:admin/models/route/route_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/service/location_service.dart';
import 'package:admin/ui/route/cubit/update_route_cubit.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/ui/common/form_base_screen.dart';
import 'package:admin/ui/route/mixin/route_form_mixin.dart';

class UpdateRouteScreen extends FormBaseScreen<UpdateRouteCubit>
    with RouteFormMixin {
  final RouteModel route;

  const UpdateRouteScreen({super.key, required this.route});

  @override
  String get headerTitle => 'Update Route';

  @override
  String get headerSubtitle => 'Update the route stops and assigned resources.';

  @override
  UpdateRouteCubit createCubit(BuildContext context) {
    return UpdateRouteCubit(
      route,
      getIt<RouteRepository>(),
      getIt<LocationService>(),
    );
  }

  @override
  void onSubmitSuccess(BuildContext context, UpdateRouteCubit cubit) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Route updated successfully!')),
      );
      Navigator.of(context).pop();
    }
  }

  @override
  Widget? get bottomNavigationBar => Builder(
    builder:
        (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: BlocBuilder<UpdateRouteCubit, SubmitOnlyState>(
              builder: (context, state) {
                return ElevatedButton(
                  onPressed:
                      state.isSubmitting
                          ? null
                          : () => context.read<UpdateRouteCubit>().submit(),
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(state.isSubmitting ? 'Updating...' : 'Update Route'),
                );
              },
            ),
          ),
        ),
  );

  @override
  Widget buildFormContent(BuildContext context, UpdateRouteCubit cubit) {
    final formBloc = cubit.formBloc;

    return Column(
      children: [
        buildInfoSection(context, formBloc),
        const SizedBox(height: 16),
        buildResourceAssignmentSection(context, formBloc),
        const SizedBox(height: 16),
        buildStopsSection(context, formBloc),
        const SizedBox(height: 16),
        buildSummarySection(context, cubit),
      ],
    );
  }
}
