import 'package:admin/models/route/route_model.dart';
import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/repository/recent_activity_repository.dart';
import 'package:admin/di/service_locator.dart';
import 'package:admin/service/polyline_decoder.dart';
import 'package:admin/ui/driver/ui/widgets/card_panel.dart';
import 'package:admin/ui/route/cubit/route_detail_cubit.dart';
import 'package:admin/ui/route/ui/update_route_screen.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';
import 'package:admin/ui/common/widgets/scrollable_google_map.dart';

class RouteDetailScreen extends FetchScreen<RouteDetailCubit, RouteModel> {
  final String routeId;

  const RouteDetailScreen({super.key, required this.routeId});

  @override
  Widget buildSuccess(BuildContext context, RouteModel data) {
    // Record this route in recent activity
    getIt<RecentActivityRepository>().addItem(
      RecentActivityItem(
        id: data.id,
        type: 'route',
        title: data.name,
        subtitle: '${data.stops.length} stops',
        viewedAt: DateTime.now(),
      ),
    );

    final state = context.watch<RouteDetailCubit>().state;
    final isLoading = state is BaseSuccess<RouteModel> && state.isLoading;

    return Stack(
      children: [
        Scaffold(
          appBar: AppBar(
            title: const Text(
              'Route Tracking',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            actions: [
              PopupMenuButton<String>(
                onSelected: (value) => _onMenuSelected(context, value, data),
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit_outlined, size: 20),
                        SizedBox(width: 8),
                        Text('Edit'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete_outline, size: 20, color: Colors.red),
                        SizedBox(width: 8),
                        Text('Delete', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(context, data),
                _buildMapSection(context, data),
                _buildStatsGrid(context, data),
                _buildDriverVehicleSection(context, data),
                _buildTimelineSection(context, data),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ),
        if (isLoading)
          Positioned.fill(
            child: Container(
              color: Colors.black.withValues(alpha: (0.3)),
              child: const Center(child: CircularProgressIndicator()),
            ),
          ),
      ],
    );
  }

  void _onMenuSelected(BuildContext context, String value, RouteModel data) {
    if (value == 'edit') {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => UpdateRouteScreen(route: data)),
      );
    } else if (value == 'delete') {
      _showDeleteConfirmation(context);
    }
  }

  @override
  void onListener(BuildContext context, BaseState<RouteModel> state) {
    if (state is RouteDeleted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Route deleted successfully')),
      );
      Navigator.pop(context);
    }
    if (state is BaseError<RouteModel>) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(state.message)));
    }
  }

  void _showDeleteConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete Route'),
        content: const Text('Are you sure you want to delete this route?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(dialogContext); // Close dialog first
              context.read<RouteDetailCubit>().deleteRoute();
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context, RouteModel data) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  data.name,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: isDark ? Colors.blue.withValues(alpha: 0.15) : const Color(0xFFE6F0FF),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'In Progress',
                  style: TextStyle(
                    color: isDark ? Colors.blue.shade300 : const Color(0xFF0052CC),
                    fontWeight: FontWeight.bold,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(
                Icons.calendar_today_outlined,
                size: 14,
                color: Colors.grey,
              ),
              const SizedBox(width: 4),
              Text(
                DateFormat('MMM dd, yyyy').format(data.createdAt),
                style: const TextStyle(color: Colors.grey, fontSize: 13),
              ),
              const SizedBox(width: 16),
              const Icon(Icons.info_outline, size: 14, color: Colors.grey),
              const SizedBox(width: 4),
              CopyableText(
                text: 'ID: ${data.id.substring(0, 8).toUpperCase()}',
                textToCopy: data.id,
                style: const TextStyle(color: Colors.grey, fontSize: 13),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMapSection(BuildContext context, RouteModel data) {
    final stops = data.stops;
    final markerPoints = stops
        .map((s) => LatLng(s.latitude, s.longitude))
        .toList();

    List<LatLng> polylinePoints = markerPoints;
    if (data.polyline != null && data.polyline!.isNotEmpty) {
      polylinePoints = PolylineDecoder.decodePolyline(data.polyline!);
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      height: 400,
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Colors.grey.shade900 : const Color(0xFFEDF2F7),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: (0.05)),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      clipBehavior: Clip.hardEdge,
      child: Stack(
        children: [
          if (markerPoints.isNotEmpty)
            ScrollableGoogleMap(
              initialCameraPosition: CameraPosition(
                target: markerPoints.first,
                zoom: 12,
              ),
              onMapCreated: (controller) {
                if (markerPoints.length > 1) {
                  final bounds = _getBounds(markerPoints);
                  controller.animateCamera(
                    CameraUpdate.newLatLngBounds(bounds, 50),
                  );
                }
              },
              markers: markerPoints.asMap().entries.map((entry) {
                final idx = entry.key;
                final pos = entry.value;
                return Marker(
                  markerId: MarkerId('stop_$idx'),
                  position: pos,
                  infoWindow: InfoWindow(title: stops[idx].stopName),
                  icon: BitmapDescriptor.defaultMarkerWithHue(
                    idx == 0
                        ? BitmapDescriptor.hueGreen
                        : idx == markerPoints.length - 1
                        ? BitmapDescriptor.hueRed
                        : BitmapDescriptor.hueAzure,
                  ),
                );
              }).toSet(),
              polylines: {
                Polyline(
                  polylineId: const PolylineId('route_path'),
                  points: polylinePoints,
                  color: Colors.blueAccent,
                  width: 5,
                  jointType: JointType.round,
                  startCap: Cap.roundCap,
                  endCap: Cap.roundCap,
                ),
              },
              zoomControlsEnabled: false,
              mapToolbarEnabled: false,
              myLocationButtonEnabled: false,
            ),

          Positioned(
            bottom: 16,
            left: 16,
            right: 16,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).cardColor,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: (0.1)),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'NEXT STOP',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            color: Colors.blueAccent,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          stops.length > 1 ? stops[1].stopName : 'Destination',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        const Text(
                          'Est. Arrival: 15 mins',
                          style: TextStyle(color: Colors.grey, fontSize: 13),
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(
                            value: 0.65,
                            backgroundColor: isDark ? Colors.grey.shade800 : Colors.grey.shade200,
                            minHeight: 6,
                          ),
                        ),
                        const SizedBox(height: 4),
                        const Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'On Time',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.green,
                              ),
                            ),
                            Text(
                              '65% Complete',
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 16),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isDark ? Colors.blue.withValues(alpha: 0.15) : const Color(0xFFE6F0FF),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.near_me, color: isDark ? Colors.blue.shade300 : Colors.blueAccent),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  LatLngBounds _getBounds(List<LatLng> points) {
    double? minLat, maxLat, minLng, maxLng;

    for (var point in points) {
      if (minLat == null || point.latitude < minLat) minLat = point.latitude;
      if (maxLat == null || point.latitude > maxLat) maxLat = point.latitude;
      if (minLng == null || point.longitude < minLng) minLng = point.longitude;
      if (maxLng == null || point.longitude > maxLng) maxLng = point.longitude;
    }

    return LatLngBounds(
      southwest: LatLng(minLat!, minLng!),
      northeast: LatLng(maxLat!, maxLng!),
    );
  }

  Widget _buildStatsGrid(BuildContext context, RouteModel data) {
    return CardPanel(
      null, // No title for stats grid
      margin: AppPadding.gutter,
      items: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      context,
                      'TOTAL DISTANCE',
                      data.totalDistance != null
                          ? '${data.totalDistance!.toStringAsFixed(1)} km'
                          : '--',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildStatCard(
                      context,
                      'DURATION',
                      data.totalDuration != null
                          ? _formatDuration(data.totalDuration!)
                          : '--',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(context, 'STOPS', '${data.stops.length}'),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: _buildBatteryCard(context, '68%')),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _formatDuration(double minutes) {
    if (minutes < 60) return '${minutes.round()}m';
    final hours = minutes ~/ 60;
    final mins = (minutes % 60).round();
    if (mins == 0) return '${hours}h';
    return '${hours}h ${mins}m';
  }

  Widget _buildStatCard(BuildContext context, String label, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.grey.shade400 : Colors.grey,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildBatteryCard(BuildContext context, String value) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? Colors.green.withValues(alpha: 0.15) : const Color(0xFFF0FFF4),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: isDark ? Colors.green.withValues(alpha: 0.3) : const Color(0xFFC6F6D5)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'BATTERY EST.',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: isDark ? Colors.green.shade300 : const Color(0xFF38A169),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.green.shade100 : const Color(0xFF2F855A),
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.ev_station, color: isDark ? Colors.green.shade300 : const Color(0xFF38A169), size: 20),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildDriverVehicleSection(BuildContext context, RouteModel data) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return CardPanel(
      'Driver & Vehicle',
      margin: AppPadding.gutter,
      items: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: isDark ? Colors.grey.shade800 : Colors.grey.shade100,
                      shape: BoxShape.circle,
                      border: Border.all(color: Theme.of(context).dividerColor),
                    ),
                    child: const Icon(Icons.person, color: Colors.grey),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Rajesh Kumar',
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                          ),
                        ),
                        Text(
                          'Rating: 4.8/5.0',
                          style: TextStyle(color: Colors.grey, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: isDark ? Colors.green.withValues(alpha: 0.15) : const Color(0xFFF0FFF4),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: isDark ? Colors.green.withValues(alpha: 0.3) : const Color(0xFFC6F6D5)),
                    ),
                    child: Icon(
                      Icons.phone_outlined,
                      color: isDark ? Colors.green.shade300 : const Color(0xFF38A169),
                      size: 20,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: isDark ? Colors.grey.shade900 : const Color(0xFFF7FAFC),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.directions_bus_outlined,
                      color: Colors.grey,
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'TN-09-EV-1234',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'Tata Ace EV',
                            style: TextStyle(color: Colors.grey, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).cardColor,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: Theme.of(context).dividerColor),
                      ),
                      child: const Text(
                        'EV',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTimelineSection(BuildContext context, RouteModel data) {
    final timelineItems = data.stops.asMap().entries.map((entry) {
      final index = entry.key;
      final stop = entry.value;
      return TimelineModel(
        title: stop.stopName,
        description: stop.stopType ?? 'Waypoint',
        status: index == 0
            ? Status.completed
            : index == 1
            ? Status.inprogress
            : Status.sceduled,
        dateTime: DateTime.now().add(Duration(hours: index)),
      );
    }).toList();

    return CardPanel(
      'Route Timeline',
      margin: AppPadding.gutter,
      items: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: timelineItems.length >= 2
              ? ProgressTimeline(timelineList: timelineItems)
              : const Center(child: Text('No timeline data available')),
        ),
      ],
    );
  }

  @override
  Widget buildLoading(BuildContext context) {
    return const Scaffold(
      body: Center(child: CircularProgressIndicator()),
    );
  }
}
