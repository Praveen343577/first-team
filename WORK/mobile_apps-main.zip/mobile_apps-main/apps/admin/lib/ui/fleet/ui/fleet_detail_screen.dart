import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/ui/fleet/cubit/fleet_detail_cubit.dart';
import 'package:admin/ui/fleet/ui/aggregated_vehicles_map_screen.dart';
import 'package:admin/ui/fleet/cubit/aggregated_vehicles_cubit.dart';
import 'package:admin/repository/vehicle_repository.dart';
import 'package:admin/di/service_locator.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class FleetDetailScreen extends FetchScreen<FleetDetailCubit, FleetModel> {
  const FleetDetailScreen({super.key});

  @override
  Widget buildSuccess(BuildContext context, FleetModel fleet) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Fleet Details"),
      ),
      body: SingleChildScrollView(
        padding: AppPadding.p16,
        child: Column(
          children: [
            /// HEADER
            CircleAvatar(
              radius: 40,
              backgroundColor: Theme.of(context).primaryColor.withValues(alpha: 0.1),
              child: Icon(
                Icons.business,
                size: 40,
                color: Theme.of(context).primaryColor,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              fleet.name,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            Text(
              fleet.companyName ?? '',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            const SizedBox(height: 32),

            /// FLEET INFO
            _buildInfoSection(
              context,
              icon: Icons.info_outline,
              title: "Fleet Information",
              children: [
                _buildInfoField(context, "FLEET ID", fleet.id),
                _buildInfoField(context, "COMPANY NAME", fleet.companyName ?? ''),
                _buildInfoField(context, "CREATED BY", fleet.createdBy ?? ''),
                _buildInfoField(
                  context,
                  "CREATED AT",
                  (fleet.createdAt ?? '').split('T')[0],
                ),
                if (fleet.updatedAt != null)
                  _buildInfoField(
                    context,
                    "LAST UPDATED",
                    fleet.updatedAt!.split('T')[0],
                  ),
              ],
            ),
            const SizedBox(height: 16),
            Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text(
                      'Fleet Live Location',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 300,
                    child: BlocProvider(
                      create: (context) => AggregatedVehiclesCubit(
                        getIt<VehicleRepository>(),
                      )..updateFleetId(fleet.id)..load(),
                      child: const AggregatedVehiclesMapScreen(),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoSection(
    BuildContext context, {
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    return Card(
      child: Padding(
        padding: AppPadding.p16,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 20, color: Theme.of(context).primaryColor),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
            const Divider(height: 24),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildInfoField(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
        ],
      ),
    );
  }
}
