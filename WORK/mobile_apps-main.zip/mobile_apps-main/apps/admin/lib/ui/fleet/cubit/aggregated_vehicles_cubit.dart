import 'package:admin/models/vehicle/aggregated_vehicle.dart';
import 'package:admin/repository/vehicle_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class AggregatedVehiclesCubit extends FetchOnlyCubit<List<AggregatedVehicle>> {
  final VehicleRepository _repository;
  String? fleetId;

  AggregatedVehiclesCubit(this._repository);

  void updateFleetId(String? id) {
    fleetId = id;
  }

  @override
  Future<List<AggregatedVehicle>> fetchData() =>
      _repository.getAggregatedVehicles(fleetId: fleetId);
}
