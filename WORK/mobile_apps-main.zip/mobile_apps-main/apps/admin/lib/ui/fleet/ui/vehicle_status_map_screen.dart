import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/models/dashboard/vehicle_status_map_model.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/ui/dashboards/cubit/vehicle_status_map_cubit.dart';
import 'package:admin/ui/driver/ui/screens/vehicle/vehicle_detail_screen.dart';
import 'package:ui/ui.dart';
import 'package:admin/ui/common/widgets/scrollable_google_map.dart';

class VehicleStatusMapScreen extends StatefulWidget {
  const VehicleStatusMapScreen({super.key});

  @override
  State<VehicleStatusMapScreen> createState() => _VehicleStatusMapScreenState();
}

class _VehicleStatusMapScreenState extends State<VehicleStatusMapScreen> {
  final Completer<GoogleMapController> _mapControllerCompleter = Completer<GoogleMapController>();
  IndividualVehicle? _selectedVehicle;
  VehicleStatusCluster? _selectedCluster;
  bool _cameraInitialized = false;

  double _getMarkerHue(String status) {
    switch (status.toLowerCase()) {
      case 'active':
      case 'running':
      case 'online':
        return BitmapDescriptor.hueGreen;
      case 'charging':
        return BitmapDescriptor.hueYellow;
      case 'idle':
        return BitmapDescriptor.hueOrange;
      case 'maintenance':
      case 'offline':
      case 'inactive':
        return BitmapDescriptor.hueRed;
      default:
        return BitmapDescriptor.hueAzure;
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'active':
      case 'running':
      case 'online':
        return EkaColors.successGreen2;
      case 'charging':
        return EkaColors.warningAmber;
      case 'idle':
        return Colors.orange;
      case 'maintenance':
      case 'offline':
      case 'inactive':
        return EkaColors.dangerRed;
      default:
        return EkaColors.primaryBlue;
    }
  }

  Future<void> _fitBounds(VehicleStatusMapModel model) async {
    final List<LatLng> points = [];
    for (final vehicle in model.individualVehicles) {
      points.add(LatLng(vehicle.lat, vehicle.lng));
    }
    for (final cluster in model.clusters) {
      points.add(LatLng(cluster.lat, cluster.lng));
    }

    if (points.isEmpty) return;

    double? minLat, maxLat, minLng, maxLng;
    for (final pt in points) {
      if (minLat == null || pt.latitude < minLat) minLat = pt.latitude;
      if (maxLat == null || pt.latitude > maxLat) maxLat = pt.latitude;
      if (minLng == null || pt.longitude < minLng) minLng = pt.longitude;
      if (maxLng == null || pt.longitude > maxLng) maxLng = pt.longitude;
    }

    if (minLat == null || maxLat == null || minLng == null || maxLng == null) return;

    final controller = await _mapControllerCompleter.future;

    if (minLat == maxLat && minLng == maxLng) {
      await controller.animateCamera(
        CameraUpdate.newLatLngZoom(LatLng(minLat, minLng), 13),
      );
    } else {
      await controller.animateCamera(
        CameraUpdate.newLatLngBounds(
          LatLngBounds(
            southwest: LatLng(minLat, minLng),
            northeast: LatLng(maxLat, maxLng),
          ),
          60, // Padding
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VehicleStatusMapCubit, FetchOnlyState<VehicleStatusMapModel>>(
      builder: (context, state) {
        if (state.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (state.isError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  state.errorMessage ?? 'Failed to load vehicle status map data',
                  style: const TextStyle(color: EkaColors.dangerRed),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: () => context.read<VehicleStatusMapCubit>().load(),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        final model = state.data;
        if (model == null || (model.individualVehicles.isEmpty && model.clusters.isEmpty)) {
          return const Center(
            child: Text(
              'No vehicles currently available on map.',
              style: TextStyle(color: EkaColors.textSecondary),
            ),
          );
        }

        // Initialize camera to frame vehicles once
        if (!_cameraInitialized) {
          _cameraInitialized = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _fitBounds(model);
          });
        }

        final total = model.totalVehicles;
        final clusterCount = model.clusters.length;

        // Create Markers
        final markers = <Marker>{};

        // Add individual vehicles
        for (final vehicle in model.individualVehicles) {
          markers.add(
            Marker(
              markerId: MarkerId(vehicle.vehicleId),
              position: LatLng(vehicle.lat, vehicle.lng),
              icon: BitmapDescriptor.defaultMarkerWithHue(_getMarkerHue(vehicle.status)),
              onTap: () {
                setState(() {
                  _selectedVehicle = vehicle;
                  _selectedCluster = null;
                });
              },
            ),
          );
        }

        // Add clusters
        for (int i = 0; i < model.clusters.length; i++) {
          final cluster = model.clusters[i];
          markers.add(
            Marker(
              markerId: MarkerId('cluster_$i'),
              position: LatLng(cluster.lat, cluster.lng),
              icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueViolet),
              onTap: () {
                setState(() {
                  _selectedCluster = cluster;
                  _selectedVehicle = null;
                });
              },
            ),
          );
        }

        final cubit = context.read<VehicleStatusMapCubit>();

        return Stack(
          children: [
            // Map
            ScrollableGoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(20.5937, 78.9629),
                zoom: 5,
              ),
              markers: markers,
              onMapCreated: (controller) {
                if (!_mapControllerCompleter.isCompleted) {
                  _mapControllerCompleter.complete(controller);
                }
              },
              onTap: (_) {
                setState(() {
                  _selectedVehicle = null;
                  _selectedCluster = null;
                });
              },
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
            ),

            // Top Control Bar Overlay
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Card(
                elevation: 4,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Total Vehicles: $total',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                          Text(
                            'Clusters: $clusterCount',
                            style: const TextStyle(
                              color: EkaColors.textSecondary,
                              fontWeight: FontWeight.bold,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 12),
                      Row(
                        children: [
                          const Icon(Icons.tune, size: 16, color: EkaColors.textSecondary),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Slider(
                              value: cubit.clusterDistanceKm,
                              min: 1.0,
                              max: 20.0,
                              divisions: 19,
                              label: '${cubit.clusterDistanceKm.toStringAsFixed(0)} km',
                              onChanged: (newVal) {
                                cubit.changeClusterDistance(newVal);
                              },
                            ),
                          ),
                          Text(
                            '${cubit.clusterDistanceKm.toStringAsFixed(0)} km',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: EkaColors.primaryBlue,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

            // Floating Recenter/Refresh Buttons
            Positioned(
              right: 16,
              bottom: (_selectedVehicle != null || _selectedCluster != null) ? 240 : 16,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FloatingActionButton.small(
                    heroTag: 'recenter_map',
                    backgroundColor: EkaColors.cardBackground,
                    foregroundColor: EkaColors.textPrimary,
                    child: const Icon(Icons.my_location),
                    onPressed: () => _fitBounds(model),
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton.small(
                    heroTag: 'refresh_map',
                    backgroundColor: EkaColors.cardBackground,
                    foregroundColor: EkaColors.textPrimary,
                    child: const Icon(Icons.refresh),
                    onPressed: () {
                      context.read<VehicleStatusMapCubit>().load();
                    },
                  ),
                ],
              ),
            ),

            // Bottom Selected Vehicle Details Card
            if (_selectedVehicle != null)
              Positioned(
                left: 16,
                right: 16,
                bottom: 16,
                child: _buildVehicleDetailCard(_selectedVehicle!),
              ),

            // Bottom Selected Cluster Details Card
            if (_selectedCluster != null)
              Positioned(
                left: 16,
                right: 16,
                bottom: 16,
                child: _buildClusterDetailCard(_selectedCluster!),
              ),
          ],
        );
      },
    );
  }

  Widget _buildVehicleDetailCard(IndividualVehicle vehicle) {
    final statusColor = _getStatusColor(vehicle.status);

    return Card(
      elevation: 8,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        vehicle.vehicleRegNo.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'ID: ${vehicle.vehicleId}',
                        style: const TextStyle(
                          color: EkaColors.textSecondary,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: statusColor.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    vehicle.status.toUpperCase(),
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            Row(
              children: [
                // Charge / SoC
                Expanded(
                  child: Row(
                    children: [
                      Icon(
                        Icons.battery_charging_full,
                        color: (vehicle.soc ?? 0) > 20
                            ? EkaColors.successGreen2
                            : EkaColors.dangerRed,
                      ),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'CHARGE',
                            style: TextStyle(fontSize: 10, color: EkaColors.textSecondary),
                          ),
                          Text(
                            '${(vehicle.soc ?? 0.0).toStringAsFixed(0)}%',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Speed
                Expanded(
                  child: Row(
                    children: [
                      const Icon(Icons.speed, color: EkaColors.primaryBlue),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'SPEED',
                            style: TextStyle(fontSize: 10, color: EkaColors.textSecondary),
                          ),
                          Text(
                            '${(vehicle.speed ?? 0.0).toStringAsFixed(0)} km/h',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    final vehicleModel = VehicleModel(
                      id: vehicle.vehicleId,
                      vehicleRegNo: vehicle.vehicleRegNo,
                      vehicleType: 'EV',
                      fleetId: '',
                      deviceId: vehicle.deviceId ?? vehicle.vehicleId,
                      createdAt: DateTime.now().toIso8601String(),
                    );
                    Navigator.push(context, VehicleDetailScreen.route(vehicleModel));
                  },
                  icon: const Icon(Icons.arrow_forward, size: 16),
                  label: const Text('Details'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    minimumSize: Size.zero,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildClusterDetailCard(VehicleStatusCluster cluster) {
    return Card(
      elevation: 8,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Cluster: ${cluster.count} Vehicles',
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Lat: ${cluster.lat.toStringAsFixed(4)}, Lng: ${cluster.lng.toStringAsFixed(4)}',
                      style: const TextStyle(
                        color: EkaColors.textSecondary,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
                const Icon(Icons.explore, color: Colors.purple),
              ],
            ),
            const Divider(height: 20),
            const Text(
              'STATUS BREAKDOWN',
              style: TextStyle(
                fontSize: 10,
                color: EkaColors.textSecondary,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: cluster.statusBreakdown.entries.map((entry) {
                final color = _getStatusColor(entry.key);
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: color.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    '${entry.key.toUpperCase()}: ${entry.value}',
                    style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
