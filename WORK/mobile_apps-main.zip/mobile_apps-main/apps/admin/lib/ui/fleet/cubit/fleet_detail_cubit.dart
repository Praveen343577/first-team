import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class FleetDetailCubit extends BaseCubit<FleetModel> {
  final FleetRepository _repository;
  final String fleetId;

  FleetDetailCubit(
    this._repository, {
    @factoryParam required this.fleetId,
  });

  @override
  Future<FleetModel> performSubmit() async {
    return await _repository.getFleetDetails(fleetId);
  }
}
