import 'package:admin/di/service_locator.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/repository/vehicle_repository.dart';
import 'package:admin/ui/driver/cubit/vehicle_list_cubit.dart';
import 'package:admin/ui/driver/ui/screens/vehicle/vehicle_list_screen.dart';
import 'package:admin/ui/fleet/ui/fleet_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class FleetManagementScreen extends StatefulWidget {
  const FleetManagementScreen({super.key});

  @override
  State<FleetManagementScreen> createState() => _FleetManagementScreenState();
}

class _FleetManagementScreenState extends State<FleetManagementScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _activeTab = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      if (_tabController.indexIsChanging) return;
      setState(() {
        _activeTab = _tabController.index;
      });
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _onCreateFleet() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Fleet'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Fleet Name',
                hintText: 'e.g. West Zone Fleet',
              ),
            ),
            SizedBox(height: 12),
            TextField(
              decoration: InputDecoration(
                labelText: 'Company Name',
                hintText: 'e.g. EKA Mobility',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Fleet creation is not integrated yet.')),
              );
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _onCreateVehicle() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Create Vehicle'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Registration Number',
                hintText: 'e.g. MH12AB1234',
              ),
            ),
            SizedBox(height: 12),
            TextField(
              decoration: InputDecoration(
                labelText: 'Model',
                hintText: 'e.g. EKA 9m Bus',
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Vehicle creation is not integrated yet.')),
              );
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Fleet Management"),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Fleets'),
            Tab(text: 'Vehicles'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          const FleetListScreen(useScaffold: false),
          BlocProvider(
            create: (context) => VehicleListCubit(
              getIt<VehicleRepository>(),
              getIt<FleetRepository>(),
            )..loadFleets(),
            child: const VehicleListScreen(useScaffold: false),
          ),
        ],
      ),
      floatingActionButton: _activeTab == 0
          ? FloatingActionButton.extended(
              onPressed: _onCreateFleet,
              icon: const Icon(Icons.add),
              label: const Text('Create Fleet'),
            )
          : null,
    );
  }
}
