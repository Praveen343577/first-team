import 'package:admin/di/service_locator.dart';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/ui/driver/cubit/fleet_list_cubit.dart';
import 'package:admin/ui/fleet/cubit/fleet_detail_cubit.dart';
import 'package:admin/ui/fleet/ui/fleet_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class FleetListScreen extends SearchListScreen<FleetListCubit, FleetModel> {
  const FleetListScreen({super.key, super.useScaffold = true});

  @override
  String get title => 'Fleets';

  @override
  String get searchHint => 'Search fleets…';

  @override
  EdgeInsets get itemPadding => AppPadding.gutter;

  @override
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No fleets found'));
  }

  @override
  Widget buildItem(BuildContext context, FleetModel fleet, int index) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => BlocProvider(
                create: (context) => FleetDetailCubit(
                  getIt<FleetRepository>(),
                  fleetId: fleet.id,
                ),
                child: const FleetDetailScreen(),
              ),
            ),
          );
        },
        child: Padding(
          padding: AppPadding.p16,
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                child: Icon(Icons.business, color: Theme.of(context).primaryColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fleet.name,
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                    Text(
                      fleet.companyName ?? '',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 20, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
