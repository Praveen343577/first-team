import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/models/vehicle/aggregated_vehicle.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/ui/fleet/cubit/aggregated_vehicles_cubit.dart';
import 'package:admin/ui/driver/ui/screens/vehicle/vehicle_detail_screen.dart';
import 'package:ui/ui.dart';
import 'package:admin/ui/common/widgets/scrollable_google_map.dart';

class AggregatedVehiclesMapScreen extends StatefulWidget {
  const AggregatedVehiclesMapScreen({super.key});

  @override
  State<AggregatedVehiclesMapScreen> createState() => _AggregatedVehiclesMapScreenState();
}

class _AggregatedVehiclesMapScreenState extends State<AggregatedVehiclesMapScreen> {
  final Completer<GoogleMapController> _mapControllerCompleter = Completer<GoogleMapController>();
  AggregatedVehicle? _selectedVehicle;
  bool _cameraInitialized = false;

  double _getMarkerHue(String status) {
    switch (status.toLowerCase()) {
      case 'active':
      case 'running':
      case 'online':
        return BitmapDescriptor.hueGreen;
      case 'charging':
        return BitmapDescriptor.hueYellow;
      case 'idle':
        return BitmapDescriptor.hueOrange;
      case 'maintenance':
      case 'offline':
      case 'inactive':
        return BitmapDescriptor.hueRed;
      default:
        return BitmapDescriptor.hueAzure;
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'active':
      case 'running':
      case 'online':
        return EkaColors.successGreen2;
      case 'charging':
        return EkaColors.warningAmber;
      case 'idle':
        return Colors.orange;
      case 'maintenance':
      case 'offline':
      case 'inactive':
        return EkaColors.dangerRed;
      default:
        return EkaColors.primaryBlue;
    }
  }

  Future<void> _fitBounds(List<AggregatedVehicle> vehicles) async {
    if (vehicles.isEmpty) return;
    
    double? minLat, maxLat, minLng, maxLng;
    for (final vehicle in vehicles) {
      if (minLat == null || vehicle.latitude < minLat) minLat = vehicle.latitude;
      if (maxLat == null || vehicle.latitude > maxLat) maxLat = vehicle.latitude;
      if (minLng == null || vehicle.longitude < minLng) minLng = vehicle.longitude;
      if (maxLng == null || vehicle.longitude > maxLng) maxLng = vehicle.longitude;
    }

    if (minLat == null || maxLat == null || minLng == null || maxLng == null) return;

    final controller = await _mapControllerCompleter.future;
    
    // Check if bounds are collapsed (e.g. single vehicle or all at same point)
    if (minLat == maxLat && minLng == maxLng) {
      await controller.animateCamera(
        CameraUpdate.newLatLngZoom(LatLng(minLat, minLng), 13),
      );
    } else {
      await controller.animateCamera(
        CameraUpdate.newLatLngBounds(
          LatLngBounds(
            southwest: LatLng(minLat, minLng),
            northeast: LatLng(maxLat, maxLng),
          ),
          60, // Padding
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AggregatedVehiclesCubit, FetchOnlyState<List<AggregatedVehicle>>>(
      builder: (context, state) {
        if (state.isLoading) {
          return const Center(child: CircularProgressIndicator());
        }

        if (state.isError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  state.errorMessage ?? 'Failed to load vehicle map data',
                  style: const TextStyle(color: EkaColors.dangerRed),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 12),
                ElevatedButton(
                  onPressed: () => context.read<AggregatedVehiclesCubit>().load(),
                  child: const Text('Retry'),
                ),
              ],
            ),
          );
        }

        final vehicles = state.data ?? <AggregatedVehicle>[];

        if (vehicles.isEmpty) {
          return const Center(
            child: Text(
              'No vehicles currently available on map.',
              style: TextStyle(color: EkaColors.textSecondary),
            ),
          );
        }

        // Initialize camera to frame vehicles once
        if (!_cameraInitialized && vehicles.isNotEmpty) {
          _cameraInitialized = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _fitBounds(vehicles);
          });
        }

        // Compute counts
        final total = vehicles.length;
        final active = vehicles.where((v) => v.status.toLowerCase() == 'active' || v.status.toLowerCase() == 'running').length;
        final charging = vehicles.where((v) => v.status.toLowerCase() == 'charging').length;
        final idle = vehicles.where((v) => v.status.toLowerCase() == 'idle').length;
        final inactive = vehicles.where((v) => v.status.toLowerCase() == 'inactive' || v.status.toLowerCase() == 'maintenance').length;

        // Create Markers
        final markers = vehicles.map((vehicle) {
          return Marker(
            markerId: MarkerId(vehicle.vehicleId),
            position: LatLng(vehicle.latitude, vehicle.longitude),
            icon: BitmapDescriptor.defaultMarkerWithHue(_getMarkerHue(vehicle.status)),
            onTap: () {
              setState(() {
                _selectedVehicle = vehicle;
              });
            },
          );
        }).toSet();

        return Stack(
          children: [
            // Map
            ScrollableGoogleMap(
              initialCameraPosition: const CameraPosition(
                target: LatLng(20.5937, 78.9629), // Center of India or default
                zoom: 5,
              ),
              markers: markers,
              onMapCreated: (controller) {
                _mapControllerCompleter.complete(controller);
              },
              onTap: (_) {
                setState(() {
                  _selectedVehicle = null;
                });
              },
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
            ),

            // Top Status Bar Overlay
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    _buildStatusPill('Total: $total', EkaColors.primaryBlue),
                    const SizedBox(width: 8),
                    _buildStatusPill('Active: $active', EkaColors.successGreen2),
                    const SizedBox(width: 8),
                    _buildStatusPill('Charging: $charging', EkaColors.warningAmber),
                    const SizedBox(width: 8),
                    _buildStatusPill('Idle: $idle', Colors.orange),
                    const SizedBox(width: 8),
                    _buildStatusPill('Inactive: $inactive', EkaColors.dangerRed),
                  ],
                ),
              ),
            ),

            // Floating Buttons
            Positioned(
              right: 16,
              bottom: _selectedVehicle != null ? 240 : 16,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  FloatingActionButton.small(
                    heroTag: 'recenter_map',
                    backgroundColor: EkaColors.cardBackground,
                    foregroundColor: EkaColors.textPrimary,
                    child: const Icon(Icons.my_location),
                    onPressed: () => _fitBounds(vehicles),
                  ),
                  const SizedBox(height: 8),
                  FloatingActionButton.small(
                    heroTag: 'refresh_map',
                    backgroundColor: EkaColors.cardBackground,
                    foregroundColor: EkaColors.textPrimary,
                    child: const Icon(Icons.refresh),
                    onPressed: () {
                      context.read<AggregatedVehiclesCubit>().load();
                    },
                  ),
                ],
              ),
            ),

            // Bottom Selected Vehicle Details Card
            if (_selectedVehicle != null)
              Positioned(
                left: 16,
                right: 16,
                bottom: 16,
                child: _buildVehicleDetailCard(_selectedVehicle!),
              ),
          ],
        );
      },
    );
  }

  Widget _buildStatusPill(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: EkaColors.cardBackground,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.3), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Text(
        text,
        style: TextStyle(
          color: EkaColors.textPrimary,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildVehicleDetailCard(AggregatedVehicle vehicle) {
    final statusColor = _getStatusColor(vehicle.status);

    return Card(
      elevation: 8,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        vehicle.registrationNumber.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${vehicle.name} | ${vehicle.type}',
                        style: const TextStyle(
                          color: EkaColors.textSecondary,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: statusColor.withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    vehicle.status.toUpperCase(),
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
            Row(
              children: [
                // Charge / SoC
                Expanded(
                  child: Row(
                    children: [
                      Icon(
                        Icons.battery_charging_full,
                        color: vehicle.charge > 20
                            ? EkaColors.successGreen2
                            : EkaColors.dangerRed,
                      ),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'CHARGE',
                            style: TextStyle(fontSize: 10, color: EkaColors.textSecondary),
                          ),
                          Text(
                            '${vehicle.charge.toStringAsFixed(0)}%',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Range
                Expanded(
                  child: Row(
                    children: [
                      const Icon(Icons.bolt, color: EkaColors.warningAmber),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'RANGE',
                            style: TextStyle(fontSize: 10, color: EkaColors.textSecondary),
                          ),
                          Text(
                            '${vehicle.rangeKm.toStringAsFixed(0)} km',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Updated: ${_formatLastUpdated(vehicle.lastUpdated)}',
                  style: const TextStyle(fontSize: 11, color: EkaColors.textSecondary),
                ),
                ElevatedButton.icon(
                  onPressed: () {
                    // Navigate to the vehicle details
                    final vehicleModel = VehicleModel(
                      id: vehicle.vehicleId,
                      vehicleRegNo: vehicle.registrationNumber,
                      vehicleType: vehicle.type,
                      fleetId: '',
                      deviceId: vehicle.vehicleId,
                      createdAt: vehicle.lastUpdated,
                    );
                    Navigator.push(context, VehicleDetailScreen.route(vehicleModel));
                  },
                  icon: const Icon(Icons.arrow_forward, size: 16),
                  label: const Text('Details'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    minimumSize: Size.zero,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _formatLastUpdated(String isoString) {
    try {
      final dt = DateTime.parse(isoString).toLocal();
      final now = DateTime.now();
      final diff = now.difference(dt);

      if (diff.inMinutes < 1) return 'Just now';
      if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
      if (diff.inHours < 24) return '${diff.inHours}h ago';
      return '${dt.day}/${dt.month} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return isoString;
    }
  }
}
