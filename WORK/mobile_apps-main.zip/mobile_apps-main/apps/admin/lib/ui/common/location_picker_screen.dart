import "package:ui/ui.dart";
import 'dart:async';
import 'package:admin/di/service_locator.dart';
import 'package:admin/models/location_result.dart';
import 'package:admin/service/google_maps_service.dart';
import 'package:admin/service/location_service.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';

class LocationPickerScreen extends StatefulWidget {
  final LatLng? initialLocation;

  const LocationPickerScreen({super.key, this.initialLocation});

  @override
  State<LocationPickerScreen> createState() => _LocationPickerScreenState();
}

class _LocationPickerScreenState extends State<LocationPickerScreen> {
  final Completer<GoogleMapController> _controller = Completer();
  final TextEditingController _searchController = TextEditingController();
  final GoogleMapsService _googleMapsService = getIt<GoogleMapsService>();
  final LocationService _locationService = getIt<LocationService>();

  late LatLng _currentPosition;
  String _currentAddress = "Loading...";
  bool _isSearching = false;
  List<Map<String, dynamic>> _predictions = [];
  Timer? _debounce;

  MapType _currentMapType = MapType.normal;

  @override
  void initState() {
    super.initState();
    _currentPosition =
        widget.initialLocation ?? _locationService.currentLocation;
  }

  void _onMapTypeChanged() {
    setState(() {
      _currentMapType = _currentMapType == MapType.normal
          ? MapType.satellite
          : MapType.normal;
    });
  }

  Future<void> _refreshPosition() async {
    await _locationService.refreshLocation();
    setState(() {
      _currentPosition = _locationService.currentLocation;
    });
    if (_controller.isCompleted) {
      final controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newLatLng(_currentPosition));
    }
  }

  void _onSearchChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () async {
      if (query.isNotEmpty) {
        final predictions = await _googleMapsService.searchPlaces(query);
        setState(() {
          _predictions = predictions;
          _isSearching = true;
        });
      } else {
        setState(() {
          _predictions = [];
          _isSearching = false;
        });
      }
    });
  }

  Future<void> _selectPrediction(Map<String, dynamic> prediction) async {
    final placeId = prediction['place_id'];
    final details = await _googleMapsService.getPlaceDetails(placeId);

    if (details != null) {
      final lat = details['geometry']['location']['lat'];
      final lng = details['geometry']['location']['lng'];
      final name = details['formatted_address'] ?? prediction['description'];

      setState(() {
        _currentPosition = LatLng(lat, lng);
        _currentAddress = name;
        _isSearching = false;
        _predictions = [];
        _searchController.text = name;
      });

      final controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newLatLng(_currentPosition));
    }
  }

  bool _isMapInitialized = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Container(
          margin: AppPadding.p8,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha:  0.1),
                blurRadius: 10,
              ),
            ],
          ),
          child: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.pop(context),
          ),
        ),
      ),
      body: Stack(
        children: [
          GoogleMap(
            mapType: _currentMapType,
            initialCameraPosition: CameraPosition(
              target: _currentPosition,
              zoom: 15,
            ),
            onMapCreated: (controller) {
              setState(() {
                _isMapInitialized = true;
              });
              _controller.complete(controller);
            },
            onCameraMove: (position) {
              setState(() {
                _currentPosition = position.target;
              });
            },
            onCameraIdle: () async {
              try {
                List<Placemark> placemarks = await placemarkFromCoordinates(
                  _currentPosition.latitude,
                  _currentPosition.longitude,
                );
                if (placemarks.isNotEmpty) {
                  final place = placemarks.first;
                  setState(() {
                    _currentAddress =
                        "${place.name}, ${place.subLocality}, ${place.locality}";
                    _searchController.text = _currentAddress;
                  });
                }
              } catch (e) {
                // Ignore geocoding errors
              }
            },
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
          ),
          if (!_isMapInitialized || !_locationService.isLocationReady)
            Container(
              color: Colors.white,
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text(
                      'Setting up map...',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ],
                ),
              ),
            ),
          // Center Marker
          Center(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 35),
              child: Icon(
                Icons.location_on,
                size: 45,
                color: Theme.of(context).primaryColor,
              ),
            ),
          ),
          // Search Bar
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: AppPadding.gutter,
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha:(0.1)),
                          blurRadius: 15,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: _onSearchChanged,
                      decoration: InputDecoration(
                        hintText: 'Search location...',
                        prefixIcon: const Icon(Icons.search),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  _searchController.clear();
                                  setState(() {
                                    _predictions = [];
                                    _isSearching = false;
                                  });
                                },
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 15,
                        ),
                      ),
                    ),
                  ),
                ),
                if (_isSearching && _predictions.isNotEmpty)
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha:(0.1)),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: _predictions.length,
                      separatorBuilder: (context, index) =>
                          const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final prediction = _predictions[index];
                        return ListTile(
                          leading: const Icon(Icons.location_on_outlined),
                          title: Text(prediction['description']),
                          onTap: () => _selectPrediction(prediction),
                        );
                      },
                    ),
                  ),
              ],
            ),
          ),
          // Map Controls (Right Side)
          Positioned(
            bottom: 110,
            right: 20,
            child: Column(
              children: [
                FloatingActionButton(
                  heroTag: 'map_type',
                  mini: true,
                  backgroundColor: Colors.white,
                  onPressed: _onMapTypeChanged,
                  child: const Icon(Icons.layers_outlined, color: Colors.black87),
                ),
                const SizedBox(height: 12),
                FloatingActionButton(
                  heroTag: 'my_location',
                  mini: true,
                  backgroundColor: Colors.white,
                  onPressed: _refreshPosition,
                  child: const Icon(Icons.my_location, color: Colors.black),
                ),
              ],
            ),
          ),
          // Confirm Button
          Positioned(
            bottom: 30,
            left: 20,
            right: 20,
            child: ElevatedButton(
              onPressed: () {
                Navigator.pop(
                  context,
                  LocationResult(
                    name:
                        _currentAddress.isNotEmpty &&
                            _currentAddress != "Loading..."
                        ? _currentAddress
                        : (_searchController.text.isNotEmpty
                              ? _searchController.text
                              : "Selected Location"),
                    latitude: _currentPosition.latitude,
                    longitude: _currentPosition.longitude,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 5,
              ),
              child: const Text(
                'Confirm Location',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
