import "package:ui/ui.dart";
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

mixin CommonFormMixin {
  /// Builds a section card with an icon, title, and children widgets.
  /// Used to group related form fields or display details.
  Widget buildSectionCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required List<Widget> children,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
            child: Row(
              children: [
                Container(
                  padding: AppPadding.p8,
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, size: 20, color: colorScheme.primary),
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.2,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  /// Builds a circular profile avatar with an optional change button.
  Widget buildProfileChangeAvatar(
    BuildContext context, {
    String? imageUrl,
    String? driverId,
    bool isEditable = true,
    bool isCard = true,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    Widget avatar = Hero(
      tag: 'driver_avatar_${driverId ?? 'new'}',
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 4),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: CircleAvatar(
          radius: 50,
          backgroundColor: colorScheme.surfaceContainerHighest,
          backgroundImage: (imageUrl != null && imageUrl.isNotEmpty)
              ? NetworkImage(imageUrl)
              : null,
          child: (imageUrl == null || imageUrl.isEmpty)
              ? Icon(
                  Icons.person,
                  size: 50,
                  color: colorScheme.onSurfaceVariant,
                )
              : null,
        ),
      ),
    );

    if (isEditable) {
      avatar = Stack(
        children: [
          avatar,
          Positioned(
            bottom: 0,
            right: 0,
            child: GestureDetector(
              onTap: () {
                // Image picking logic would go here
              },
              child: Container(
                padding: AppPadding.p8,
                decoration: BoxDecoration(
                  color: colorScheme.primary,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: const Icon(
                  Icons.camera_alt,
                  color: Colors.white,
                  size: 18,
                ),
              ),
            ),
          ),
        ],
      );
    }

    if (!isCard) return avatar;

    return Center(child: avatar);
  }

  /// Launches the system dialer with the given phone number.
  Future<void> launchDialer(String? phoneNumber) async {
    if (phoneNumber == null || phoneNumber.isEmpty) return;

    // Clean phone number: keep only positive (+) and numbers
    var cleaned = phoneNumber.replaceAll(RegExp(r'[^0-9+]'), '');
    
    // Default to +91 if not specified
    if (!cleaned.startsWith('+')) {
      cleaned = '+91$cleaned';
    }
    
    final Uri uri = Uri(scheme: 'tel', path: cleaned);

    try {
      await launchUrl(uri);
    } catch (e) {
      // In case launching fails, we can log it here
      debugPrint('Could not launch dialer: $e');
    }
  }
}
