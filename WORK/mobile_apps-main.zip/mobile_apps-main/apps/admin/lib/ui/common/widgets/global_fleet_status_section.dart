import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/models/dashboard/fleet_status_model.dart';
import 'package:admin/ui/dashboards/cubit/fleet_status_cubit.dart';
import 'package:admin/ui/driver/ui/widgets/charts.dart';

class GlobalFleetStatusSection extends StatelessWidget {
  final double? height;

  const GlobalFleetStatusSection({super.key, this.height});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FleetStatusCubit, FetchOnlyState<FleetStatusModel>>(
      builder: (context, state) {
        if (state.isLoading) {
          return DoughnutChartShimmer(
            title: 'Fleet Health Status',
            centerLabel: 'Total Vehicles',
            height: height ?? 280,
          );
        } else if (state.isError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Failed to load fleet status: ${state.errorMessage}',
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () => context.read<FleetStatusCubit>().load(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        }

        final status = state.data;
        if (status == null) {
          return const SizedBox.shrink();
        }

        return StatusDoughnutChart(
          title: 'Fleet Health Status',
          centerLabel: 'Total Vehicles',
          height: height ?? 280,
          data: [
            ChartDataPoint(
              'Active  ${status.active}',
              status.active.toDouble(),
              color: const Color(0xFF4CAF50),
            ),
            ChartDataPoint(
              'Inactive  ${status.inactive}',
              status.inactive.toDouble(),
              color: const Color(0xFF9E9E9E),
            ),
            ChartDataPoint(
              'Charging  ${status.charging}',
              status.charging.toDouble(),
              color: const Color(0xFF2196F3),
            ),
            ChartDataPoint(
              'Idle  ${status.idle}',
              status.idle.toDouble(),
              color: const Color(0xFFFF9800),
            ),
            ChartDataPoint(
              'Maintenance  ${status.maintenance}',
              status.maintenance.toDouble(),
              color: const Color(0xFFF44336),
            ),
          ],
        );
      },
    );
  }
}
