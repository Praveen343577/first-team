import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class ScrollableGoogleMap extends StatelessWidget {
  final CameraPosition initialCameraPosition;
  final MapCreatedCallback? onMapCreated;
  final Set<Marker> markers;
  final Set<Polyline> polylines;
  final bool zoomControlsEnabled;
  final bool mapToolbarEnabled;
  final bool myLocationButtonEnabled;
  final ArgumentCallback<LatLng>? onTap;
  final bool showExpandButton;

  const ScrollableGoogleMap({
    super.key,
    required this.initialCameraPosition,
    this.onMapCreated,
    this.markers = const <Marker>{},
    this.polylines = const <Polyline>{},
    this.zoomControlsEnabled = false,
    this.mapToolbarEnabled = false,
    this.myLocationButtonEnabled = false,
    this.onTap,
    this.showExpandButton = true,
  });

  @override
  Widget build(BuildContext context) {
    final mapWidget = GoogleMap(
      initialCameraPosition: initialCameraPosition,
      onMapCreated: onMapCreated,
      markers: markers,
      polylines: polylines,
      zoomControlsEnabled: zoomControlsEnabled,
      mapToolbarEnabled: mapToolbarEnabled,
      myLocationButtonEnabled: myLocationButtonEnabled,
      onTap: onTap,
      gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
        Factory<OneSequenceGestureRecognizer>(
          () => EagerGestureRecognizer(),
        ),
      },
    );

    if (!showExpandButton) {
      return mapWidget;
    }

    return Stack(
      children: [
        mapWidget,
        Positioned(
          top: 16,
          right: 16,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => FullScreenMapScreen(
                      initialCameraPosition: initialCameraPosition,
                      markers: markers,
                      polylines: polylines,
                      onTap: onTap,
                    ),
                  ),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Icon(Icons.fullscreen, color: Colors.black, size: 24),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class FullScreenMapScreen extends StatelessWidget {
  final CameraPosition initialCameraPosition;
  final Set<Marker> markers;
  final Set<Polyline> polylines;
  final ArgumentCallback<LatLng>? onTap;

  const FullScreenMapScreen({
    super.key,
    required this.initialCameraPosition,
    required this.markers,
    required this.polylines,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Map View'),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: GoogleMap(
        initialCameraPosition: initialCameraPosition,
        markers: markers,
        polylines: polylines,
        onTap: onTap,
        zoomControlsEnabled: true,
        mapToolbarEnabled: true,
        myLocationButtonEnabled: true,
        rotateGesturesEnabled: true,
        scrollGesturesEnabled: true,
        zoomGesturesEnabled: true,
        tiltGesturesEnabled: true,
      ),
    );
  }
}
