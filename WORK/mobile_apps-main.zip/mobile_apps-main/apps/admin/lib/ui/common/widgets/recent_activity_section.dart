import 'dart:async';
import 'package:admin/di/service_locator.dart';
import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/repository/recent_activity_repository.dart';
import 'package:admin/ui/common/widgets/recent_activity_navigator.dart';
import 'package:flutter/material.dart';

class RecentActivitySection extends StatefulWidget {
  final int limit;
  final List<String>? filterTypes;

  const RecentActivitySection({super.key, this.limit = 5, this.filterTypes});

  @override
  State<RecentActivitySection> createState() => _RecentActivitySectionState();
}

class _RecentActivitySectionState extends State<RecentActivitySection> {
  List<RecentActivityItem> _items = [];
  late final StreamSubscription<List<RecentActivityItem>> _subscription;

  @override
  void initState() {
    super.initState();
    final repo = getIt<RecentActivityRepository>();
    _subscription = repo.watchRecentItems(limit: widget.limit, filterTypes: widget.filterTypes).listen((items) {
      if (mounted) {
        setState(() {
          _items = items;
        });
      }
    });
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  IconData _iconForType(String type) {
    switch (type) {
      case 'route':
        return Icons.route;
      case 'vehicle':
        return Icons.directions_car;
      case 'driver':
        return Icons.person;
      case 'fleet':
        return Icons.local_shipping;
      case 'fleet_manager':
        return Icons.admin_panel_settings;
      default:
        return Icons.history;
    }
  }

  String _labelForType(String type) {
    switch (type) {
      case 'route':
        return 'Route';
      case 'vehicle':
        return 'Vehicle';
      case 'driver':
        return 'Driver';
      case 'fleet':
        return 'Fleet';
      case 'fleet_manager':
        return 'Manager';
      default:
        return type;
    }
  }

  String _timeAgo(DateTime dateTime) {
    final diff = DateTime.now().difference(dateTime);
    if (diff.inSeconds < 60) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recent Activity',
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        if (_items.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 16),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.history,
                      size: 40,
                      color: theme.colorScheme.onSurfaceVariant.withValues(
                        alpha: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'No recent activity',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Items you view will appear here',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant.withValues(
                          alpha: 0.7,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _items.length,
            separatorBuilder: (_, index) => const SizedBox(height: 4),
            itemBuilder: (context, index) {
              final item = _items[index];
              return _RecentActivityCard(
                item: item,
                icon: _iconForType(item.type),
                label: _labelForType(item.type),
                timeAgo: _timeAgo(item.viewedAt),
                onTap: () => _onItemTap(context, item),
              );
            },
          ),
      ],
    );
  }

  void _onItemTap(BuildContext context, RecentActivityItem item) {
    // Navigate based on type — import the necessary cubits/screens at usage site
    // This is a lightweight navigation helper
    RecentActivityNavigator.navigateTo(context, item);
  }
}

class _RecentActivityCard extends StatelessWidget {
  final RecentActivityItem item;
  final IconData icon;
  final String label;
  final String timeAgo;
  final VoidCallback onTap;

  const _RecentActivityCard({
    required this.item,
    required this.icon,
    required this.label,
    required this.timeAgo,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: cs.primaryContainer.withValues(alpha: 0.5),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: cs.primary, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item.title,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 6,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: cs.surfaceContainerHighest,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            label,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: cs.onSurfaceVariant,
                              fontSize: 10,
                            ),
                          ),
                        ),
                        if (item.subtitle != null) ...[
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              item.subtitle!,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: cs.onSurfaceVariant,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    timeAgo,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: cs.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Icon(
                    Icons.chevron_right,
                    size: 18,
                    color: cs.onSurfaceVariant,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
