import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

/// A base screen for forms that follow the "Premium" sectional design:
/// - Dark header background
/// - Transparent AppBar
/// - Stacked content
/// - Scaffold with sticky bottom navigation bar
abstract class FormBaseScreen<TCubit extends SubmitOnlyCubit>
    extends SubmitOnlyScreen<TCubit> {
  const FormBaseScreen({super.key});

  /// The main title shown in the header
  String get headerTitle;

  /// The descriptive subtitle shown in the header
  String get headerSubtitle;

  /// Optional: Height of the dark header background
  double get headerHeight => 220.0;

  /// Optional: Background color of the header
  Color get headerColor => const Color(0xff0B213F);

  /// Build the actual form fields/sections here
  Widget buildFormContent(BuildContext context, TCubit cubit);

  @override
  PreferredSizeWidget? get appBar => AppBar(
    backgroundColor: Colors.transparent,
    foregroundColor: Colors.white,
    elevation: 0,
    centerTitle: false,
  );

  @override
  Widget buildForm(BuildContext context, TCubit cubit) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          // Dark Header Background
          Container(
            height: headerHeight,
            color: headerColor,
            width: double.infinity,
          ),

          // Form Content
          Padding(
            padding: AppPadding.p16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 60), // Account for transparent AppBar
                Text(
                  headerTitle,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 28,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  headerSubtitle,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 16,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 24),
                buildFormContent(context, cubit),
                const SizedBox(height: 120),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
