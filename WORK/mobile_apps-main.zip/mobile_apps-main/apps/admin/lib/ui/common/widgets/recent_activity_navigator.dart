import 'package:admin/di/service_locator.dart';
import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/ui/route/cubit/route_detail_cubit.dart';
import 'package:admin/ui/route/ui/route_detail_screen.dart';
import 'package:admin/ui/driver/cubit/driver_detail_cubit.dart';
import 'package:admin/ui/driver/cubit/driver_scorecard_cubit.dart';
import 'package:admin/ui/driver/ui/screens/driver/driver_detail_screen.dart';
import 'package:admin/ui/fleet/cubit/fleet_detail_cubit.dart';
import 'package:admin/ui/fleet/ui/fleet_detail_screen.dart';
import 'package:admin/repository/fleet_manager_repository.dart';
import 'package:admin/ui/users/cubit/fleet_manager_detail_cubit.dart';
import 'package:admin/ui/users/ui/fleet_manager_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// Centralized navigation for recent activity items.
class RecentActivityNavigator {
  RecentActivityNavigator._();

  static void navigateTo(BuildContext context, RecentActivityItem item) {
    switch (item.type) {
      case 'route':
        _navigateToRoute(context, item.id);
        break;
      case 'driver':
        _navigateToDriver(context, item.id);
        break;
      case 'fleet':
        _navigateToFleet(context, item.id);
        break;
      case 'fleet_manager':
        _navigateToFleetManager(context, item.id);
        break;
      // Vehicle detail requires a full VehicleModel, not just an id.
      // We still record vehicles in recent activity but skip re-navigation.
      default:
        break;
    }
  }

  static void _navigateToRoute(BuildContext context, String routeId) {
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        builder: (_) => BlocProvider(
          create: (_) => getIt<RouteDetailCubit>(param1: routeId),
          child: RouteDetailScreen(routeId: routeId),
        ),
      ),
    );
  }

  static void _navigateToDriver(BuildContext context, String driverId) {
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        builder: (_) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (_) => DriverDetailCubit(
                getIt<DriverRepository>(),
                driverId: driverId,
              ),
            ),
            BlocProvider(
              create: (_) => DriverScorecardCubit(
                getIt<DriverRepository>(),
                driverId: driverId,
              )..load(),
            ),
          ],
          child: const Material(child: DriverDetailScreen()),
        ),
      ),
    );
  }

  static void _navigateToFleet(BuildContext context, String fleetId) {
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        builder: (_) => BlocProvider(
          create: (_) => FleetDetailCubit(
            getIt<FleetRepository>(),
            fleetId: fleetId,
          ),
          child: const FleetDetailScreen(),
        ),
      ),
    );
  }

  static void _navigateToFleetManager(BuildContext context, String managerId) {
    Navigator.of(context, rootNavigator: true).push(
      MaterialPageRoute(
        builder: (_) => BlocProvider(
          create: (_) => FleetManagerDetailCubit(
            getIt<FleetManagerRepository>(),
            managerId: managerId,
          ),
          child: const FleetManagerDetailScreen(),
        ),
      ),
    );
  }
}
