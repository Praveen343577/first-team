import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/models/vehicle/aggregated_vehicle.dart';
import 'package:admin/ui/fleet/cubit/aggregated_vehicles_cubit.dart';
import 'package:admin/ui/driver/ui/widgets/charts.dart';

class FleetHealthStatusSection extends StatefulWidget {
  final double? height;

  const FleetHealthStatusSection({super.key, this.height});

  @override
  State<FleetHealthStatusSection> createState() => _FleetHealthStatusSectionState();
}

class _FleetHealthStatusSectionState extends State<FleetHealthStatusSection> {
  String _selectedType = 'All';

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AggregatedVehiclesCubit, FetchOnlyState<List<AggregatedVehicle>>>(
      builder: (context, state) {
        if (state.isLoading) {
          return DoughnutChartShimmer(
            title: 'Fleet Health Status',
            centerLabel: 'Total Vehicles',
            height: widget.height ?? 280,
          );
        } else if (state.isError) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Failed to load fleet status: ${state.errorMessage}',
                    style: const TextStyle(color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton(
                    onPressed: () => context.read<AggregatedVehiclesCubit>().load(),
                    child: const Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        }

        final vehicles = state.data ?? <AggregatedVehicle>[];
        
        final vehicleTypes = vehicles
            .map((v) => v.type)
            .where((t) => t.isNotEmpty)
            .toSet()
            .toList();
        vehicleTypes.sort();

        if (_selectedType != 'All' && !vehicleTypes.contains(_selectedType)) {
          _selectedType = 'All';
        }

        final filteredVehicles = _selectedType == 'All'
            ? vehicles
            : vehicles.where((v) => v.type == _selectedType).toList();

        final activeCount = filteredVehicles.where((v) {
          final s = v.status.toLowerCase();
          return s == 'active' || s == 'running' || s == 'online';
        }).length;

        final chargingCount = filteredVehicles.where((v) => v.status.toLowerCase() == 'charging').length;

        final idleCount = filteredVehicles.where((v) => v.status.toLowerCase() == 'idle').length;

        final maintenanceCount = filteredVehicles.where((v) => v.status.toLowerCase() == 'maintenance').length;

        final inactiveCount = filteredVehicles.where((v) {
          final s = v.status.toLowerCase();
          return s == 'inactive' || s == 'offline';
        }).length;

        final isDark = Theme.of(context).brightness == Brightness.dark;

        return StatusDoughnutChart(
          title: 'Fleet Health Status',
          centerLabel: 'Total Vehicles',
          height: widget.height ?? 280,
          trailing: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
            decoration: BoxDecoration(
              color: isDark ? Colors.grey.shade800 : Colors.grey.shade100,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: isDark ? Colors.grey.shade700 : Colors.grey.shade300,
                width: 1,
              ),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                isDense: true,
                value: _selectedType,
                dropdownColor: isDark ? Colors.grey.shade800 : Colors.white,
                icon: const Icon(Icons.arrow_drop_down, color: Colors.grey, size: 20),
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: isDark ? Colors.white70 : Colors.black87,
                ),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    setState(() {
                      _selectedType = newValue;
                    });
                  }
                },
                items: ['All', ...vehicleTypes].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ),
          ),
          data: [
            ChartDataPoint(
              'Active  $activeCount',
              activeCount.toDouble(),
              color: const Color(0xFF4CAF50),
            ),
            ChartDataPoint(
              'Inactive  $inactiveCount',
              inactiveCount.toDouble(),
              color: const Color(0xFF9E9E9E),
            ),
            ChartDataPoint(
              'Charging  $chargingCount',
              chargingCount.toDouble(),
              color: const Color(0xFF2196F3),
            ),
            ChartDataPoint(
              'Idle  $idleCount',
              idleCount.toDouble(),
              color: const Color(0xFFFF9800),
            ),
            ChartDataPoint(
              'Maintenance  $maintenanceCount',
              maintenanceCount.toDouble(),
              color: const Color(0xFFF44336),
            ),
          ],
        );
      },
    );
  }
}
