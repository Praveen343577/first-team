import 'package:flutter/material.dart';

class TabNavigator extends StatelessWidget {
  final Widget root;
  final GlobalKey<NavigatorState> navigatorKey;

  const TabNavigator({
    super.key,
    required this.root,
    required this.navigatorKey,
  });

  @override
  Widget build(BuildContext context) {
    return Navigator(
      key: navigatorKey,
      onGenerateRoute: (routeSettings) {
        return MaterialPageRoute(
          builder: (context) => root,
        );
      },
    );
  }
}
