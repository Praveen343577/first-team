import 'package:admin/ui/driver/cubit/update_driver_profile_cubit.dart';
import 'package:admin/ui/driver/mixin/driver_profile_form_mixin.dart';
import 'package:admin/ui/common/mixin/common_form_mixin.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/ui/common/form_base_screen.dart';

class UpdateDriverProfileScreen
    extends FormBaseScreen<UpdateDriverProfileCubit>
    with CommonFormMixin, DriverProfileFormMixin {
  const UpdateDriverProfileScreen({super.key});

  @override
  String get headerTitle => 'Update Driver Profile';

  @override
  String get headerSubtitle => 'Update the driver details in the system.';

  @override
  void onSubmitSuccess(BuildContext context, UpdateDriverProfileCubit cubit) {
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Driver profile updated successfully!')),
    );
  }

  @override
  Widget? get bottomNavigationBar => Builder(
    builder:
        (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: BlocBuilder<UpdateDriverProfileCubit, SubmitOnlyState>(
              builder: (context, state) {
                return ElevatedButton(
                  onPressed:
                      state.isSubmitting
                          ? null
                          : () => context.read<UpdateDriverProfileCubit>().submit(),
                  child: Text(state.isSubmitting ? 'Updating...' : 'Update Driver'),
                );
              },
            ),
          ),
        ),
  );

  @override
  Widget buildFormContent(
    BuildContext context,
    UpdateDriverProfileCubit cubit,
  ) {
    return buildDriverProfileFields(
      context,
      cubit.formBloc,
      driverId: cubit.driverId,
    );
  }
}
