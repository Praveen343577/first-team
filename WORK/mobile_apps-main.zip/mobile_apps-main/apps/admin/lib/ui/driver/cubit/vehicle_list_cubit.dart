import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/models/vehicle/dto/vehicle_list_request_dto.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/repository/vehicle_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

enum VehicleSortOption { regNoAsc, regNoDesc, newest, oldest }

@injectable
class VehicleListCubit extends FetchOnlyCubit<List<VehicleModel>>
    with SearchableCubit {
  final VehicleRepository _vehicleRepository;
  final FleetRepository _fleetRepository;

  VehicleListCubit(this._vehicleRepository, this._fleetRepository);

  String _searchQuery = '';
  VehicleSortOption _sortOption = VehicleSortOption.regNoAsc;
  String? _typeFilter;
  FleetModel? _selectedFleet;
  List<FleetModel> _fleets = [];

  @override
  String get searchQuery => _searchQuery;
  VehicleSortOption get sortOption => _sortOption;
  String? get typeFilter => _typeFilter;
  FleetModel? get selectedFleet => _selectedFleet;
  List<FleetModel> get fleets => _fleets;

  @override
  void setSearchQuery(String query) {
    _searchQuery = query;
    load();
  }

  void updateFiltersAndSort({
    String? typeFilter,
    FleetModel? selectedFleet,
    VehicleSortOption? sortOption,
    bool clearAll = false,
  }) {
    if (clearAll) {
      _typeFilter = null;
      _selectedFleet = null;
      _sortOption = VehicleSortOption.regNoAsc;
    } else {
      if (typeFilter != null || typeFilter == null) _typeFilter = typeFilter;
      _selectedFleet = selectedFleet;
      if (sortOption != null) _sortOption = sortOption;
    }
    load();
  }

  /// Load fleets first
  Future<void> loadFleets() async {
    _fleets = await _fleetRepository.getFleets();
    load();
  }

  @override
  Future<List<VehicleModel>> fetchData() async {
    final vehicles = await _vehicleRepository.getVehicles(
      const VehicleListRequestDto(fleetId: null),
    );
    return _applyFiltersAndSort(vehicles);
  }

  List<VehicleModel> _applyFiltersAndSort(List<VehicleModel> vehicles) {
    var result = vehicles.where((v) {
      final matchesSearch =
          _searchQuery.isEmpty ||
          v.vehicleRegNo.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          v.deviceId.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesType = _typeFilter == null || v.vehicleType == _typeFilter;
      final matchesFleet =
          _selectedFleet == null || v.fleetId == _selectedFleet!.id;
      return matchesSearch && matchesType && matchesFleet;
    }).toList();

    switch (_sortOption) {
      case VehicleSortOption.regNoAsc:
        result.sort((a, b) => a.vehicleRegNo.compareTo(b.vehicleRegNo));
      case VehicleSortOption.regNoDesc:
        result.sort((a, b) => b.vehicleRegNo.compareTo(a.vehicleRegNo));
      case VehicleSortOption.newest:
        result.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      case VehicleSortOption.oldest:
        result.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    }
    return result;
  }
}
