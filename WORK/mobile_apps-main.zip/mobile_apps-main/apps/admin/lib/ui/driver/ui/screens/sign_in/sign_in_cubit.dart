import 'package:flutter/foundation.dart';
import 'package:admin/models/login/dto/login_request_dto.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/ui/driver/ui/screens/sign_in/login_form_bloc.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class SignInCubit extends BaseCubit<void> {
  final AuthRepository _authRepository;
  final LoginFormBloc formBloc;

  SignInCubit({
    required this.formBloc,
    required AuthRepository authRepository,
  }) : _authRepository = authRepository;

  @override
  @protected
  Future<void> performSubmit() async {
    // Validate form
    if (!formBloc.state.isValid()) {
      throw Exception('Please fill all required fields');
    }

    // Perform login
    await _authRepository.login(
      LoginRequestDto(
        username: formBloc.email.value,
        password: formBloc.password.value,
      ),
    );
  }
}
