import 'package:admin/di/service_locator.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:admin/ui/driver/cubit/driver_list_cubit.dart';
import 'package:admin/ui/driver/ui/screens/driver/driver_list_screen.dart';
import 'package:admin/ui/driver/ui/screens/routes/dashboard_base.dart';
import 'package:admin/ui/driver/ui/widgets/charts.dart';
import 'package:admin/ui/driver/ui/widgets/detailed_navigation_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:ui/ui.dart';
import 'package:admin/ui/common/widgets/recent_activity_section.dart';

class DriverDashboard extends DashboardBase {
  @override
  Tab get tab => const Tab(icon: Icon(Icons.person), text: 'Driver');

  const DriverDashboard({super.key})
    : super(
        title: "Driver",
        description: "Monitor ongoing trips, schedules, and route performance.",
      );

  @override
  List<Widget> buildContent(_) => [
    const Padding(
      padding: AppPadding.gutter,
      child: RevenueLineChart(),
    ),
    const Padding(
      padding: AppPadding.gutter,
      child: RecentActivitySection(),
    ),
  ];

  @override
  Widget buildStickyHeader(context) => DetailedNavigationCard(
    title: 'Drivers',
    subtitle: 'Driver Status & Performance',
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) =>
                DriverListCubit(getIt<DriverRepository>())..load(),
            child: const Material(child: DriverListScreen()),
          ),
        ),
      );
    },
    leadingIcon: Icons.person_pin,
  );
}
