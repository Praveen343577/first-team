import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:admin/models/telemetry/dto/telemetry_history_request_dto.dart';
import 'package:admin/models/telemetry/dto/telemetry_history_response_dto.dart';
import 'package:admin/models/telemetry/mapper.dart';
import 'package:admin/models/telemetry/telemetry_model.dart';
import 'package:admin/models/token/token_store.dart';
import 'package:admin/repository/telemetry_repository.dart';
import 'package:admin/service/vehicle_websocket_service.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class TelemetryHistoryCubit extends BaseCubit<List<TelemetryModel>> {
  final TelemetryRepository _repository;
  final VehicleWebSocketService _wsService;
  final TokenStore _tokenStore;
  StreamSubscription? _wsSubscription;
  late TelemetryHistoryRequestDto _request;

  TelemetryHistoryCubit(
    this._repository,
    this._wsService,
    this._tokenStore,
  );

  void loadHistory(TelemetryHistoryRequestDto request) {
    _request = request;
    load();
  }

  @override
  Future<List<TelemetryModel>> performSubmit() async {
    List<TelemetryModel> data;
    try {
      data = await _repository.getHistory(_request);
    } catch (e) {
      debugPrint('Failed to load history from repository: $e. Falling back to mock data.');
      // Simulated delay for realistic mock
      await Future<void>.delayed(const Duration(milliseconds: 500));

      // For now, return mock data as fallback
      final List<TelemetryModel> mockData = [];
      final startTime = DateTime.tryParse(_request.startTime) ?? DateTime.now();
      
      for (int i = 19; i >= 0; i--) {
        mockData.add(
          TelemetryModel(
            ts: startTime.subtract(Duration(minutes: (19 - i) * 5)).toIso8601String(),
            deviceId: _request.deviceId,
            vehicleRegNo: 'MH12EK1234',
            // Pune area coordinates as sample
            latitude: 18.5204 + (i * 0.005), 
            longitude: 73.8567 + (i * 0.005),
            speed: 40.0 + (i % 5 * 10),
            odometer: 1000.0 + (i * 0.5),
            heading: 90.0,
            altitude: 560.0,
            ignition: 1,
            mainPowerStatus: i % 10 == 0 ? 0 : 1, // Simulate power toggle
            mainInputVoltage: 24.5,
            internalBatteryVoltage: 4.2,
            gsmStrength: 80,
            gpsFix: 3,
            noOfSatellites: 12,
            operatorName: 'Jio 4G',
          ),
        );
      }
      data = mockData;
    }

    _connectWebSocket();

    return data;
  }

  Future<void> _connectWebSocket() async {
    await _wsSubscription?.cancel();
    
    await _tokenStore.loadToken();
    final token = _tokenStore.token;
    if (token == null) {
      debugPrint('Token is null, cannot connect WebSocket');
      return;
    }

    try {
      await _wsService.connect(
        token: token,
        deviceId: _request.deviceId,
      );

      _wsSubscription = _wsService.messages.listen(
        (message) {
          _onWebSocketMessage(message);
        },
        onError: (err) {
          debugPrint('TelemetryHistoryCubit WebSocket error: $err');
        },
      );
    } catch (e) {
      debugPrint('Error connecting WebSocket: $e');
    }
  }

  void _onWebSocketMessage(dynamic message) {
    try {
      Map<String, dynamic> jsonMap;
      if (message is String) {
        jsonMap = jsonDecode(message) as Map<String, dynamic>;
      } else if (message is Map<String, dynamic>) {
        jsonMap = message;
      } else {
        debugPrint('Unknown WebSocket message format: $message');
        return;
      }

      final dto = TelemetryHistoryResponseDto.fromJson(jsonMap);
      final mapper = TelemetryMapper();
      final newTelemetry = mapper.convert<TelemetryHistoryResponseDto, TelemetryModel>(dto);

      final currentState = state;
      if (currentState is BaseSuccess<List<TelemetryModel>>) {
        final currentList = List<TelemetryModel>.from(currentState.data);
        if (newTelemetry.deviceId == _request.deviceId) {
          currentList.insert(0, newTelemetry);
          if (currentList.length > 100) {
            currentList.removeLast();
          }
          emit(BaseSuccess<List<TelemetryModel>>(currentList));
        }
      }
    } catch (e, stack) {
      debugPrint('Error handling WebSocket message: $e\n$stack');
    }
  }

  @override
  Future<void> close() async {
    await _wsSubscription?.cancel();
    _wsService.disconnect();
    return super.close();
  }
}
