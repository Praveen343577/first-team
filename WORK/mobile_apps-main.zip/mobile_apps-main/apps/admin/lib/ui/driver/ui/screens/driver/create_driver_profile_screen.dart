import 'package:admin/ui/driver/cubit/create_driver_profile_cubit.dart';
import 'package:admin/ui/driver/mixin/driver_profile_form_mixin.dart';
import 'package:admin/ui/common/mixin/common_form_mixin.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/ui/common/form_base_screen.dart';

class CreateDriverProfileScreen
    extends FormBaseScreen<CreateDriverProfileCubit>
    with CommonFormMixin, DriverProfileFormMixin {
  const CreateDriverProfileScreen({super.key});

  @override
  String get headerTitle => 'Create Driver Profile';

  @override
  String get headerSubtitle =>
      'Enter the details to register a new driver in the system.';

  @override
  void onSubmitSuccess(BuildContext context, CreateDriverProfileCubit cubit) {
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Driver profile created successfully!')),
    );
  }

  @override
  Widget? get bottomNavigationBar => Builder(
    builder:
        (context) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: BlocBuilder<CreateDriverProfileCubit, SubmitOnlyState>(
              builder: (context, state) {
                return ElevatedButton(
                  onPressed:
                      state.isSubmitting
                          ? null
                          : () => context.read<CreateDriverProfileCubit>().submit(),
                  child: Text(state.isSubmitting ? 'Creating...' : 'Create Driver'),
                );
              },
            ),
          ),
        ),
  );

  @override
  Widget buildFormContent(
    BuildContext context,
    CreateDriverProfileCubit cubit,
  ) {
    return buildDriverProfileFields(context, cubit.formBloc);
  }
}
