import 'package:flutter/foundation.dart';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:state_handler/state_handler.dart';

class ImageUploadCubit extends BaseCubit<void> {
  final DriverRepository _driverRepository;
  String? _driverId;
  File? _file;

  ImageUploadCubit(this._driverRepository);

  Future<void> upload({required String driverId, required File file}) async {
    _driverId = driverId;
    _file = file;
    return submit();
  }

  @override
  @protected
  Future<void> performSubmit() async {
    if (_driverId == null || _file == null) {
      throw Exception('Driver ID and file are required');
    }

    final multipartFile = await MultipartFile.fromFile(
      _file!.path,
      filename: _file!.path.split('/').last,
    );

    await _driverRepository.uploadProfilePic(
      driverId: _driverId!,
      file: multipartFile,
    );
  }
}
