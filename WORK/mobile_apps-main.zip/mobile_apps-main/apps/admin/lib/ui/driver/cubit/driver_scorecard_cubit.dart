import 'package:admin/models/driver/dto/driver_scorecard_response_dto.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

enum ScorecardPeriod {
  today('today'),
  week('week'),
  month('month');

  final String value;
  const ScorecardPeriod(this.value);
}

@injectable
class DriverScorecardCubit extends FetchOnlyCubit<DriverScorecardResponseDto> {
  final DriverRepository _repository;
  final String driverId;
  ScorecardPeriod _currentPeriod = ScorecardPeriod.week;

  DriverScorecardCubit(
    this._repository, {
    @factoryParam required this.driverId,
  });

  ScorecardPeriod get period => _currentPeriod;

  void changePeriod(ScorecardPeriod newPeriod) {
    _currentPeriod = newPeriod;
    load();
  }

  @override
  Future<DriverScorecardResponseDto> fetchData() {
    return _repository.getScorecard(
      driverId: driverId,
      period: _currentPeriod.value,
    );
  }
}
