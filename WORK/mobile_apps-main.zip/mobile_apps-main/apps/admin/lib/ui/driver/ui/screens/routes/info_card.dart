import 'package:flutter/material.dart';

class TripLogisticsCard extends StatelessWidget {
  const TripLogisticsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color.fromARGB(255, 24, 117, 133),
            Color.fromARGB(255, 39, 181, 237),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Trip Logistics',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Today's schedule overview",
                      style: TextStyle(color: Colors.white70, fontSize: 16),
                    ),
                  ],
                ),
                Icon(Icons.send_rounded, color: Colors.white, size: 30),
              ],
            ),
            const SizedBox(height: 30),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatusItem('1240', 'PLANNED', Colors.white),
                vertBorder(),
                _buildStatusItem('458', 'ONGOING', Colors.yellow[600]!),
                vertBorder(),
                _buildStatusItem('680', 'COMPLETED', Colors.greenAccent),
              ],
            ),
          ],
        ),
      ),
    );
  }

  SizedBox vertBorder() {
    return SizedBox(
      height: 60,
      child: const VerticalDivider(
        color: Colors.white24,
        width: 2,
        thickness: 1,
      ),
    );
  }

  Widget _buildStatusItem(String count, String label, Color countColor) {
    return Column(
      children: [
        Text(
          count,
          style: TextStyle(
            color: countColor,
            fontSize: 40,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(label, style: TextStyle(color: Colors.white70, fontSize: 14)),
      ],
    );
  }
}
