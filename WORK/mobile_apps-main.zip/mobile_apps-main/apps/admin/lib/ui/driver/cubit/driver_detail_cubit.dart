import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class DriverDetailCubit extends BaseCubit<DriverModel> {
  final DriverRepository _repository;
  final String driverId;

  DriverDetailCubit(
    this._repository, {
    @factoryParam required this.driverId,
  });

  @override
  Future<DriverModel> performSubmit() async {
    return _repository.getDriverProfile(driverId);
  }

  Future<void> delete() async {
    await _repository.deleteDriver(driverId);
  }
}
