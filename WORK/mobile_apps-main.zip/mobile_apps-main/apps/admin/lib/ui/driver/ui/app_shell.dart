import 'package:admin/di/service_locator.dart';
import 'package:admin/models/user_role.dart';
import 'package:admin/service/permission_service.dart';
import 'package:admin/ui/app_navigation/tab_navigator.dart';
import 'package:admin/ui/driver/ui/screens/home/home_screen.dart';
import 'package:admin/ui/driver/ui/screens/setting/setting_screen.dart';
import 'package:admin/ui/driver/ui/screens/fleet/fleet_dashboard.dart';
import 'package:admin/ui/driver/ui/screens/routes/route_dashboard.dart';
import 'package:admin/ui/users/users_dashboard.dart';
import 'package:flutter/material.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _currentIndex = 0;

  final Map<int, GlobalKey<NavigatorState>> _navigatorKeys = {
    0: GlobalKey<NavigatorState>(),
    1: GlobalKey<NavigatorState>(),
    2: GlobalKey<NavigatorState>(),
    3: GlobalKey<NavigatorState>(),
    4: GlobalKey<NavigatorState>(),
  };

  @override
  void initState() {
    super.initState();
    // Request location permission on launch
    WidgetsBinding.instance.addPostFrameCallback((_) {
      getIt<PermissionService>().requestLocationPermission();
    });
  }

  void _onTap(int index) {
    if (_currentIndex == index) {
      // Pop to root if tapping the same tab
      _navigatorKeys[index]?.currentState?.popUntil((route) => route.isFirst);
    } else {
      setState(() => _currentIndex = index);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isAdmin = AppRoleState.isAdmin;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final navigator = _navigatorKeys[_currentIndex]?.currentState;
        if (navigator != null && navigator.canPop()) {
          navigator.pop();
        }
      },
      child: Scaffold(
        body: IndexedStack(
          index: _currentIndex,
          children: [
            TabNavigator(
              navigatorKey: _navigatorKeys[0]!,
              root: const HomeScreen(),
            ),
            TabNavigator(
              navigatorKey: _navigatorKeys[1]!,
              root: const RouteDashboard(),
            ),
            TabNavigator(
              navigatorKey: _navigatorKeys[2]!,
              root: const FleetDashboard(),
            ),
            if (isAdmin)
              TabNavigator(
                navigatorKey: _navigatorKeys[3]!,
                root: const UsersDashboard(),
              )
            else
              const SizedBox.shrink(),
            TabNavigator(
              navigatorKey: _navigatorKeys[4]!,
              root: const SettingScreen(),
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: _onTap,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : Theme.of(context).primaryColor,
          unselectedItemColor: Colors.grey,
          showUnselectedLabels: true,
          items: [
            const BottomNavigationBarItem(
              icon: Icon(Icons.dashboard_outlined),
              activeIcon: Icon(Icons.dashboard),
              label: 'Dashboard',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.route_outlined),
              activeIcon: Icon(Icons.route),
              label: 'Routes',
            ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.local_shipping_outlined),
              activeIcon: Icon(Icons.local_shipping),
              label: 'Fleet',
            ),
            if (isAdmin)
              const BottomNavigationBarItem(
                icon: Icon(Icons.people_outlined),
                activeIcon: Icon(Icons.people),
                label: 'Users',
              ),
            const BottomNavigationBarItem(
              icon: Icon(Icons.settings_outlined),
              activeIcon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }
}
