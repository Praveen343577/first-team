import 'package:admin/models/profile/dto/profile_dto.dart';
import 'package:admin/service/api/client_api.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

// part 'profile_state.dart';
@LazySingleton()
class ProfileCubit extends BaseCubit<ProfileDTO> {
  final ClientApi _clientApi;
  ProfileCubit(this._clientApi);

  @override
  Future<ProfileDTO> performSubmit() async => _clientApi.getMe();
}
