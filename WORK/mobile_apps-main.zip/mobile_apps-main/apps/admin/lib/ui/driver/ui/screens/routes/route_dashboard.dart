import 'package:admin/di/service_locator.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/ui/driver/ui/screens/routes/dashboard_base.dart';
import 'package:admin/ui/driver/ui/screens/routes/route_list_screen.dart';
import 'package:admin/ui/driver/ui/widgets/charts.dart';
import 'package:admin/ui/driver/ui/widgets/detailed_navigation_card.dart';
import 'package:admin/ui/route/cubit/route_list_cubit.dart';
import 'package:admin/models/dashboard/trip_stats_model.dart';
import 'package:admin/ui/dashboards/cubit/trip_stats_cubit.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:flutter/material.dart';
import 'package:admin/ui/common/widgets/recent_activity_section.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';
import 'package:intl/intl.dart';

class RouteDashboard extends DashboardBase {
  @override
  Tab get tab => const Tab(icon: Icon(Icons.route), text: 'Routes');

  const RouteDashboard({super.key})
    : super(
        title: "Routes",
        description: "Monitor ongoing trips, schedules, and route performance.",
      );

  @override
  List<Widget> buildContent(BuildContext context) => [
    _buildTripStatsSection(context),
    const Padding(
      padding: AppPadding.gutter,
      child: RecentActivitySection(),
    ),
  ];

  Widget _buildTripStatsSection(BuildContext context) {
    return Padding(
      padding: AppPadding.gutter,
      child: BlocBuilder<TripStatsCubit, FetchOnlyState<TripStatsModel>>(
        builder: (context, state) {
          if (state.isLoaded) {
            return _buildTripStatsChart(context, state.data!);
          } else if (state.isError) {
            return Center(
              child: Text(
                'Failed to load trip stats: ${state.errorMessage}',
                style: const TextStyle(color: Colors.red),
              ),
            );
          }
          return const ChartShimmer(title: 'Trip Statistics');
        },
      ),
    );
  }



  Widget _buildTripStatsChart(BuildContext context, TripStatsModel model) {
    final List<ChartDataPoint> data = [
      ChartDataPoint(
        'Planned',
        model.planned.toDouble(),
        color: const Color(0xFF9E9E9E),
      ),
      ChartDataPoint(
        'Ongoing',
        model.ongoing.toDouble(),
        color: const Color(0xFF2196F3),
      ),
      ChartDataPoint(
        'Completed',
        model.completed.toDouble(),
        color: const Color(0xFF4CAF50),
      ),
      ChartDataPoint(
        'Cancelled',
        model.cancelled.toDouble(),
        color: const Color(0xFFF44336),
      ),
    ];

    final maxVal = [
      model.planned,
      model.ongoing,
      model.completed,
      model.cancelled,
    ].fold<int>(0, (max, e) => e > max ? e : max);
    final double? yInterval = maxVal <= 5 ? 1.0 : null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Trip Statistics',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.blue.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Total: ${model.total}',
                    style: const TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 220,
              child: SfCartesianChart(
                plotAreaBorderWidth: 0,
                primaryXAxis: CategoryAxis(
                  majorGridLines: const MajorGridLines(width: 0),
                  labelStyle: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color:
                        Theme.of(context).textTheme.bodySmall?.color ??
                        Colors.grey,
                  ),
                ),
                primaryYAxis: NumericAxis(
                  axisLine: const AxisLine(width: 0),
                  majorTickLines: const MajorTickLines(size: 0),
                  numberFormat: NumberFormat('###'),
                  interval: yInterval,
                  labelStyle: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color:
                        Theme.of(context).textTheme.bodySmall?.color ??
                        Colors.grey,
                  ),
                ),
                series: <CartesianSeries<ChartDataPoint, String>>[
                  ColumnSeries<ChartDataPoint, String>(
                    dataSource: data,
                    xValueMapper: (ChartDataPoint p, _) => p.label,
                    yValueMapper: (ChartDataPoint p, _) => p.value,
                    pointColorMapper: (ChartDataPoint p, _) => p.color,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(6),
                    ),
                    dataLabelSettings: DataLabelSettings(
                      isVisible: true,
                      textStyle: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).textTheme.bodyMedium?.color,
                      ),
                      labelAlignment: ChartDataLabelAlignment.top,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget buildStickyHeader(BuildContext context) => DetailedNavigationCard(
    title: 'Routes',
    subtitle: 'Manage and configure service routes',
    onTap: () {
      Navigator.of(context, rootNavigator: true).push(
        MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) =>
                RouteListCubit(getIt<RouteRepository>())..load(),
            child: const RouteListScreen(useScaffold: true),
          ),
        ),
      );
    },
    leadingIcon: Icons.route,
  );
}
