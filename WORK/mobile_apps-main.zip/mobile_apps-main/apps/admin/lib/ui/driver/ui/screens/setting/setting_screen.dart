import 'package:admin/di/service_locator.dart';
import 'package:admin/ui/driver/ui/screens/routes/dashboard_base.dart';
import 'package:admin/ui/driver/ui/screens/setting/widgets/setting_panel.dart';
import 'package:admin/ui/driver/ui/screens/setting/widgets/setting_tile.dart';
import 'package:admin/ui/driver/ui/screens/setting/logout_cubit.dart';
import 'package:app_settings/app_settings.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';
import 'package:go_router/go_router.dart';
import 'package:admin/ui/common/widgets/eka_snack_bar.dart';

class SettingScreen extends DashboardBase {
  @override
  Tab get tab => const Tab(icon: Icon(Icons.settings), text: 'Setting');

  const SettingScreen({super.key})
    : super(
        title: 'Setting',
        description: 'Manage your account settings and preferences.',
      );

  @override
  List<Widget> buildContent(BuildContext context) => [
    appearance(),
    legalAndSupport(),
    // notifications(),
    signOut(context),
    Padding(
      padding: AppPadding.gutter,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'EKA Connect v${getIt<PackageInfo>().version}',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          Text(
            '© 2024 EKA Mobility. All rights reserved.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ],
      ),
    ),
  ];
  Widget signOut(BuildContext context) {
    return BlocProvider(
      create: (_) => getIt<LogoutCubit>(),
      child: BlocConsumer<LogoutCubit, SubmitOnlyState>(
        listener: (context, state) {
          if (state.isSuccess) {
            EkaSnackBar.showSuccess('Logged out successfully');
            context.go('/login');
          } else if (state.isError) {
            EkaSnackBar.showError(state.errorMessage ?? 'Error logging out');
          }
        },
        builder: (context, state) {
          return Padding(
            padding: AppPadding.gutter,
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    'Sign Out',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Securely log out of your account on this device.',
                    style: TextStyle(color: Colors.grey),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: state.isSubmitting
                        ? null
                        : () => context.read<LogoutCubit>().submit(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: EkaColors.dangerRed,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    icon: state.isSubmitting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.logout),
                    label: Text(
                      state.isSubmitting ? 'Logging Out...' : 'Sign Out',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  SettingPanel appearance() {
    return SettingPanel(
      'Appearance',
      items: [
        SettingTile(
          title: 'Dark Theme',
          subtitle: 'Switch between light and dark mode',
          icon: ThemeBuilder.getThemeSettingData().$1,
          iconColor: ThemeBuilder.getThemeSettingData().$2, // Green

          trailing: ThemeBuilder(
            builder: (context, themeMode) {
              return Switch.adaptive(
                value: themeMode.brightness == Brightness.dark,
                onChanged: (bool value) => ThemeBuilder.switchTheme(),
              );
            },
          ),
          onTap: () => ThemeBuilder.switchTheme(),
        ),
      ],
    );
  }

  SettingPanel notifications() {
    return SettingPanel(
      'Notifications',
      items: [
        SettingTile(
          title: 'Push Notifications',
          subtitle: 'Configure device notifications',
          icon: Icons.notifications_outlined,
          iconColor: Colors.indigo,
          onTap: () =>
              AppSettings.openAppSettings(type: AppSettingsType.notification),
        ),
      ],
    );
  }

  SettingPanel legalAndSupport() {
    return SettingPanel(
      'Legal & Support',
      items: [
        SettingTile(
          title: 'Terms & Conditions',
          subtitle: 'Read our terms of service',
          icon: Icons.description_outlined,
          iconColor: const Color(0xFF10B981), // Green
          onTap: () {},
        ),
        SettingTile(
          title: 'Privacy Policy',
          subtitle: 'View privacy guidelines',
          icon: Icons.shield_outlined,
          iconColor: const Color(0xFF8B5CF6), // Purple
          onTap: () {},
        ),
      ],
    );
  }
}
