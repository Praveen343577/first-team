import 'package:admin/repository/auth_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@injectable
class LogoutCubit extends SubmitOnlyCubit {
  final AuthRepository _authRepository;

  LogoutCubit(this._authRepository);

  @override
  Future<void> onSubmit() async {
    await _authRepository.logout();
  }
}
