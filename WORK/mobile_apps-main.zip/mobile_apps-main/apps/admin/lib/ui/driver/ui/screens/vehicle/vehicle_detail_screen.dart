import 'dart:async';
import 'package:admin/di/service_locator.dart';
import 'package:admin/ui/common/widgets/scrollable_google_map.dart';
import 'package:admin/models/route/route_model.dart';
import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/repository/recent_activity_repository.dart';
import 'package:admin/models/telemetry/dto/telemetry_history_request_dto.dart';
import 'package:admin/models/telemetry/telemetry_model.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/service/polyline_decoder.dart';
import 'package:admin/ui/driver/cubit/telemetry_history_cubit.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class VehicleDetailScreen
    extends FetchScreen<TelemetryHistoryCubit, List<TelemetryModel>> {
  final VehicleModel vehicle;

  const VehicleDetailScreen({super.key, required this.vehicle});

  /// Factory to push this screen with its own cubit already provided.
  static Route<void> route(VehicleModel vehicle) => MaterialPageRoute(
    builder: (_) => BlocProvider(
      create: (_) => getIt<TelemetryHistoryCubit>(),
      child: VehicleDetailScreen(vehicle: vehicle),
    ),
  );

  @override
  void onInit(BuildContext context) {
    final now = DateTime.now().toUtc();
    context.read<TelemetryHistoryCubit>().loadHistory(
      TelemetryHistoryRequestDto(
        deviceId: vehicle.deviceId,
        startTime: now.subtract(const Duration(days: 7)).toIso8601String(),
        endTime: now.toIso8601String(),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(padding: AppPadding.p16, child: child),
    );
  }

  Widget _sectionTitle(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(
      text,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
    ),
  );

  Widget _infoRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: EkaColors.textSecondary)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w500)),
      ],
    ),
  );

  AppBar _appBar() => AppBar(title: Text(vehicle.vehicleRegNo.toUpperCase()));

  @override
  Widget buildLoading(BuildContext context) => Scaffold(
    appBar: _appBar(),
    body: const Center(child: CircularProgressIndicator()),
  );

  @override
  Widget buildError(BuildContext context, String message) => Scaffold(
    appBar: _appBar(),
    body: Center(
      child: Text(message, style: const TextStyle(color: EkaColors.dangerRed)),
    ),
  );

  @override
  Widget buildSuccess(BuildContext context, List<TelemetryModel> data) {
    // Record this vehicle in recent activity
    getIt<RecentActivityRepository>().addItem(
      RecentActivityItem(
        id: vehicle.id,
        type: 'vehicle',
        title: vehicle.vehicleRegNo.toUpperCase(),
        subtitle: vehicle.vehicleType,
        viewedAt: DateTime.now(),
      ),
    );

    final TelemetryModel? latest = data.isNotEmpty ? data.first : null;

    return Scaffold(
      appBar: _appBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            _MapCard(latest: latest, isLoading: false),

            _card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        vehicle.vehicleRegNo.toUpperCase(),
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: latest?.ignition == 1
                              ? EkaColors.successGreen.withValues(alpha: 0.15)
                              : EkaColors.gray200,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          latest?.ignition == 1
                              ? 'IGNITION ON'
                              : 'IGNITION OFF',
                          style: TextStyle(
                            fontSize: 12,
                            color: latest?.ignition == 1
                                ? EkaColors.successGreen
                                : EkaColors.gray500,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text('${vehicle.vehicleType}   |   ${vehicle.deviceId}'),
                  if (latest != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      'Last seen: ${latest.ts}',
                      style: const TextStyle(
                        color: EkaColors.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            // ── LIVE STATS ─────────────────────────────────────────
            Row(
              children: [
                Expanded(
                  child: _card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'SPEED',
                          style: TextStyle(
                            color: EkaColors.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          latest != null
                              ? '${latest.speed.toStringAsFixed(1)} km/h'
                              : '—',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _card(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'ODOMETER',
                          style: TextStyle(
                            color: EkaColors.textSecondary,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          latest != null
                              ? '${latest.odometer.toStringAsFixed(1)} km'
                              : '—',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            // ── LOCATION DETAILS ───────────────────────────────────
            if (latest != null)
              _card(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _sectionTitle('Location Details'),
                    _infoRow('Latitude', latest.latitude.toStringAsFixed(7)),
                    _infoRow('Longitude', latest.longitude.toStringAsFixed(7)),
                    _infoRow(
                      'Heading',
                      '${latest.heading.toStringAsFixed(1)}°',
                    ),
                    _infoRow(
                      'Altitude',
                      '${latest.altitude.toStringAsFixed(1)} m',
                    ),
                    _infoRow(
                      'GPS Fix',
                      latest.gpsFix == 1 ? '✓ Fixed' : '✗ No fix',
                    ),
                    _infoRow('Satellites', '${latest.noOfSatellites ?? 'N/A'}'),
                  ],
                ),
              ),

            // ── POWER & BATTERY ────────────────────────────────────
            Container(
              width: double.infinity,
              padding: AppPadding.p16,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(
                  colors: [Color(0xff0F2027), Color(0xff203A43)],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Power & Battery',
                    style: TextStyle(
                      color: EkaColors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Main Voltage',
                              style: TextStyle(
                                color: Color(0x8AFFFFFF),
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              latest?.mainInputVoltage != null
                                  ? '${latest!.mainInputVoltage!.toStringAsFixed(1)} V'
                                  : '— V',
                              style: const TextStyle(
                                color: EkaColors.successGreen2,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Internal Battery',
                              style: TextStyle(
                                color: Color(0x8AFFFFFF),
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              latest?.internalBatteryVoltage != null
                                  ? '${latest!.internalBatteryVoltage!.toStringAsFixed(1)} V'
                                  : '— V',
                              style: const TextStyle(
                                color: EkaColors.white,
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Main Power: ${latest?.mainPowerStatus == 1
                        ? 'ON'
                        : latest == null
                        ? '—'
                        : 'OFF'}',
                    style: TextStyle(
                      color: latest?.mainPowerStatus == 1
                          ? EkaColors.successGreen2
                          : EkaColors.dangerRed,
                    ),
                  ),
                ],
              ),
            ),

            // ── TELEMATICS DEVICE ──────────────────────────────────
            _card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionTitle('Telematics Device'),
                  _infoRow('Device ID', vehicle.deviceId),
                  _infoRow('Fleet ID', vehicle.fleetId),
                  if (latest != null) ...[
                    _infoRow('Operator', latest.operatorName ?? 'N/A'),
                    _infoRow('GSM Strength', '${latest.gsmStrength ?? 'N/A'}'),
                    _infoRow('Last Update', latest.ts),
                  ],
                ],
              ),
            ),

            // ── IMPORTANT DATES ────────────────────────────────────
            _card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionTitle('Important Dates'),
                  _infoRow(
                    'Created',
                    vehicle.createdAt.length >= 10
                        ? vehicle.createdAt.substring(0, 10)
                        : vehicle.createdAt,
                  ),
                  _infoRow('Insurance', '2025-01-14'),
                  _infoRow('AMC', '2026-01-15 (Valid)'),
                ],
              ),
            ),

            // ── VEHICLE SPECS ──────────────────────────────────────
            _card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _sectionTitle('Vehicle Specifications'),
                  _infoRow('Type', vehicle.vehicleType),
                  _infoRow('Device ID', vehicle.deviceId),
                  _infoRow('Fleet ID', vehicle.fleetId),
                ],
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

// ── Map Card ─────────────────────────────────────────────────────────────

class _MapCard extends StatefulWidget {
  final TelemetryModel? latest;
  final bool isLoading;
  final RouteModel? route;

  const _MapCard({
    required this.latest,
    required this.isLoading,
    // ignore: unused_element_parameter
    this.route,
  });

  @override
  State<_MapCard> createState() => _MapCardState();
}

class _MapCardState extends State<_MapCard> {
  final Completer<GoogleMapController> _mapController = Completer();

  @override
  void didUpdateWidget(_MapCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.latest != null &&
        (oldWidget.latest?.latitude != widget.latest?.latitude ||
            oldWidget.latest?.longitude != widget.latest?.longitude)) {
      _updateCamera();
    }
  }

  Future<void> _updateCamera() async {
    if (widget.latest == null) return;
    final controller = await _mapController.future;
    controller.animateCamera(
      CameraUpdate.newLatLng(
        LatLng(widget.latest!.latitude, widget.latest!.longitude),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 240,
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.hardEdge,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: EkaColors.gray300,
      ),
      child: widget.isLoading
          ? const Center(child: CircularProgressIndicator())
          : widget.latest == null
          ? const Center(
              child: Text(
                'No location data',
                style: TextStyle(color: EkaColors.textSecondary),
              ),
            )
          : Stack(
              children: [
                ScrollableGoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: LatLng(
                      widget.latest!.latitude,
                      widget.latest!.longitude,
                    ),
                    zoom: 15,
                  ),
                  onMapCreated: (controller) {
                    _mapController.complete(controller);
                  },
                  markers: _buildMarkers(),
                  polylines: _buildPolylines(),
                  myLocationButtonEnabled: false,
                  zoomControlsEnabled: false,
                  mapToolbarEnabled: false,
                  showExpandButton: true,
                ),
                // Speed badge overlay
                Positioned(
                  bottom: 10,
                  left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: EkaColors.cardBackground,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: EkaColors.gray300.withValues(alpha: 0.6),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.speed,
                          size: 16,
                          color: EkaColors.gray500,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${widget.latest!.speed.toStringAsFixed(0)} km/h',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }

  Set<Marker> _buildMarkers() {
    final markers = <Marker>{};

    // Vehicle Marker
    if (widget.latest != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('vehicle'),
          position: LatLng(widget.latest!.latitude, widget.latest!.longitude),
          rotation: widget.latest!.heading,
          anchor: const Offset(0.5, 0.5),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: const InfoWindow(title: 'Live Position'),
        ),
      );
    }

    // Route Stop Markers
    if (widget.route != null) {
      for (final stop in widget.route!.stops) {
        markers.add(
          Marker(
            markerId: MarkerId('stop_${stop.stopOrder}'),
            position: LatLng(stop.latitude, stop.longitude),
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueAzure,
            ),
            infoWindow: InfoWindow(title: stop.stopName),
          ),
        );
      }
    }

    return markers;
  }

  Set<Polyline> _buildPolylines() {
    if (widget.route == null ||
        widget.route!.polyline == null ||
        widget.route!.polyline!.isEmpty) {
      return {};
    }

    return {
      Polyline(
        polylineId: const PolylineId('route_path'),
        points: PolylineDecoder.decodePolyline(widget.route!.polyline!),
        color: Colors.blueAccent,
        width: 5,
        jointType: JointType.round,
        startCap: Cap.roundCap,
        endCap: Cap.roundCap,
      ),
    };
  }
}
