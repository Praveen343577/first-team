import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/models/vehicle/vehicle_model.dart';
import 'package:admin/ui/driver/cubit/vehicle_list_cubit.dart';
import 'package:admin/ui/driver/ui/screens/vehicle/vehicle_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:ui/ui.dart';
import 'package:state_handler/state_handler.dart';

class VehicleListScreen
    extends SearchListScreen<VehicleListCubit, VehicleModel> {
  const VehicleListScreen({super.key, super.onItemTap, super.useScaffold = true});

  @override
  String get title => 'Vehicles';

  @override
  String get searchHint => 'Search vehicles…';

  @override
  EdgeInsets get itemPadding => AppPadding.gutter;

  @override
  bool get showFilter => true;

  @override
  bool get showSort => false;

  @override
  bool isFilterActive(VehicleListCubit cubit) =>
      cubit.typeFilter != null ||
      cubit.selectedFleet != null ||
      cubit.sortOption != VehicleSortOption.regNoAsc;

  @override
  void onFilterTap(BuildContext context, VehicleListCubit cubit) =>
      _showFilterSheet(context, cubit);

  @override
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No vehicles found'));
  }

  @override
  Widget buildItem(BuildContext context, VehicleModel vehicle, int index) {
    final theme = Theme.of(context);

    return Card(
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        onTap: onItemTap != null
            ? null
            : () => Navigator.push(
                  context,
                  VehicleDetailScreen.route(vehicle),
                ),
        leading: CircleAvatar(
          backgroundColor: theme.colorScheme.primaryContainer,
          child: Icon(
            Icons.local_shipping,
            color: theme.colorScheme.onPrimaryContainer,
          ),
        ),
        title: Text(
          vehicle.vehicleRegNo.toUpperCase(),
          style: theme.textTheme.titleSmall?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        subtitle: Text(vehicle.vehicleType),
        trailing: Text(
          vehicle.deviceId,
          style: theme.textTheme.bodySmall,
        ),
      ),
    );
  }

  void _showFilterSheet(BuildContext context, VehicleListCubit cubit) {
    final state = cubit.state;
    final vehicles = state.isLoaded ? (state.data ?? []) : <VehicleModel>[];
    final types = vehicles.map((v) => v.vehicleType).toSet().toList()..sort();

    // Draft selections
    String? selectedType = cubit.typeFilter;
    VehicleSortOption selectedSort = cubit.sortOption;
    FleetModel? selectedFleet = cubit.selectedFleet;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(0, 20, 0, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Filter & Sort',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(ctx).pop(),
                    ),
                  ],
                ),
              ),
              const Divider(),
              // Sort Section
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Sort by',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              ...VehicleSortOption.values.map((option) {
                final labels = {
                  VehicleSortOption.regNoAsc: 'Reg No (A → Z)',
                  VehicleSortOption.regNoDesc: 'Reg No (Z → A)',
                  VehicleSortOption.newest: 'Newest first',
                  VehicleSortOption.oldest: 'Oldest first',
                };
                return RadioListTile<VehicleSortOption>(
                  title: Text(labels[option]!),
                  value: option,
                  groupValue: selectedSort,
                  dense: true,
                  onChanged: (v) {
                    setSheetState(() => selectedSort = v!);
                  },
                );
              }),
              const Divider(),
              // Type Section
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Filter by Type',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ChoiceChip(
                      label: const Text('All'),
                      selected: selectedType == null,
                      selectedColor: Theme.of(ctx).colorScheme.primary,
                      onSelected: (_) {
                        setSheetState(() => selectedType = null);
                      },
                    ),
                    ...types.map(
                      (type) => ChoiceChip(
                        label: Text(type),
                        selected: selectedType == type,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedType = type);
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              // Fleet selection
              if (cubit.fleets.isNotEmpty) ...[
                const Divider(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Fleet',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          ChoiceChip(
                            label: const Text('All Fleets'),
                            selected: selectedFleet == null,
                            selectedColor: Theme.of(ctx).colorScheme.primary,
                            onSelected: (_) {
                              setSheetState(() => selectedFleet = null);
                            },
                          ),
                          ...cubit.fleets.map((fleet) {
                            final isSelected = selectedFleet?.id == fleet.id;
                            return ChoiceChip(
                              label: Text(fleet.name),
                              selected: isSelected,
                              selectedColor: Theme.of(ctx).colorScheme.primary,
                              onSelected: (_) {
                                setSheetState(() => selectedFleet = fleet);
                              },
                            );
                          }),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          cubit.updateFiltersAndSort(clearAll: true);
                          Navigator.of(ctx).pop();
                        },
                        child: const Text('Clear All'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          cubit.updateFiltersAndSort(
                            typeFilter: selectedType,
                            sortOption: selectedSort,
                            selectedFleet: selectedFleet,
                          );
                          Navigator.of(ctx).pop();
                        },
                        child: const Text('Apply'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
