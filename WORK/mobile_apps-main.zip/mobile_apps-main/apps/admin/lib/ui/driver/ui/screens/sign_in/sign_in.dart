import 'dart:ui';
import 'package:admin/di/service_locator.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/ui/driver/ui/screens/sign_in/sign_in_cubit.dart';
import 'package:go_router/go_router.dart';
import 'package:state_handler/ui/submit_screen.dart';
import 'package:admin/ui/common/widgets/eka_snack_bar.dart';

class LoginScreen extends SubmitScreen<SignInCubit, void> {
  const LoginScreen({super.key});

  @override
  void onInit(BuildContext context) {
    super.onInit(context);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final authRepo = getIt<AuthRepository>();
      final isAutoLoggedIn = await authRepo.tryAutoLogin();
      if (isAutoLoggedIn && context.mounted) {
        context.go('/');
      }
    });
  }

  @override
  void onSubmitSuccess(BuildContext context, void data) {
    context.go('/');
  }

  @override
  Widget buildForm(BuildContext context) {
    final cubit = context.read<SignInCubit>();
    final fb = cubit.formBloc;
    return Scaffold(
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset('assets/sign_in.png', fit: BoxFit.cover),
          ),
          // Dark Overlay
          Positioned.fill(child: Container(color: Colors.black26)),

          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: GlassLoginCard(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset('assets/EkaConnectLogo_White.png', height: 24),
                    const SizedBox(height: 16),
                    const Text(
                      "Welcome back",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 28,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const Text(
                      "Sign in to manage your fleet",
                      style: TextStyle(color: Colors.white70),
                    ),
                    const SizedBox(height: 16),
                    _buildTextField(
                      label: "EMAIL",
                      hint: "admin@ekaconnect.com",
                      icon: Icons.email_outlined,
                      fieldBloc: fb.email,
                    ),
                    const SizedBox(height: 20),
                    _buildTextField(
                      label: "PASSWORD",
                      hint: "••••••••",
                      icon: Icons.lock_outline,
                      isPassword: true,
                      fieldBloc: fb.password,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        onPressed: () => cubit.submit(),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Sign In",
                              style: TextStyle(
                                color: Theme.of(context).primaryColor,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(width: 8),
                            Icon(
                              Icons.arrow_forward,
                              color: Theme.of(context).primaryColor,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    TextButton(
                      onPressed: () => _showForgotPasswordBottomSheet(context),
                      child: const Text(
                        "Forgot password?",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "EKA MOBILITY SYSTEM V${getIt<PackageInfo>().version}",
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 10,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required String label,
    required String hint,
    required IconData icon,
    required TextFieldBloc fieldBloc,
    bool isPassword = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextFieldBlocBuilder(
          textFieldBloc: fieldBloc,
          suffixButton: isPassword ? SuffixButton.obscureText : null,
          textStyle: const TextStyle(color: Colors.white),
          textColor: WidgetStateProperty.all(Colors.white),
          decoration: InputDecoration(
            filled: true,
            suffixIconColor: Colors.white,
            fillColor: Colors.white.withValues(alpha: 0.1),
            prefixIcon: Icon(icon, color: Colors.white70),
            hintText: hint,
            hintStyle: TextStyle(color: Colors.white38),
            errorStyle: const TextStyle(color: Colors.redAccent),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
      ],
    );
  }

  void _showForgotPasswordBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (modalContext) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(modalContext).viewInsets.bottom,
          ),
          child: const ForgotPasswordBottomSheetContent(),
        );
      },
    );
  }
}

class ForgotPasswordBottomSheetContent extends StatefulWidget {
  const ForgotPasswordBottomSheetContent({super.key});

  @override
  State<ForgotPasswordBottomSheetContent> createState() =>
      _ForgotPasswordBottomSheetContentState();
}

class _ForgotPasswordBottomSheetContentState
    extends State<ForgotPasswordBottomSheetContent> {
  final _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);
    try {
      final authRepo = getIt<AuthRepository>();
      final response = await authRepo.forgotPassword(
        _emailController.text.trim(),
      );

      if (mounted) {
        Navigator.pop(context); // Close bottomsheet
        if (response.token == null || response.token!.isEmpty) {
          EkaSnackBar.showError("This email address is not registered.");
          return;
        }
        EkaSnackBar.showSuccess("Reset token generated successfully.");
        // Navigate to reset password page with the token from response
        context.go('/reset-password?token=${response.token}');
      }
    } catch (e) {
      EkaSnackBar.showError('Error: $e');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(
          0xFF1E293B,
        ).withValues(alpha: 0.95), // sleek dark blue-grey matching theme
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Forgot Password",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Enter your email address and we'll generate a reset token for you.",
              style: TextStyle(color: Colors.white70, fontSize: 14),
            ),
            const SizedBox(height: 24),
            const Text(
              "EMAIL ADDRESS",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _emailController,
              keyboardType: TextInputType.emailAddress,
              style: const TextStyle(color: Colors.white),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your email';
                }
                if (!RegExp(
                  r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                ).hasMatch(value)) {
                  return 'Please enter a valid email address';
                }
                return null;
              },
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white.withValues(alpha: 0.1),
                prefixIcon: const Icon(
                  Icons.email_outlined,
                  color: Colors.white70,
                ),
                hintText: "adc@example.com",
                hintStyle: const TextStyle(color: Colors.white38),
                errorStyle: const TextStyle(color: Colors.redAccent),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: _isLoading ? null : _submit,
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.black)
                    : const Text(
                        "Generate Reset Token",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GlassLoginCard extends StatelessWidget {
  final Widget child;

  const GlassLoginCard({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
          ),
          child: child,
        ),
      ),
    );
  }
}
