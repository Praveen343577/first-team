import 'package:flutter/foundation.dart';
import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/ui/driver/form_bloc/driver_form_bloc.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';

class UpdateDriverProfileCubit extends SubmitOnlyCubit {
  final CreateDriverProfileFormBloc formBloc = CreateDriverProfileFormBloc();

  final String driverId;
  String? _pendingFleetId;

  UpdateDriverProfileCubit({required this.driverId});

  void populateForm(DriverModel data) {
    formBloc.fullName.updateValue(data.fullName);
    formBloc.email.updateValue(data.email);
    formBloc.mobile.updateValue(data.mobile ?? '');
    formBloc.dob.updateValue(data.dob ?? '');

    // Safety check for blood group to avoid dropdown crash
    final bloodValue = data.bloodGroup;
    if (bloodValue != null &&
        formBloc.bloodGroup.state.items.contains(bloodValue)) {
      formBloc.bloodGroup.updateValue(bloodValue);
    } else {
      formBloc.bloodGroup.updateValue('Select');
    }

    formBloc.address.updateValue(data.address ?? '');
    formBloc.emergencyContactName.updateValue(data.emergencyContactName ?? '');
    formBloc.emergencyContactNumber.updateValue(
      data.emergencyContactNumber ?? '',
    );

    _pendingFleetId = data.fleetId;

    // We will handle fleet selection in the UI once GetFleetCubit loads the items
    // If the fleet items are already in the bloc, we can select now
    if (formBloc.fleet.state.items.isNotEmpty) {
      _selectFleet(_pendingFleetId);
    }
  }

  void onFleetsLoaded() {
    _selectFleet(_pendingFleetId);
  }

  void _selectFleet(String? fleetId) {
    if (fleetId == null) return;

    final fleets = formBloc.fleet.state.items;
    final index = fleets.indexWhere((f) => f.id == fleetId);

    if (index != -1) {
      formBloc.fleet.updateValue(fleets[index]);
      _pendingFleetId = null;
    }
  }

  @override
  void onChange(Change<SubmitOnlyState> change) {
    super.onChange(change);
    debugPrint('DEBUG: UpdateDriverProfileCubit state change: $change');
  }

  @override
  Future<void> onSubmit() async {
    formBloc.submit();

    if (!formBloc.state.isValid()) {
      throw Exception('Please fill all required fields');
    }

    // Implement update logic here using formBloc values
    await Future<void>.delayed(const Duration(milliseconds: 500));
  }
}
