import 'package:admin/ui/driver/ui/widgets/card_panel.dart';
import 'package:admin/ui/driver/ui/screens/setting/widgets/setting_tile.dart';

class SettingPanel extends CardPanel<SettingTile> {
  const SettingPanel(super.title, {super.key, required super.items});

  const SettingPanel.compact(super.title, {super.key, required super.items})
    : super.compact();

  // Widget build(BuildContext context) {
  //   return Padding(
  //     padding: const EdgeInsets.all(16.0),
  //     child: Card(
  //       clipBehavior: Clip.antiAlias,
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         mainAxisSize: MainAxisSize.min,
  //         children: [
  //           if (!isCompact && title != null) ...[
  //             Padding(
  //               padding: AppPadding.p16,
  //               child: Text(
  //                 title!,
  //                 style: Theme.of(context).textTheme.titleMedium,
  //               ),
  //             ),
  //             const Divider(),
  //           ],
  //           for (int i = 0; i < items.length; i++) ...[
  //             items[i],
  //             if (i != items.length - 1) const Divider(),
  //           ],
  //         ],
  //       ),
  //     ),
  //   );
  // }
}
