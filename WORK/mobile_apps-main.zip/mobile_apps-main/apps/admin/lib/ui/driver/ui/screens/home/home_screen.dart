import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:admin/models/dashboard/sustainability_model.dart';
import 'package:admin/ui/dashboards/cubit/sustainability_cubit.dart';
import 'package:admin/ui/common/widgets/global_fleet_status_section.dart';
import 'package:admin/ui/common/widgets/recent_activity_section.dart';
import 'package:admin/ui/driver/ui/widgets/charts.dart';
import 'package:ui/ui.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: AppPadding.p16,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [


            const GlobalFleetStatusSection(height: 280),
            const SizedBox(height: 24),

            // Sustainability Metrics
            BlocBuilder<SustainabilityCubit, FetchOnlyState<SustainabilityModel>>(
              builder: (context, state) {
                if (state.isLoaded) {
                  return _buildSustainabilitySection(context, state.data!);
                } else if (state.isError) {
                  return Center(
                    child: Text(
                      'Failed to load sustainability metrics: ${state.errorMessage}',
                      style: const TextStyle(color: Colors.red),
                    ),
                  );
                }
                return const GridMetricsShimmer();
              },
            ),
            const SizedBox(height: 24),

            const RecentActivitySection(),
          ],
        ),
      ),
    );
  }

  Widget _buildSustainabilitySection(BuildContext context, SustainabilityModel model) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Text(
            'Sustainability Metrics',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.5,
          children: [
            _sustainabilityCard(
              'CO2 Saved',
              '${model.co2SavedTons.toStringAsFixed(2)} Tons',
              Icons.co2,
              Colors.green,
              'Equivalent: ${model.co2SavedKg.toStringAsFixed(0)} kg',
            ),
            _sustainabilityCard(
              'Trees Equivalent',
              '${model.treesEquivalent}',
              Icons.park_outlined,
              Colors.teal,
              'Equivalent trees planted',
            ),
            _sustainabilityCard(
              'Cost Saved',
              '₹${(model.costSavedInr / 1000).toStringAsFixed(1)}K',
              Icons.currency_rupee_rounded,
              Colors.amber.shade800,
              'Total INR saved',
            ),
            _sustainabilityCard(
              'Total Distance',
              '${(model.totalDistanceKm / 1000).toStringAsFixed(1)}K km',
              Icons.map_outlined,
              Colors.blue,
              'Total distance recorded',
            ),
          ],
        ),
      ],
    );
  }

  Widget _sustainabilityCard(
    String title,
    String value,
    IconData icon,
    Color color,
    String subtitle,
  ) {
    return Card(
      child: Padding(
        padding: AppPadding.p12,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 18),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: EkaColors.textSecondary,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 10, color: Colors.grey),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
