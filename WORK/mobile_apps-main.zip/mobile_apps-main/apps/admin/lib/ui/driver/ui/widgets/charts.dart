import "package:ui/ui.dart";
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:shimmer/shimmer.dart';

// ─── Data models ─────────────────────────────────────────────────────────────

class ChartDataPoint {
  final String label;
  final double value;
  final Color? color;

  const ChartDataPoint(this.label, this.value, {this.color});
}

class MultiSeriesPoint {
  final String label;
  final List<double> values;

  const MultiSeriesPoint(this.label, this.values);
}

// ─── Column series descriptor ────────────────────────────────────────────────

class ColumnSeriesConfig {
  final String name;
  final List<ChartDataPoint> data;
  final List<Color> gradientColors;

  const ColumnSeriesConfig({
    required this.name,
    required this.data,
    required this.gradientColors,
  });
}

// ─── Line series descriptor ──────────────────────────────────────────────────

class LineSeriesConfig {
  final String name;
  final Color color;
  final bool isArea;
  final List<double>? dashArray;
  final DataMarkerType markerShape;
  final bool showDataLabels;

  const LineSeriesConfig({
    required this.name,
    required this.color,
    this.isArea = false,
    this.dashArray,
    this.markerShape = DataMarkerType.circle,
    this.showDataLabels = false,
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// 1. TRIPS COLUMN CHART (grouped columns with gradients)
// ═══════════════════════════════════════════════════════════════════════════════

class TripsColumnChart extends StatelessWidget {
  final String title;
  final String yAxisLabel;
  final double height;
  final List<ColumnSeriesConfig> seriesList;

  const TripsColumnChart({
    super.key,
    this.title = 'Trips Per Day',
    this.yAxisLabel = 'Trips',
    this.height = 270,
    List<ColumnSeriesConfig>? series,
  }) : seriesList = series ?? const [];

  // Mock data used when no series are provided
  static List<ColumnSeriesConfig> get mockSeries => [
    ColumnSeriesConfig(
      name: 'Completed',
      data: const [
        ChartDataPoint('Mon', 35),
        ChartDataPoint('Tue', 42),
        ChartDataPoint('Wed', 58),
        ChartDataPoint('Thu', 47),
        ChartDataPoint('Fri', 63),
        ChartDataPoint('Sat', 38),
        ChartDataPoint('Sun', 25),
      ],
      gradientColors: const [Color(0xFF1565C0), Color(0xFF42A5F5)],
    ),
    ColumnSeriesConfig(
      name: 'Delayed',
      data: const [
        ChartDataPoint('Mon', 12),
        ChartDataPoint('Tue', 9),
        ChartDataPoint('Wed', 15),
        ChartDataPoint('Thu', 11),
        ChartDataPoint('Fri', 7),
        ChartDataPoint('Sat', 14),
        ChartDataPoint('Sun', 10),
      ],
      gradientColors: const [Color(0xFFF57C00), Color(0xFFFFB74D)],
    ),
    ColumnSeriesConfig(
      name: 'Cancelled',
      data: const [
        ChartDataPoint('Mon', 5),
        ChartDataPoint('Tue', 8),
        ChartDataPoint('Wed', 3),
        ChartDataPoint('Thu', 6),
        ChartDataPoint('Fri', 4),
        ChartDataPoint('Sat', 9),
        ChartDataPoint('Sun', 7),
      ],
      gradientColors: const [Color(0xFFC62828), Color(0xFFEF5350)],
    ),
  ];

  List<ColumnSeriesConfig> get _effectiveSeries =>
      seriesList.isEmpty ? mockSeries : seriesList;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(
          title: title,
          icon: Icons.bar_chart_rounded,
          color: const Color(0xFF1565C0),
        ),
        SizedBox(
          height: height,
          child: Padding(
            padding: _kGutter,
            child: SfCartesianChart(
              plotAreaBorderWidth: 0,
              legend: const Legend(
                isVisible: true,
                position: LegendPosition.top,
                overflowMode: LegendItemOverflowMode.wrap,
                textStyle: TextStyle(fontSize: 12),
              ),
              primaryXAxis: const CategoryAxis(
                majorGridLines: MajorGridLines(width: 0),
                axisLine: AxisLine(width: 0.5, color: Colors.grey),
                labelStyle: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 12,
                ),
              ),
              primaryYAxis: NumericAxis(
                title: AxisTitle(
                  text: yAxisLabel,
                  textStyle: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
                axisLine: const AxisLine(width: 0),
                majorTickLines: const MajorTickLines(size: 0),
                majorGridLines: const MajorGridLines(
                  width: 0.5,
                  dashArray: [4, 4],
                  color: Colors.grey,
                ),
              ),
              tooltipBehavior: TooltipBehavior(
                enable: true,
                header: '',
                canShowMarker: true,
              ),
              enableSideBySideSeriesPlacement: false,
              series: _effectiveSeries.map((cfg) {
                return ColumnSeries<ChartDataPoint, String>(
                  dataSource: cfg.data,
                  xValueMapper: (d, _) => d.label,
                  yValueMapper: (d, _) => d.value,
                  name: cfg.name,
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: cfg.gradientColors,
                  ),
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(6),
                  ),
                  width: 0.55,
                  spacing: 0.15,
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. MULTI-LINE / SPLINE CHART
// ═══════════════════════════════════════════════════════════════════════════════

class RevenueLineChart extends StatelessWidget {
  final String title;
  final String yAxisLabel;
  final double height;
  final List<MultiSeriesPoint>? data;
  final List<LineSeriesConfig>? seriesConfigs;

  const RevenueLineChart({
    super.key,
    this.title = 'Revenue vs Expenses vs Profit',
    this.yAxisLabel = '₹ (in Thousands)',
    this.height = 280,
    this.data,
    this.seriesConfigs,
  });

  static List<MultiSeriesPoint> get mockData => const [
    MultiSeriesPoint('Jan', [120, 80, 40]),
    MultiSeriesPoint('Feb', [150, 95, 55]),
    MultiSeriesPoint('Mar', [170, 88, 82]),
    MultiSeriesPoint('Apr', [140, 92, 48]),
    MultiSeriesPoint('May', [200, 105, 95]),
    MultiSeriesPoint('Jun', [180, 98, 82]),
    MultiSeriesPoint('Jul', [220, 110, 110]),
    MultiSeriesPoint('Aug', [195, 102, 93]),
    MultiSeriesPoint('Sep', [240, 115, 125]),
    MultiSeriesPoint('Oct', [210, 108, 102]),
    MultiSeriesPoint('Nov', [260, 120, 140]),
    MultiSeriesPoint('Dec', [290, 130, 160]),
  ];

  static List<LineSeriesConfig> get mockConfigs => const [
    LineSeriesConfig(name: 'Revenue', color: Color(0xFF4CAF50), isArea: true),
    LineSeriesConfig(
      name: 'Expenses',
      color: Color(0xFFEF5350),
      dashArray: [8, 4],
      markerShape: DataMarkerType.diamond,
    ),
    LineSeriesConfig(
      name: 'Profit',
      color: Color(0xFF7E57C2),
      markerShape: DataMarkerType.triangle,
      showDataLabels: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final effectiveData = data ?? mockData;
    final configs = seriesConfigs ?? mockConfigs;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(
          title: title,
          icon: Icons.show_chart_rounded,
          color: const Color(0xFF2E7D32),
        ),
        SizedBox(
          height: height,
          child: Padding(
            padding: _kGutter,
            child: SfCartesianChart(
              plotAreaBorderWidth: 0,
              legend: const Legend(
                isVisible: true,
                position: LegendPosition.top,
                overflowMode: LegendItemOverflowMode.wrap,
                textStyle: TextStyle(fontSize: 12),
              ),
              primaryXAxis: const CategoryAxis(
                majorGridLines: MajorGridLines(width: 0),
                axisLine: AxisLine(width: 0.5, color: Colors.grey),
                labelStyle: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 11,
                ),
                labelRotation: -30,
              ),
              primaryYAxis: NumericAxis(
                title: AxisTitle(
                  text: yAxisLabel,
                  textStyle: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
                axisLine: const AxisLine(width: 0),
                majorTickLines: const MajorTickLines(size: 0),
                majorGridLines: const MajorGridLines(
                  width: 0.5,
                  dashArray: [4, 4],
                  color: Colors.grey,
                ),
                minimum: 0,
                maximum: 320,
                interval: 40,
              ),
              tooltipBehavior: TooltipBehavior(
                enable: true,
                shared: true,
                canShowMarker: true,
              ),
              crosshairBehavior: CrosshairBehavior(
                enable: true,
                lineType: CrosshairLineType.vertical,
                activationMode: ActivationMode.singleTap,
              ),
              series: _buildLineSeries(effectiveData, configs),
            ),
          ),
        ),
      ],
    );
  }

  List<CartesianSeries<MultiSeriesPoint, String>> _buildLineSeries(
    List<MultiSeriesPoint> points,
    List<LineSeriesConfig> configs,
  ) {
    final result = <CartesianSeries<MultiSeriesPoint, String>>[];
    for (var i = 0; i < configs.length; i++) {
      final cfg = configs[i];
      if (cfg.isArea) {
        result.add(
          SplineAreaSeries<MultiSeriesPoint, String>(
            dataSource: points,
            xValueMapper: (d, _) => d.label,
            yValueMapper: (d, _) => d.values[i],
            name: cfg.name,
            color: cfg.color.withValues(alpha: 0.15),
            borderColor: cfg.color,
            borderWidth: 3,
            markerSettings: MarkerSettings(
              isVisible: true,
              shape: cfg.markerShape,
              width: 8,
              height: 8,
              borderWidth: 2,
              borderColor: cfg.color,
              color: Colors.white,
            ),
          ),
        );
      } else {
        result.add(
          SplineSeries<MultiSeriesPoint, String>(
            dataSource: points,
            xValueMapper: (d, _) => d.label,
            yValueMapper: (d, _) => d.values[i],
            name: cfg.name,
            color: cfg.color,
            width: 3,
            dashArray: cfg.dashArray ?? const [],
            markerSettings: MarkerSettings(
              isVisible: true,
              shape: cfg.markerShape,
              width: 9,
              height: 9,
              borderWidth: 2,
              borderColor: cfg.color,
              color: Colors.white,
            ),
            dataLabelSettings: DataLabelSettings(
              isVisible: cfg.showDataLabels,
              labelAlignment: ChartDataLabelAlignment.top,
              textStyle: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: cfg.color,
              ),
            ),
          ),
        );
      }
    }
    return result;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. DOUGHNUT / PIE CHART
// ═══════════════════════════════════════════════════════════════════════════════

class StatusDoughnutChart extends StatelessWidget {
  final String title;
  final String centerLabel;
  final double height;
  final List<ChartDataPoint>? data;
  final Widget? trailing;

  const StatusDoughnutChart({
    super.key,
    this.title = 'Trip Status Distribution',
    this.centerLabel = 'Total Trips',
    this.height = 300,
    this.data,
    this.trailing,
  });

  static List<ChartDataPoint> get mockData => const [
    ChartDataPoint('On Time', 52, color: Color(0xFF4CAF50)),
    ChartDataPoint('Delayed', 18, color: Color(0xFFFFA726)),
    ChartDataPoint('Cancelled', 8, color: Color(0xFFEF5350)),
    ChartDataPoint('In Progress', 14, color: Color(0xFF42A5F5)),
    ChartDataPoint('Scheduled', 8, color: Color(0xFFAB47BC)),
  ];

  @override
  Widget build(BuildContext context) {
    final effectiveData = data ?? mockData;
    final total = effectiveData.fold<double>(0, (s, d) => s + d.value).toInt();

    return Card(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionHeader(
            title: title,
            icon: Icons.pie_chart_rounded,
            color: const Color(0xFFE65100),
            trailing: trailing,
          ),
          SizedBox(
            height: 180,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: SfCircularChart(
                legend: const Legend(
                  isVisible: true,
                  position: LegendPosition.left,
                  overflowMode: LegendItemOverflowMode.wrap,
                  textStyle: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                  iconHeight: 14,
                  iconWidth: 14,
                ),
                tooltipBehavior: TooltipBehavior(
                  enable: true,
                  format: 'point.x : point.y%',
                ),
                annotations: <CircularChartAnnotation>[
                  CircularChartAnnotation(
                    widget: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          '$total',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF37474F),
                          ),
                        ),
                      Text(
                        centerLabel,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
              series: <CircularSeries<ChartDataPoint, String>>[
                DoughnutSeries<ChartDataPoint, String>(
                  dataSource: effectiveData,
                  xValueMapper: (d, _) => d.label,
                  yValueMapper: (d, _) => d.value,
                  pointColorMapper: (d, _) => d.color,
                  name: 'Status',
                  innerRadius: '80%',
                  radius: '85%',
                  // strokeWidth: 2,
                  // strokeColor: Colors.white,
                  // cornerStyle: CornerStyle.bothCurve,
                  dataLabelSettings: DataLabelSettings(
                    isVisible: true,
                    labelPosition: ChartDataLabelPosition.outside,
                    // connectorLineSettings: const ConnectorLineSettings(
                    //   type: ConnectorType.curve,
                    //   length: '12%',
                    // ),
                    textStyle: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                    builder: (data, point, series, pointIndex, seriesIndex) {
                      final d = effectiveData[pointIndex];
                      return Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: d.color?.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: d.color ?? Colors.grey,
                            width: 1,
                          ),
                        ),
                        child: Text(
                          d.label,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: d.color,
                          ),
                        ),
                      );
                    },
                  ),
                  explode: true,
                  explodeIndex: 0,
                  explodeOffset: '6%',
                  animationDuration: 1200,
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
}
}

// ─── Shared helpers ──────────────────────────────────────────────────────────

const EdgeInsets _kGutter = AppPadding.gutter;

class _SectionHeader extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final Widget? trailing;

  const _SectionHeader({
    required this.title,
    required this.icon,
    required this.color,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: _kGutter,
      child: Row(
        children: [
          Container(
            padding: AppPadding.p8,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 8),
            trailing!,
          ],
        ],
      ),
    );
  }
}

// ─── Shimmer Loading Placeholders ─────────────────────────────────────────────

class ChartShimmer extends StatelessWidget {
  final String title;
  final double height;

  const ChartShimmer({
    super.key,
    required this.title,
    this.height = 220,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark ? Colors.grey[800]! : Colors.grey[300]!;
    final highlightColor = isDark ? Colors.grey[700]! : Colors.grey[100]!;

    return Shimmer.fromColors(
      baseColor: baseColor,
      highlightColor: highlightColor,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 120,
                    height: 16,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  Container(
                    width: 80,
                    height: 20,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                width: double.infinity,
                height: height,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DoughnutChartShimmer extends StatelessWidget {
  final String title;
  final String centerLabel;
  final double height;

  const DoughnutChartShimmer({
    super.key,
    required this.title,
    required this.centerLabel,
    this.height = 300,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark ? Colors.grey[800]! : Colors.grey[300]!;
    final highlightColor = isDark ? Colors.grey[700]! : Colors.grey[100]!;

    return Shimmer.fromColors(
      baseColor: baseColor,
      highlightColor: highlightColor,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 140,
                height: 16,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Container(
                    width: 140,
                    height: 140,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: List.generate(
                      5,
                      (index) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            Container(
                              width: 12,
                              height: 12,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              width: 80,
                              height: 10,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GridMetricsShimmer extends StatelessWidget {
  const GridMetricsShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark ? Colors.grey[800]! : Colors.grey[300]!;
    final highlightColor = isDark ? Colors.grey[700]! : Colors.grey[100]!;

    return Shimmer.fromColors(
      baseColor: baseColor,
      highlightColor: highlightColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
            child: Container(
              width: 180,
              height: 18,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
          const SizedBox(height: 8),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: List.generate(
              4,
              (index) => Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 18,
                            height: 18,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            width: 60,
                            height: 10,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 80,
                            height: 16,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(3),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Container(
                            width: 100,
                            height: 8,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
