import 'dart:async';

import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:admin/models/fleet/fleet_model.dart';

class CreateDriverProfileFormBloc extends FormBloc<String, String> {
  CreateDriverProfileFormBloc()
      : fullName = TextFieldBloc(validators: [_fullNameValidator]),
        email = TextFieldBloc(validators: [_emailValidator]),
        mobile = TextFieldBloc(validators: [_mobileValidator]),
        address = TextFieldBloc(),
        emergencyContactName = TextFieldBloc(validators: [_fullNameValidator]),
        emergencyContactNumber = TextFieldBloc(validators: [_mobileValidator]),
        bloodGroup = SelectFieldBloc<String, dynamic>(
          items: ['Select', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
          initialValue: 'Select',
          validators: [], // Made optional since 'Select' represents null
        ),
        fleet = SelectFieldBloc<FleetModel, dynamic>(
          validators: [_requiredSelect],
        ),
        dob = TextFieldBloc(validators: [_dobValidator]) {
    addFieldBlocs(
      fieldBlocs: [
        fullName,
        email,
        mobile,
        address,
        emergencyContactName,
        emergencyContactNumber,
        bloodGroup,
        fleet,
        dob,
      ],
    );
  }

  final TextFieldBloc fullName;
  final TextFieldBloc email;
  final TextFieldBloc mobile;
  final TextFieldBloc address;
  final TextFieldBloc emergencyContactName;
  final TextFieldBloc emergencyContactNumber;
  final SelectFieldBloc<String, dynamic> bloodGroup;
  final SelectFieldBloc<FleetModel, dynamic> fleet;
  final TextFieldBloc dob;

  static String? _fullNameValidator(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    if (value.length < 3) return 'At least 3 characters';
    if (value.length > 60) return 'Maximum 60 characters';
    if (!RegExp(r'^[a-zA-Z\s]+$').hasMatch(value)) {
      return 'Only letters and spaces allowed';
    }
    return null;
  }

  static String? _emailValidator(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    final emailError = FieldBlocValidators.email(value);
    if (emailError != null) return 'Invalid email format';
    return null;
  }

  static String? _mobileValidator(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    if (value.length != 10) return 'Must be exactly 10 digits';
    if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
      return 'Only digits allowed';
    }
    return null;
  }

  static String? _dobValidator(String? value) {
    if (value == null || value.trim().isEmpty) return 'Required';
    try {
      // Format YYYY-MM-DD as set in DriverProfileFormMixin
      final parts = value.split('-');
      if (parts.length != 3) return 'Invalid format (YYYY-MM-DD)';

      final year = int.parse(parts[0]);
      final month = int.parse(parts[1]);
      final day = int.parse(parts[2]);

      final birthDate = DateTime(year, month, day);
      final today = DateTime.now();

      var age = today.year - birthDate.year;
      if (today.month < birthDate.month ||
          (today.month == birthDate.month && today.day < birthDate.day)) {
        age--;
      }

      if (age < 18) return 'Must be at least 18 years old';
    } catch (e) {
      return 'Invalid date';
    }
    return null;
  }

  static String? _requiredSelect(dynamic value) {
    if (value == null) return 'Required';
    return null;
  }

  @override
  FutureOr<void> onSubmitting() {}
}
