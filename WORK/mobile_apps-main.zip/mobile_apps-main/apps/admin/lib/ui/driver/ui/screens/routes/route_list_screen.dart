import 'package:admin/di/service_locator.dart';
import 'package:admin/models/route/route_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/service/location_service.dart';
import 'package:admin/ui/route/cubit/create_route_cubit.dart';
import 'package:admin/ui/route/cubit/route_detail_cubit.dart';
import 'package:admin/ui/route/cubit/route_list_cubit.dart';
import 'package:admin/ui/route/ui/create_route_screen.dart';
import 'package:admin/ui/route/ui/route_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class RouteListScreen extends SearchListScreen<RouteListCubit, RouteModel> {
  const RouteListScreen({super.key, super.useScaffold = true});

  @override
  String get title => 'Routes';

  @override
  String get searchHint => 'Search routes…';

  @override
  EdgeInsets get itemPadding => AppPadding.gutter;

  @override
  bool get showFilter => true;

  @override
  bool get showSort => false;

  @override
  bool isFilterActive(RouteListCubit cubit) =>
      cubit.activeFilter != null || cubit.sortOption != RouteSortOption.nameAsc;

  @override
  void onFilterTap(BuildContext context, RouteListCubit cubit) =>
      _showFilterSheet(context, cubit);

  @override
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No routes found'));
  }

  @override
  Widget? buildFloatingActionButton(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: () {
        final routeListCubit = context.read<RouteListCubit>();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BlocProvider(
              create: (context) => CreateRouteCubit(
                getIt<RouteRepository>(),
                getIt<LocationService>(),
                fleetId: routeListCubit.fleetId,
              ),
              child: CreateRouteScreen(fleetId: routeListCubit.fleetId),
            ),
          ),
        ).then((_) {
          // Refresh list after returning from create screen if it was successful
          // For now just load again
          if (context.mounted) {
            context.read<RouteListCubit>().load();
          }
        });
      },
      icon: const Icon(Icons.add),
      label: const Text('Add Route'),
    );
  }

  @override
  Widget buildItem(BuildContext context, RouteModel route, int index) {
    final firstStop = route.stops.isNotEmpty ? route.stops.first : null;
    final lastStop = route.stops.length > 1 ? route.stops.last : null;

    return RouteInfoCard(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BlocProvider(
              create: (context) => getIt<RouteDetailCubit>(param1: route.id),
              child: RouteDetailScreen(routeId: route.id),
            ),
          ),
        );
      },
      name: route.name,
      status: route.isActive ? Status.inprogress : Status.sceduled,
      start: TimelineModel(
        title: firstStop?.stopName ?? 'Start',
        dateTime: route.createdAt,
      ),
      end: TimelineModel(
        title: lastStop?.stopName ?? 'End',
        dateTime: route.createdAt,
      ),
    );
  }

  void _showFilterSheet(BuildContext context, RouteListCubit cubit) {
    // Draft selections
    bool? selectedFilter = cubit.activeFilter;
    RouteSortOption selectedSort = cubit.sortOption;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(0, 20, 0, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Filter & Sort',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(ctx).pop(),
                    ),
                  ],
                ),
              ),
              const Divider(),
              // Sort Section
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Sort by',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              ...RouteSortOption.values.map((option) {
                final labels = {
                  RouteSortOption.nameAsc: 'Name (A → Z)',
                  RouteSortOption.nameDesc: 'Name (Z → A)',
                  RouteSortOption.newest: 'Newest first',
                  RouteSortOption.oldest: 'Oldest first',
                };
                return RadioListTile<RouteSortOption>(
                  title: Text(labels[option]!),
                  value: option,
                  groupValue: selectedSort,
                  dense: true,
                  onChanged: (v) {
                    setSheetState(() => selectedSort = v!);
                  },
                );
              }),
              const Divider(),
              // Status Section
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Filter by Status',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('All'),
                        selected: selectedFilter == null,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedFilter = null);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Active'),
                        selected: selectedFilter == true,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedFilter = true);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Inactive'),
                        selected: selectedFilter == false,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedFilter = false);
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          cubit.updateFiltersAndSort(clearAll: true);
                          Navigator.of(ctx).pop();
                        },
                        child: const Text('Clear All'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          cubit.updateFiltersAndSort(
                            activeFilter: selectedFilter,
                            sortOption: selectedSort,
                          );
                          Navigator.of(ctx).pop();
                        },
                        child: const Text('Apply'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
