import 'package:admin/di/service_locator.dart';
import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/repository/route_repository.dart';
import 'package:admin/ui/driver/cubit/fleet_list_cubit.dart';
import 'package:admin/ui/driver/ui/screens/routes/route_list_screen.dart';
import 'package:admin/ui/route/cubit/route_list_cubit.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';

class FleetListScreen extends SearchListScreen<FleetListCubit, FleetModel> {
  const FleetListScreen({super.key});

  @override
  String get title => 'Fleets';

  @override
  String get searchHint => 'Search fleets…';

  @override
  Widget buildItem(BuildContext context, FleetModel fleet, int index) {
    return ListTile(
      title: Text(fleet.name),
      subtitle: Text(fleet.companyName ?? ''),
      trailing: const Icon(Icons.chevron_right, size: 20),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => BlocProvider(
            create: (context) =>
                RouteListCubit(getIt<RouteRepository>(), fleetId: fleet.id)
                  ..load(),
            child: RouteListScreen(),
          ),
        ),
      ),
    );
  }

  @override
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No fleets found'));
  }
}
