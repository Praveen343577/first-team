import 'package:flutter/material.dart';

abstract class DashboardBase extends StatefulWidget {
  Tab get tab;

  final String title;
  final String description;

  const DashboardBase({
    super.key,
    required this.title,
    required this.description,
  });

  /// Whether to show the large header (title and description) in the AppBar.
  bool get showHeader => true;

  /// Override this if the dashboard has tabs.
  List<Tab>? get tabs => null;

  /// Content for each tab if [tabs] is not null.
  List<Widget>? get tabBodies => null;

  /// Single content view if [tabs] is null.
  List<Widget> buildContent(BuildContext context) => [];

  /// Content to show on the dashboard when there are no tabs.
  /// If this is provided, it will take precedence over [buildContent].
  Widget? buildSingleContent(BuildContext context) => null;

  Widget? buildStickyHeader(BuildContext context) => null;

  @override
  State<DashboardBase> createState() => _DashboardBaseState();
}

class DashboardLayout {
  static const double stickyHeaderHeight = 120;
}

class _DashboardBaseState extends State<DashboardBase>
    with AutomaticKeepAliveClientMixin, TickerProviderStateMixin {
  TabController? _tabController;

  @override
  void initState() {
    super.initState();
    if (widget.tabs != null) {
      _tabController = TabController(length: widget.tabs!.length, vsync: this);
    }
  }

  @override
  void didUpdateWidget(DashboardBase oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.tabs?.length != oldWidget.tabs?.length) {
      _tabController?.dispose();
      if (widget.tabs != null) {
        _tabController = TabController(
          length: widget.tabs!.length,
          vsync: this,
        );
      } else {
        _tabController = null;
      }
    }
  }

  @override
  void dispose() {
    _tabController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final stickyHeader = widget.buildStickyHeader(context);

    if (widget.tabs != null) {
      return Scaffold(body: _buildTabView(context, stickyHeader));
    }

    return Scaffold(body: buildBody(context, stickyHeader));
  }

  Widget buildBody(BuildContext context, Widget? stickyHeader) {
    final singleContent = widget.buildSingleContent(context);

    return CustomScrollView(
      slivers: [
        _buildAppBar(context),
        if (stickyHeader != null) _buildStickyHeader(stickyHeader),
        const SliverToBoxAdapter(child: SizedBox(height: 8)),
        if (singleContent != null)
          SliverFillRemaining(hasScrollBody: true, child: singleContent)
        else
          SliverList(
            delegate: SliverChildListDelegate(widget.buildContent(context)),
          ),
      ],
    );
  }

  Widget _buildTabView(BuildContext context, Widget? stickyHeader) {
    return NestedScrollView(
      headerSliverBuilder: (context, innerBoxIsScrolled) {
        return [
          _buildAppBar(context, isTabbed: true),
          if (stickyHeader != null) _buildStickyHeader(stickyHeader),
        ];
      },
      body: TabBarView(
        controller: _tabController,
        children: widget.tabBodies ?? [],
      ),
    );
  }

  Widget _buildAppBar(BuildContext context, {bool isTabbed = false}) {
    final double headerHeight = widget.showHeader
        ? (isTabbed ? 128 : 96)
        : (isTabbed ? kToolbarHeight + 32 : kToolbarHeight);

    return SliverAppBar(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      pinned: true,
      expandedHeight: headerHeight,
      automaticallyImplyLeading: true,
      flexibleSpace: widget.showHeader
          ? FlexibleSpaceBar(
              titlePadding: const EdgeInsetsDirectional.only(
                top: 24,
                start: 16,
                bottom: 16, // Added space for tabs
              ),
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    widget.title,
                    style: Theme.of(context).textTheme.titleMedium,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    widget.description,
                    style: Theme.of(
                      context,
                    ).textTheme.bodySmall!.copyWith(fontSize: 10),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            )
          : null,
      bottom: widget.tabs != null
          ? TabBar(
              controller: _tabController,
              tabs: widget.tabs!,
              isScrollable: false,
              labelColor: Theme.of(context).primaryColor,
              unselectedLabelColor: Colors.grey,
            )
          : null,
    );
  }

  Widget _buildStickyHeader(Widget child) {
    return SliverPersistentHeader(
      pinned: true,
      delegate: _StickyHeaderDelegate(
        child: child,
        extent: DashboardLayout.stickyHeaderHeight,
      ),
    );
  }

  @override
  bool get wantKeepAlive => true;
}

class _StickyHeaderDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;
  final double extent;

  const _StickyHeaderDelegate({required this.child, required this.extent});

  @override
  double get minExtent => extent;

  @override
  double get maxExtent => extent;

  @override
  Widget build(
    BuildContext context,
    double shrinkOffset,
    bool overlapsContent,
  ) {
    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).dividerColor.withValues(alpha: 0.25),
          ),
        ),
      ),
      child: SizedBox.expand(
        child: Align(alignment: Alignment.centerLeft, child: child),
      ),
    );
  }

  @override
  bool shouldRebuild(covariant _StickyHeaderDelegate oldDelegate) {
    return oldDelegate.child != child || oldDelegate.extent != extent;
  }
}
