import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:injectable/injectable.dart';
import 'package:admin/ui/driver/ui/screens/sign_in/login_credentials.dart';

@injectable
class LoginFormBloc extends FormBloc<String, String> {
  final email = TextFieldBloc(
    validators: [FieldBlocValidators.required, FieldBlocValidators.email],
  );

  final password = TextFieldBloc(
    validators: [FieldBlocValidators.required],
  );

  LoginFormBloc(LoginCredentials credentials) {
    addFieldBlocs(fieldBlocs: [email, password]);

    if (credentials.email.isNotEmpty) {
      email.updateInitialValue(credentials.email);
    }
    if (credentials.password.isNotEmpty) {
      password.updateInitialValue(credentials.password);
    }
  }

  @override
  void onSubmitting() {
    // This is handled by the LoginCubit
  }
}
