import "package:ui/ui.dart";
import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/models/driver/dto/driver_scorecard_response_dto.dart';
import 'package:admin/models/recent_activity/recent_activity_item.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/repository/recent_activity_repository.dart';
import 'package:admin/di/service_locator.dart';
import 'package:admin/ui/driver/cubit/driver_detail_cubit.dart';
import 'package:admin/ui/driver/cubit/driver_scorecard_cubit.dart';
import 'package:admin/ui/driver/cubit/get_fleet_cubit.dart';
import 'package:admin/ui/driver/cubit/update_driver_profile_cubit.dart';
import 'package:admin/ui/driver/ui/screens/driver/update_driver_profile_screen.dart';
import 'package:admin/ui/common/mixin/common_form_mixin.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:shimmer/shimmer.dart';

class DriverDetailScreen extends FetchScreen<DriverDetailCubit, DriverModel>
    with CommonFormMixin {
  // final String driverId;

  const DriverDetailScreen({super.key});


  @override
  Widget buildSuccess(BuildContext context, DriverModel profile) {
    // Record this driver in recent activity
    getIt<RecentActivityRepository>().addItem(
      RecentActivityItem(
        id: profile.id,
        type: 'driver',
        title: profile.fullName,
        subtitle: profile.email,
        viewedAt: DateTime.now(),
      ),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text("Driver"),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'edit') {
                _onEdit(context, profile);
              } else if (value == 'delete') {
                _onDelete(context);
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Text('Edit'),
                  ],
                ),
              ),
              PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Text(
                      'Delete',
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: AppPadding.p16,
        child: Column(
          children: [
            /// PROFILE HEADER
            buildProfileChangeAvatar(
              context,
              imageUrl: profile.profilePicUrl,
              driverId: profile.id,
              isEditable: false,
              isCard: false,
            ),
            const SizedBox(height: 8),
            Text(
              profile.fullName,
              style: Theme.of(
                context,
              ).textTheme.titleMedium!.copyWith(fontSize: 22),
            ),
            const SizedBox(height: 8),

            Text(profile.id, style: Theme.of(context).textTheme.bodySmall),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  profile.email,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(width: 4),
                Text(
                  profile.isActive ? 'Active' : 'Inactive',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: profile.isActive ? Colors.green : Colors.red,
                      ),
                ),
              ],
            ),

            const SizedBox(height: 16),
            BlocBuilder<DriverScorecardCubit, FetchOnlyState<DriverScorecardResponseDto>>(
              builder: (context, state) {
                if (state.isLoaded) {
                  final scorecard = state.data!;
                  final currentPeriod = context.read<DriverScorecardCubit>().period;
                  return Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStatColumn(context, "Rating", scorecard.ratingScore.toStringAsFixed(1)),
                          _buildStatColumn(context, "On-Time", "${scorecard.onTimeDeliveryRate.toStringAsFixed(0)}%"),
                          _buildStatColumn(context, "Trips", scorecard.totalTrips.toString()),
                        ],
                      ),
                      const SizedBox(height: 16),
                      buildSectionCard(
                        context: context,
                        icon: Icons.analytics_outlined,
                        title: "Performance & Scorecard",
                        children: [
                          // Safety score gauge/bar
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      "SAFETY SCORE",
                                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                                          ),
                                    ),
                                    Text(
                                      "${scorecard.safetyScore.toStringAsFixed(0)}/100",
                                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                            fontWeight: FontWeight.bold,
                                            color: scorecard.safetyScore >= 90
                                                ? Colors.green
                                                : scorecard.safetyScore >= 70
                                                    ? Colors.orange
                                                    : Colors.red,
                                          ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: LinearProgressIndicator(
                                    value: scorecard.safetyScore / 100,
                                    minHeight: 8,
                                    backgroundColor: Colors.grey[200],
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      scorecard.safetyScore >= 90
                                          ? Colors.green
                                          : scorecard.safetyScore >= 70
                                              ? Colors.orange
                                              : Colors.red,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Divider(),
                          // Grid of driving behaviors and trip details
                          GridView.count(
                            crossAxisCount: 2,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            childAspectRatio: 2.2,
                            crossAxisSpacing: 16,
                            mainAxisSpacing: 8,
                            children: [
                              _buildScorecardMetric(
                                context,
                                "Harsh Braking",
                                scorecard.harshBrakingCount.toString(),
                                Icons.warning_amber_rounded,
                                scorecard.harshBrakingCount > 0 ? Colors.orange : Colors.grey,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Harsh Accel.",
                                scorecard.harshAccelerationCount.toString(),
                                Icons.speed,
                                scorecard.harshAccelerationCount > 0 ? Colors.orange : Colors.grey,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Overspeeding",
                                scorecard.overspeedCount.toString(),
                                Icons.trending_up,
                                scorecard.overspeedCount > 0 ? Colors.red : Colors.grey,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Completion Rate",
                                "${(scorecard.completionRate * 100).toStringAsFixed(0)}%",
                                Icons.check_circle_outline,
                                Colors.blue,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Distance",
                                "${scorecard.totalDistanceKm.toStringAsFixed(1)} km",
                                Icons.navigation_outlined,
                                Colors.indigo,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Avg Speed",
                                "${scorecard.avgSpeed.toStringAsFixed(1)} km/h",
                                Icons.tire_repair,
                                Colors.teal,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Runtime",
                                "${scorecard.totalRuntimeHours.toStringAsFixed(1)} hrs",
                                Icons.timer_outlined,
                                Colors.deepPurple,
                              ),
                              _buildScorecardMetric(
                                context,
                                "Idle Time",
                                "${scorecard.idleTimeMinutes.toStringAsFixed(0)} mins",
                                Icons.snooze,
                                scorecard.idleTimeMinutes > 30 ? Colors.amber : Colors.grey,
                              ),
                            ],
                          ),
                          const Divider(),
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _buildPeriodButton(context, 'Today', ScorecardPeriod.today, currentPeriod),
                                _buildPeriodButton(context, 'Week', ScorecardPeriod.week, currentPeriod),
                                _buildPeriodButton(context, 'Month', ScorecardPeriod.month, currentPeriod),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                } else if (state.isError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        'Failed to load scorecard: ${state.errorMessage}',
                        style: const TextStyle(color: Colors.red),
                      ),
                    ),
                  );
                }
                return _buildScorecardShimmer(context);
              },
            ),

            const SizedBox(height: 16),

            /// BASIC INFO
            buildSectionCard(
              context: context,
              icon: Icons.person_outline,
              title: "Basic Information",
              children: [
                buildField(context, "FULL NAME", profile.fullName),
                buildField(context, "EMAIL", profile.email),
                buildField(context, "DATE OF BIRTH", profile.dob),
                buildField(context, "BLOOD GROUP", profile.bloodGroup),
              ],
            ),

            const SizedBox(height: 16),

            /// CONTACT INFO
            buildSectionCard(
              context: context,
              icon: Icons.contact_phone_outlined,
              title: "Contact Information",
              children: [
                buildField(
                  context,
                  "PHONE NUMBER",
                  profile.mobile,
                  trailing: profile.mobile != null
                      ? IconButton(
                          icon: const Icon(Icons.call, size: 20),
                          onPressed: () => launchDialer(profile.mobile),
                        )
                      : null,
                ),
                buildField(context, "ADDRESS", profile.address),
              ],
            ),

            /// EMPLOYMENT
            buildSectionCard(
              context: context,
              icon: Icons.work_outline,
              title: "Employment",
              children: [
                buildField(context, "ROLE", profile.role),
                buildField(
                  context,
                  "STATUS",
                  profile.isActive ? 'Active' : 'Inactive',
                ),
                buildField(
                  context,
                  "JOINED DATE",
                  profile.createdAt.toString().split(' ')[0],
                ),
              ],
            ),

            const SizedBox(height: 16),

            /// EMERGENCY
            if (profile.emergencyContactName != null ||
                profile.emergencyContactNumber != null)
              buildSectionCard(
                context: context,
                icon: Icons.health_and_safety_outlined,
                title: "Emergency Contact",
                children: [
                  if (profile.emergencyContactName != null)
                    buildField(
                      context,
                      "CONTACT PERSON",
                      profile.emergencyContactName,
                    ),
                  if (profile.emergencyContactNumber != null)
                    buildField(
                      context,
                      "PHONE",
                      profile.emergencyContactNumber,
                      trailing: IconButton(
                        icon: const Icon(Icons.call, size: 20),
                        onPressed: () =>
                            launchDialer(profile.emergencyContactNumber),
                      ),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  /// SINGLE REUSABLE FUNCTION
  Widget buildField(
    BuildContext context,
    String label,
    String? value, {
    Widget? trailing,
  }) {
    final cs = Theme.of(context).colorScheme;
    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(
            context,
          ).textTheme.labelSmall?.copyWith(color: cs.onSurfaceVariant),
        ),
        const SizedBox(height: 4),
        Text(
          value ?? "-",
          style: Theme.of(
            context,
          ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
        ),
      ],
    );

    if (trailing == null) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: body,
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: body),
          trailing,
        ],
      ),
    );
  }

  Widget _buildStatColumn(BuildContext context, String title, String data) {
    return Column(
      children: [
        Text(
          data,
          style: Theme.of(
            context,
          ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(
          title.toUpperCase(),
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
        ),
      ],
    );
  }

  Widget _buildPeriodButton(BuildContext context, String label, ScorecardPeriod value, ScorecardPeriod selectedValue) {
    final isSelected = value == selectedValue;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: isSelected
            ? FilledButton(
                onPressed: () {},
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  visualDensity: VisualDensity.compact,
                ),
                child: Text(label),
              )
            : OutlinedButton(
                onPressed: () {
                  context.read<DriverScorecardCubit>().changePeriod(value);
                },
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  visualDensity: VisualDensity.compact,
                ),
                child: Text(label),
              ),
      ),
    );
  }

  Widget _buildScorecardShimmer(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark ? Colors.grey[800]! : Colors.grey[300]!;
    final highlightColor = isDark ? Colors.grey[700]! : Colors.grey[100]!;

    return Shimmer.fromColors(
      baseColor: baseColor,
      highlightColor: highlightColor,
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(
              3,
              (index) => Column(
                children: [
                  Container(
                    width: 50,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    width: 40,
                    height: 18,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        width: 150,
                        height: 16,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    height: 40,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 8),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    childAspectRatio: 2.2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 8,
                    children: List.generate(
                      8,
                      (index) => Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScorecardMetric(
    BuildContext context,
    String label,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerLowest,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: Theme.of(context).dividerColor.withValues(alpha: 0.1),
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: color.withValues(alpha: 0.1),
            radius: 16,
            child: Icon(icon, color: color, size: 16),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontSize: 10,
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                ),
                Text(
                  value,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _onEdit(BuildContext context, DriverModel profile) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => UpdateDriverProfileCubit(
                driverId: profile.id,
              )..populateForm(profile),
            ),
            BlocProvider(
              create: (context) => GetFleetCubit(
                fleetRepository: getIt<FleetRepository>(),
              )..load(),
            ),
          ],
          child: const UpdateDriverProfileScreen(),
        ),
      ),
    );
  }

  void _onDelete(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 24),
              Icon(
                Icons.delete_outline,
                size: 48,
                color: Theme.of(context).colorScheme.error,
              ),
              const SizedBox(height: 16),
              Text(
                "Delete Driver?",
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                "Are you sure you want to remove this driver? This action cannot be undone.",
                textAlign: TextAlign.center,
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text("Cancel"),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () async {
                        Navigator.pop(ctx); // Close dialog
                        try {
                          await context.read<DriverDetailCubit>().delete();
                          if (context.mounted) {
                            Navigator.pop(context); // Go back to list
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text("Driver deleted successfully"),
                              ),
                            );
                          }
                        } catch (e) {
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text("Failed to delete driver: $e"),
                              ),
                            );
                          }
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).colorScheme.error,
                        foregroundColor: Theme.of(context).colorScheme.onError,
                      ),
                      child: const Text("Delete"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
