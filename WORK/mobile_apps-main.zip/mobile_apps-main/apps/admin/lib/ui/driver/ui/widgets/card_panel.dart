import 'package:flutter/material.dart';
import 'package:ui/ui.dart';

class CardPanel<T extends Widget> extends StatelessWidget {
  final String? title;
  final List<T> items;
  final bool isCompact;
  final EdgeInsetsGeometry? margin;

  const CardPanel(
    this.title, {
    super.key,
    required this.items,
    this.margin,
  }) : isCompact = false;

  const CardPanel.compact(
    this.title, {
    super.key,
    required this.items,
    this.margin,
  }) : isCompact = true;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? const EdgeInsets.all(16.0),
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (title != null) ...[
              Padding(
                padding: AppPadding.p16,
                child: Text(
                  title!,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              const Divider(),
            ],
            for (int i = 0; i < items.length; i++) ...[
              items[i],
              if ((i != items.length - 1) && !isCompact) const Divider(),
            ],
          ],
        ),
      ),
    );
  }
}
