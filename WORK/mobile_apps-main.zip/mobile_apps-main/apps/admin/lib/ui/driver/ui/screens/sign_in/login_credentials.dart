import 'package:flutter/foundation.dart';
import 'package:injectable/injectable.dart';

@lazySingleton
class LoginCredentials {
  final String email;
  final String password;

  LoginCredentials()
      : email = kDebugMode ? 'admin@gmail.com' : '',
        password = kDebugMode ? 'Admin@123' : '';
}
