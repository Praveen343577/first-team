import 'package:admin/ui/driver/ui/screens/routes/dashboard_base.dart';
import 'package:admin/ui/driver/ui/widgets/charts.dart';
import 'package:admin/ui/driver/ui/widgets/detailed_navigation_card.dart';
import 'package:admin/ui/fleet/fleet_management_screen.dart';
import 'package:ui/ui.dart';
import 'package:admin/ui/fleet/ui/vehicle_status_map_screen.dart';
import 'package:admin/ui/common/widgets/fleet_health_status_section.dart';
import 'package:admin/models/dashboard/vehicle_status_map_model.dart';
import 'package:admin/ui/dashboards/cubit/vehicle_status_map_cubit.dart';
import 'package:admin/models/dashboard/distance_chart_model.dart';
import 'package:admin/ui/dashboards/cubit/distance_chart_cubit.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:state_handler/state_handler.dart';
import 'package:flutter/material.dart';

class FleetDashboard extends DashboardBase {
  @override
  Tab get tab => const Tab(icon: Icon(Icons.local_shipping), text: 'Fleet');

  const FleetDashboard({super.key})
    : super(
        title: "Fleet",
        description: "Monitor and manage your vehicle fleet hierarchies.",
      );

  @override
  Widget buildStickyHeader(BuildContext context) => DetailedNavigationCard(
    title: 'Fleet',
    subtitle: 'Manage fleet hierarchies and vehicles',
    onTap: () {
      Navigator.of(context, rootNavigator: true).push(
        MaterialPageRoute(builder: (context) => const FleetManagementScreen()),
      );
    },
    leadingIcon: Icons.local_shipping,
  );

  @override
  List<Widget> buildContent(BuildContext context) => [
    _buildMapCard(context),
    _buildDistanceChartSection(context),
    _buildVehicleStatusSection(context),
    _buildFleetStatusSection(context),
    const SizedBox(height: 32),
  ];

  Widget _buildMapCard(BuildContext context) {
    return Padding(
      padding: AppPadding.gutter,
      child: Card(
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'Live Vehicle Locations',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 350, child: const VehicleStatusMapScreen()),
          ],
        ),
      ),
    );
  }

  Widget _buildDistanceChartSection(BuildContext context) {
    return Padding(
      padding: AppPadding.gutter,
      child:
          BlocBuilder<DistanceChartCubit, FetchOnlyState<DistanceChartModel>>(
            builder: (context, state) {
              if (state.isLoaded) {
                return _buildDistanceChart(context, state.data!);
              } else if (state.isError) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Text(
                      'Failed to load distance chart: ${state.errorMessage}',
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                );
              }
              return const ChartShimmer(title: 'Distance Traveled');
            },
          ),
    );
  }

  Widget _buildVehicleStatusSection(BuildContext context) {
    return Padding(
      padding: AppPadding.gutter,
      child:
          BlocBuilder<
            VehicleStatusMapCubit,
            FetchOnlyState<VehicleStatusMapModel>
          >(
            builder: (context, state) {
              if (state.isLoaded) {
                return _buildVehicleStatusMapChart(context, state.data!);
              } else if (state.isError) {
                return Center(
                  child: Text(
                    'Failed to load vehicle status SoC: ${state.errorMessage}',
                    style: const TextStyle(color: Colors.red),
                  ),
                );
              }
              return const ChartShimmer(title: 'Vehicle State of Charge (SoC)');
            },
          ),
    );
  }

  Widget _buildFleetStatusSection(BuildContext context) {
    return const Padding(
      padding: AppPadding.gutter,
      child: FleetHealthStatusSection(),
    );
  }

  Widget _buildVehicleStatusMapChart(
    BuildContext context,
    VehicleStatusMapModel model,
  ) {
    final List<ChartDataPoint> data = [];
    if (model.individualVehicles.isEmpty) {
      data.add(const ChartDataPoint('No Vehicles', 0, color: Colors.grey));
    } else {
      for (var vehicle in model.individualVehicles) {
        data.add(
          ChartDataPoint(
            vehicle.vehicleRegNo,
            vehicle.soc ?? 0.0,
            color: vehicle.status.toLowerCase() == 'active'
                ? const Color(0xFF4CAF50)
                : const Color(0xFF9E9E9E),
          ),
        );
      }
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Vehicle State of Charge (SoC)',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.green.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Vehicles: ${model.totalVehicles}',
                    style: const TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 220,
              child: SfCartesianChart(
                plotAreaBorderWidth: 0,
                primaryXAxis: const CategoryAxis(
                  majorGridLines: MajorGridLines(width: 0),
                  labelStyle: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                  labelRotation: -20,
                ),
                primaryYAxis: const NumericAxis(
                  axisLine: AxisLine(width: 0),
                  majorTickLines: MajorTickLines(size: 0),
                  minimum: 0,
                  maximum: 100,
                  title: AxisTitle(
                    text: 'SoC (%)',
                    textStyle: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                series: <CartesianSeries<ChartDataPoint, String>>[
                  ColumnSeries<ChartDataPoint, String>(
                    dataSource: data,
                    xValueMapper: (ChartDataPoint p, _) => p.label,
                    yValueMapper: (ChartDataPoint p, _) => p.value,
                    pointColorMapper: (ChartDataPoint p, _) => p.color,
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(6),
                    ),
                    dataLabelSettings: const DataLabelSettings(
                      isVisible: true,
                      textStyle: TextStyle(
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                      labelAlignment: ChartDataLabelAlignment.top,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDistanceChart(
    BuildContext context,
    DistanceChartModel chartModel,
  ) {
    final List<ChartDataPoint> points = [];
    if (chartModel.data.isEmpty) {
      points.add(const ChartDataPoint('No Data', 0));
    } else {
      for (var item in chartModel.data) {
        final label = item['date'] ?? item['timestamp'] ?? '';
        final value = (item['distance_km'] ?? item['value'] ?? 0.0) as num;
        points.add(ChartDataPoint(label.toString(), value.toDouble()));
      }
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Distance Traveled',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.blue.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Total: ${chartModel.totalDistanceKm.toStringAsFixed(1)} km',
                    style: const TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 220,
              child: SfCartesianChart(
                plotAreaBorderWidth: 0,
                primaryXAxis: const CategoryAxis(
                  majorGridLines: MajorGridLines(width: 0),
                  labelStyle: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                primaryYAxis: const NumericAxis(
                  axisLine: AxisLine(width: 0),
                  majorTickLines: MajorTickLines(size: 0),
                  title: AxisTitle(
                    text: 'Distance (km)',
                    textStyle: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                series: <CartesianSeries<ChartDataPoint, String>>[
                  SplineAreaSeries<ChartDataPoint, String>(
                    dataSource: points,
                    xValueMapper: (ChartDataPoint p, _) => p.label,
                    yValueMapper: (ChartDataPoint p, _) => p.value,
                    name: 'Distance',
                    color: Colors.blue.withValues(alpha: 0.15),
                    borderColor: Colors.blue,
                    borderWidth: 3,
                    markerSettings: const MarkerSettings(
                      isVisible: true,
                      shape: DataMarkerType.circle,
                      width: 6,
                      height: 6,
                      color: Colors.blue,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
