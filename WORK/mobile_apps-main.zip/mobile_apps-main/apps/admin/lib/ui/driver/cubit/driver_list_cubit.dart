import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

enum SortOption { nameAsc, nameDesc, newest, oldest }

@injectable
class DriverListCubit extends FetchOnlyCubit<List<DriverModel>> with SearchableCubit {
  final DriverRepository _repository;

  DriverListCubit(this._repository);

  String _searchQuery = '';
  SortOption _sortOption = SortOption.nameAsc;
  bool? _activeFilter;

  @override
  String get searchQuery => _searchQuery;
  SortOption get sortOption => _sortOption;
  bool? get activeFilter => _activeFilter;

  @override
  void setSearchQuery(String query) {
    _searchQuery = query;
    load();
  }

  void updateFiltersAndSort({
    bool? activeFilter,
    SortOption? sortOption,
    bool clearAll = false,
  }) {
    if (clearAll) {
      _activeFilter = null;
      _sortOption = SortOption.nameAsc;
    } else {
      if (activeFilter != null || activeFilter == null) {
        _activeFilter = activeFilter;
      }
      if (sortOption != null) _sortOption = sortOption;
    }
    load();
  }

  @override
  Future<List<DriverModel>> fetchData() async {
    final drivers = await _repository.getDrivers();
    return _applyFiltersAndSort(drivers);
  }

  List<DriverModel> _applyFiltersAndSort(List<DriverModel> drivers) {
    var result = drivers.where((d) {
      final matchesSearch =
          _searchQuery.isEmpty ||
          d.fullName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          d.email.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesFilter =
          _activeFilter == null || d.isActive == _activeFilter;
      return matchesSearch && matchesFilter;
    }).toList();

    switch (_sortOption) {
      case SortOption.nameAsc:
        result.sort((a, b) => a.fullName.compareTo(b.fullName));
      case SortOption.nameDesc:
        result.sort((a, b) => b.fullName.compareTo(a.fullName));
      case SortOption.newest:
        result.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      case SortOption.oldest:
        result.sort((a, b) => a.createdAt.compareTo(b.createdAt));
    }
    return result;
  }
}
