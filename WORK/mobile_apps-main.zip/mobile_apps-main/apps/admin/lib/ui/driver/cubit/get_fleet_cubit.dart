import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:state_handler/state_handler.dart';

class GetFleetCubit extends BaseCubit<List<FleetModel>> {
  final FleetRepository _fleetRepository;

  GetFleetCubit({required FleetRepository fleetRepository})
    : _fleetRepository = fleetRepository;

  @override
  Future<List<FleetModel>> performSubmit() async {
    return await _fleetRepository.getFleets();
  }
}
