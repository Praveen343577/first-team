import 'package:admin/di/service_locator.dart';
import 'package:admin/models/driver/driver_model.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/ui/driver/cubit/create_driver_profile_cubit.dart';
import 'package:admin/ui/driver/cubit/driver_detail_cubit.dart';
import 'package:admin/ui/driver/cubit/driver_scorecard_cubit.dart';
import 'package:admin/ui/driver/cubit/driver_list_cubit.dart';
import 'package:admin/ui/driver/cubit/get_fleet_cubit.dart';
import 'package:admin/ui/driver/ui/screens/driver/create_driver_profile_screen.dart';
import 'package:admin/ui/driver/ui/screens/driver/driver_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:state_handler/state_handler.dart';
import 'package:ui/ui.dart';

class DriverListScreen
    extends SearchListScreen<DriverListCubit, DriverModel> {
  const DriverListScreen({super.key, super.onItemTap, super.useScaffold = true});

  @override
  String get title => 'Drivers';

  @override
  String get searchHint => 'Search drivers…';

  @override
  EdgeInsets get itemPadding => AppPadding.gutter;

  @override
  Widget? buildFloatingActionButton(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: () => _navigateToCreateDriver(context),
      label: const Text('Add Driver'),
      icon: const Icon(Icons.add),
    );
  }

  @override
  bool get showFilter => true;

  @override
  bool get showSort => false;

  @override
  bool isFilterActive(DriverListCubit cubit) =>
      cubit.activeFilter != null || cubit.sortOption != SortOption.nameAsc;

  @override
  void onFilterTap(BuildContext context, DriverListCubit cubit) =>
      _showFilterSheet(context, cubit);

  @override
  Widget buildEmpty(BuildContext context) {
    return const Center(child: Text('No drivers found'));
  }

  @override
  Widget buildItem(BuildContext context, DriverModel driver, int index) {
    return DriverCompact(
      onTap: onItemTap != null
          ? null
          : () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MultiBlocProvider(
                    providers: [
                      BlocProvider(
                        create: (context) => DriverDetailCubit(
                          getIt<DriverRepository>(),
                          driverId: driver.id,
                        ),
                      ),
                      BlocProvider(
                        create: (context) => DriverScorecardCubit(
                          getIt<DriverRepository>(),
                          driverId: driver.id,
                        )..load(),
                      ),
                    ],
                    child: const Material(child: DriverDetailScreen()),
                  ),
                ),
              ),
      driver: Driver(
        name: driver.fullName,
        vehicleNumber: driver.id,
        profileImageUrl: driver.profilePicUrl ?? '',
      ),
    );
  }

  void _navigateToCreateDriver(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => MultiBlocProvider(
          providers: [
            BlocProvider(
              create: (context) => CreateDriverProfileCubit(
                authRepository: getIt<AuthRepository>(),
                driverRepository: getIt<DriverRepository>(),
              ),
            ),
            BlocProvider(
              create: (context) => GetFleetCubit(
                fleetRepository: getIt<FleetRepository>(),
              )..load(),
            ),
          ],
          child: const CreateDriverProfileScreen(),
        ),
      ),
    );
  }

  void _showFilterSheet(BuildContext context, DriverListCubit cubit) {
    // Draft selections
    bool? selectedFilter = cubit.activeFilter;
    SortOption selectedSort = cubit.sortOption;

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(0, 20, 0, 32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Filter & Sort',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.of(ctx).pop(),
                    ),
                  ],
                ),
              ),
              const Divider(),
              // Sort Section
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Sort by',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              ...SortOption.values.map((option) {
                final labels = {
                  SortOption.nameAsc: 'Name (A → Z)',
                  SortOption.nameDesc: 'Name (Z → A)',
                  SortOption.newest: 'Newest first',
                  SortOption.oldest: 'Oldest first',
                };
                return RadioListTile<SortOption>(
                  title: Text(labels[option]!),
                  value: option,
                  groupValue: selectedSort,
                  dense: true,
                  onChanged: (v) {
                    setSheetState(() => selectedSort = v!);
                  },
                );
              }),
              const Divider(),
              // Status Section
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: Text(
                  'Filter by Status',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('All'),
                        selected: selectedFilter == null,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedFilter = null);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Active'),
                        selected: selectedFilter == true,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedFilter = true);
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: ChoiceChip(
                        label: const Text('Inactive'),
                        selected: selectedFilter == false,
                        selectedColor: Theme.of(ctx).colorScheme.primary,
                        onSelected: (_) {
                          setSheetState(() => selectedFilter = false);
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () {
                          cubit.updateFiltersAndSort(clearAll: true);
                          Navigator.of(ctx).pop();
                        },
                        child: const Text('Clear All'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {
                          cubit.updateFiltersAndSort(
                            activeFilter: selectedFilter,
                            sortOption: selectedSort,
                          );
                          Navigator.of(ctx).pop();
                        },
                        child: const Text('Apply'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
