import "package:ui/ui.dart";
import 'package:admin/ui/driver/form_bloc/driver_form_bloc.dart';
import 'package:admin/ui/driver/cubit/get_fleet_cubit.dart';
import 'package:admin/ui/driver/cubit/update_driver_profile_cubit.dart';
import 'package:state_handler/state_handler.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_form_bloc_plus/flutter_form_bloc_plus.dart';
import 'package:admin/ui/common/mixin/common_form_mixin.dart';
import 'package:admin/models/fleet/fleet_model.dart';

mixin DriverProfileFormMixin on CommonFormMixin {
  /// Builds the common form fields for driver profile
  Widget buildDriverProfileFields(
    BuildContext context,
    CreateDriverProfileFormBloc fb, {
    String? driverId,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        buildProfileChangeAvatar(context, driverId: driverId),
        const SizedBox(height: 24),
        buildSectionCard(
          context: context,
          icon: Icons.person_outline,
          title: 'Personal Details',
          children: [
            _buildField(
              label: 'Full Name *',
              hint: 'e.g. John Doe',
              textFieldBloc: fb.fullName,
              maxLength: 60,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
                LengthLimitingTextInputFormatter(60),
              ],
            ),
            const SizedBox(height: 16),
            _buildField(
              label: 'Email *',
              hint: 'e.g. john@ekaconnect.com',
              textFieldBloc: fb.email,
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            _buildDatePicker(
              context: context,
              label: 'Date of Birth *',
              hint: 'Select Date',
              textFieldBloc: fb.dob,
            ),
            const SizedBox(height: 16),
            _buildDropdown<String>(
              label: 'Blood Group *',
              hint: 'Select Blood Group',
              selectFieldBloc: fb.bloodGroup,
              itemBuilder: (context, value) => FieldItem(child: Text(value)),
            ),
          ],
        ),
        const SizedBox(height: 24),
        buildSectionCard(
          context: context,
          icon:
              Icons.business_outlined, // Icon representing a fleet/organization
          title: 'Fleet Details',
          children: [
            BlocListener<GetFleetCubit, BaseState<List<FleetModel>>>(
              listener: (context, state) {
                if (state is BaseSuccess<List<FleetModel>>) {
                  fb.fleet.updateItems(state.data);

                  // Notify UpdateCubit if applicable to select the fleet
                  final updateCubit = context.read<UpdateDriverProfileCubit?>();
                  if (updateCubit != null && driverId != null) {
                    updateCubit.onFleetsLoaded();
                  }
                }
              },
              child: BlocBuilder<GetFleetCubit, BaseState<List<FleetModel>>>(
                builder: (context, state) {
                  // if (fb.fleet.value != null) {
                  // return Text(fb.fleet.value?.name ?? 'Select Fleet');
                  // }
                  return _buildDropdown<FleetModel>(
                    label: 'Fleet *',
                    hint: state is BaseLoading
                        ? 'Loading fleets...'
                        : 'Select Fleet',
                    selectFieldBloc: fb.fleet,
                    itemBuilder: (context, value) =>
                        FieldItem(child: Text(value.name)),
                  );
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        buildSectionCard(
          context: context,
          icon: Icons.contact_phone_outlined,
          title: 'Contact Information',
          children: [
            _buildField(
              label: 'Phone Number *',
              hint: 'e.g. 9876543210',
              textFieldBloc: fb.mobile,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(10),
              ],
            ),
            const SizedBox(height: 16),
            _buildField(
              label: 'Address',
              hint: 'e.g. 123 Main St, Springfield',
              textFieldBloc: fb.address,
            ),
          ],
        ),
        const SizedBox(height: 24),
        buildSectionCard(
          context: context,
          icon: Icons.health_and_safety_outlined,
          title: 'Emergency Contact',
          children: [
            _buildField(
              label: 'Emergency Contact Name *',
              hint: 'e.g. Jane Doe',
              textFieldBloc: fb.emergencyContactName,
              maxLength: 60,
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[a-zA-Z\s]')),
                LengthLimitingTextInputFormatter(60),
              ],
            ),
            const SizedBox(height: 16),
            _buildField(
              label: 'Emergency Contact Number *',
              hint: 'e.g. 9876543211',
              textFieldBloc: fb.emergencyContactNumber,
              keyboardType: TextInputType.phone,
              maxLength: 10,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(10),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildField({
    required String label,
    required String hint,
    required TextFieldBloc textFieldBloc,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    bool readOnly = false,
    VoidCallback? onTap,
    int? maxLength,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        TextFieldBlocBuilder(
          key: ValueKey(textFieldBloc),
          textFieldBloc: textFieldBloc,
          keyboardType: keyboardType,
          inputFormatters: inputFormatters,
          readOnly: readOnly,
          onTap: onTap,
          maxLength: maxLength,
          isEnabled: true,
          decoration: InputDecoration(hintText: hint, isDense: true),
        ),
      ],
    );
  }

  Widget _buildDatePicker({
    required BuildContext context,
    required String label,
    required String hint,
    required TextFieldBloc textFieldBloc,
  }) {
    return _buildField(
      label: label,
      hint: hint,
      textFieldBloc: textFieldBloc,
      readOnly: true,
      onTap: () async {
        final date = await showDatePicker(
          context: context,
          initialDate: DateTime.now().subtract(const Duration(days: 365 * 18)),
          firstDate: DateTime(1900),
          lastDate: DateTime.now(),
        );
        if (date != null) {
          // Format as GMT/ISO (YYYY-MM-DD)
          textFieldBloc.updateValue(date.toIso8601String().split('T')[0]);
        }
      },
    );
  }

  Widget _buildDropdown<T>({
    required String label,
    required String hint,
    required SelectFieldBloc<T, dynamic> selectFieldBloc,
    required FieldItem Function(BuildContext, T) itemBuilder,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          label,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 8),
        DropdownFieldBlocBuilder<T>(
          key: ValueKey(selectFieldBloc),
          selectFieldBloc: selectFieldBloc,
          itemBuilder: itemBuilder,
          isEnabled: true,
          decoration: InputDecoration(hintText: hint, isDense: true),
        ),
      ],
    );
  }

  /// Reusable parent scaffold screen for Create & Update profile forms
  Widget buildDriverProfileScreen({
    required BuildContext context,
    required String title,
    required String buttonText,
    required CreateDriverProfileFormBloc formBloc,
    required VoidCallback onSubmit,
    String? driverId,
  }) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
      ),
      extendBodyBehindAppBar: true,
      body: SingleChildScrollView(
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Container(
              margin: EdgeInsets.symmetric(horizontal: 8),
              height: 220,
              color: Color(0xff0B213F),
              width: double.infinity,
              padding: AppPadding.p16,
            ),
            Padding(
              padding: AppPadding.p16,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 50),
                        Text(
                          title,
                          style: Theme.of(context).textTheme.displaySmall
                              ?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                fontSize: 24,
                              ),
                        ),
                        Text(
                          driverId != null
                              ? 'Update the driver details in the system.'
                              : 'Enter the details to register a new driver in the system.',
                          style: const TextStyle(
                            color: Colors.white54,
                            fontSize: 18,
                          ),
                        ),
                        // SizedBox(height: 50),
                      ],
                    ),
                  ),
                  buildDriverProfileFields(
                    context,
                    formBloc,
                    driverId: driverId,
                  ),
                  const SizedBox(
                    height: 20,
                  ), // Reserve space for the sticky bottom bar
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          // color: EkaColors.borderColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(15),
          ),
        ),
        padding: const EdgeInsets.all(16.0),
        child: SafeArea(
          child:
              BlocBuilder<
                CreateDriverProfileFormBloc,
                FormBlocState<String, String>
              >(
                bloc: formBloc,
                builder: (context, state) {
                  return ElevatedButton(
                    onPressed: state.isValid() ? onSubmit : null,
                    child: Text(buttonText),
                  );
                },
              ),
        ),
      ),
    );
  }
}
