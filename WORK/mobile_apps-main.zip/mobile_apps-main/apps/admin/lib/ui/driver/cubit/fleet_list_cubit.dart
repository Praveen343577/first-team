import 'package:admin/models/fleet/fleet_model.dart';
import 'package:admin/repository/fleet_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class FleetListCubit extends FetchOnlyCubit<List<FleetModel>>
    with SearchableCubit {
  final FleetRepository _repository;

  FleetListCubit(this._repository);

  String _searchQuery = '';

  @override
  String get searchQuery => _searchQuery;

  @override
  void setSearchQuery(String query) {
    _searchQuery = query;
    load();
  }

  @override
  Future<List<FleetModel>> fetchData() => _repository.getFleets();
}
