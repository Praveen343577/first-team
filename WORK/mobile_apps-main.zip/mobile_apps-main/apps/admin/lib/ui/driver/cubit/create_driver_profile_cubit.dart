import 'package:admin/models/driver/dto/create_driver_profile_request_dto.dart';
import 'package:admin/repository/auth_repository.dart';
import 'package:admin/repository/driver_repository.dart';
import 'package:admin/ui/driver/form_bloc/driver_form_bloc.dart';
import 'package:state_handler/state_handler.dart';

class CreateDriverProfileCubit extends SubmitOnlyCubit {
  final CreateDriverProfileFormBloc formBloc = CreateDriverProfileFormBloc();

  CreateDriverProfileCubit({
    required AuthRepository authRepository,
    required DriverRepository driverRepository,
  }) : _driverRepository = driverRepository;

  final DriverRepository _driverRepository;

  @override
  void onChange(Change<SubmitOnlyState> change) {
    super.onChange(change);
  }

  @override
  Future<void> onSubmit() async {
    formBloc.submit();

    if (!formBloc.state.isValid()) {
      throw Exception('Please fill all required fields');
    }

    await _driverRepository.createDriverProfile(
      request: CreateDriverProfileRequestDto(
        email: formBloc.email.value,
        fullName: formBloc.fullName.value,
        mobile: formBloc.mobile.value,
        role: 'driver',
        fleetId: formBloc.fleet.value?.id ?? '',
        isActive: true,
        profilePicUrl: '',
        dob: formBloc.dob.value,
        bloodGroup: formBloc.bloodGroup.value ?? 'Select',
        address: formBloc.address.value,
        emergencyContactNumber: formBloc.emergencyContactNumber.value,
        emergencyContactName: formBloc.emergencyContactName.value,
        password: 'Driver@123',
      ),
    );
  }
}
