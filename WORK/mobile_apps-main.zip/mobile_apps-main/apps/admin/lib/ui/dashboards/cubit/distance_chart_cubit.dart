import 'package:admin/models/dashboard/distance_chart_model.dart';
import 'package:admin/repository/dashboard_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class DistanceChartCubit extends FetchOnlyCubit<DistanceChartModel> {
  final DashboardRepository _repository;
  String _period = 'day';

  DistanceChartCubit(this._repository);

  String get period => _period;

  void changePeriod(String newPeriod) {
    _period = newPeriod;
    load();
  }

  @override
  Future<DistanceChartModel> fetchData() => _repository.getDistanceChart(_period);
}
