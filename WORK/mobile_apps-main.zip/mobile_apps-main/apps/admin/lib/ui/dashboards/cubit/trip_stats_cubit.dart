import 'package:admin/models/dashboard/trip_stats_model.dart';
import 'package:admin/repository/dashboard_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class TripStatsCubit extends FetchOnlyCubit<TripStatsModel> {
  final DashboardRepository _repository;
  String _period = 'day';

  TripStatsCubit(this._repository);

  String get period => _period;

  void changePeriod(String newPeriod) {
    _period = newPeriod;
    load();
  }

  @override
  Future<TripStatsModel> fetchData() => _repository.getTripStats(_period);
}
