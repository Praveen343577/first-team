import 'package:admin/models/dashboard/fleet_status_model.dart';
import 'package:admin/repository/dashboard_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class FleetStatusCubit extends FetchOnlyCubit<FleetStatusModel> {
  final DashboardRepository _repository;

  FleetStatusCubit(this._repository);

  @override
  Future<FleetStatusModel> fetchData() => _repository.getFleetStatus();
}
