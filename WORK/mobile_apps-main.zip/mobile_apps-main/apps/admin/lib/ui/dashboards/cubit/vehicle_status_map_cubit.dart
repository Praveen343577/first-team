import 'package:admin/models/dashboard/vehicle_status_map_model.dart';
import 'package:admin/repository/dashboard_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class VehicleStatusMapCubit extends FetchOnlyCubit<VehicleStatusMapModel> {
  final DashboardRepository _repository;
  double _clusterDistanceKm = 5.0;

  VehicleStatusMapCubit(this._repository);

  double get clusterDistanceKm => _clusterDistanceKm;

  void changeClusterDistance(double newDistance) {
    _clusterDistanceKm = newDistance;
    load();
  }

  @override
  Future<VehicleStatusMapModel> fetchData() =>
      _repository.getVehicleStatusMap(_clusterDistanceKm);
}
