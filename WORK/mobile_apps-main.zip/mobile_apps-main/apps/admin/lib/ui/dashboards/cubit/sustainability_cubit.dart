import 'package:admin/models/dashboard/sustainability_model.dart';
import 'package:admin/repository/dashboard_repository.dart';
import 'package:injectable/injectable.dart';
import 'package:state_handler/state_handler.dart';

@lazySingleton
class SustainabilityCubit extends FetchOnlyCubit<SustainabilityModel> {
  final DashboardRepository _repository;

  SustainabilityCubit(this._repository);

  @override
  Future<SustainabilityModel> fetchData() => _repository.getSustainability();
}
