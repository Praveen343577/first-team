package com.ekaconnect.admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
