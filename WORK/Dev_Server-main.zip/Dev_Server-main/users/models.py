from django.db import models
from django.contrib.auth.models import AbstractUser,Group,Permission, BaseUserManager
import string,secrets
from datetime import timezone,timedelta

from ekaConnect import settings
from devices.models import Device

class UserManager(BaseUserManager):
    use_in_migrations = True

    def create_user(self, email, password=None, **extra_fields):
        """Create and save a User with email instead of username."""
        if not email:
            raise ValueError("Email is required")

        email = self.normalize_email(email)

        if not password:
            alphabet = string.ascii_letters + string.digits
            password = ''.join(secrets.choice(alphabet) for _ in range(10))

        user = self.model(email=email, username=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user  

    def create_superuser(self, email, password=None, **extra_fields):
        """Create and save a SuperUser with email and password."""
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(email, password, **extra_fields)

class User(AbstractUser):
    # Extend default Django user for profile
    email = models.EmailField(unique=True)
    mobile = models.CharField(max_length=15, blank=True, null=True)
    full_name = models.CharField(max_length=100, blank=True, null=True)
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    
    objects = UserManager() 
    
    groups = models.ManyToManyField(
        Group,
        related_name='EkaGroup',
        blank=True,
        help_text='The groups this user belongs to.',
        verbose_name='groups'
    )
    user_permissions = models.ManyToManyField(
        Permission,
        related_name='EkaPermissions',
        blank=True,
        help_text='Specific permissions for this user.',
        verbose_name='user permissions'
    )
    
    def save(self, *args, **kwargs):
        if not self.username:
            self.username = self.email
        super().save(*args, **kwargs)

class UserDeviceAssignment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='devices')
    devices = models.JSONField(default=list, blank=True)
    assigned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username 
        
class SubscriptionPlan(models.Model):
    # PLAN_CHOICES = [
    #     ('basic', 'Basic'),
    #     ('gold', 'Gold'),
    #     ('platinum', 'Platinum'),
    # ]

    # name = models.CharField(max_length=50, choices=PLAN_CHOICES, unique=True)
    name = models.CharField(max_length=50,unique=True)
    description = models.TextField(blank=True, null=True)
    features = models.JSONField(default=dict)  

    def __str__(self):
        return self.name

class UserSubscription(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="subscription")
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.CASCADE)
    start_date = models.DateTimeField(auto_now_add=True)
    end_date = models.DateTimeField(blank=True, null=True)  
    is_active = models.BooleanField(default=True)
    
    razorpay_order_id = models.CharField(max_length=100, blank=True, null=True)
    razorpay_payment_id = models.CharField(max_length=100, blank=True, null=True)
    razorpay_signature = models.CharField(max_length=200, blank=True, null=True)

    def activate(self, plan: SubscriptionPlan):
        self.plan = plan
        self.start_date = timezone.now()
        self.end_date = self.start_date + timedelta(days=plan.duration_days)
        self.save()

    def is_active(self):
        return self.end_date and self.end_date >= timezone.now()

    def __str__(self):
        return f"{self.user.email} - {self.plan.name if self.plan else 'No Plan'}"    

