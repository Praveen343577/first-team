import json
from channels.generic.websocket import AsyncWebsocketConsumer
from asgiref.sync import sync_to_async
from rest_framework import status
from rest_framework.response import Response
import asyncio
from django.db.models import Max
from channels.db import database_sync_to_async
from django.db import close_old_connections



class LiveDataConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
        await self.send(text_data=json.dumps({"message": "Connection established."}))

        self.device_ids = None
        self.platform = None
        self.username = None
        self.task = None

    async def disconnect(self, close_code):
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except:
                pass

    async def receive(self, text_data=None, bytes_data=None):
        if text_data:
            try:
                data = json.loads(text_data)
                self.device_ids = data.get("device_ids") if isinstance(data.get("device_ids"), list) else None
                self.platform = data.get("platform") if isinstance(data.get("platform"), str) else None
                self.username = data.get("username") if isinstance(data.get("username"), str) else None

                msg = "Showing data for all devices"
                if self.device_ids and self.platform:
                    msg = f"Filtering devices {self.device_ids} on platform {self.platform}"
                elif self.device_ids:
                    msg = f"Filtering devices {self.device_ids}"
                elif self.platform:
                    msg = f"Filtering platform {self.platform}"
                elif self.username:
                    msg = f"Filtering user devices {self.username}"

                if self.task:
                    self.task.cancel()
                    try:
                        await self.task
                    except:
                        pass

                self.task = asyncio.create_task(self.send_live_data())

                await self.send(text_data=json.dumps({"message": msg}))

            except json.JSONDecodeError:
                await self.send(text_data=json.dumps({"error": "Invalid JSON"}))

    async def send_live_data(self):
        try:
            while True:
                close_old_connections()

                data = await asyncio.wait_for(
                    self.get_latest_data(
                        device_ids=self.device_ids,
                        platform=self.platform,
                        username=self.username
                    ),
                    timeout=5
                )

                await self.send(text_data=json.dumps(data))
                await asyncio.sleep(10)

        except asyncio.CancelledError:
            pass

    @database_sync_to_async
    def get_latest_data(self, device_ids=None, platform=None, username=None):
        from devices.models import DeviceData, Device,LiveData
        from devices.serializers import DevicePartialDataSerializer,CustomDevicePartialDataSerializer
        from users.models import UserDeviceAssignment
        from django.db.models import OuterRef, Subquery
 
        queryset = LiveData.objects.all()
 
        if platform:
            platform_device_ids = Device.objects.filter(platform=platform).values_list('device_id', flat=True)
            queryset = queryset.filter(device_id__in=platform_device_ids)
 
        if device_ids:
            queryset = queryset.filter(device_id__in=device_ids)
 
        if username:
            try:
                user_assignment = UserDeviceAssignment.objects.get(user__email=username)
                user_device_ids = user_assignment.devices  # list of device IDs

                latest_entries = LiveData.objects.filter(imei__in=user_device_ids)

            except UserDeviceAssignment.DoesNotExist:
                return {"message": f"No devices assigned for user: {username}"}

        else:
            # Return all live data (fast because 1 row per device)
            latest_entries = LiveData.objects.all()
 
        if not latest_entries:
            return {"message": "No Data Found"}
        
        device_type_map = dict(
        Device.objects
        .filter(device_id__in=latest_entries.values_list("imei", flat=True))
        .values_list("device_id", "device_type"))

        
        device_variant_map = dict(
            Device.objects
            .filter(device_id__in=queryset.values_list("imei", flat=True))
            .values_list("device_id", "device_type_name")
        )

        if username == 'fanie.roos@unitrans.co.za':
            serializer = CustomDevicePartialDataSerializer(latest_entries, many=True, context={"device_type_map": device_type_map, "device_variant_map": device_variant_map,})
            return serializer.data
 
        serializer = DevicePartialDataSerializer(latest_entries, many=True, context={"device_type_map": device_type_map, "device_variant_map": device_variant_map,})
        return serializer.data
    

    
# class LiveDataConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         await self.send(text_data=json.dumps({"message": "Connection established."}))
 
#         self.device_ids = None
#         self.platform = None
#         self.username = None
#         self.running = True

 
#     async def disconnect(self, close_code):
#         print("WebSocket disconnected:", close_code)
#         self.running = False
 
#     async def receive(self, text_data=None, bytes_data=None):   
#         """
#         Expecting JSON like: {"device_ids": [1,2,3], "platform": "4w"}
#         """
#         if text_data:
#             try:
#                 data = json.loads(text_data)
#                 self.device_ids = data.get("device_ids") if isinstance(data.get("device_ids"), list) else None
#                 self.platform = data.get("platform") if isinstance(data.get("platform"), str) else None
#                 self.username = data.get("username") if isinstance(data.get("username"), str) else None
 
#                 msg = "Showing data for all devices"
#                 if self.device_ids and self.platform:
#                     msg = f"Filtering devices {self.device_ids} on platform {self.platform}"
#                 elif self.device_ids:
#                     msg = f"Filtering devices {self.device_ids}"
#                 elif self.platform:
#                     msg = f"Filtering platform {self.platform}"
#                 elif self.username:
#                     msg = f"Filtering user devices {self.username}"
                    
#                 asyncio.create_task(self.send_live_data())
 
#                 await self.send(text_data=json.dumps({"message": msg}))
                        
 
#             except json.JSONDecodeError:
#                 await self.send(text_data=json.dumps({"error": "Invalid JSON"}))
 
#     async def send_live_data(self):
#         while self.running:
#             data = await self.get_latest_data(device_ids=self.device_ids, platform=self.platform, username = self.username)
#             await self.send(text_data=json.dumps(data))
#             await asyncio.sleep(10)
 
#     @sync_to_async
#     def get_latest_data(self, device_ids=None, platform=None, username=None):
#         from devices.models import DeviceData, Device,LiveData
#         from devices.serializers import DevicePartialDataSerializer,CustomDevicePartialDataSerializer
#         from users.models import UserDeviceAssignment
#         from django.db.models import OuterRef, Subquery
 
#         queryset = LiveData.objects.all()
 
#         if platform:
#             platform_device_ids = Device.objects.filter(platform=platform).values_list('device_id', flat=True)
#             queryset = queryset.filter(device_id__in=platform_device_ids)
 
#         if device_ids:
#             queryset = queryset.filter(device_id__in=device_ids)
 
#         if username:
#             try:
#                 user_assignment = UserDeviceAssignment.objects.get(user__email=username)
#                 user_device_ids = user_assignment.devices  # list of device IDs

#                 latest_entries = LiveData.objects.filter(imei__in=user_device_ids)

#             except UserDeviceAssignment.DoesNotExist:
#                 return {"message": f"No devices assigned for user: {username}"}

#         else:
#             # Return all live data (fast because 1 row per device)
#             latest_entries = LiveData.objects.all()
 
#         if not latest_entries:
#             return {"message": "No Data Found"}
        
#         device_type_map = dict(
#         Device.objects
#         .filter(device_id__in=latest_entries.values_list("imei", flat=True))
#         .values_list("device_id", "device_type"))

        
#         device_variant_map = dict(
#             Device.objects
#             .filter(device_id__in=queryset.values_list("imei", flat=True))
#             .values_list("device_id", "device_type_name")
#         )

#         if username == 'fanie.roos@unitrans.co.za':
#             serializer = CustomDevicePartialDataSerializer(latest_entries, many=True, context={"device_type_map": device_type_map, "device_variant_map": device_variant_map,})
#             return serializer.data
 
#         serializer = DevicePartialDataSerializer(latest_entries, many=True, context={"device_type_map": device_type_map, "device_variant_map": device_variant_map,})
#         return serializer.data

# class DeviceCalculatedDataConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         await self.send(text_data=json.dumps({
#             "message": "Connection established. Send device_id or device_type_name to filter, or nothing to get all devices."
#         }))
#         self.device_id = None
#         self.device_type_name = None

#     async def receive(self, text_data):
#         data = json.loads(text_data or "{}")

#         self.device_id = data.get("device_id")
#         self.device_type_name = data.get("device_type_name")

#         if self.device_id:
#             await self.send(text_data=json.dumps({"message": f"Listening for device_id: {self.device_id}"}))
#         elif self.device_type_name:
#             await self.send(text_data=json.dumps({"message": f"Listening for device_type_name: {self.device_type_name}"}))
#         else:
#             await self.send(text_data=json.dumps({"message": "Listening for all device calculations"}))

#         await self.stream_data()

#     async def stream_data(self):
#         while True:
#             if self.device_id:
#                 data = await self.get_latest_data_by_device_id(self.device_id)
#             elif self.device_type_name:
#                 data = await self.get_latest_data_by_device_type_name(self.device_type_name)
#             else:
#                 data = await self.get_latest_data_for_all_devices()

#             await self.send(text_data=json.dumps(data))
#             await self.sleep(10)  # adjust as needed

#     @sync_to_async
#     def get_latest_data_by_device_id(self, device_id):
#         from devices.models import DeviceCalculatedData
#         from devices.serializers import DeviceCalculateSerializer

#         latest = DeviceCalculatedData.objects.filter(device_id=device_id).last()
#         if latest:
#             return DeviceCalculateSerializer(latest).data
#         return {"message": f"No data found for device_id: {device_id}"}

#     @sync_to_async
#     def get_latest_data_by_device_type_name(self, device_type_name):
#         from devices.models import Device, DeviceCalculatedData
#         from devices.serializers import DeviceCalculateSerializer

#         device_ids = Device.objects.filter(
#             device_type_name__icontains=device_type_name
#         ).values_list('device_id', flat=True)

#         latest_data = []
#         for did in device_ids:
#             latest = DeviceCalculatedData.objects.filter(device_id=did).last()
#             if latest:
#                 latest_data.append(DeviceCalculateSerializer(latest).data)

#         return {"data": latest_data or [], "message": "Data fetched by device_type_name"}

#     @sync_to_async
#     def get_latest_data_for_all_devices(self):
#         from devices.models import DeviceCalculatedData
#         from devices.serializers import DeviceCalculateSerializer
#         from django.db.models import Max

#         latest_timestamps = DeviceCalculatedData.objects.values('device_id').annotate(
#             latest_timestamp=Max('start_time')
#         )

#         latest_data = []
#         for entry in latest_timestamps:
#             record = DeviceCalculatedData.objects.filter(
#                 device_id=entry['device_id'],
#                 start_time=entry['latest_timestamp']
#             ).first()
#             if record:
#                 latest_data.append(DeviceCalculateSerializer(record).data)

#         return {"data": latest_data or [], "message": "Latest data for all devices"}

#     async def sleep(self, seconds):
#         import asyncio
#         await asyncio.sleep(seconds)

class DeviceCanDataConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
        await self.send(text_data=json.dumps({
            "message": "Connection established. Send device_id or device_type_name to filter, or nothing to get all devices."
        }))
        self.device_id = None
        self.device_type_name = None

    async def receive(self, text_data):
        import json
        data = json.loads(text_data or "{}")

        self.device_id = data.get("device_id")
        self.device_type_name = data.get("device_type_name")

        if self.device_id:
            await self.send(text_data=json.dumps({"message": f"Listening for device_id: {self.device_id}"}))
        elif self.device_type_name:
            await self.send(text_data=json.dumps({"message": f"Listening for device_type_name: {self.device_type_name}"}))
        else:
            await self.send(text_data=json.dumps({"message": "Listening for all devices"}))

        await self.stream_data()

    async def stream_data(self):
        from django.db import close_old_connections
        while True:
            if self.device_id:
                data = await self.get_latest_data_by_device_id(self.device_id)
            elif self.device_type_name:
                data = await self.get_latest_data_by_device_type_name(self.device_type_name)
            else:
                data = await self.get_latest_data_for_all_devices()

            await self.send(text_data=json.dumps(data))
            await self.sleep(10)

    @sync_to_async
    def get_latest_data_by_device_id(self, device_id):
        from devices.models import DeviceData
        from devices.serializers import DeviceCanDataSerializer

        latest = DeviceData.objects.filter(device_id=device_id).last()
        if latest:
            return DeviceCanDataSerializer(latest).data
        return {"message": f"No data found for device_id: {device_id}"}

    @sync_to_async
    def get_latest_data_by_device_type_name(self, device_type_name):
        from devices.models import Device, DeviceData
        from devices.serializers import DeviceCanDataSerializer

        device_ids = Device.objects.filter(
            device_type_name__icontains=device_type_name
        ).values_list('device_id', flat=True)

        latest_data = []
        for did in device_ids:
            latest = DeviceData.objects.filter(device_id=did).last()
            if latest:
                latest_data.append(DeviceCanDataSerializer(latest).data)

        return {"data": latest_data or [], "message": "Data fetched by device_type_name"}

    @sync_to_async
    def get_latest_data_for_all_devices(self):
        from devices.models import DeviceData
        from devices.serializers import DeviceCanDataSerializer
        from django.db.models import Max

        latest_timestamps = DeviceData.objects.values('device_id').annotate(
            latest_timestamp=Max('timestamp')
        )

        latest_data = []
        for entry in latest_timestamps:
            record = DeviceData.objects.filter(
                device_id=entry['device_id'],
                timestamp=entry['latest_timestamp']
            ).first()
            if record:
                latest_data.append(DeviceCanDataSerializer(record).data)

        return {"data": latest_data or [], "message": "Latest data for all devices"}

    async def sleep(self, seconds):
        import asyncio
        await asyncio.sleep(seconds)

# class TotalCalculationConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         self.is_active = True
#         # Initialize filters
#         self.device_id = None
#         self.device_type_name = None
#         self.platform = None
#         self.username = None

#         await self.send(text_data=json.dumps({
#             "message": "Connection established. Send device_type_name or device_id to filter, or nothing to get all devices."
#         }))

#     async def receive(self, text_data):
#         data = json.loads(text_data or "{}")
        
#         self.device_type_name = data.get("device_type_name")
#         self.device_id = data.get('device_id')
#         self.platform = data.get('platform')
#         self.username = data.get('username')

#         if self.device_type_name:
#             await self.send(text_data=json.dumps({"message": f"Listening for device_type_name: {self.device_type_name}"}))
#         elif self.device_id:
#             await self.send(text_data=json.dumps({"message": f"Listening for device_id: {self.device_id}"}))
#         elif self.platform:
#             await self.send(text_data=json.dumps({"message": f"Listening for devices for selected platform: {self.platform}"}))
#         elif self.username:
#             await self.send(text_data=json.dumps({"message": f"Listening for devices for user: {self.username}"}))
#         else:
#             await self.send(text_data=json.dumps({"message": "Listening for all devices"}))

#         # Start streaming data
#         asyncio.create_task(self.stream_data())

#     async def disconnect(self, close_code):
#         self.is_active = False

#     async def stream_data(self):
#         while self.is_active:
#             if self.username and self.device_type_name:
#                 data = await self.get_latest_data_for_username(self.username, self.device_type_name,self.platform)
#             elif self.username and self.platform:
#                 data = await self.get_latest_data_for_username(self.username, self.device_type_name,self.platform)
#             elif self.device_type_name:
#                 data = await self.get_latest_data_by_device_type_name(self.device_type_name)
#             elif self.device_id:
#                 data = await self.get_latest_data_by_device_id(self.device_id)
#             elif self.platform:
#                 data = await self.get_latest_data_for_platforms(self.platform)
#             elif self.username:
#                 data = await self.get_latest_data_for_username(self.username,self.device_type_name,self.platform)
#             else:
#                 data = await self.get_latest_data_for_all_devices()

#             await self.send(text_data=json.dumps(data))
#             await asyncio.sleep(10)





# class TotalCalculationConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         self.is_active = True

#         self.device_id = None
#         self.device_type_name = None
#         self.platform = None
#         self.username = None

#         self.stream_task = None

#         await self.send(text_data=json.dumps({
#             "message": "Connection established. Send device_type_name or device_id to filter, or nothing to get all devices."
#         }))

#     async def receive(self, text_data):
#         data = json.loads(text_data or "{}")

#         self.device_type_name = data.get("device_type_name")
#         self.device_id = data.get("device_id")
#         self.platform = data.get("platform")
#         self.username = data.get("username")

#         msg = "Listening for "
#         if self.device_type_name:
#             msg += f"device_type_name: {self.device_type_name}"
#         elif self.device_id:
#             msg += f"device_id: {self.device_id}"
#         elif self.platform:
#             msg += f"platform: {self.platform}"
#         elif self.username:
#             msg += f"user: {self.username}"
#         else:
#             msg += "all devices"

#         await self.send(text_data=json.dumps({"message": msg}))

#         if self.stream_task:
#             self.stream_task.cancel()

#         self.stream_task = asyncio.create_task(self.stream_data())

#     async def disconnect(self, close_code):
#         self.is_active = False
#         if self.stream_task:
#             self.stream_task.cancel()

#     async def stream_data(self):
#         try:
#             while True:
#                 try:
#                     if self.username and self.device_type_name:
                        
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_for_username(self.username, self.device_type_name, self.platform),
#                             timeout=5
#                         )
#                     elif self.username and self.platform:
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_for_username(self.username, self.device_type_name, self.platform),
#                             timeout=5
#                         )
#                     elif self.device_type_name:
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_by_device_type_name(self.device_type_name),
#                             timeout=5
#                         )
#                     elif self.device_id:
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_by_device_id(self.device_id),
#                             timeout=5
#                         )
#                     elif self.platform:
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_for_platforms(self.platform),
#                             timeout=5
#                         )
#                     elif self.username:
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_for_username(self.username, self.device_type_name, self.platform),
#                             timeout=5
#                         )
#                     else:
#                         data = await asyncio.wait_for(
#                             self.get_latest_data_for_all_devices(),
#                             timeout=5
#                         )
#                 except Exception as e:
#                     data = {"error": str(e)}

#                 try:
#                     await self.send(text_data=json.dumps(data))
#                 except Exception:
#                     break

#                 await asyncio.sleep(10)

#         except asyncio.CancelledError:
#             pass
# class TotalCalculationConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         await self.accept()
#         self.is_active = True

#         self.device_id = None
#         self.device_type_name = None
#         self.platform = None
#         self.username = None

#         self.stream_task = None  # Track streaming task

#         await self.send(text_data=json.dumps({
#             "message": "Connection established. Send device_type_name or device_id to filter, or nothing to get all devices."
#         }))

#     async def receive(self, text_data):
#         data = json.loads(text_data or "{}")

#         self.device_type_name = data.get("device_type_name")
#         self.device_id = data.get("device_id")
#         self.platform = data.get("platform")
#         self.username = data.get("username")

#         msg = "Listening for "
#         if self.device_type_name:
#             msg += f"device_type_name: {self.device_type_name}"
#         elif self.device_id:
#             msg += f"device_id: {self.device_id}"
#         elif self.platform:
#             msg += f"platform: {self.platform}"
#         elif self.username:
#             msg += f"user: {self.username}"
#         else:
#             msg += "all devices"

#         await self.send(text_data=json.dumps({"message": msg}))

#         # Start streaming data if not already started
#         if not self.stream_task or self.stream_task.done():
#             self.stream_task = asyncio.create_task(self.stream_data())

#     async def disconnect(self, close_code):
#         self.is_active = False
#         if self.stream_task and not self.stream_task.done():
#             self.stream_task.cancel()  # Cancel streaming task

#     async def stream_data(self):
#         try:
#             while self.is_active:
#                 try:
#                     # Choose query based on filters
#                     if self.username and self.device_type_name:
#                         data = await self.get_latest_data_for_username(self.username, self.device_type_name, self.platform)
#                     elif self.username and self.platform:
#                         data = await self.get_latest_data_for_username(self.username, self.device_type_name, self.platform)
#                     elif self.device_type_name:
#                         data = await self.get_latest_data_by_device_type_name(self.device_type_name)
#                     elif self.device_id:
#                         data = await self.get_latest_data_by_device_id(self.device_id)
#                     elif self.platform:
#                         data = await self.get_latest_data_for_platforms(self.platform)
#                     elif self.username:
#                         data = await self.get_latest_data_for_username(self.username, self.device_type_name, self.platform)
#                     else:
#                         data = await self.get_latest_data_for_all_devices()
#                 except Exception as e:
#                     # Catch query errors
#                     data = {"error": str(e)}

#                 try:
#                     await self.send(text_data=json.dumps(data))
#                 except Exception:
#                     # WS closed mid-send
#                     self.is_active = False
#                     break

#                 await asyncio.sleep(10)

#         except asyncio.CancelledError:
#             # Task cancelled due to disconnect
#             pass
    # @sync_to_async
    # def get_latest_data_by_device_type_name(self, device_type_name):
    #     from devices.models import DeviceTotalCalculationData, Device
    #     from django.db.models import Sum

    #     close_old_connections()

    #     queryset = DeviceTotalCalculationData.objects.all()

    #     if device_type_name:
    #         queryset = queryset.filter(
    #             device_id__in=Device.objects.filter(
    #                 device_type_name__icontains=device_type_name
    #             ).values_list("device_id", flat=True)
    #         )

    #     totals = queryset.aggregate(
    #         total_distance=Sum("total_distance"),
    #         co2_saving=Sum("co2_saving"),
    #         energy_consumption=Sum("energy_consumption"),
    #         run_time=Sum("run_time"),
    #         traction_energy=Sum("traction_energy"),
    #         regen_energy=Sum("regen_energy"),
    #         idle_time=Sum("idle_time"),
    #         charging_unit=Sum("charging_unit"),
    #         charging_count=Sum("charging_count"),
    #         cost_saved=Sum("cost_saved")
    #     )

    #     return {"data": totals or [], "message": f"Data fetched by device_type_name: {device_type_name}"}

    # @sync_to_async
    # def get_latest_data_by_device_id(self, device_id):
    #     from devices.models import DeviceTotalCalculationData, Device
    #     from django.db.models import Sum

    #     close_old_connections()

    #     queryset = DeviceTotalCalculationData.objects.all()

    #     if device_id:
    #         queryset = queryset.filter(
    #             device_id__in=Device.objects.filter(
    #                 device_id=device_id
    #             ).values_list("device_id", flat=True)
    #         )

    #     totals = queryset.aggregate(
    #         total_distance=Sum("total_distance"),
    #         co2_saving=Sum("co2_saving"),
    #         energy_consumption=Sum("energy_consumption"),
    #         run_time=Sum("run_time"),
    #         traction_energy=Sum("traction_energy"),
    #         regen_energy=Sum("regen_energy"),
    #         idle_time=Sum("idle_time"),
    #         charging_unit=Sum("charging_unit"),
    #         charging_count=Sum("charging_count"),
    #         cost_saved=Sum("cost_saved")
    #     )

    #     return {"data": totals or [], "message": f"Data fetched by device_id : {device_id}"}
    
    # @sync_to_async
    # def get_latest_data_for_platforms(self,platform):
    #     from devices.models import DeviceTotalCalculationData
    #     from django.db.models import Sum
    #     from devices.models import Device

    #     close_old_connections()

    #     queryset = DeviceTotalCalculationData.objects.all()

    #     if platform:
    #         # Get all device_ids for the given platform
    #         platform_device_ids = Device.objects.filter(platform=platform).values_list('device_id', flat=True)
    #         # Ensure all are strings (Postgres type safety)
    #         platform_device_ids = [str(d) for d in platform_device_ids]
    #         queryset = queryset.filter(device_id__in=platform_device_ids)
    #     # Aggregate totals
    #     totals = queryset.aggregate(
    #         total_distance=Sum("total_distance"),
    #         co2_saving=Sum("co2_saving"),
    #         energy_consumption=Sum("energy_consumption"),
    #         run_time=Sum("run_time"),
    #         traction_energy=Sum("traction_energy"),
    #         regen_energy=Sum("regen_energy"),
    #         idle_time=Sum("idle_time"),
    #         charging_unit=Sum("charging_unit"),
    #         charging_count=Sum("charging_count"),
    #         cost_saved=Sum("cost_saved")
    #     )

    #     return {"data": totals or [], "message": f"Data fetched for platform device: {platform}"}
    


    # @sync_to_async
    # def get_latest_data_for_username(self,username,device_type_name,platform):
    #     from devices.models import DeviceTotalCalculationData
    #     from django.db.models import Sum
    #     from devices.models import Device
    #     from users.models import UserDeviceAssignment

    #     close_old_connections()


    #     queryset = DeviceTotalCalculationData.objects.all()

    #     if username:
    #         user_assignment = UserDeviceAssignment.objects.get(user__email=username)
    #         user_device_ids = user_assignment.devices  
    #         queryset = queryset.filter(device_id__in=user_device_ids)

    #     if username and device_type_name:
    #         device_ids = Device.objects.filter(
    #             device_id__in=user_device_ids,  
    #             device_type_name__iexact=device_type_name
    #         ).values_list('device_id', flat=True)
    #         queryset = queryset.filter(device_id__in=device_ids)

    #     if username and platform:
    #         device_ids = Device.objects.filter(
    #             device_id__in=user_device_ids,  
    #             platform__iexact=platform
    #         ).values_list('device_id', flat=True)
    #         queryset = queryset.filter(device_id__in=device_ids)

        


    #     # Aggregate totals
    #     totals = queryset.aggregate(
    #         total_distance=Sum("total_distance"),
    #         co2_saving=Sum("co2_saving"),
    #         energy_consumption=Sum("energy_consumption"),
    #         run_time=Sum("run_time"),
    #         traction_energy=Sum("traction_energy"),
    #         regen_energy=Sum("regen_energy"),
    #         idle_time=Sum("idle_time"),
    #         charging_unit=Sum("charging_unit"),
    #         charging_count=Sum("charging_count"),
    #         cost_saved=Sum("cost_saved")
    #     )

    #     return {"data": totals or [], "message": f"Data fetched for platform device: {username}"}

    # @sync_to_async
    # def get_latest_data_for_all_devices(self):
    #     from devices.models import DeviceTotalCalculationData
    #     from django.db.models import Sum

    #     close_old_connections()

    #     queryset = DeviceTotalCalculationData.objects.all()

    #     totals = queryset.aggregate(
    #         total_distance=Sum("total_distance"),
    #         co2_saving=Sum("co2_saving"),
    #         energy_consumption=Sum("energy_consumption"),
    #         run_time=Sum("run_time"),
    #         traction_energy=Sum("traction_energy"),
    #         regen_energy=Sum("regen_energy"),
    #         idle_time=Sum("idle_time"),
    #         charging_unit=Sum("charging_unit"),
    #         charging_count=Sum("charging_count"),
    #         cost_saved=Sum("cost_saved")
    #     )

    #     return {"data": totals or [], "message": "Latest data for all devices"}
    




    # async def sleep(self, seconds):
    #     import asyncio
    #     await asyncio.sleep(seconds)

class TotalCalculationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
        self.stream_task = None

        self.device_id = None
        self.device_type_name = None
        self.platform = None
        self.username = None

        await self.send(text_data=json.dumps({
            "message": "Connection established. Send filters to start."
        }))

    async def receive(self, text_data):
        data = json.loads(text_data or "{}")

        self.device_type_name = data.get("device_type_name")
        self.device_id = data.get("device_id")
        self.platform = data.get("platform")
        self.username = data.get("username")

        msg = "Listening for "
        if self.device_type_name:
            msg += f"device_type_name: {self.device_type_name}"
        elif self.device_id:
            msg += f"device_id: {self.device_id}"
        elif self.platform:
            msg += f"platform: {self.platform}"
        elif self.username:
            msg += f"user: {self.username}"
        else:
            msg += "all devices"

        await self.send(text_data=json.dumps({"message": msg}))

        if self.stream_task:
            self.stream_task.cancel()
            try:
                await self.stream_task
            except:
                pass

        self.stream_task = asyncio.create_task(self.stream_data())

    async def disconnect(self, close_code):
        if self.stream_task:
            self.stream_task.cancel()
            try:
                await self.stream_task
            except:
                pass

    async def stream_data(self):
        try:
            while True:
                close_old_connections()

                if self.username and self.device_type_name:
                    data = await asyncio.wait_for(
                        self.get_latest_data_for_username(self.username, self.device_type_name, self.platform),
                        timeout=5
                    )
                elif self.username and self.platform:
                    data = await asyncio.wait_for(
                        self.get_latest_data_for_username(self.username, self.device_type_name, self.platform),
                        timeout=5
                    )
                elif self.device_type_name:
                    data = await asyncio.wait_for(
                        self.get_latest_data_by_device_type_name(self.device_type_name),
                        timeout=5
                    )
                elif self.device_id:
                    data = await asyncio.wait_for(
                        self.get_latest_data_by_device_id(self.device_id),
                        timeout=5
                    )
                elif self.platform:
                    data = await asyncio.wait_for(
                        self.get_latest_data_for_platforms(self.platform),
                        timeout=5
                    )
                elif self.username:
                    data = await asyncio.wait_for(
                        self.get_latest_data_for_username(self.username, self.device_type_name, self.platform),
                        timeout=5
                    )
                else:
                    data = await asyncio.wait_for(
                        self.get_latest_data_for_all_devices(),
                        timeout=5
                    )

                await self.send(text_data=json.dumps(data))
                await asyncio.sleep(10)

        except asyncio.CancelledError:
            pass

    @database_sync_to_async
    def get_latest_data_by_device_type_name(self, device_type_name):
        from devices.models import DeviceTotalCalculationData, Device
        from django.db.models import Sum

        queryset = DeviceTotalCalculationData.objects.all()

        if device_type_name:
            queryset = queryset.filter(
                device_id__in=Device.objects.filter(
                    device_type_name__icontains=device_type_name
                ).values_list("device_id", flat=True)
            )

        totals = queryset.aggregate(
            total_distance=Sum("total_distance"),
            co2_saving=Sum("co2_saving"),
            energy_consumption=Sum("energy_consumption"),
            run_time=Sum("run_time"),
            traction_energy=Sum("traction_energy"),
            regen_energy=Sum("regen_energy"),
            idle_time=Sum("idle_time"),
            charging_unit=Sum("charging_unit"),
            charging_count=Sum("charging_count"),
            cost_saved=Sum("cost_saved")
        )

        return {
            "data": totals or [],
            "message": f"Data fetched by device_type_name: {device_type_name}"
        }

    @database_sync_to_async
    def get_latest_data_by_device_id(self, device_id):
        from devices.models import DeviceTotalCalculationData
        from django.db.models import Sum

        queryset = DeviceTotalCalculationData.objects.all()

        if device_id:
            queryset = queryset.filter(device_id=device_id)

        totals = queryset.aggregate(
            total_distance=Sum("total_distance"),
            co2_saving=Sum("co2_saving"),
            energy_consumption=Sum("energy_consumption"),
            run_time=Sum("run_time"),
            traction_energy=Sum("traction_energy"),
            regen_energy=Sum("regen_energy"),
            idle_time=Sum("idle_time"),
            charging_unit=Sum("charging_unit"),
            charging_count=Sum("charging_count"),
            cost_saved=Sum("cost_saved")
        )

        return {
            "data": totals or [],
            "message": f"Data fetched by device_id: {device_id}"
        }

    @database_sync_to_async
    def get_latest_data_for_platforms(self, platform):
        from devices.models import DeviceTotalCalculationData, Device
        from django.db.models import Sum

        queryset = DeviceTotalCalculationData.objects.all()

        if platform:
            queryset = queryset.filter(
                device_id__in=Device.objects.filter(
                    platform=platform
                ).values_list("device_id", flat=True)
            )

        totals = queryset.aggregate(
            total_distance=Sum("total_distance"),
            co2_saving=Sum("co2_saving"),
            energy_consumption=Sum("energy_consumption"),
            run_time=Sum("run_time"),
            traction_energy=Sum("traction_energy"),
            regen_energy=Sum("regen_energy"),
            idle_time=Sum("idle_time"),
            charging_unit=Sum("charging_unit"),
            charging_count=Sum("charging_count"),
            cost_saved=Sum("cost_saved")
        )

        return {
            "data": totals or [],
            "message": f"Data fetched for platform: {platform}"
        }

    @database_sync_to_async
    def get_latest_data_for_username(self, username, device_type_name, platform):
        from devices.models import DeviceTotalCalculationData, Device
        from django.db.models import Sum
        from users.models import UserDeviceAssignment

        queryset = DeviceTotalCalculationData.objects.all()

        user_assignment = UserDeviceAssignment.objects.get(user__email=username)
        user_device_ids = user_assignment.devices

        queryset = queryset.filter(device_id__in=user_device_ids)

        if device_type_name:
            queryset = queryset.filter(
                device_id__in=Device.objects.filter(
                    device_id__in=user_device_ids,
                    device_type_name__iexact=device_type_name
                ).values_list("device_id", flat=True)
            )

        if platform:
            queryset = queryset.filter(
                device_id__in=Device.objects.filter(
                    device_id__in=user_device_ids,
                    platform__iexact=platform
                ).values_list("device_id", flat=True)
            )

        totals = queryset.aggregate(
            total_distance=Sum("total_distance"),
            co2_saving=Sum("co2_saving"),
            energy_consumption=Sum("energy_consumption"),
            run_time=Sum("run_time"),
            traction_energy=Sum("traction_energy"),
            regen_energy=Sum("regen_energy"),
            idle_time=Sum("idle_time"),
            charging_unit=Sum("charging_unit"),
            charging_count=Sum("charging_count"),
            cost_saved=Sum("cost_saved")
        )

        return {
            "data": totals or [],
            "message": f"Data fetched for user: {username}"
        }

    @database_sync_to_async
    def get_latest_data_for_all_devices(self):
        from devices.models import DeviceTotalCalculationData
        from django.db.models import Sum

        queryset = DeviceTotalCalculationData.objects.all()

        totals = queryset.aggregate(
            total_distance=Sum("total_distance"),
            co2_saving=Sum("co2_saving"),
            energy_consumption=Sum("energy_consumption"),
            run_time=Sum("run_time"),
            traction_energy=Sum("traction_energy"),
            regen_energy=Sum("regen_energy"),
            idle_time=Sum("idle_time"),
            charging_unit=Sum("charging_unit"),
            charging_count=Sum("charging_count"),
            cost_saved=Sum("cost_saved")
        )

        return {
            "data": totals or [],
            "message": "Data fetched for all devices"
        }