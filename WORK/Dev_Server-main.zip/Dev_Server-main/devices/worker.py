import time
from django.db import close_old_connections
from devices.models import DeviceData
from devices.pipeline import process_device_data_pipeline
from django.db import transaction
 
BATCH_SIZE = 100
SLEEP = 0.05
 
def run_worker():
    print("Worker started")
 
    while True:
        with transaction.atomic():
            rows = list(
                DeviceData.objects
                .select_for_update(skip_locked=True)
                .filter(processed=False)
                .order_by("id")[:BATCH_SIZE]
            )
 
            if not rows:
                time.sleep(SLEEP)
                continue
 
            ids = [r.id for r in rows]

            DeviceData.objects.filter(id__in=ids).update(processed=True)

        for row in rows:
            try:
                start = time.time()
                process_device_data_pipeline(row.id)
                print("Time:", time.time() - start)
            except Exception as e:
                print(f"[PIPELINE ERROR] {row.id}: {e}")
# BATCH_SIZE = 100
# SLEEP = 0.2

# def run_worker():
#     print("Worker started")

#     while True:
#         close_old_connections()

#         rows = (
#             DeviceData.objects
#             .filter(processed=False)
#             .order_by("id")[:BATCH_SIZE]
#         )

#         if not rows:
#             time.sleep(SLEEP)
#             continue

#         for row in rows:
#             try:
#                 process_device_data_pipeline(row.id)
#             except Exception as e:
#                 print(f"[PIPELINE ERROR] {row.device_id}: {e}")
#             finally:
#                 # Always mark as processed once picked
#                 DeviceData.objects.filter(id=row.id).update(processed=True)
# import time
# from django.db import close_old_connections, transaction
# from devices.models import DeviceData
# from devices.pipeline import process_device_data_pipeline

# BATCH_SIZE = 50
# SLEEP = 0.2

# def run_worker():
#     print("Worker started")

#     while True:
#         close_old_connections()

#         with transaction.atomic():
#             rows = (
#                 DeviceData.objects
#                 .select_for_update(skip_locked=True)
#                 .order_by("id")[:BATCH_SIZE]
#             )

#             if not rows:
#                 time.sleep(SLEEP)
#                 continue

#             for row in rows:
#                 try:
#                     process_device_data_pipeline(row.id)
#                 except Exception as e:

#                     print(f"[WORKER ERROR] {row.device_id}: {e}")