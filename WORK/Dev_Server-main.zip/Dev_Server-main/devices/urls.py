# urls.py
from django.urls import path
from .views import (
    AlertAPIView,
    CalculationReportAPIView,
    ConnectedDevicesLastDataAPIView,
    DailyReportAPIView,
    DeviceAPIView,
    DeviceAggregateSummaryAPIView,
    DeviceCalculateData,
    DeviceCanDataSummaryAPIView,
    DeviceDataListView,
    DisconnectedDevicesLastDataAPIView,
    FaultAlertAPIView,
    FaultsAPIView,
    LatestDeviceLocationAPIView,
    DailyTrailAPIView,
    MISCalculationReportAPIView,
    MaintenanceTicketsAPIView,
    TotalEnergySavedAPIView,
    SummaryReportView,
    SummaryDataAPIView,
    ReportDataAPIView,
    MmiDataAPIVIEW,
    ChargingPopUpAPIView,
    DmsAPIView
)

urlpatterns = [
    path('', DeviceAPIView.as_view(), name='device-list-create'),
    path('<int:pk>', DeviceAPIView.as_view(), name='device-update-delete'),
    path('detail', DeviceDataListView.as_view(), name='device-data-list'),
    path('alerts', AlertAPIView.as_view(), name='alert-list'),
    path('fault', FaultAlertAPIView.as_view(), name='fault-alerts-api'),
    
    #Specific Device
    path('aggregate-summary/', DeviceAggregateSummaryAPIView.as_view(), name='device-aggregate-summary'), #testing
    path('map-devices/', LatestDeviceLocationAPIView.as_view(), name='device-last-known-summary'), #testing
    path('chart-view/', DeviceCanDataSummaryAPIView.as_view(), name='device-last-known-summary'), #testing
    path('daily-trail/', DailyTrailAPIView.as_view(), name='daily-trail'),
    path("total-data/", TotalEnergySavedAPIView.as_view(), name="total-energy-saved"),
    path("calculate-report/", CalculationReportAPIView.as_view(), name="calculation-reports"),
    path('disconnected-device/',DisconnectedDevicesLastDataAPIView.as_view(), name="disconnected-devices"),
    path('connected-device/',ConnectedDevicesLastDataAPIView.as_view(), name="connected-devices"),
    path('daily-report/',DailyReportAPIView.as_view(), name="daily-report"),
    path('all-data-report/',DeviceCalculateData.as_view(), name="all-data-report"),
    path('mis-report/',MISCalculationReportAPIView.as_view(), name="mis-report"),
    path('daily-summary-report/', SummaryReportView.as_view()),
    path('maintainence-tickets/', MaintenanceTicketsAPIView.as_view(),name = "maintenance-tickets"),
    path('faults/', FaultsAPIView.as_view(),name="faults-list"),
    path('summary-data/',SummaryDataAPIView.as_view(),name='summary-data'),
    path('reports/',ReportDataAPIView.as_view(),name='reports'),
    path('mmi-data/',MmiDataAPIVIEW.as_view(),name = 'mmi-live-data'),
    path("popups/", ChargingPopUpAPIView.as_view(), name="charging-pop-up"),
    path("dms/",DmsAPIView.as_view(), name="dms-data")
]