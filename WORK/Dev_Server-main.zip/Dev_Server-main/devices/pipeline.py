import traceback
from devices.models import DeviceData, AlertRule, Alert, FaultAlert, Fault,Device,DeviceTotalCalculationData, FaultRule, LiveData
from django.utils import timezone
from devices.calculation import (
    combine_dtc_fields,
    total_calculations,
    total_calculations_3w,
    initialize_metrics
)
from devices.summary import live_daily_report_4w_calculation,live_daily_report_3w_calculation
import traceback
from datetime import timedelta,datetime
import unicodedata

def process_device_data_pipeline(id):
    instance = DeviceData.objects.get(id=id)
    device = Device.objects.filter(device_id=instance.device_id).first()
    if not device:
        print("No device found with this Id")
        return
    # try:
    #     process_live_data(instance, device)
    # except Exception as e:
    #     print(f"error:{e}")
    try:
        process_device_calculations(instance, device)
    except Exception as e:
        print(f"error:{e}")

    try:
        process_data_summary(instance, device)
    except Exception as e:
        print(f"error:{e}")

    try:
        process_alerts(instance,device)
    except Exception as e:
        print(f"error:{e}")

    try:
        process_faults(instance,device)
    except Exception as e:
        print(f"error:{e}")


# def process_live_data(instance, device):
#     can_data = instance.can_data or {}
#     if  can_data is None:
#         return
#     device_type = device.device_type.strip()
#     #For 4w
#     if device_type == '4w' and instance.header == '$NRM':
#         ignition = can_data.get("Ignition_Sense",0)
#         if ignition in (None, 0, "0", "OFF", False,"N"):
#             return
#         odometer = (
#             can_data.get("ODOMETER_CRUT")
#             if "ODOMETER_CRUT" in can_data and can_data.get("ODOMETER_CRUT") not in [None, 0, "N"]
#             else can_data.get("ODOMETER") if can_data.get("ODOMETER") not in [None, 0, "N"] else 0
#         )
#         speed = can_data.get("WheelBasedVehicleSpeed_Rx",0)
#         signal_mapping_variant_wise = {"7M": ["A"],"9M": ["A", "B"],"12M": ["A", "B", "C"],"13.5M": ["A"],"55T": ["A"],"1.5t": ["A"],}
#         variant = device.device_type_name 
#         prefixes = signal_mapping_variant_wise.get(variant, [])

#         # Directly build SOC keys and temp keys based on the variants
#         soc_keys = [f"{p}_SOC_Value" for p in prefixes]
#         temp_keys = [f"{p}_Max_Cell_Temp" for p in prefixes]

#         soc_values = []
#         for key in soc_keys:
#             value = can_data.get(key)
#             if value is None:
#                 continue
#             try:
#                 soc_values.append(float(value))
#             except (TypeError, ValueError):
#                 pass

#         if not soc_values:
#             soc = 0
#         else:
#             soc = sum(soc_values) / len(soc_values)
#         #for temperature
#         temp_values = []
#         for key in temp_keys:
#             value = can_data.get(key)
#             if value is None:
#                 continue
#             try:
#                 temp_values.append(float(value))
#             except (TypeError, ValueError):
#                 pass
#         if temp_values:
#             cell_temp = max(temp_values)
#         else:
#             cell_temp = 0
        
#         dte = float(can_data.get("DTE")) if str(can_data.get("DTE")).replace('.', '', 1).lstrip('-').isdigit() else 0
#         ts = 0
#         #Common fields
#         latitude = instance.latitude
#         latitude_dir = instance.latitude_dir
#         longitude = instance.longitude
#         longitude_dir = instance.longitude_dir
#         heading = instance.heading
        
#         time_stamp = can_data.get("timestamp")

#         if time_stamp:
#             time_stamp = datetime.fromisoformat(time_stamp)   # naive datetime
#             time_stamp = timezone.make_aware(time_stamp, timezone.utc) # explicitly IST-aware

#         last_timestamp = time_stamp

#         try:
#             obj,created = LiveData.objects.update_or_create(imei=instance.device_id,defaults={"last_timestamp":last_timestamp,"latitude":latitude,"latitude_dir":latitude_dir,
#                                             "longitude":longitude,"longitude_dir":longitude_dir,"heading":heading,
#                                             "odometer" : odometer,"speed" : speed,"soc":soc,"ts":ts,"cell_temp":cell_temp,"dte" : dte,
#                                             "can_data": can_data,})
#             if created:
#                 print(f"[Live Data] CREATED for {device} for type 4w")
#             else:
#                 print(f"[Live Data] UPDATED for {device}for type 4w")
#         except Exception as e:
#             print(f"[Live Data] ERROR for {instance.device_id}: {e}")


#     #For 3w
#     elif device_type == '3w' and instance.header == '$NRM':
#         ignition = can_data.get("IgnitionStatus")
#         if ignition in (None, 0, "0", "OFF", False,"N"):
#             return
#         odometer = can_data.get("MCU_Odometer_Val")
#         speed = can_data.get("MCU_Speed_Kmph")
#         soc = can_data.get("SOC")
#         ts_columns = ['TS1','TS1','TS3','TS4','TS5','TS6']
#         ts_values = []
#         for col in ts_columns:
#             value = can_data.get(col)
#             if value not  in (None,"N"):
#                 ts_values.append(value)
#             else:
#                 continue
#         if ts_values:
#             ts = max(ts_values)
#         else:
#             ts = 0
        
#         dte = float(can_data.get("Vehicle_DTE_Km")) if str(can_data.get("Vehicle_DTE_Km")).replace('.', '', 1).lstrip('-').isdigit() else 0
#         cell_temp = 0
#         #Common fields
#         latitude = instance.latitude
#         latitude_dir = instance.latitude_dir
#         longitude = instance.longitude
#         longitude_dir = instance.longitude_dir
#         heading = instance.heading

#         time_stamp = can_data.get("timestamp")

#         if time_stamp:
#             time_stamp = datetime.fromisoformat(time_stamp)   # naive datetime
#             time_stamp = timezone.make_aware(time_stamp, timezone.utc) # explicitly IST-aware

#         last_timestamp = time_stamp

        
#         try:
#             obj,created = LiveData.objects.update_or_create(imei=instance.device_id,defaults={"last_timestamp":last_timestamp,"latitude":latitude,"latitude_dir":latitude_dir,
#                                             "longitude":longitude,"longitude_dir":longitude_dir,"heading":heading,
#                                             "odometer" : odometer,"speed" : speed,"soc":soc,"ts":ts,"cell_temp":cell_temp,"dte" : dte,
#                                             "can_data": can_data,})
#             if created:
#                 print(f"[Live Data] CREATED for {device} for type 3w")
#             else:
#                 print(f"[Live Data] UPDATED for {device} for type 3w")
#         except Exception as e:
#             print(f"[Live Data] ERROR for {instance.device_id}: {e}")

#     else:
#         print("[Live Data] unpexpected header")
#         return


def process_device_calculations(instance, device):
    can_data = instance.can_data
    try:
        device_type = device.device_type
        device_type_name = device.device_type_name
        if not DeviceTotalCalculationData.objects.filter(device_id=instance.device_id).exists():
            if device_type == "3w":
                odometer = can_data.get("MCU_Odometer_Val", 0)
                initialize_metrics(device.device_id, "3w_6s", odometer)
            else:
                variant = "7m"
                for size in ["7m", "9m", "12m", "coach", "55T_truck", "1.5t"]:
                    if size in device_type_name:
                        variant = size
                odometer = can_data.get("ODOMETER", 0)
                initialize_metrics(device.device_id, variant, odometer)

        if device_type == "3w":
            odometer = can_data.get("MCU_Odometer_Val", 0)
            total_calculations_3w(can_data,instance.device_id,odometer,"3w_6s")

        elif device_type == "4w":
            odometer = can_data.get("ODOMETER", 0)
            variant = "7m"
            for size in ["7m", "9m", "12m", "coach", "55T_truck", "1.5t"]:
                if size in device_type_name:
                    variant = size

            total_calculations(can_data,instance.device_id,variant,odometer)

    except Exception as e:
        print(f"[Device Calculated Data] Error: {e}")

def process_data_summary(instance, device):
    try:
        device_data = instance
        device_id = instance.device_id
        end_lat = instance.latitude
        end_long = instance.longitude
        header = instance.header

        if device.device_type == "3w" and header == "$NRM":
            print(f"[Device Summary] for device {device_id}")
            live_daily_report_3w_calculation(device_data, device_id, end_lat, end_long)

        elif device.device_type == "4w" and header == "$NRM":
            print(f"[Device Summary] for device {device_id}")
            variants = ['7M', '9M', '12M', '13.5M', '55T', '1.5t']
            variant = next((v for v in variants if v in device.device_type_name), '7m')
            live_daily_report_4w_calculation(device_data, device_id, variant, end_lat, end_long)

    except Exception as e:
        print(f"[ERROR] Exception in create_data_summary: {e}")
        traceback.print_exc()

def process_alerts(instance, device):
    can_data = instance.can_data or {}
    if not can_data:
        return
    
    ignition_value = can_data.get("Ignition_Sense")

    if ignition_value in (None, 0, "0", "OFF", False,"N"):
        print("[INFO] Ignition OFF — skipping alert checks.")
        return

    try:
        device = Device.objects.get(device_id=instance.device_id)
    except Device.DoesNotExist:
        print(f"[ALERT SKIP] No Device row for device_id={instance.device_id}")
        return

    if device.device_type != '4w':
        return
    device_type_name = device.device_type_name
    FIVE_MIN = timedelta(minutes=5)
    THREE_MIN = timedelta(minutes=3)
    MIN_DURATION_BY_TYPE = {"Alert": FIVE_MIN}
    DEFAULT_MIN_DURATION = THREE_MIN

    def to_num(v, default=0.0):
        try:
            if v in (None, '', 'null', 'None', 'NaN', 'nan', 'N'):
                return default
            x = float(v)
            return x if x == x and x not in (float('inf'), float('-inf')) else default
        except (TypeError, ValueError):
            return default

    class SafeDict(dict):
        def get(self, key, default=0.0):
            return to_num(super().get(key, default), default)
        def __getitem__(self, key):
            return to_num(super().get(key, 0.0), 0.0)
    safe_can = SafeDict(can_data)
    PARAM_MAP = {
        "7M": ["A"],
        "9M": ["A", "B"],
        "12M": ["A", "B", "C"],
        "13.5M": ["A"],
        "55T": ["A"],
        "1.5t": ["A"],
    }

    prefixes = PARAM_MAP.get(device_type_name, [])
    #For soc values you can use this in the rules 
    soc_values = [
        safe_can.get(f"{p}_SOC_Value")
        for p in prefixes
        if safe_can.get(f"{p}_SOC_Value") is not None
    ]

    #For temperatures
    temp_values = [
        safe_can.get(f"{p}_Max_Cell_Temp")
        for p in prefixes
        if safe_can.get(f"{p}_Max_Cell_Temp") is not None
    ]

    MAX_CELL_TEMP = max(temp_values) if temp_values else 0

    #For voltages 
    voltage_values = [
        safe_can.get(f"{p}_Pack_Voltage_Value")
        for p in prefixes
        if safe_can.get(f"{p}_Pack_Voltage_Value") is not None
    ]

    #For currents
    current_values = [
        safe_can.get(f"{p}_Pack_Current_Value")
        for p in prefixes
        if safe_can.get(f"{p}_Pack_Current_Value") is not None
    ]
    bcs = ['BCS_Thermistor_1','BCS_Thermistor_2','BCS_Thermistor_3']
    #For dcdc
    bcs_values = [
        safe_can.get(d)
        for d in bcs
        if safe_can.get(d) is not None
    ]
    SAFE_FUNCS = {
        "float": float, "int": int, "str": str,
        "max": max, "min": min, "abs": abs, "round": round,
        "sum": sum, "any": any, "all": all, "bool": bool
    }

    def _normalize_rule_text(s: str) -> str:
        return unicodedata.normalize("NFKC", (s or "")).strip()

    def _eval_rule(rule_text: str, ctx: dict) -> bool:
        rt = _normalize_rule_text(rule_text)
        code = compile(rt, "<rule>", "eval")
        safe_globals = {"__builtins__": {},  **ctx,}

        return bool(eval(code, safe_globals, {}))

    now = timezone.now()

    active_by_key = {(a.imei, a.name): a
        for a in Alert.objects.filter(imei=device.device_id, is_active=True)
    }

    alert_rules = AlertRule.objects.all()
    print("[INFO] Checking for alerts.")

    for rule in alert_rules:
        
        try:
            req_signals = list(rule.req_signals or [])
            snapshot = {
                signal: can_data[signal]
                for signal in req_signals
                if signal in can_data
            }
            ctx = {
                "can_data": safe_can,
                "device": instance,
                "timezone": timezone,
                "device_type_name": device_type_name,
                "soc_values": soc_values,
                "temp_values": temp_values,
                "voltage_values": voltage_values,
                "current_values": current_values,
                "bcs_values": bcs_values,
                **SAFE_FUNCS,
            }
            condition_true = _eval_rule(rule.condition, ctx)
            key = (device.device_id, rule.name)
            open_alert = active_by_key.get(key)

            if condition_true:
                if not open_alert:
                    a = Alert.objects.create(
                        alert_type=rule.alert_type,
                        value=rule.description,
                        start_time=now,
                        end_time=now,
                        is_active=True,
                        imei=device.device_id,
                        duration_seconds=0,
                        name=rule.name,
                        device_type_name = device_type_name,
                        req_data=[snapshot] if snapshot else [],
                    )
                    active_by_key[key] = a
                    print(f"[Alert OPENED] {rule.name}")
                else:
                    open_alert.end_time = now
                    dur = now - open_alert.start_time
                    open_alert.duration_seconds = int(dur.total_seconds())
            
                    if snapshot:
                        open_alert.req_data.append(snapshot)
                    open_alert.save(update_fields=["end_time", "duration_seconds","req_data"])

            else:
                if open_alert:
                    open_alert.end_time = now
                    dur = now - open_alert.start_time
                    open_alert.duration_seconds = int(dur.total_seconds())
                    open_alert.is_active = False

                    if snapshot:
                        open_alert.req_data.append(snapshot)
                    open_alert.save(update_fields=["end_time", "duration_seconds", "is_active", "req_data"])

                    min_required = MIN_DURATION_BY_TYPE.get(rule.alert_type, DEFAULT_MIN_DURATION)
                    if dur < min_required:
                        open_alert.delete()
                        print(f"[Alert DROPPED <{int(min_required.total_seconds()/60)}m] {rule.name}")
                    else:   
                        print(f"[Alert CLOSED] {rule.name} duration={dur}")

                    # Remove from cache
                    active_by_key.pop(key, None)

        except Exception as e:
            print(f"[ALERT ERROR] {rule.name}: {e}")


def process_faults(instance,device):
    FAULT_GAP_SECONDS = 300 
    now = timezone.now()

    can_data = instance.can_data or {}

    if not can_data:
        return 

    try:
        device = Device.objects.get(device_id=instance.device_id)
    except Device.DoesNotExist:
        return  
 
    vehicle_type = str(device.device_type)


    if vehicle_type.lower() == '4w':

        ignition = can_data.get("Ignition_Sense", 0)
        if ignition in (None, 0, "0", "OFF", False, "N"):
            return

        dtc_fields = combine_dtc_fields(can_data)

        current_keys = set()

        for component, identifier in dtc_fields.items():
            component = component.split('_DTC')[0].upper()

            if float(identifier) < 50:
                identifier = str(float(identifier) + 50)

            rule = FaultRule.objects.filter(
                vehicle_type='4W',
                identifier=identifier
            ).first()

            if not rule:
                continue

            current_keys.add(rule.id)

            active_fault = Fault.objects.filter(
                imei=instance.device_id,
                component=component,
                # identifier=identifier,
                rule=rule,
                is_active=True
            ).first()

            if active_fault:
                gap = (now - active_fault.end_time).total_seconds()
                if gap <= FAULT_GAP_SECONDS:
                    active_fault.end_time = now
                    active_fault.save(update_fields=["end_time"])
                    continue
                else:
                    active_fault.is_active = False
                    active_fault.save(update_fields=["is_active"])

            Fault.objects.create(
                imei=instance.device_id,
                rule=rule,
                component=component,
                # identifier=identifier,
                data_snapshot=instance.can_data,
                start_time=now,
                end_time=now,
                is_active=True
            )
        
        Fault.objects.filter(
                imei=instance.device_id,
                is_active=True,
                rule__vehicle_type='4W'
            ).exclude(
                rule_id__in=current_keys
            ).update(
                is_active=False,
                end_time=now
            )
    # Working for 3W Faults
    elif vehicle_type.lower() == '3w':

        ignition = can_data.get("IgnitionStatus")
        if ignition in (None, 0, "0", "OFF", False, "N"):
            return

        rules = FaultRule.objects.filter(vehicle_type='3W')
        rules_map = {r.identifier: r for r in rules}

        for identifier, rule in rules_map.items():

            value = can_data.get(identifier)
            active_fault = Fault.objects.filter(
                imei=instance.device_id,
                rule=rule,
                is_active=True
            ).first()

            # fault ON
            if value in (1, "1", True, "True", "true"):
                if active_fault:
                    active_fault.end_time = now
                    active_fault.save(update_fields=["end_time"])
                else:
                    Fault.objects.create(
                        imei=instance.device_id,
                        rule=rule,
                        component=rule.component,
                        # identifier=rule.identifier,
                        data_snapshot=instance.can_data,
                        start_time=now,
                        end_time=now,
                        is_active=True
                    )

            # fault OFF → close if active
            else:
                if active_fault:
                    active_fault.is_active = False
                    active_fault.end_time = now
                    active_fault.save(update_fields=["is_active", "end_time"])