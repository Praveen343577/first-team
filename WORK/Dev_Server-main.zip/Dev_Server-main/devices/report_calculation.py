from devices.models import DailySummaryReport,Alert,Fault, FaultRule
from collections import defaultdict
from datetime import datetime
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime, time
from django.utils.timezone import make_aware

def parse_ts(ts):
    return datetime.fromisoformat(ts)

#Trip calculations
TRIP_GAP_MIN = 15  

def build_trip_objects(sessions):
    trips = []
    current = []

    for i, s in enumerate(sessions):
        current.append(s)

        if i == len(sessions) - 1:
            trips.append(current)
            break

        cur_end = parse_ts(s["end_time_val"])
        next_start = parse_ts(sessions[i + 1]["start_time_val"])
        diff = (next_start - cur_end).total_seconds() / 60

        if diff >= TRIP_GAP_MIN:
            trips.append(current)
            current = []

    final_trips = []

    for trip_no, trip in enumerate(trips, start=1):
        trip_start = parse_ts(trip[0]["start_time_val"])
        trip_end = parse_ts(trip[-1]["end_time_val"])

        total_energy = 0
        movement_distance = 0
        movement_duration = 0
        idle_duration = 0

        for s in trip:
            total_energy += s.get("energy_consumed", 0)

            if s["label"] == "Movement":
                movement_distance += s.get("distance", 0)
                movement_duration += s.get("duration", 0)

            elif s["label"] == "Idle":
                idle_duration += s.get("duration", 0)

        
        if movement_duration > 0:
            avg_speed = movement_distance / (movement_duration / 60)
        else:
            avg_speed = 0

        final_trips.append({
            "trip_no": trip_no,
            "start_time": trip[0]["start_time_val"],
            "end_time": trip[-1]["end_time_val"],
            "duration_minutes": (trip_end - trip_start).total_seconds() / 60,
            "movement_distance": movement_distance,
            "movement_duration": movement_duration,
            "idle_duration": idle_duration,
            "energy_consumed": total_energy,
            "avg_speed": avg_speed,
        })

    return final_trips

def daily_summary_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","distance","runtime_minutes",
                                            "idle_minutes","stoppage_minutes","start_odometer","end_odometer","sessions")
    if not qs.exists():
        return {}
    
    date_grouped = defaultdict(list)

    for row in qs:
        sessions = row.sessions or []
        movement_sessions = [
            s for s in sessions
            if s.get("label") == "Movement"
        ]


        if not movement_sessions:
            continue

        # Add session numbers
        for no, s in enumerate(movement_sessions, 1):
            s["session_no"] = no

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "session_count": len(movement_sessions),
            "city":row.city,
            "distance":row.distance,
            "runtime":row.runtime_minutes,
            "avg_speed":row.average_speed,
            "idletime":row.idle_minutes,
            "stoppagetime":row.stoppage_minutes,
            "start_odometer":row.start_odometer,
            "end_odometer":row.end_odometer,
            "trips": movement_sessions
        })

    return date_grouped

def charging_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","charging_minutes",
                                             "charging_unit","insufficient_charge","sessions")
        
    if not qs.exists():
        return {}

    date_grouped = defaultdict(list)

    for row in qs:
        sessions = row.sessions or []
        charging_sessions = [
            s for s in sessions
            if s.get("label") == "Charging"
        ]

        if not charging_sessions:
            continue

        # Add session numbers
        for no, s in enumerate(charging_sessions, 1):
            s["session_no"] = no

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "session_count": len(charging_sessions),
            "city":row.city,
            "charging_time":row.charging_minutes,
            "charging_unit":row.charging_unit,
            "Insufficient_charge":row.insufficient_charge,
            "sessions": charging_sessions
        })
    return date_grouped



def energy_consumpumtion_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","runtime_minutes","idle_minutes",
                                             "energy_consumed","regen_energy","energy_consumption","sessions")
    
    if not qs.exists():
        return {}

    date_grouped = defaultdict(list)

    for row in qs:
        all_sessions = row.sessions or []
        all_sessions = all_sessions if isinstance(all_sessions, list) else []

        filtered = [
            s for s in all_sessions
            if isinstance(s, dict) and s.get("label") in ("Movement", "Idle") 
        ]

        if not filtered:
            continue

        filtered.sort(key=lambda x: x["start_time_val"])

        trips = build_trip_objects(filtered)

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "city": row.city,
            "trip_count": len(trips),
            "distance": row.distance,
            "runtime": row.runtime_minutes,
            "ideltime": row.idle_minutes,
            "ec": row.energy_consumed,
            "regen": row.regen_energy,
            "ecr": row.energy_consumption,
            "trips": trips
        })
    return date_grouped

def vehicle_status_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","start_time_of_day","stop_time_of_day","distance","runtime_minutes",
                                            "idle_minutes","stoppage_minutes","charging_minutes","no_of_movement_sessions","no_of_charging_cycles","no_of_idle_sessions",
                                            "start_odometer","end_odometer","battery_temperature","motor_temperature","sessions")
    if not qs.exists():
        return {}
    
    date_grouped = defaultdict(list)

    for row in qs:
        sessions = row.sessions or []
        all_sessions = [
            s for s in sessions
        ]

        if not all_sessions:
            continue

        # Add session numbers
        for no, s in enumerate(all_sessions, 1):
            s["session_no"] = no

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "session_count": len(all_sessions),
            "city":row.city,
            "start_time_of_day":row.start_time_of_day,
            "stop_time_of_day":row.stop_time_of_day,
            "distance":row.distance,
            "runtime":row.runtime_minutes,
            "idletime":row.idle_minutes,
            "stoppagetime":row.stoppage_minutes,
            "chargetime":row.charging_minutes,
            "no_of_movement_sessions":row.no_of_movement_sessions,
            "no_of_charging_cycles":row.no_of_charging_cycles,
            "no_of_idle_sessions":row.no_of_idle_sessions,
            "start_odometer":row.start_odometer,
            "end_odometer":row.end_odometer,
            "max_battery_temperature":row.battery_temperature,
            "max_motor_temperature":row.motor_temperature,
            "sessions": all_sessions
        })

    return date_grouped



def cooling_report(vehicle_list,start_date,end_date=None):
    pass

def alert_report(vehicle_list,start_date,end_date=None):
    from django.utils.dateparse import parse_date
    start_date = parse_date(start_date)
    end_date = parse_date(end_date)
    start_dt = make_aware(datetime.combine(start_date, time.min))
    end_dt = make_aware(datetime.combine(end_date, time.max))
    
    qs = Alert.objects.filter(imei__in=vehicle_list,start_time__date__range = [start_dt, end_dt],duration_seconds__gt=120)

    if not qs.exists():
        return {}

    date_grouped = defaultdict(list)
    for row in qs:
        row_time = row.start_time
        row_time = row_time.date()
        date_grouped[str(row_time)].append({
        "alert_type": row.alert_type,
        "name": row.name,
        "value": row.value,
        "imei": row.imei,
        "start_time": row.start_time,
        "end_time": row.end_time,
        "is_active": row.is_active,
        "duration_seconds": row.duration_seconds,
        "req_data": row.req_data,
        "device_type_name": row.device_type_name
        })

    return date_grouped

def fault_report(request,vehicle_list,start_date,paged,end_date):
    # from django.utils.dateparse import parse_date
    from rest_framework.pagination import PageNumberPagination
    from devices.pagination import FaultReportPagination
    # start_date =   start_date.date()
    # end_date = end_date.date()
    # start_dt = make_aware(datetime.combine(start_date, time.min))
    # end_dt = make_aware(datetime.combine(end_date, time.max))
    
    qs = Fault.objects.filter(imei__in=vehicle_list,start_time__date__range = [start_date, end_date])

    if not qs.exists():
        return Response({"No data found"})
    
    if paged:
        paginator = FaultReportPagination()
        page = paginator.paginate_queryset(qs, request)

        date_grouped = defaultdict(list)

        for row in page:
            row_time = row.start_time.date().isoformat()
            
            # Fault Rule Query set
            fr_qs = FaultRule.objects.get(id=row.rule_id).details
            date_grouped[row_time].append({
                "imei": row.imei,
                "start_time": row.start_time,
                "end_time": row.end_time,
                "is_active": row.is_active,
                "duration_seconds": (row.end_time - row.start_time).total_seconds(),
                "data_snapshot": row.data_snapshot,
                "component": row.component,
                "details": fr_qs
            })

        return paginator.get_paginated_response(date_grouped)
    
    else:
        date_grouped = defaultdict(list)
        for row in qs:
            time_diff = (row.end_time - row.start_time).total_seconds()
            row_time = row.start_time
            row_time = row_time.date()
            date_grouped[str(row_time)].append({
            "imei": row.imei,
            "start_time": row.start_time,
            "end_time": row.end_time,
            "is_active": row.is_active,
            "duration_seconds": time_diff,
            "data_snapshot": row.data_snapshot,
            "component":row.component
            })
        return date_grouped


#For excel report grouping by vehicle wise
def group_by_vehicle(data):
    vehicle_map = {}

    for date, items in data.items():
        for v in items:

            # Skip missing / empty rows
            if not v or not isinstance(v, dict):
                continue
            
            vrn = v.get("vrn")
            if not vrn:   # device has no row / no vrn
                continue

            if vrn not in vehicle_map:
                vehicle_map[vrn] = []

            if "trips" in v:
                for t in v["trips"]:
                    row = {"date": date, "vrn": vrn, **t}
                    vehicle_map[vrn].append(row)

            if "sessions" in v:
                for s in v["sessions"]:
                    row = {"date": date, "vrn": vrn, **s}
                    vehicle_map[vrn].append(row)

            if "trips" not in v and "sessions" not in v:
                vehicle_map[vrn].append({"date": date, "vrn": vrn, **v})

    return vehicle_map

#For excel report generation
def export_excel(data, filename_prefix):
    import openpyxl
    from openpyxl.utils import get_column_letter
    from django.http import HttpResponse

    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    vehicle_map = group_by_vehicle(data)

    # FIX: if no sheets would be created, add fallback sheet
    if not vehicle_map:
        ws = wb.create_sheet("No_Data")
        ws.append(["No data available"])

    for vrn, rows in vehicle_map.items():
        ws = wb.create_sheet(title=vrn[:31])  # sheet name limit

        if not rows:
            ws.append(["No Data"])
            continue

        header = list(rows[0].keys())
        ws.append(header)

        for r in rows:
            ws.append([r.get(col, "") for col in header])

        # Auto width
        for idx, col in enumerate(header, 1):
            ws.column_dimensions[get_column_letter(idx)].width = min(40, len(col) + 5)

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="{filename_prefix}.xlsx"'
    wb.save(response)
    return response



