from .models import DailySummaryReport, Fault, FaultRule
from rest_framework import serializers
from rest_framework import serializers
from devices.models import (
    Alert,
    Device,
    DeviceData,
    FaultAlert,
    DeviceTotalCalculationData,
    LiveData
)

class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = '__all__'
        read_only_fields = ['is_active', 'last_seen']

class CustomDevicePartialDataSerializer(serializers.ModelSerializer):
    odometer = serializers.SerializerMethodField()
    speed = serializers.SerializerMethodField()
    soc = serializers.SerializerMethodField()
    ts = serializers.SerializerMethodField()
    cell_temp = serializers.SerializerMethodField()
    dte = serializers.SerializerMethodField()
    is_connected = serializers.SerializerMethodField()
 
    REQ_SIGNALS = [
        'BMS_Status','MCU_Status','EVCC_1_Status','Gun_Detection_1','Gun_Detection_2',
        'Door_1_F','Door_2_R','Door_3','Vehicle_Acceleration','BMS_DTC_1','BMS_DTC_2',
        'MCU_DTC_1','MCU_DTC_2','Charging_Time','EVCC_Present_Current',
        'MCU_HighPowerCurrent','MCU_HighPowerVoltage','MCU_State','MCU_Motor_Speed',
        'Motor_Temperature','MCU_Temperature','Cabin_Temprature',
        'EVCC_PresentVoltage','A_Pack_Current_Value','A_Pack_Voltage_Value',
        'A_Insulation_Value','A_SOH_Value','A_SOC_Value','A_Fault_Rank',
        'A_Min_Cell_Temp','A_Max_Cell_Temp','A_Max_Cell_Volt','A_Min_Cell_Volt',
        'B_Pack_Current_Value','B_Pack_Voltage_Value','B_Insulation_Value',
        'B_SOH_Value','B_SOC_Value','B_Fault_Rank','B_Min_Cell_Temp',
        'B_Max_Cell_Temp','B_Max_Cell_Volt','B_Min_Cell_Volt',
        'C_Pack_Current_Value','C_Pack_Voltage_Value','C_Insulation_Value',
        'C_SOH_Value','C_SOC_Value','C_Fault_Rank','C_Min_Cell_Temp',
        'C_Max_Cell_Temp','C_Max_Cell_Volt','C_Min_Cell_Volt'
    ]
 
    class Meta:
        model = LiveData
        fields = [
            'imei', 'last_timestamp', 'latitude', 'latitude_dir',
            'longitude', 'longitude_dir', 'heading','odometer',
            'speed','soc','ts','cell_temp','dte','is_connected'
        ]
 
    def to_representation(self, instance):
        data = super().to_representation(instance)
        can = instance.can_data or {}
 
        for key in self.REQ_SIGNALS:
            data[key] = can.get(key)
 
        return data
    
    def _get_values(self, obj):
        if hasattr(obj, "_can_values"):
            return obj._can_values

        device_type = self.context["device_type_map"].get(obj.imei)

        if  device_type == "4w":
            values = self._calc_4w(obj)
        else:
            values = self._calc_3w(obj)

        obj._can_values = values
        return values

    def _calc_4w(self, obj):
        can = obj.can_data or {}

        odometer = ( can.get("ODOMETER_CRUT") if can.get("ODOMETER_CRUT") not in (None, 0, "N") else can.get("ODOMETER", 0))

        try:
            speed = float(can.get("WheelBasedVehicleSpeed_Rx"))
        except (TypeError, ValueError):
            speed = 0

        variant_map = {
            "7M": ["A"],
            "9M": ["A", "B"],
            "12M": ["A", "B", "C"],
            "13.5M": ["A"],
            "55T": ["A"],
            "1.5t": ["A"],
            "5T": ["A"]
        }

        variant = self.context["device_variant_map"].get(obj.imei)
        prefixes = variant_map.get(variant, [])

        soc_vals = []
        for p in prefixes:
            try:
                soc_vals.append(float(can.get(f"{p}_SOC_Value")))
            except (TypeError, ValueError):
                pass
        soc = sum(soc_vals) / len(soc_vals) if soc_vals else 0

        temp_vals = []
        for p in prefixes:
            try:
                temp_vals.append(float(can.get(f"{p}_Max_Cell_Temp")))
            except (TypeError, ValueError):
                pass
        cell_temp = max(temp_vals) if temp_vals else 0

        try:
            dte = float(can.get("DTE"))
        except (TypeError, ValueError):
            dte = 0

        ts = 0

        return odometer, speed, soc, ts, cell_temp, dte

    def _calc_3w(self, obj):
        can = obj.can_data or {}

        try:
            odometer = float(can.get("MCU_Odometer_Val"))
        except (TypeError, ValueError):
            odometer = 0

        try:
            speed = float(can.get("MCU_Speed_Kmph"))
        except (TypeError, ValueError):
            speed = 0

        try:
            soc = float(can.get("SOC"))
        except (TypeError, ValueError):
            soc = 0

        ts_vals = []
        for k in ["TS1", "TS2", "TS3", "TS4", "TS5", "TS6"]:
            v = can.get(k)
            if v not in (None, "N"):
                try:
                    ts_vals.append(float(v))
                except (TypeError, ValueError):
                    pass
        ts = max(ts_vals) if ts_vals else 0

        try:
            dte = float(can.get("Vehicle_DTE_Km"))
        except (TypeError, ValueError):
            dte = 0

        cell_temp = 0

        return odometer, speed, soc, ts, cell_temp, dte


    def get_odometer(self, obj):
        return self._get_values(obj)[0]

    def get_speed(self, obj):
        return self._get_values(obj)[1]

    def get_soc(self, obj):
        return self._get_values(obj)[2]

    def get_ts(self, obj):
        return self._get_values(obj)[3]

    def get_cell_temp(self, obj):
        return self._get_values(obj)[4]

    def get_dte(self, obj):
        return self._get_values(obj)[5]

    # def get_is_connected(self, obj):
    #     if not obj.last_timestamp:
    #         return False
    #     return obj.last_timestamp >= timezone.now() - timedelta(minutes=2)
   
    def get_is_connected(self, obj):
        from django.utils import timezone
        from datetime import timedelta, timezone as dt_timezone
        if not obj.last_timestamp:
            return False
 
        last_ts = obj.last_timestamp
 
        # Normalize to UTC
        if timezone.is_aware(last_ts):
            last_ts_utc = last_ts.astimezone(dt_timezone.utc)
        else:
            last_ts_utc = timezone.make_aware(last_ts, dt_timezone.utc)
 
        now_utc = timezone.now()
 
        return last_ts_utc >= now_utc - timedelta(minutes=2)
    
class DevicePartialDataSerializer(serializers.ModelSerializer):
    odometer = serializers.SerializerMethodField()
    speed = serializers.SerializerMethodField()
    soc = serializers.SerializerMethodField()
    ts = serializers.SerializerMethodField()
    cell_temp = serializers.SerializerMethodField()
    dte = serializers.SerializerMethodField()
    is_connected = serializers.SerializerMethodField()

    class Meta:
        model = LiveData
        fields = [
            'imei', 'last_timestamp', 'latitude', 'latitude_dir',
            'longitude', 'longitude_dir', 'heading','odometer',
            'speed','soc','ts','cell_temp','dte','is_connected'
        ]

    def _get_values(self, obj):
        if hasattr(obj, "_can_values"):
            return obj._can_values
        
        device_type = self.context["device_type_map"].get(obj.imei)

        if  device_type == "4w":
            values = self._calc_4w(obj)
        else:
            values = self._calc_3w(obj)

        obj._can_values = values
        return values

    def _calc_4w(self, obj):
        can = obj.can_data or {}

        odometer = ( can.get("ODOMETER_CRUT") if can.get("ODOMETER_CRUT") not in (None, 0, "N") else can.get("ODOMETER", 0))

        try:
            speed = float(can.get("WheelBasedVehicleSpeed_Rx"))
        except (TypeError, ValueError):
            speed = 0

        variant_map = {
            "7M": ["A"],
            "9M": ["A", "B"],
            "12M": ["A", "B", "C"],
            "13.5M": ["A"],
            "55T": ["A"],
            "1.5t": ["A"],
            "5T": ["A"]
        }

        variant = self.context["device_variant_map"].get(obj.imei)
        prefixes = variant_map.get(variant, [])

        soc_vals = []
        for p in prefixes:
            try:
                soc_vals.append(float(can.get(f"{p}_SOC_Value")))
            except (TypeError, ValueError):
                pass
        soc = sum(soc_vals) / len(soc_vals) if soc_vals else 0

        temp_vals = []
        for p in prefixes:
            try:
                temp_vals.append(float(can.get(f"{p}_Max_Cell_Temp")))
            except (TypeError, ValueError):
                pass
        cell_temp = max(temp_vals) if temp_vals else 0

        try:
            dte = float(can.get("DTE"))
        except (TypeError, ValueError):
            dte = 0

        ts = 0

        return odometer, speed, soc, ts, cell_temp, dte

    def _calc_3w(self, obj):
        can = obj.can_data or {}

        try:
            odometer = float(can.get("MCU_Odometer_Val"))
        except (TypeError, ValueError):
            odometer = 0

        try:
            speed = float(can.get("MCU_Speed_Kmph"))
        except (TypeError, ValueError):
            speed = 0

        try:
            soc = float(can.get("SOC"))
        except (TypeError, ValueError):
            soc = 0

        ts_vals = []
        for k in ["TS1", "TS2", "TS3", "TS4", "TS5", "TS6"]:
            v = can.get(k)
            if v not in (None, "N"):
                try:
                    ts_vals.append(float(v))
                except (TypeError, ValueError):
                    pass
        ts = max(ts_vals) if ts_vals else 0

        try:
            dte = float(can.get("Vehicle_DTE_Km"))
        except (TypeError, ValueError):
            dte = 0

        cell_temp = 0

        return odometer, speed, soc, ts, cell_temp, dte


    def get_odometer(self, obj):
        return self._get_values(obj)[0]

    def get_speed(self, obj):
        return self._get_values(obj)[1]

    def get_soc(self, obj):
        return self._get_values(obj)[2]

    def get_ts(self, obj):
        return self._get_values(obj)[3]

    def get_cell_temp(self, obj):
        return self._get_values(obj)[4]

    def get_dte(self, obj):
        return self._get_values(obj)[5]

    def get_is_connected(self, obj):
        from django.utils import timezone
        from datetime import timedelta, timezone as dt_timezone
        if not obj.last_timestamp:
            return False
        return obj.last_timestamp >= timezone.now() - timedelta(minutes=2)
    
# class DevicePartialDataSerializer(serializers.ModelSerializer):
#     is_connected = serializers.SerializerMethodField()

#     class Meta:
#         model = LiveData
#         fields = ['imei','last_timestamp','latitude','latitude_dir','longitude',
#                   'longitude_dir','odometer','speed','heading','soc','ts',
#                   'cell_temp','dte','is_connected']
#     def _get_ilike_key(self, obj, pattern):
#         """
#         Case-insensitive partial match for keys in can_data.
#         Returns first matching value or None.
#         """
#         if not obj.can_data:
#             return None
#         for key, value in obj.can_data.items():
#             if pattern.lower() in key.lower():
#                 return value
#         return None
    
#     def get_is_connected(self, obj):
#         from django.utils import timezone
#         from datetime import timedelta 

#         if not obj.last_timestamp:
#             return False

#         return obj.last_timestamp >= timezone.now() - timedelta(minutes=2)
    
class DeviceDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceData
        fields = '__all__'
        read_only_fields = ['can_data', 'extra_data']

# class DailyTrailSerializer(serializers.ModelSerializer):
#     MCU_MotorSpeed = serializers.CharField(source='can_data.MCU_MotorSpeed', read_only=True)
#     MCU_MotorTorqueEstimated = serializers.CharField(source='can_data.MCU_MotorTorqueEstimated', read_only=True)  #accerlaration, brake, faults

#     class Meta:
#         model = DeviceData
#         fields = ['timestamp','device_id','latitude','latitude_dir','longitude',
#                   'longitude_dir','odometer','speed','heading','MCU_MotorSpeed','MCU_MotorTorqueEstimated']

# class DailyTrailSerializer(serializers.ModelSerializer):
#     MCU_MotorSpeed = serializers.SerializerMethodField()
#     MCU_MotorTorqueEstimated = serializers.SerializerMethodField()
#     fault_counts = serializers.SerializerMethodField()
#     Accpedal_Position = serializers.SerializerMethodField()
#     Brake_Pedal_Position = serializers.SerializerMethodField()
#     A_SOC_Value = serializers.SerializerMethodField()
#     A_Pack_Current_Value = serializers.SerializerMethodField()
    

#     class Meta:
#         model = DeviceData
#         fields = [
#             'timestamp', 'device_id', 'latitude', 'latitude_dir',
#             'longitude', 'longitude_dir', 'odometer', 'speed', 'heading',
#             'MCU_MotorSpeed', 'MCU_MotorTorqueEstimated', 'fault_counts',
#             'Accpedal_Position', 'Brake_Pedal_Position', 'A_SOC_Value','A_Pack_Current_Value'
#         ]

#     def _get_ilike_key(self, obj, pattern):
#         """
#         Case-insensitive partial match for keys in can_data.
#         Returns first matching value or None.
#         """
#         if not obj.can_data:
#             return None
#         for key, value in obj.can_data.items():
#             if pattern.lower() in key.lower():
#                 return value
#         return None

#     def get_MCU_MotorSpeed(self, obj):
#         possible_keys = ["MCU_MotorSpeed", "MotorActSpeed","Motor_Speed"]
#         for key in possible_keys:
#             value = self._get_ilike_key(obj, key)
#             if value is not None:
#                 return value
            
#         return None


#     def get_MCU_MotorTorqueEstimated(self, obj):
#         return self._get_ilike_key(obj, "MCU_Motor_Torque_Estimated")

#     def get_fault_counts(self, obj):
#         return self.context.get('fault_counts', 0)

#     def get_Accpedal_Position(self, obj):
#         possible_keys = ["Accpedal_Position", "Throttle_perc"]

#         for key in possible_keys:
#             value = self._get_ilike_key(obj, key)
#             if value is not None:
#                 return value

#         return None

#     def get_Brake_Pedal_Position(self, obj):
#         possible_keys = ["Brake_Pedal_Position", "Brake_perc"]
        
#         for key in possible_keys:
#             value = self._get_ilike_key(obj, key)
#             if value is not None:
#                 return value

#         return None

#     def get_A_SOC_Value(self, obj):
#         return self._get_ilike_key(obj, "SOC")
    
#     def get_A_Pack_Current_Value(self,obj):
#         possible_keys = ["A_Pack_Current_Value","BatteryCurrent"]

#         for key in possible_keys:
#             value = self._get_ilike_key(obj, key)
#             if value is not None:
#                 return value

#         return None


class DailyTrailSerializer(serializers.ModelSerializer):
    MCU_MotorSpeed = serializers.SerializerMethodField()
    MCU_MotorTorqueEstimated = serializers.SerializerMethodField()
    fault_counts = serializers.SerializerMethodField()
    Accpedal_Position = serializers.SerializerMethodField()
    Brake_Pedal_Position = serializers.SerializerMethodField()
    A_SOC_Value = serializers.SerializerMethodField()
    A_Pack_Current_Value = serializers.SerializerMethodField()
    Odometer = serializers.SerializerMethodField()
    Speed = serializers.SerializerMethodField()
    

    class Meta:
        model = DeviceData
        fields = [
            'timestamp', 'device_id', 'latitude', 'latitude_dir',
            'longitude', 'longitude_dir', 'Odometer', 'Speed', 'heading','packet_type','header',
            'MCU_MotorSpeed', 'MCU_MotorTorqueEstimated', 'fault_counts',
            'Accpedal_Position', 'Brake_Pedal_Position', 'A_SOC_Value','A_Pack_Current_Value',
        ]

    def _get_ilike_key(self, obj, pattern):
        """
        Case-insensitive partial match for keys in can_data.
        Returns first matching value or None.
        """
        if not obj.can_data:
            return None
        
        for key, value in obj.can_data.items():
            if key.lower() == pattern.lower():
                return value
        
        for key, value in obj.can_data.items():
            if pattern.lower() in key.lower():
                return value
        return None

    def get_MCU_MotorSpeed(self, obj):
        possible_keys = ["MCU_MotorSpeed", "MCU_MotorActSpeed_RPM","Motor_Speed"]
        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value
            
        return None

    def get_Odometer(self, obj):
        # return self._get_ilike_key(obj, "ODOMETER","MCU_Odometer_Val")
        possible_keys = ["ODOMETER","MCU_Odometer_Val"]
        
        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value

        return None
    
    def get_Speed(self, obj):
        # return self._get_ilike_key(obj,"WheelBasedVehicleSpeed_Rx", "WheelBasedVehicleSpeedRx")
        possible_keys = ["WheelBasedVehicleSpeed_Rx","WheelBasedVehicleSpeedRx","MCU_Speed_Kmph"]
        
        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value

        return None

    def get_MCU_MotorTorqueEstimated(self, obj):
        return self._get_ilike_key(obj, "MCU_Motor_Torque_Estimated")

    def get_fault_counts(self, obj):
        return self.context.get('fault_counts', 0)

    def get_Accpedal_Position(self, obj):
        possible_keys = ["Accpedal_Position", "Throttle_perc", "Accerationpedalposition"]

        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value

        return None

    def get_Brake_Pedal_Position(self, obj):
        possible_keys = ["Brake_Pedal_Position", "Brake_perc","BrakePedalPosition"]
        
        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value

        return None

    def get_A_SOC_Value(self, obj):
        possible_keys = ["A_SOC_Value","SOC"]
        
        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value

        return None
    
    def get_A_Pack_Current_Value(self,obj):
        possible_keys = ["A_Pack_Current_Value","BatteryCurrent"]

        for key in possible_keys:
            value = self._get_ilike_key(obj, key)
            if value is not None:
                return value

        return None

class AlertDataSerializer(serializers.ModelSerializer):
    device_id = serializers.CharField(source='device.device_id', read_only=True)

    class Meta:
        model = Alert
        fields = '__all__'
        read_only_fields = ['timestamp']

class FaultAlertSerializer(serializers.ModelSerializer):
    fault_name = serializers.CharField(source='fault.name', read_only=True)
    device_id = serializers.CharField(source='device.device_id', read_only=True)

    class Meta:
        model = FaultAlert
        fields = ['id', 'device_id', 'fault_name', 'can_data_snapshot', 'timestamp']

class LiveDataSerializer(serializers.ModelSerializer):
    # MCU_MotorSpeed = serializers.SerializerMethodField()
    # MCU_MotorTorqueEstimated = serializers.SerializerMethodField()
    # fault_counts = serializers.SerializerMethodField()
    # Accpedal_Position = serializers.SerializerMethodField()
    # Brake_Pedal_Position = serializers.SerializerMethodField()
    # A_SOC_Value = serializers.SerializerMethodField()
    # Vehicle_DTE_Km = serializers.SerializerMethodField()
    # TS = serializers.SerializerMethodField()
    # Max_Cell_Temp = serializers.SerializerMethodField()
    # Min_Cell_Temp = serializers.SerializerMethodField()
    
    class Meta:
        model = DeviceData
        fields = '__all__'

    # def _get_ilike_key(self, obj, pattern):
    #     """
    #     Case-insensitive partial match for keys in can_data.
    #     Returns first matching value or None.
    #     """
    #     if not obj.can_data:
    #         return None
    #     for key, value in obj.can_data.items():
    #         if pattern.lower() in key.lower():
    #             return value
    #     return None

    # def get_MCU_MotorSpeed(self, obj):
    #     return self._get_ilike_key(obj, "MCU_MotorSpeed")

    # def get_MCU_MotorTorqueEstimated(self, obj):
    #     return self._get_ilike_key(obj, "MCU_MotorTorqueEstimated")

    # def get_fault_counts(self, obj):
    #     return self.context.get('fault_counts', 0)

    # def get_Accpedal_Position(self, obj):
    #     return self._get_ilike_key(obj, "Accpedal_Position")

    # def get_Brake_Pedal_Position(self, obj):
    #     return self._get_ilike_key(obj, "Brake_Pedal_Position")

    # def get_A_SOC_Value(self, obj):
    #     return self._get_ilike_key(obj, "SOC")

    # def get_Vehicle_DTE_Km(self, obj):
    #     return self._get_ilike_key(obj, "Vehicle_DTE_Km")
    
    # def get_TS(self, obj):
    #     return self._get_ilike_key(obj, "TS")

    # def get_Max_Cell_Temp(self, obj):
    #     return self._get_ilike_key(obj, "Max_Cell_Temp")
    
    # def get_Min_Cell_Temp(self, obj):
    #     return self._get_ilike_key(obj, "Min_Cell_Temp")
        
class DeviceCanDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceData
        fields = ['can_data']       
        
class DeviceTotalCalculationDataSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = DeviceTotalCalculationData
        fields = '__all__'


#New code
class DailySummaryReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailySummaryReport
        fields = '__all__'

class FaultRuleSerializer(serializers.ModelSerializer):
    class Meta:
        model = FaultRule
        fields = ['vehicle_type', 'component', 'identifier', 'details']
 

# class FaultSerializer(serializers.ModelSerializer):
#     rule = FaultRuleSerializer(read_only=True)
#     device = DeviceSerializer(read_only=True)
    

#     class Meta:
#         model = Fault
#         fields = ['id', 'device', 'rule', 'component', 'identifier', 'data_snapshot', 'created_at']

class FaultSerializer(serializers.ModelSerializer):
    rule = FaultRuleSerializer(read_only=True)

    class Meta:
        model = Fault
        fields = '__all__'


class FaultReportSerializer(serializers.ModelSerializer):
    vrn = serializers.SerializerMethodField()
    chassis = serializers.SerializerMethodField()
    device_type = serializers.SerializerMethodField()
    fault_code = serializers.CharField(source='rule.identifier')
    fault_component = serializers.CharField(source='rule.component')
    details = serializers.CharField(source='rule.details')

    class Meta:
        model = Fault
        fields = [
            'vrn',
            'chassis',
            'device_type',
            'fault_code',
            'fault_component',
            'created_at',
            'details'
        ]

    def get_vrn(self, obj):
        device = Device.objects.filter(device_id=obj.device).first()
        return device.VRN if device else None

    def get_chassis(self, obj):
        device = Device.objects.filter(device_id=obj.device).first()
        return device.chassis_number if device else None

    def get_device_type(self, obj):
        device = Device.objects.filter(device_id=obj.device).first()
        return device.device_type_name if device else None
    

class SummaryDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = DailySummaryReport
        fields = [
            'date',
            'imei',
            'vehicle_type_name',
            'vehicle_type',
            'fleet',
            'city',
            'distance',
            'runtime_minutes',
            'energy_consumed',
            'motor_ec',
            'regen_energy',
            'co2_saving',
            'cost_saved',
            'mode',
            'sessions',
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        period = self.context.get('period', None)

        # Remove mode and sessions for non-today periods
        if period != 'today':
            self.fields.pop('mode', None)
            self.fields.pop('sessions', None)