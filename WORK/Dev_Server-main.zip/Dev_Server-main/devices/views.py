# Third Party Imports
from datetime import datetime, time, timedelta, date
import json
import io
import csv
from django.forms import model_to_dict
from django.utils import timezone
from django.http import JsonResponse, HttpResponse
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.utils.dateparse import parse_datetime,parse_date
from django.db.models import Q,Max,Sum
from rest_framework.pagination import LimitOffsetPagination
import numpy as np
import pandas as pd
import pytz
from django.db.models.functions import Length

#Local Imports
from devices.calculation import report_calculations_charging_duration_4w, report_calculations_charging_report_3w, report_calculations_cooling_4w, report_calculations_daily_3w, report_calculations_daily_4w, report_calculations_dod_4w, report_calculations_energy_consumption_3w, report_calculations_energy_consumption_4w
from devices.models import (
    Alert,
    Device,
    DeviceData,
    FaultAlert,
    Fault,
    CanKeyPatterns,
    DeviceTotalCalculationData,
    DailySummaryReport,
    MaintenanceTickets,
    LiveData
)
from users.models import UserDeviceAssignment
from devices.pagination import AlertDataPagination, DeviceDataPagination, FaultPagination
from devices.serializers import (
    AlertDataSerializer,
    DeviceDataSerializer,
    DevicePartialDataSerializer, 
    DeviceSerializer,
    DeviceTotalCalculationDataSerializer,
    FaultAlertSerializer,
    DailyTrailSerializer,
    DailySummaryReportSerializer,
    FaultReportSerializer,
    FaultSerializer,
    SummaryDataSerializer
)


class DeviceAPIView(APIView):
    
    def get(self, request):
        devices = Device.objects.all()
        device_id = request.query_params.get("device_id")
        device_type = request.query_params.get("device_type")
        device_type_name = request.query_params.get("device_type_name")
        is_connected = request.query_params.get("is_connected")
        last_seen = request.query_params.get("last_seen")
        platform = request.query_params.get("platform")
        username = request.query_params.get("username")

        if device_id:
            devices = devices.filter(device_id__icontains=device_id)

        if device_type:
            devices = devices.filter(device_type__icontains=device_type)

        if device_type_name:
            devices = devices.filter(device_type_name__icontains=device_type_name)

        if is_connected is not None:
            devices = devices.filter(is_connected=is_connected.lower() == 'true')

        if platform is not None:
            devices = devices.filter(platform__icontains = platform)

        if username is not None:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            user_devices = user_assignment.devices
            devices = devices.filter(device_id__in=user_devices)
        else:
            return Response({"error": "Username required."}, status=status.HTTP_404_NOT_FOUND)
            
            

        if last_seen:
            try:
                parsed_date = parse_date(last_seen)
                if parsed_date:
                    devices = devices.filter(last_seen__date=parsed_date)
            except:
                pass

        serializer = DeviceSerializer(devices, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = DeviceSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        device_id = request.data.get('id') or request.data.get('device_id')
        if not device_id:
            return Response({"error": "Device ID is required for update."}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            device = Device.objects.get(device_id=device_id)
        except Device.DoesNotExist:
            return Response({"error": "Device not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = DeviceSerializer(device, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request):
        device_id = request.query_params.get("device_id")
        if not device_id:
            return Response({"error": "Device ID is required for deletion."}, status=status.HTTP_400_BAD_REQUEST)

        try:
            device = Device.objects.get(device_id=device_id)
            device.delete()
            return Response({"success": f"Device {device_id} deleted."}, status=status.HTTP_204_NO_CONTENT)
        except Device.DoesNotExist:
            return Response({"error": "Device not found."}, status=status.HTTP_404_NOT_FOUND)

class DeviceDataListView(APIView):
    
    def get(self, request):
        queryset = DeviceData.objects.all()

        # Filters
        start_time = request.GET.get('start_time')
        end_time = request.GET.get('end_time')
        vendor_id = request.GET.get('vendor_id')
        imei = request.GET.get('imei')
        device_id = request.GET.get('device_id')
        device_type = request.GET.get('device_type')  # e.g., "7m", "9m", "12m"
        is_export = request.GET.get("is_export", "false") == "true"

        # Date range filter
        if start_time and end_time:
            try:
                queryset = queryset.filter(
                    timestamp__range=(
                        parse_datetime(start_time),
                        parse_datetime(end_time)
                    )
                )
            except Exception:
                return Response({"error": "Invalid datetime format. Use ISO 8601."}, status=400)

        # Vendor filter
        if vendor_id:
            queryset = queryset.filter(vendor_id=vendor_id)

        # IMEI filter
        if imei:
            queryset = queryset.filter(IMEI=imei)

        # Device ID filter
        if device_id:
            queryset = queryset.filter(device_id=device_id)

        # Device type filter (joins with Device table)
        if device_type:
            queryset = queryset.filter(
                device_id__in=Device.objects.filter(
                    device_type_name__icontains=device_type  # ILIKE equivalent in Django
                ).values_list('device_id', flat=True)
            )

        #Ordering
        queryset = queryset.order_by('timestamp')

        if is_export:
            import numpy as np
            import pandas as pd

            serialized_data = DeviceDataSerializer(queryset, many=True).data  

            buffer = io.StringIO()
            writer = csv.writer(buffer)

            # Helper to normalize values
            def normalize_value(v):
                if v is None:
                    return ""
                if isinstance(v, (np.integer,)):
                    return int(v)
                if isinstance(v, (np.floating,)):
                    return float(v)
                if isinstance(v, (np.ndarray, list, tuple)):
                    return ", ".join(str(normalize_value(i)) for i in v)
                if isinstance(v, pd.Timestamp):
                    return v.isoformat()
                if hasattr(v, "isoformat"):  # datetime, date
                    return v.isoformat()
                return str(v)

            can_data_dicts = []
            all_keys = set()
 
            for obj in queryset:
                data = obj.can_data or {}
                if isinstance(data, dict):
                    can_data_dicts.append(data)
                    all_keys.update(data.keys())
            #sorting and reordering
            all_keys = sorted(all_keys)
            all_keys.remove('timestamp')
            all_keys = ['timestamp']+all_keys
           
            writer.writerow(all_keys)
 
           
            for row in can_data_dicts:
                writer.writerow([normalize_value(row.get(k, "")) for k in all_keys])
 
            buffer.seek(0)
            response = HttpResponse(buffer.getvalue(), content_type="text/csv")
            response["Content-Disposition"] = f'attachment; filename="report_{device_id}.csv"'
            return response

        
        # Pagination
        paginator = DeviceDataPagination()
        result_page = paginator.paginate_queryset(queryset, request)
        serializer = DeviceDataSerializer(result_page, many=True)
        return paginator.get_paginated_response(serializer.data)

class AlertAPIView(APIView):
    def get(self, request):
        from django.utils.timezone import localdate
        # alerts = Alert.objects.all()

        device_id = request.GET.get('device_id')
        alert_type = request.GET.get('alert_type')
        value = request.GET.get('value')
        timestamp = request.GET.get('timestamp')
        username = request.GET.get('username')

        if device_id:
            alerts = Alert.objects.filter(device__device_id__icontains=device_id)

        if alert_type:
            alerts = Alert.objects.filter(alert_type__icontains=alert_type)

        if value:
            alerts = Alert.objects.filter(value__icontains=value)

        if timestamp:
            try:
                parsed_datetime = parse_datetime(timestamp)
                if parsed_datetime:
                    alerts = Alert.objects.filter(timestamp__date=parsed_datetime.date())
            except:
                pass

        today = datetime.now().date()
        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            
            if user_assignment and user_assignment.devices:
                user_devices = user_assignment.devices
                alerts = Alert.objects.filter(imei__in=user_devices,start_time__date = today,duration_seconds__gt=120)


        # Apply custom pagination
        # paginator = AlertDataPagination()
        # paginated_alerts = paginator.paginate_queryset(alerts, request)
        serializer = AlertDataSerializer(alerts, many=True)

        return  Response(serializer.data)

class FaultAlertAPIView(APIView):

    def get(self, request):
        queryset = FaultAlert.objects.select_related('device', 'fault').all().order_by('-timestamp')

        # Filters
        device_id = request.query_params.get('device_id')
        fault_name = request.query_params.get('fault_name')
        timestamp = request.query_params.get('timestamp')
        search = request.query_params.get('search')

        if device_id:
            queryset = queryset.filter(device__device_id__icontains=device_id)

        if fault_name:
            queryset = queryset.filter(fault__name__icontains=fault_name)

        if timestamp:
            try:
                parsed_ts = parse_datetime(timestamp)
                if parsed_ts:
                    queryset = queryset.filter(timestamp__date=parsed_ts.date())
            except:
                pass

        if search:
            queryset = queryset.filter(
                Q(device__device_id__icontains=search) |
                Q(fault__name__icontains=search)
            )

        # Apply Pagination
        paginator = FaultAlertPagination()
        paginated_qs = paginator.paginate_queryset(queryset, request)
        serializer = FaultAlertSerializer(paginated_qs, many=True)

        return paginator.get_paginated_response(serializer.data)

class DeviceAggregateSummaryAPIView(APIView):
    def get(self, request):
        total_device = Device.objects.count()
        active = Device.objects.filter(is_connected=True).count()
        inactive = Device.objects.filter(is_connected=False).count()

        # Grouped by device_type
        device_type_summary = []
        device_types = Device.objects.values('device_type','device_type_name').distinct()
        for dt in device_types:
            dtype_name = dt['device_type_name']
            dtype = dt['device_type']
            total = Device.objects.filter(device_type_name=dtype_name).count()
            active_count = Device.objects.filter(device_type_name=dtype_name, is_connected=True).count()
            inactive_count = Device.objects.filter(device_type_name=dtype_name, is_connected=False).count()

            device_type_summary.append({
                "device_type_name": dtype_name,
                "device_type": dtype,
                "total_device": total,
                "active": active_count,
                "inactive": inactive_count,
            })

        return Response({
            "total_device": total_device,
            "active": active,
            "inactive": inactive,
            "device_types": device_type_summary
        }, status=status.HTTP_200_OK)

class LatestDeviceLocationAPIView(APIView):
    def get(self, request):
        today = datetime.now().date()

        # Filter only today's data
        latest_timestamps = DeviceData.objects.filter(timestamp__date=today).values('device_id').annotate(
            latest_timestamp=Max('timestamp')
        )

        latest_data = []
        for entry in latest_timestamps:
            record = DeviceData.objects.filter(
                device_id=entry['device_id'],
                timestamp=entry['latest_timestamp']
            ).first()

            if record:
                latest_data.append({
                    "imei": record.IMEI,
                    "device_id": record.device_id,
                    "latitude": record.latitude,
                    "longitude": record.longitude,
                    "latitude_dir": record.latitude_dir,
                    "longitude_dir": record.longitude_dir,
                    "heading": record.heading,
                    "time": record.time,
                    "speed": record.speed,
                    "Vehicle_DTE_Km": {k: v for k, v in record.can_data.items() if "DTE" in k.upper()},
                    "SOC": {k: v for k, v in record.can_data.items() if "SOC" in k.upper()},
                    "Max_Cell_Temp": {k: v for k, v in record.can_data.items() if "Max_Cell_Temp" in k.upper()},
                    "Min_Cell_Temp": {k: v for k, v in record.can_data.items() if "Min_Cell_Temp" in k.upper()},
                    "TS": {k: v for k, v in record.can_data.items() if "TS" in k.upper()},
                })

        paginator = LimitOffsetPagination()
        paginated_data = paginator.paginate_queryset(latest_data, request)

        return paginator.get_paginated_response(paginated_data)

from collections import defaultdict
class DeviceCanDataSummaryAPIView(APIView):
    def get_can_key_patterns(self,):
        global_patterns = CanKeyPatterns.objects.filter(device_id__isnull=True)
        #device_specific_patterns = CanKeyPatterns.objects.filter(device_id=device_id)
        all_patterns = list(global_patterns.values_list('name', flat=True)) #+ \
                       #list(device_specific_patterns.values_list('name', flat=True))
        return all_patterns

    def get(self, request):
        device_id = request.query_params.get('device_id')
        start_str = request.query_params.get('start_datetime')
        end_str = request.query_params.get('end_datetime')

        if not device_id:
            return Response({'error': 'device_id is required'}, status=status.HTTP_400_BAD_REQUEST)

        can_key_patterns = self.get_can_key_patterns()#device_id)
        if not can_key_patterns:
            return Response({'error': 'No CAN key patterns found for this device or globally'}, status=status.HTTP_404_NOT_FOUND)

        # Filtering and fetching at once
        # records = DeviceData.objects.filter(device_id=device_id).exclude(can_data=None)

        if start_str and end_str:
            try:
                start_datetime = parse_datetime(start_str)
                end_datetime = parse_datetime(end_str)

                if not start_datetime or not end_datetime:
                    raise ValueError

                if end_datetime - start_datetime > timedelta(days=1):
                    return Response({'error': 'Datetime range must not exceed one day'}, status=status.HTTP_400_BAD_REQUEST)

                # records = records.filter(timestamp__gte=start_datetime, timestamp__lte=end_datetime)
                records = DeviceData.objects.filter(device_id=device_id,timestamp__gte=start_datetime,timestamp__lte=end_datetime).exclude(can_data=None)
            except Exception:
                return Response({'error': 'Invalid datetime format. Use ISO format: YYYY-MM-DDTHH:MM:SSZ'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            today = datetime.now().date()
            # records = records.filter(timestamp__date=today)
            records = DeviceData.objects.filter(device_id=device_id,timestamp__date=today).exclude(can_data=None)
        
        #For faster filtering
        result = defaultdict(list)

        for record in records:
            can_data = record.can_data or {}
            for key, value in can_data.items():
                # Check if any pattern matches this key (case-insensitive)
                if any(pattern.lower() in key.lower() for pattern in can_key_patterns):
                    result[key].append(value)

        # Convert defaultdict to normal dict for JSON response
        return Response(dict(result), status=status.HTTP_200_OK)

class DailyTrailAPIView(APIView):

    def get(self, request):
        device_id = request.query_params.get("device_id")
        query_date = request.query_params.get("date")

        if not device_id:
            return Response({"error": "device_id is required"}, status=400)

        try:
            if query_date:
                query_date = parse_date(query_date)
                if not query_date:
                    raise ValueError("Invalid date format")
            else:
                query_date = date.today()
        except Exception:
            return Response({"error": "Invalid date format. Use YYYY-MM-DD."}, status=400)

        start_datetime = datetime.combine(query_date, datetime.min.time())
        end_datetime = datetime.combine(query_date, datetime.max.time())

        db_to_use = "default" if query_date != date.today() else "default"

        # Order by timestamp to ensure consistent pagination
        queryset = DeviceData.objects.using(db_to_use).filter(
            device_id=device_id,
            timestamp__range=(start_datetime, end_datetime)
        ).order_by('timestamp')
        
        # paginator = DeviceDataPagination()
        # result_page = paginator.paginate_queryset(queryset, request)

        # # Fetch all relevant faults
        # faults = Fault.objects.filter(device__device_id=device_id)

        # # Only count faults for the current page to improve performance
        # count = 0
        # for data in result_page:  # Changed from queryset to result_page
        #     can_data = data.can_data or {}
        #     for fault_key in faults:
        #         value = can_data.get(fault_key)
        #         if isinstance(value, bool) and value:
        #             count += 1
        #         elif isinstance(value, (int, str)) and str(value).lower() in ("1", "true"):
        #             count += 1
        serializer = DailyTrailSerializer(queryset, many=True)#, context={'fault_counts': count})
        return Response(serializer.data, status=status.HTTP_200_OK)

class TotalEnergySavedAPIView(APIView):
    
    def get(self, request):
        device_type = request.query_params.get("device_type", None)
        device_id = request.query_params.get("device_id", None)

        queryset = DeviceTotalCalculationData.objects.all()

        if device_type:
            queryset = queryset.filter(
                device_id__in=Device.objects.filter(
                    device_type_name__icontains=device_type
                ).values_list("device_id", flat=True)
            )
            
        if device_id:
            queryset = queryset.filter(
                device_id__in = Device.objects.filter(
                    device_id = device_id
                ).values_list("device_id", flat=True)
            )

        totals = queryset.aggregate(
            total_distance=Sum("total_distance"),
            co2_saving=Sum("co2_saving"),
            energy_consumption=Sum("energy_consumption"),
            run_time=Sum("run_time"),
            traction_energy=Sum("traction_energy"),
            regen_energy=Sum("regen_energy"),
            idle_time=Sum("idle_time"),
            charging_unit=Sum("charging_unit"),
            charging_count=Sum("charging_count"),
            cost_saved=Sum("cost_saved")
        )

        return Response(totals)


class CalculationReportAPIView(APIView):
    def get(self, request):
        # try:
            start_date_str = request.GET.get("start_date")
            end_date_str = request.GET.get("end_date")
            device_id = request.GET.get("device_id")

            cooling_report = request.GET.get("cooling_report") == "true"
            charging_duration = request.GET.get("charging_duration") == "true"
            dod = request.GET.get("dod") == 'true'
            charging_report = request.GET.get('charging_report') == 'true'
            energy_consumption = request.GET.get("energy_consumption") == 'true'
            is_export = request.GET.get("is_export", "false") == "true"
            

            # Validate required params
            if not start_date_str or not end_date_str or not device_id:
                return JsonResponse({"error": "start_date, end_date, and device_id are required"}, status=400)

            # Convert to datetime
            start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
            end_date = datetime.strptime(end_date_str, "%Y-%m-%d")

            # Check time difference limit (max 3 months)
            if (end_date - start_date).days > 92:  # ~3 months
                return JsonResponse({"error": "Date range cannot exceed 3 months"}, status=400)

            # Get pagination parameters with defaults
            # try:
            #     limit = int(request.GET.get('limit', 500))  # Default to 500 if not specified
            #     offset = int(request.GET.get('offset', 0))   # Default to 0 if not specified
                
            #     # Validate pagination parameters
            #     if limit < 1 or limit > 1000:  # Set a reasonable max limit
            #         return JsonResponse({"error": "Limit must be between 1 and 1000"}, status=400)
            #     if offset < 0:
            #         return JsonResponse({"error": "Offset cannot be negative"}, status=400)
                    
            # except ValueError:
            #     return JsonResponse({"error": "Limit and offset must be integers"}, status=400)

            # Get can_data for given device and date range with pagination
            can_data_queryset = DeviceData.objects.filter(
                device_id=device_id,
                timestamp__range=(start_date, end_date)
            ).order_by('-timestamp')
            
            # Apply pagination
            # total_count = can_data_queryset.count()
            # paginated_queryset = can_data_queryset[offset:offset + limit]
            
            # response_data = {
            #     "pagination": {
            #         "total": total_count,
            #         "limit": limit,
            #         "offset": offset,
            #         "has_more": (offset + limit) < total_count
            #     }
            # }
            
            device = Device.objects.get(device_id=device_id)
            can_data_list = list(can_data_queryset.values_list('can_data', flat=True))
            
            # Handle empty results
            if not can_data_list:
                return JsonResponse({"error": "No data found for the given criteria"}, status=404)
                
            # Get start and end data points from the paginated results
            start_data = can_data_queryset.first()
            end_data = can_data_queryset.last()
            
            # Safely get coordinates if they exist
            start_lat = start_data.latitude if start_data and hasattr(start_data, 'latitude') else None
            start_long = start_data.longitude if start_data and hasattr(start_data, 'longitude') else None
            end_lat = end_data.latitude if end_data and hasattr(end_data, 'latitude') else None
            end_long = end_data.longitude if end_data and hasattr(end_data, 'longitude') else None
            
            response_data = {}
            
            if device.device_type == '4w':
                variant = (device.device_type_name)
                # device_type = str(device.device_type_name).lower()
                # variant = '7m'
                # Type = 7
                # for size in ['7m', '9m', '12m']:
                #     if size in device_type:
                #         variant = size
                # for size in [7, 9, 12]:
                #     if str(size) in device_type:
                #         Type = size
                
                # Call respective reports based on flags
                if charging_duration:
                    response_data["charging_duration"] = report_calculations_charging_duration_4w(can_data_list,device_id,variant)

                if cooling_report:
                    response_data["cooling"] = report_calculations_cooling_4w(can_data_list,device_id,variant)
                    
                if dod:
                    response_data["dod"] = report_calculations_dod_4w(can_data_list,device_id,variant)
                    
                if charging_report:
                    print('comming at 4')
                    response_data['charging_report'] = report_calculations_charging_duration_4w(can_data_list,device_id,variant)

                if energy_consumption:
                    response_data["energy_consumption"] = report_calculations_energy_consumption_4w(can_data_list,variant,start_lat,start_long,end_lat,end_long)

            if device.device_type == "3w":
                if charging_duration:
                    return JsonResponse({"error": "This Vehicle doesn't have Charging Report"}, status=400)

                if cooling_report:
                    return JsonResponse({"error": "This Vehicle doesn't have Cooling Report"}, status=400)
                    
                if dod:
                    return JsonResponse({"error": "This Vehicle doesn't have DOD Report"}, status=400)
                    
                if charging_report:
                    print('comming at 3')
                    response_data['charging_report'] = report_calculations_charging_report_3w(can_data_list,start_lat,start_long,end_lat,end_long)

                if energy_consumption:
                    response_data["energy_consumption"] = report_calculations_energy_consumption_3w(can_data_list,start_lat,start_long,end_lat,end_long)


            if is_export:
                import io
                import pandas as pd
                import numpy as np
                from django.http import HttpResponse

                buffer = io.StringIO()

                # small helper to normalize various numpy/pandas types to plain Python / strings
                def _conv(x):
                    # None/NaN
                    try:
                        if x is None:
                            return ""
                        if isinstance(x, (float,)) and np.isnan(x):
                            return ""
                    except Exception:
                        pass

                    # numpy scalar -> python scalar
                    if isinstance(x, (np.integer,)):
                        return int(x)
                    if isinstance(x, (np.floating,)):
                        v = float(x)
                        if np.isnan(v) or np.isinf(v):
                            return ""
                        return v

                    # numpy arrays -> convert elements
                    if isinstance(x, (np.ndarray,)):
                        try:
                            return [ _conv(i) for i in x.tolist() ]
                        except Exception:
                            return str(x)

                    # pandas Timestamp
                    if isinstance(x, pd.Timestamp):
                        return x.isoformat()

                    # Iterable (list/tuple) -> convert elements
                    if isinstance(x, (list, tuple)):
                        return [ _conv(i) for i in x ]

                    # has .item()
                    if hasattr(x, "item") and not isinstance(x, (str, bytes)):
                        try:
                            return _conv(x.item())
                        except Exception:
                            pass

                    # fallback
                    return x

                # write a section to buffer using pandas (keeps proper csv quoting)
                def _write_section(title, df):
                    buffer.write(f"--- {title} ---\n")
                    # ensure DataFrame columns/values are serializable
                    for col in df.columns:
                        df[col] = df[col].apply(_conv)
                    # write CSV for this df (no index)
                    df.to_csv(buffer, index=False)
                    buffer.write("\n")

                # PAGINATION (dict -> single-row DataFrame)
                if "pagination" in response_data:
                    pag = response_data["pagination"]
                    # make a single-row DF
                    df_pag = pd.DataFrame([ {k: _conv(v) for k, v in pag.items()} ])
                    _write_section("Pagination", df_pag)

                # CHARGING_DURATION (likely dict of lists)
                if "charging_duration" in response_data:
                    cd = response_data["charging_duration"]
                    # ensure values are lists
                    cd_clean = {}
                    for k, v in cd.items():
                        if isinstance(v, (list, tuple, np.ndarray)):
                            cd_clean[k] = [ _conv(i) for i in v ]
                        else:
                            cd_clean[k] = [ _conv(v) ]
                    try:
                        df_cd = pd.DataFrame(cd_clean)
                    except Exception:
                        # fallback: convert to single-row dict
                        df_cd = pd.DataFrame([ {k: (v if not isinstance(v, (list, tuple)) else v[0]) for k, v in cd_clean.items()} ])
                    _write_section("Charging Duration", df_cd)

                # COOLING (list of dicts)
                if "cooling" in response_data:
                    cooling = response_data["cooling"]
                    if isinstance(cooling, list) and len(cooling) > 0:
                        rows = []
                        for row in cooling:
                            rows.append({k: _conv(v) for k, v in row.items()})
                        df_cooling = pd.DataFrame(rows)
                        _write_section("Cooling", df_cooling)
                    else:
                        buffer.write("--- Cooling ---\nNo cooling data\n\n")

                # CHARGING_REPORT (dict of lists or list of dicts)
                if "charging_report" in response_data:
                    cr = response_data["charging_report"]
                    if isinstance(cr, dict):
                        cr_clean = {}
                        for k, v in cr.items():
                            if isinstance(v, (list, tuple, np.ndarray)):
                                cr_clean[k] = [ _conv(i) for i in v ]
                            else:
                                cr_clean[k] = [ _conv(v) ]
                        try:
                            df_cr = pd.DataFrame(cr_clean)
                        except Exception:
                            df_cr = pd.DataFrame([ {k: (v if not isinstance(v, (list,tuple)) else v[0]) for k, v in cr_clean.items()} ])
                    elif isinstance(cr, list):
                        df_cr = pd.DataFrame([ {k: _conv(v) for k, v in item.items()} for item in cr ])
                    else:
                        df_cr = pd.DataFrame([{"value": _conv(cr)}])
                    _write_section("Charging Report", df_cr)

                # DOD (could be dict/list)
                if "dod" in response_data:
                    dod = response_data["dod"]
                    if isinstance(dod, dict):
                        dod_clean = {}
                        for k, v in dod.items():
                            if isinstance(v, (list, tuple, np.ndarray)):
                                dod_clean[k] = [ _conv(i) for i in v ]
                            else:
                                dod_clean[k] = [ _conv(v) ]
                        try:
                            df_dod = pd.DataFrame(dod_clean)
                        except Exception:
                            df_dod = pd.DataFrame([dod_clean])
                    elif isinstance(dod, list):
                        df_dod = pd.DataFrame([ {k: _conv(v) for k, v in item.items()} for item in dod ])
                    else:
                        df_dod = pd.DataFrame([{"value": _conv(dod)}])
                    _write_section("DOD Report", df_dod)

                # ENERGY_CONSUMPTION (could be list/dict)
                if "energy_consumption" in response_data:
                    ec = response_data["energy_consumption"]
                    if isinstance(ec, dict):
                        ec_clean = {}
                        for k, v in ec.items():
                            if isinstance(v, (list, tuple, np.ndarray)):
                                ec_clean[k] = [ _conv(i) for i in v ]
                            else:
                                ec_clean[k] = [ _conv(v) ]
                        try:
                            df_ec = pd.DataFrame(ec_clean)
                        except Exception:
                            df_ec = pd.DataFrame([ec_clean])
                    elif isinstance(ec, list):
                        # if list of dicts, flatten
                        if len(ec) > 0 and isinstance(ec[0], dict):
                            df_ec = pd.DataFrame([ {k: _conv(v) for k, v in item.items()} for item in ec ])
                        else:
                            df_ec = pd.DataFrame({"value": [ _conv(i) for i in ec ]})
                    else:
                        df_ec = pd.DataFrame([{"value": _conv(ec)}])
                    _write_section("Energy Consumption", df_ec)

                # finalize buffer and return response
                buffer.seek(0)
                resp = HttpResponse(buffer.getvalue(), content_type="text/csv")
                resp["Content-Disposition"] = f'attachment; filename="report_{device_id}.csv"'
                return resp
            return Response(response_data)

        # except ValidationError as e:
        #     return JsonResponse({"error": str(e)}, status=400)
        # except Exception as e:
        #     return JsonResponse({"error": str(e)}, status=500)

class DailyReportAPIView(APIView):
    def get(self, request):
        device_id = request.GET.get("device_id")
        today_str = request.GET.get('start_date')
        if today_str is None:
            today_date = timezone.now().date()  
            today = datetime.combine(today_date, time.min)
        else:
            today = datetime.strptime(today_str, '%Y-%m-%d').date()
        start_of_day = timezone.make_aware(datetime.combine(today, datetime.min.time()))
        end_of_day = timezone.make_aware(datetime.combine(today, datetime.max.time()))
        is_export = request.GET.get("is_export", "false") == "true"
    
        
        if not device_id:
            return JsonResponse({"error": "device_id is required"}, status=400)
        
        if device_id:
            can_data_queryset = DeviceData.objects.using('replica').filter(
                device_id=device_id,
                timestamp__range=(start_of_day, end_of_day)
            )
        else:
            can_data_queryset = DeviceData.objects.using('replica').filter(
                timestamp__range=(start_of_day, end_of_day)
            )

        device = Device.objects.get(device_id=device_id)
        start_data = can_data_queryset.first()
        end_data = can_data_queryset.last()
        start_lat = start_data.latitude
        start_long = start_data.longitude
        end_lat = end_data.latitude
        end_long = end_data.longitude
        can_data_list = list(can_data_queryset.values_list('can_data', flat=True))
        if device.device_type == '4w':
            device_type = device.device_type_name
            variant = '7m'
            Type = 7
            for size in ['7m', '9m', '12m']:
                if size in device_type:
                    variant = size
            for size in [7, 9, 12]:
                if str(size) in device_type:
                    Type = size
                daily_summary = report_calculations_daily_4w(can_data_list,variant,start_lat,start_long,end_lat,end_long)
                
            if is_export:
                import io
                import pandas as pd
                import numpy as np
                from django.http import HttpResponse

                buffer = io.StringIO()

                # small helper to normalize various numpy/pandas types to plain Python / strings
                def _conv(x):
                    # None/NaN
                    try:
                        if x is None:
                            return ""
                        if isinstance(x, (float,)) and np.isnan(x):
                            return ""
                    except Exception:
                        pass

                    # numpy scalar -> python scalar
                    if isinstance(x, (np.integer,)):
                        return int(x)
                    if isinstance(x, (np.floating,)):
                        v = float(x)
                        if np.isnan(v) or np.isinf(v):
                            return ""
                        return v

                    # numpy arrays -> convert elements
                    if isinstance(x, (np.ndarray,)):
                        try:
                            return [ _conv(i) for i in x.tolist() ]
                        except Exception:
                            return str(x)

                    # pandas Timestamp
                    if isinstance(x, pd.Timestamp):
                        return x.isoformat()

                    # Iterable (list/tuple) -> convert elements
                    if isinstance(x, (list, tuple)):
                        return [ _conv(i) for i in x ]

                    # has .item()
                    if hasattr(x, "item") and not isinstance(x, (str, bytes)):
                        try:
                            return _conv(x.item())
                        except Exception:
                            pass

                    # fallback
                    return x

                # write a section to buffer using pandas (keeps proper csv quoting)
                def _write_section(title, df):
                    buffer.write(f"--- {title} ---\n")
                    # ensure DataFrame columns/values are serializable
                    for col in df.columns:
                        df[col] = df[col].apply(_conv)
                    # write CSV for this df (no index)
                    df.to_csv(buffer, index=False)
                    buffer.write("\n")

                # PAGINATION (dict -> single-row DataFrame)
                if daily_summary:
                    pag = daily_summary
                    # make a single-row DF
                    df_pag = pd.DataFrame([ {k: _conv(v) for k, v in pag.items()} ])
                    _write_section("Pagination", df_pag)

                    buffer.seek(0)

                    response = HttpResponse(buffer.getvalue(), content_type="text/csv")
                    response["Content-Disposition"] = f'attachment; filename="report_{device_id}.csv"'
                    return response
            return Response(daily_summary) if daily_summary else JsonResponse({})
            
        else:
            daily_summary = report_calculations_daily_3w(can_data_list,start_lat,start_long,end_lat,end_long)
            if is_export:
                import io
                import pandas as pd
                import numpy as np
                from django.http import HttpResponse

                buffer = io.StringIO()

                # small helper to normalize various numpy/pandas types to plain Python / strings
                def _conv(x):
                    # None/NaN
                    try:
                        if x is None:
                            return ""
                        if isinstance(x, (float,)) and np.isnan(x):
                            return ""
                    except Exception:
                        pass

                    # numpy scalar -> python scalar
                    if isinstance(x, (np.integer,)):
                        return int(x)
                    if isinstance(x, (np.floating,)):
                        v = float(x)
                        if np.isnan(v) or np.isinf(v):
                            return ""
                        return v

                    # numpy arrays -> convert elements
                    if isinstance(x, (np.ndarray,)):
                        try:
                            return [ _conv(i) for i in x.tolist() ]
                        except Exception:
                            return str(x)

                    # pandas Timestamp
                    if isinstance(x, pd.Timestamp):
                        return x.isoformat()

                    # Iterable (list/tuple) -> convert elements
                    if isinstance(x, (list, tuple)):
                        return [ _conv(i) for i in x ]

                    # has .item()
                    if hasattr(x, "item") and not isinstance(x, (str, bytes)):
                        try:
                            return _conv(x.item())
                        except Exception:
                            pass

                    # fallback
                    return x

                # write a section to buffer using pandas (keeps proper csv quoting)
                def _write_section(title, df):
                    buffer.write(f"--- {title} ---\n")
                    # ensure DataFrame columns/values are serializable
                    for col in df.columns:
                        df[col] = df[col].apply(_conv)
                    # write CSV for this df (no index)
                    df.to_csv(buffer, index=False)
                    buffer.write("\n")

                # PAGINATION (dict -> single-row DataFrame)
                if daily_summary:
                    pag = daily_summary
                    # make a single-row DF
                    df_pag = pd.DataFrame([ {k: _conv(v) for k, v in pag.items()} ])
                    _write_section("Pagination", df_pag)

                buffer.seek(0)

                response = HttpResponse(buffer.getvalue(), content_type="text/csv")
                response["Content-Disposition"] = f'attachment; filename="report_{device_id}.csv"'
                return response
            return Response(daily_summary) if daily_summary else JsonResponse({})
        
        return JsonResponse({})

class DisconnectedDevicesLastDataAPIView(APIView):
    """
    API that returns the last DeviceData entry for all devices
    where is_connected = False.
    """

    def get(self, request):
        from users.models import UserDeviceAssignment
        device_type = request.query_params.get("device_type", None)
        platform = request.query_params.get("platform", None)
        username = request.query_params.get("username", None)
        disconnected_devices = Device.objects.filter(is_connected=False)


        if device_type:
            disconnected_devices = Device.objects.filter(device_type_name__icontains=device_type,is_connected = False)

        if platform:
            disconnected_devices = disconnected_devices.filter(platform__icontains=platform)

        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            if user_assignment and user_assignment.devices:
                assigned_device_ids = user_assignment.devices
                disconnected_devices = disconnected_devices.filter(device_id__in=assigned_device_ids)
            else:
                disconnected_devices = Device.objects.none()

        if not disconnected_devices.exists():
            return Response(
                {"message": "No disconnected devices found."},
                status=status.HTTP_200_OK
            )

        disconnected_device_ids = disconnected_devices.values_list('device_id', flat=True)

        latest_data_info = DeviceData.objects.filter(
            device_id__in=disconnected_device_ids
        ).values('device_id').annotate(
            latest_timestamp=Max('timestamp')
        )

        device_last_timestamps = {
            entry['device_id']: entry['latest_timestamp'] for entry in latest_data_info
        }
        
        last_device_data = DeviceData.objects.filter(
            device_id__in=device_last_timestamps.keys(),
            timestamp__in=device_last_timestamps.values()
        )

        serializer = DevicePartialDataSerializer(last_device_data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class ConnectedDevicesLastDataAPIView(APIView):
    """
    API that returns the last DeviceData entry for all devices
    where is_connected = True.
    """

    def get(self, request):
        from users.models import UserDeviceAssignment

        device_type = request.query_params.get("device_type", None)
        platform = request.query_params.get("platform", None)
        username = request.query_params.get("username", None)

        isconnected_devices = Device.objects.filter(is_connected=True)

        if device_type:
            isconnected_devices = isconnected_devices.filter(device_type_name__icontains=device_type)

        if platform:
            isconnected_devices = isconnected_devices.filter(platform__icontains=platform)

        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            if user_assignment and user_assignment.devices:
                assigned_device_ids = user_assignment.devices
                isconnected_devices = isconnected_devices.filter(device_id__in=assigned_device_ids)
            else:
                isconnected_devices = Device.objects.none()

        isconnected_device_ids = isconnected_devices.values_list('device_id', flat=True)

        latest_data_info = DeviceData.objects.filter(
            device_id__in=isconnected_device_ids
        ).values('device_id').annotate(
            latest_timestamp=Max('timestamp')
        )

        device_last_timestamps = {
            entry['device_id']: entry['latest_timestamp'] for entry in latest_data_info
        }
        
        last_device_data = DeviceData.objects.filter(
            device_id__in=device_last_timestamps.keys(),
            timestamp__in=device_last_timestamps.values()
        )

        serializer = DevicePartialDataSerializer(last_device_data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

class DeviceCalculateData(APIView):
    def get(self,request):
        username = request.query_params.get("username", None)
        data = DeviceTotalCalculationData.objects.all()

        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            if user_assignment and user_assignment.devices:
                user_devices = user_assignment.devices
                data = data.filter(device_id__in=user_devices)
            else:
                # No devices assigned to this user
                data = DeviceTotalCalculationData.objects.none()



        serializer = DeviceTotalCalculationDataSerializer(data, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)

import math

def clean_nan_values(obj):
    if isinstance(obj, dict):
        return {k: clean_nan_values(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan_values(item) for item in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
    return obj

class MISCalculationReportAPIView(APIView):
    def get(self, request):
        import pandas as pd
        fleet_name = request.GET.get("fleet_name")
        start_date_str = request.GET.get("start_date")
        end_date_str = request.GET.get("end_date")
        report_type = request.GET.get("report_type", "daily")  # daily/weekly/monthly
        is_export = request.GET.get("is_export", "false") == "true"
        username = request.GET.get("username")

        if not fleet_name or not start_date_str or not end_date_str or not username:
            return JsonResponse({"error": "username,fleet_name, start_date, and end_date are required"}, status=400)

        try:
            start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
            end_date = datetime.strptime(end_date_str, "%Y-%m-%d")

            if start_date.date() == end_date.date():
                start_date = datetime.combine(start_date.date(), datetime.min.time())
                end_date = datetime.combine(end_date.date(), datetime.max.time())
        except ValueError:
            return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD"}, status=400)

        
        user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()

        if not user_assignment or not user_assignment.devices:
            return JsonResponse({"error": "No devices assigned to this user"}, status=404)

        # Assuming user_assignment.devices is a list of device IDs
        user_devices = user_assignment.devices

        # Filter devices belonging to the fleet and assigned to user
        devices = Device.objects.filter(fleet=fleet_name, device_id__in=user_devices)

        if not devices.exists():
            return JsonResponse({"error": "No devices found for this fleet and user"}, status=404)



        can_data_queryset = DeviceData.objects.filter(
            device_id__in=devices.values_list("device_id", flat=True),
            timestamp__range=(start_date, end_date)
        ).order_by("timestamp")


        if not can_data_queryset.exists():
            return JsonResponse({"error": "No data found in given range"}, status=404)

        df = pd.DataFrame(list(can_data_queryset.values("device_id","timestamp", "can_data", "latitude", "longitude")))
        df["timestamp"] = pd.to_datetime(df["timestamp"])

        if report_type == "daily":
            df["period"] = df["timestamp"].dt.date
        elif report_type == "weekly":
            df["period"] = df["timestamp"].dt.to_period("W").apply(lambda r: r.start_time.date())
        elif report_type == "monthly":
            df["period"] = df["timestamp"].dt.to_period("M").apply(lambda r: r.start_time.date())
        else:
            return JsonResponse({"error": "Invalid report_type. Choose daily, weekly, or monthly"}, status=400)

        grouped = df.groupby(["period","device_id"])
        response_data = {}

        device_map = {d.device_id: d for d in devices}

        for (period, device_id), group in grouped:
            device = device_map.get(device_id)
            if not device:
                continue

            can_data_list = list(group["can_data"])
            start_row = group.iloc[0]
            end_row = group.iloc[-1]
            start_lat, start_long = start_row.get("latitude"), start_row.get("longitude")
            end_lat, end_long = end_row.get("latitude"), end_row.get("longitude")

            period_key = f"{period}_{device_id}"
            period_result = {}

            if device.device_type == "4w":
                device_type = device.device_type_name
                variant = "7m"
                for size in ["7m", "9m", "12m"]:
                    if size in device_type:
                        variant = size

                period_result["charging_duration"] =clean_nan_values(report_calculations_charging_duration_4w(can_data_list, device_id, variant))
                # period_result["cooling"] = report_calculations_cooling_4w(can_data_list, device_id, variant)
                period_result["dod"] = clean_nan_values(report_calculations_dod_4w(can_data_list, device_id, variant))
                period_result["energy_consumption"] = clean_nan_values(report_calculations_energy_consumption_4w(
                    can_data_list, variant, start_lat, start_long, end_lat, end_long
                ))

            elif device.device_type == "3w":
                period_result["charging_report"] = clean_nan_values(report_calculations_charging_report_3w(
                    can_data_list, start_lat, start_long, end_lat, end_long
                ))
                period_result["energy_consumption"] = clean_nan_values(report_calculations_energy_consumption_3w(
                    can_data_list, start_lat, start_long, end_lat, end_long
                ))

            response_data[period_key] = period_result
        if is_export:
            import io
            import pandas as pd
            import numpy as np
            from django.http import HttpResponse

            buffer = io.StringIO()

            # Small helper to normalize various numpy/pandas types to plain Python / strings
            def _conv(x):
                try:
                    if x is None:
                        return ""
                    if isinstance(x, (float,)) and np.isnan(x):
                        return ""
                except Exception:
                    pass
                if isinstance(x, (np.integer,)):
                    return int(x)
                if isinstance(x, (np.floating,)):
                    v = float(x)
                    if np.isnan(v) or np.isinf(v):
                        return ""
                    return v
                if isinstance(x, (np.ndarray,)):
                    try:
                        return [_conv(i) for i in x.tolist()]
                    except Exception:
                        return str(x)
                if isinstance(x, pd.Timestamp):
                    return x.isoformat()
                if isinstance(x, (list, tuple)):
                    return [_conv(i) for i in x]
                if hasattr(x, "item") and not isinstance(x, (str, bytes)):
                    try:
                        return _conv(x.item())
                    except Exception:
                        pass
                return x

            # Write a section to buffer using pandas (keeps proper csv quoting)
            def _write_section(title, df):
                buffer.write(f"========== {title} ==========\n")
                for col in df.columns:
                    df[col] = df[col].apply(_conv)
                df.to_csv(buffer, index=False)
                buffer.write("\n")

            # Loop through each period_device entry in response_data
            for section_key, section_data in response_data.items():
                buffer.write(f"\n########## Report for: {section_key} ##########\n")

                for metric_name in ["charging_duration", "cooling", "dod", "charging_report", "energy_consumption"]:
                    if metric_name not in section_data:
                        continue
                    metric_data = section_data[metric_name]

                    try:
                        if isinstance(metric_data, dict):
                            # Normalize dict into DataFrame
                            clean = {}
                            for k, v in metric_data.items():
                                if isinstance(v, (list, tuple, np.ndarray)):
                                    clean[k] = [_conv(i) for i in v]
                                else:
                                    clean[k] = [_conv(v)]
                            df_metric = pd.DataFrame(clean)
                        elif isinstance(metric_data, list):
                            if len(metric_data) > 0 and isinstance(metric_data[0], dict):
                                df_metric = pd.DataFrame([{k: _conv(v) for k, v in item.items()} for item in metric_data])
                            else:
                                df_metric = pd.DataFrame({"value": [_conv(i) for i in metric_data]})
                        else:
                            df_metric = pd.DataFrame([{"value": _conv(metric_data)}])

                        _write_section(metric_name.replace("_", " ").title(), df_metric)
                    except Exception as e:
                        buffer.write(f"--- {metric_name.title()} ---\nError generating section: {str(e)}\n\n")

            # Finalize buffer and return response
            buffer.seek(0)
            resp = HttpResponse(buffer.getvalue(), content_type="text/csv")
            resp["Content-Disposition"] = f'attachment; filename="report_{fleet_name}.csv"'
            return resp

        return Response(response_data)


class MaintenanceTicketsAPIView(APIView):
    
    def get(self, request):
        username = request.query_params.get('username')

        if not username:
            return JsonResponse({"error": "username is required"}, status=400)

        tickets = MaintenanceTickets.objects.all()

        # Filter tickets by devices assigned to the user
        user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
        if user_assignment and user_assignment.devices:
            user_devices = user_assignment.devices  # list of device IDs
            tickets = tickets.filter(device__id__in=user_devices)
        else:
            # No devices assigned to this user
            tickets = MaintenanceTickets.objects.none()

        # Build JSON response with proper date/boolean serialization
        data = [
            {
                "id": ticket.id,
                "vrn": ticket.vrn,
                "device_specific_type": ticket.device_specific_type,
                "chassis_number": ticket.chassis_number,
                "scheduled_date": ticket.scheduled_date.strftime("%Y-%m-%d") if ticket.scheduled_date else None,
                "location": ticket.location,
                "priority": ticket.priority,
                "category": ticket.category,
                "description": ticket.description,
                "odometer": ticket.odometer,
                "status": bool(ticket.status),
                "resolved_date": ticket.resolved_date.strftime("%Y-%m-%d") if ticket.resolved_date else None,
                "resolved_by": ticket.resolved_by,
            }
            for ticket in tickets
        ]

        return JsonResponse(data, safe=False)

    def post(self, request):
        try:
            data = json.loads(request.body)
            
            # Get the Device object if VRN exists
            device_details = Device.objects.filter(VRN=data.get('vrn')).first()

            # Optionally get last odometer reading
            last_entry = None
            if device_details:
                last_entry = DeviceData.objects.filter(device_id=device_details.device_id).order_by('-timestamp').first()

            ticket = MaintenanceTickets.objects.create(
                device=device_details,
                vrn=data.get('vrn'),
                device_specific_type=data.get('device_specific_type'),
                chassis_number=device_details.chassis_number if device_details else None,
                scheduled_date=datetime.strptime(data['scheduled_date'], "%Y-%m-%d").date() if data.get('scheduled_date') else None,
                location=data.get('location'),
                priority=data.get('priority'),
                category=data.get('category'),
                description=data.get('description'),
                odometer=data.get('odometer') if data.get('odometer') else (last_entry.odometer if last_entry else 0),
            )

            return JsonResponse({
                "id": ticket.id,
                "message": "Ticket created successfully"
            }, status=201)

        except (KeyError, json.JSONDecodeError) as e:
            return JsonResponse({"errordsfds": str(e)}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)

    def put(self, request):
        try:
            data = json.loads(request.body)
            ticket_id = data.get('id')
            if not ticket_id:
                return JsonResponse({'error': 'Ticket ID is required for update.'}, status=400)

            try:
                ticket = MaintenanceTickets.objects.get(id=ticket_id)
            except MaintenanceTickets.DoesNotExist:
                return JsonResponse({'error': 'Ticket not found.'}, status=404)

            # Update only the fields provided
            for field in [
                'vrn', 'device_specific_type', 'chassis_number', 'scheduled_date',
                'location', 'priority', 'category', 'description', 'odometer', 'status',
                'resolved_date', 'resolved_by'
            ]:
                if field in data:
                    # Convert dates from string to date object
                    if field in ['scheduled_date', 'resolved_date'] and data[field]:
                        setattr(ticket, field, datetime.strptime(data[field], "%Y-%m-%d").date())
                    elif field == 'status':
                        setattr(ticket, field, bool(data[field]))
                    else:
                        setattr(ticket, field, data[field])

            ticket.save()

            # Return updated ticket
            updated_ticket = {
                "id": ticket.id,
                "vrn": ticket.vrn,
                "device_specific_type": ticket.device_specific_type,
                "chassis_number": ticket.chassis_number,
                "scheduled_date": ticket.scheduled_date.strftime("%Y-%m-%d") if ticket.scheduled_date else None,
                "location": ticket.location,
                "priority": ticket.priority,
                "category": ticket.category,
                "description": ticket.description,
                "odometer": ticket.odometer,
                "status": bool(ticket.status),
                "resolved_date": ticket.resolved_date.strftime("%Y-%m-%d") if ticket.resolved_date else None,
                "resolved_by": ticket.resolved_by,
            }

            return JsonResponse(updated_ticket, status=200)

        except (KeyError, json.JSONDecodeError) as e:
            return JsonResponse({"error": str(e)}, status=400)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=500)


    
class SummaryReportView(APIView):

    def get(self, request):
        is_export = request.GET.get("is_export")
        fleet_name = request.GET.get("fleet_name")
        vehicle_type = request.GET.get("vehicle_type")
        username = request.GET.get("username")

        start_date = request.GET.get("start_date")
        end_date = request.GET.get("end_date")

        if start_date == "today":
            start_date = datetime.today().date()
            end_date = start_date
        elif start_date == "yesterday":
            start_date = (datetime.today() - timedelta(days=1)).date()
            end_date = start_date

        try:
            if start_date and isinstance(start_date, str):
                start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
            if end_date and isinstance(end_date, str):
                end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        except ValueError:
            return JsonResponse({"error": "Invalid date format. Use YYYY-MM-DD"}, status=400)
         
        if not username:
            return JsonResponse({"error": "Please provide username"}, status=400)

        if not start_date or not end_date:
            return JsonResponse({"error": "Please provide start_date and end_date"}, status=400)

        # Fetch reports in the date range
        reports = DailySummaryReport.objects.filter(date__range=[start_date, end_date])


        # Apply filters
        if fleet_name:
            reports = reports.filter(fleet=fleet_name)
        if vehicle_type:
            reports = reports.filter(vehicle_type=vehicle_type)
        user_devices = None  
        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            
            if user_assignment and user_assignment.devices:
                user_devices = user_assignment.devices
                reports = reports.filter(imei__in=user_devices) 
            else:
                # No devices assigned to this user
                reports = DailySummaryReport.objects.none()



        reports_dict = {r.imei: r for r in reports}

        # Fetch all devices
        devices = Device.objects.all()
        if fleet_name:
            devices = devices.filter(fleet=fleet_name)
        if vehicle_type:
            devices = devices.filter(device_type=vehicle_type)
        if username:
            devices = devices.filter(device_id__in=user_devices) 
        
        reported_imeis = set(reports_dict.keys())
        device_imeis = set(devices.values_list("device_id", flat=True))
        missing_imeis = device_imeis - reported_imeis
        old_report = DailySummaryReport.objects.filter(imei__in=missing_imeis, date__lt=start_date,end_odometer__isnull=False).order_by('imei', '-date').distinct('imei')
        old_report_dict = {r.imei: r for r in old_report}
        
        IST = pytz.timezone("Asia/Kolkata")
        now = timezone.now()
        now_ist = now.astimezone(IST)

        midnight = now.replace(hour=0,minute=0,second=0,microsecond=0)
        result = []
        for device in devices:
            if device.device_id in reports_dict:
                # Use serializer for existing report
                report = reports_dict[device.device_id]

                if any(
                    isinstance(getattr(report, f.name), float)
                    and (math.isnan(getattr(report, f.name)) or math.isinf(getattr(report, f.name)))
                    for f in report._meta.fields
                ):
                    continue
                result.append(DailySummaryReportSerializer(report).data)
            else:
                old = old_report_dict.get(device.device_id)
                # Build placeholder using device info
                placeholder = {
                    "imei": device.device_id,
                    "date": str(start_date),
                    "vrn": device.VRN or "-",
                    "vehicle_type": device.device_type or "-",
                    "vehicle_type_name": device.device_type_name or "-",
                    "chassis_number": device.chassis_number or "-",
                    "fleet": device.fleet or "-",
                    "city": device.city or "-",
                    # summary-specific fields  "-"
                    "start_time_of_day": "-",
                    "stop_time_of_day": "-",
                    "start_odometer":old.end_odometer if old else 0,
                    "end_odometer":old.end_odometer if old else 0,
                    "latitude": "-",
                    "longitude": "-",
                    "mode": "stopped",
                    "runtime_minutes": "0",
                    "idle_minutes": "0",
                    "charging_minutes": "0",
                    "stoppage_minutes": int((now_ist - midnight).total_seconds() // 60),
                    "distance": "0",
                    "average_speed": "0",
                    "no_of_movement_sessions": "-",
                    "no_of_charging_cycles": "-",
                    "no_of_idle_sessions": "-",
                    "start_soc":old.end_soc if old else 0,
                    "end_soc":old.end_soc if old else 0,
                    "energy_consumed": "0",
                    "regen_energy": "0",
                    "motor_ec": "0",
                    "dcdc_ec": "0",
                    "ecompressor_and_steering_ec": "0",
                    "bcs_ec": "0",
                    "tcs_ec": "0",
                    "energy_consumption": "0",
                    "charging_unit": "0",
                    "depth_of_discharge": "false",
                    "insufficient_charge": "false",
                    "battery_temperature": old.battery_temperature if old else 0,
                    "motor_temperature": old.motor_temperature if old else 0,
                    "co2_saving": "0",
                    "cost_saved": "0",
                    "sessions": "-"
                }
                result.append(placeholder)


        return Response({"data": result})

    
    
# class FaultsAPIView(APIView):
#     # permission_classes = [permissions.IsAuthenticated]

#     def get(self, request):
#         faults_qs = Fault.objects.all().order_by('-created_at')
#         is_export = request.GET.get("is_export", "false") == "true"

#         # Manual filtering
#         device_id = request.query_params.get('device', None)
#         device_type = request.query_params.get('device_type',None)
#         fault_code = request.query_params.get('fault_code', None)
#         date_from = request.query_params.get('start_date', None)
#         date_to = request.query_params.get('end_date', None)
#         is_report = request.query_params.get('report',None) == 'true'
#         username = request.query_params.get('username')

#         if not username:
#             return JsonResponse({"error": "username is required"}, status=400)
        
#         if username:
#             user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            
#             if user_assignment and user_assignment.devices:
#                 user_devices = user_assignment.devices 
#                 faults_qs = faults_qs.filter(device__in=user_devices)
                
#                 # Apply default date filter for today if no date filters are provided
#                 if not date_from and not date_to:
#                     from django.utils import timezone
#                     from datetime import datetime, time

#                     today = timezone.now().date()
#                     start_of_day = timezone.make_aware(datetime.combine(today, time.min))
#                     end_of_day = timezone.make_aware(datetime.combine(today, time.max))

#                     faults_qs = faults_qs.filter(created_at__range=(start_of_day, end_of_day))
#             else:
#                 faults_qs = Fault.objects.none()

#         if device_id:
#             faults_qs = faults_qs.filter(device__iexact=device_id)  # device is a CharField

#         if device_type:
#             # Get all IMEIs of devices of this type
#             device_ids = Device.objects.filter(
#                 device_type_name__iexact=device_type
#             ).values_list("device_id", flat=True)

#             # Match them against Fault.device
#             faults_qs = faults_qs.filter(device__in=device_ids)

#         if fault_code:
#             faults_qs = faults_qs.filter(rule__identifier__iexact=fault_code)

#         if date_from and date_to:
#             faults_qs = faults_qs.filter(created_at__date__range=[date_from, date_to])
#         elif date_from:
#             faults_qs = faults_qs.filter(created_at__date__gte=date_from)
#         elif date_to:
#             faults_qs = faults_qs.filter(created_at__date__lte=date_to)
#         if is_export:
#             serializer = FaultReportSerializer(faults_qs, many=True)
#             serialized_data = serializer.data

#             buffer = io.StringIO()
#             writer = csv.writer(buffer)

#             if serialized_data:
#                 # Write CSV header based on serializer keys
#                 writer.writerow(serialized_data[0].keys())
                
#                 # Write rows
#                 for row in serialized_data:
#                     writer.writerow(row.values())

#             buffer.seek(0)
#             response = HttpResponse(buffer, content_type="text/csv")
#             response["Content-Disposition"] = 'attachment; filename="fault_report.csv"'
#             return response

#         # serializer = FaultSerializer(faults_qs, many=True)
#         Serializer = FaultReportSerializer if is_report else FaultSerializer
#         return Response(Serializer(faults_qs, many=True).data, status=status.HTTP_200_OK)

class FaultsAPIView(APIView):

    def get(self, request):
        from django.utils import timezone
        from datetime import datetime, time
        device_id = request.GET.get('device_id')
        username = request.GET.get('username')
        component = request.GET.get('component')



        if not username:
            return JsonResponse({"error": "username is required"}, status=400)
        
        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            
            if user_assignment and user_assignment.devices:
                user_devices = user_assignment.devices 
                faults_qs = Fault.objects.filter(imei__in=user_devices)
                
                today = timezone.now().date()

                faults_qs = faults_qs.filter(start_time__date=today)
            else:
                faults_qs = Fault.objects.none()
        
        if device_id:
            faults_qs = Fault.objects.filter(device__device_id__icontains=device_id)

        if component:
            faults_qs = Fault.objects.filter(component__icontains=component)

        paginator = FaultPagination()
        paginated_result = paginator.paginate_queryset(faults_qs, request)

        serializer = FaultSerializer(paginated_result,many=True)
        return paginator.get_paginated_response(serializer.data)
    
    
class SummaryDataAPIView(APIView):
    def get(self,request):
        username = request.GET.get('username')
        period = request.GET.get('period')
        fleet = request.GET.get('fleet')
    
        if not username:
            return JsonResponse({"error": "username is required"}, status=400)
        
        today = datetime.today().date()
        if period == 'week':
            start_date = today - timedelta(days=today.weekday())  
            end_date = today

        elif period == 'month':
            start_date = today.replace(day=1)
            end_date = today

        elif period == 'today':
            start_date = today
            end_date = today

        else:
            return JsonResponse({"error": "Invalid period range"}, status=400)
        
        fields = [
            'date',
            'imei',
            'vehicle_type_name',
            'vehicle_type',
            'fleet',
            'city',
            'distance',
            'runtime_minutes',
            'energy_consumed',
            'motor_ec',
            'regen_energy',
            'co2_saving',
            'cost_saved',
        ]

        # Include 'mode' and 'sessions' only if period is 'today'
        if period == 'today':
            fields += ['mode', 'sessions']

        reports = DailySummaryReport.objects.filter(date__range=[start_date, end_date]).only(*fields)
        
        if username:
            user_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
            
            if user_assignment and user_assignment.devices:
                user_devices = user_assignment.devices
                reports = reports.filter(imei__in=user_devices) 
            else:
                # No devices assigned to this user
                reports = DailySummaryReport.objects.none()

        serializer = SummaryDataSerializer(reports, many=True, context={'period': period})
        return Response({"reports": serializer.data})
    
class ReportDataAPIView(APIView):
    
    def post(self, request):
        from devices.report_calculation import (daily_summary_report,
                                                charging_report,
                                                energy_consumpumtion_report,
                                                vehicle_status_report,
                                                alert_report,
                                                fault_report,
                                                export_excel)
        device_list = request.data.get("devices", [])
        start_date = request.data.get("start_date")
        end_date = request.data.get("end_date")
        report_type = request.data.get("report_type")
        is_export = request.data.get("is_export")

        
        if start_date == end_date:
            report_name = f"{report_type}_{start_date}"
        else:
            report_name = f"{report_type}_{start_date}_to_{end_date}"

        if not device_list or not isinstance(device_list, list):
            return Response({"error": "devices must be a list"}, status=400)

        if not start_date or not end_date:
            return Response({"error": "start_date and end_date required"}, status=400)
        
        # if report_type == "daily_summary_report":
        #     data = daily_summary_report(device_list, start_date, end_date)
        #     if is_export:
        #         return export_excel(data, report_name)
        #     return Response(data)

        # elif report_type == "charging_report":
        #     data = charging_report(device_list, start_date, end_date)
        #     if is_export:
        #         return export_excel(data, report_name)
        #     return Response(data)

        # elif report_type == "energy_consumption_report":
        #     data = energy_consumpumtion_report(device_list, start_date, end_date)
        #     if is_export:
        #         return export_excel(data, report_name)
        #     return Response(data)

        if not device_list or not isinstance(device_list, list):
            return Response({"error": "devices must be a list"}, status=400)

        if not start_date or not end_date:
            return Response({"error": "start_date and end_date required"}, status=400)
        
        if not report_type:
            return Response({"error": "Report type is required"}, status=400)
        
        if report_type == "daily_summary_report":
            data = daily_summary_report(device_list, start_date, end_date)
            if not data:
                return Response({"message": "No daily summary report data found."},status=status.HTTP_200_OK)
            if is_export:
                return export_excel(data, report_name)
            return Response(data)

        elif report_type == "charging_report":
            data = charging_report(device_list, start_date, end_date)
            if not data:
                return Response({"message": "No charging report data found."},status=status.HTTP_200_OK)
            if is_export:
                return export_excel(data, report_name)
            return Response(data)

        elif report_type == "energy_consumption_report":
            data = energy_consumpumtion_report(device_list, start_date, end_date)
            if not data:
                return Response({"message": "No energy consumption report data found."},status=status.HTTP_200_OK)
            if is_export:
                return export_excel(data, report_name)
            return Response(data)
        
        elif report_type == "vehicle_status_report":
            data = vehicle_status_report(device_list,start_date,end_date)
            if not data:
                return Response({"message": "No vehicle status report data found."},status=status.HTTP_200_OK)
            if is_export:
                return export_excel(data,report_name)
            return Response(data)
        
        elif report_type == "alert_report":
            data = alert_report(device_list,start_date,end_date)
            if not data:
                return Response({"message": "No alert report data found"},status=status.HTTP_200_OK)
            if is_export:
                return export_excel(data,report_name)
            return Response(data)
        
        elif report_type == "fault_report":
            paged = True
            data = fault_report(request,device_list,start_date,paged,end_date)
            if not data:
                return Response({"message": "No alert report data found"},status=status.HTTP_200_OK)
            if is_export:
                return export_excel(data,report_name)
            return data
        
        

class MmiDataAPIVIEW(APIView):
    def get(self, request):
        from django.core.cache import cache
        data = cache.get("buffer_data")
        return Response(data)
    
class ChargingPopUpAPIView(APIView):
    def post(self, request):
        username = request.data.get("username")
 
        if not username:
            return Response({"error": "username is required"}, status=400)
 
        try:
            user_device_assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
 
            if not user_device_assignment:
                return Response(
                    {"error": " User not exist or No devices assigned to user"},
                    status=404,
                )
 
            assigned_devices = set(user_device_assignment.devices)
            # print(assigned_devices)
 
            cities = [
                "Chhatrapati Sambhajinagar",
                "Mumbai",
                "Nagpur",
                "Pune",
                "Prithampur",
            ]
 
            devices = list(
                Device.objects.filter(city__in=cities).values_list(
                    "device_id", flat=True
                )
            )
 
            mh_mp_vehicle_list = [
                device_id for device_id in devices if device_id in assigned_devices
            ]
            # print(mh_mp_vehicle_list)
 
            daily_summary_report = DailySummaryReport.objects.filter(
                imei__in=mh_mp_vehicle_list
            )
 
            # following code will return all the values for that imei
            # charging_devices = daily_summary_report.filter(mode="Charging")
 
            now = datetime.now()
 
            # following code will only return imei
            charging_devices = daily_summary_report.filter(
                date=now.date(), mode="Charging"
            ).values_list("imei", "end_soc")
 
            columns = ["imei", "soc"]
            response = []
            for imei in charging_devices:
                row_dict = dict(zip(columns, imei))
                response.append(row_dict)
 
            # print(response)
            # print(now.hour)
            if now.hour < 9 or now.hour > 16:
                # only return DEVICE IDs apart of 9 AM and 5 PM charging sessions
                return Response(
                    {
                        "charging_devices": list(response),
                        "message": "Dear user, if you charge your vehicle between 9.00 AM - 5.00 PM, you will get a rebate of ₹1.3 (As per MSEDCL Bill) or ₹1.5 (As per MPEB Bill) per unit of the electricity consumed.",
                    },
                    status=status.HTTP_200_OK,
                )
 
            return Response(
                {
                    "charging_devices": list(response),
                    "message": "CHARGING_AWARNESS_HOURS",
                },
                status=status.HTTP_200_OK,
            )
        except:
            pass



class DmsAPIView(APIView):
    # permission_classes=[IsAuthenticated]
    # throttle_classes=[SubscriptionRateThrottle]
    def get(self, request):
        try:
            # Extract query parameters
            device_id = request.GET.get("device_id")
            chassis_number = request.GET.get("chassis_number")
            vrn = request.GET.get("vrn")
            vehicle_type = request.GET.get("vehicle_type")
            fleet = request.GET.get("fleet")

            # Base queryset
            devices_qs = (
                Device.objects.annotate(device_id_length=Length("device_id")).filter(
                    device_id_length=15
                )
                .exclude(
                    Q(fleet="HIL_LAB") | Q(device_type_name="5T")
                )
                .order_by("fleet", "device_id")
            )

            # Apply filters dynamically
            filters = {}

            if device_id:
                filters["device_id"] = device_id

            if vehicle_type:
                filters["device_type_name"] = vehicle_type

            if chassis_number:
                filters["chassis_number"] = chassis_number

            if vrn:
                filters["VRN"] = vrn

            if fleet:
                filters["fleet"] = fleet

            if filters:
                devices_qs = devices_qs.filter(**filters)

            # Check if data exists
            if not devices_qs.exists():
                return Response(
                    {
                        "message": "No devices found matching the provided filters.",
                        "filters_applied": filters,
                    },
                    status=status.HTTP_404_NOT_FOUND,
                )

            # Fetch required fields
            device_values = devices_qs.values_list(
                "fleet", "device_type_name", "device_id", "chassis_number", "VRN"
            )

            device_ids = [row[2] for row in device_values]

            # Fetch LiveData efficiently
            live_data_qs = LiveData.objects.filter(imei__in=device_ids).values_list(
                "imei", "odometer", "last_timestamp"
            )

            odo_dict = {
                imei: (odometer, last_timestamp)
                for imei, odometer, last_timestamp in live_data_qs
            }

            # Timezone setup
            ist = pytz.timezone("Asia/Kolkata")

            # Prepare response
            response_data = []

            for fleet_val, vehicle_type_val, dev_id, chassis, vrn_val in device_values:
                odometer, last_timestamp = odo_dict.get(dev_id, (None, None))

                # Format timestamp
                formatted_timestamp = None
                if last_timestamp:
                    if timezone.is_naive(last_timestamp):
                        last_timestamp = timezone.make_aware(last_timestamp)

                    formatted_timestamp = last_timestamp.astimezone(ist).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                # descriptive text
                description_text = None
                vehicle_type_name = None
                if vehicle_type_val == "3S":
                    description_text = "Three Seater"
                elif vehicle_type_val == "6S":
                    description_text = "Six Seater"
                elif vehicle_type_val in ["12M", "9M"]:
                    if vehicle_type_val == "12M":
                        vehicle_type_name = "12 Meter"
                    elif vehicle_type_val == "9M":
                        vehicle_type_name = "9 Meter"
                elif vehicle_type_val in ("12.35M", "13.5M"):
                    vehicle_type_name = "Coach"
                elif vehicle_type_val == "55T":
                    description_text = "Truck"

                value = str(fleet_val)
                if value.endswith("NAC"):
                    text = "NAC"
                elif value.endswith("AC") or fleet_val in ("Africa_Export"):
                    text = "AC"
                else:
                    text = None

                description_text = (
                    f"{vehicle_type_name}{' ' + text if text else ''} Bus"
                )

                response_data.append(
                    {
                        "fleet": fleet_val,
                        "vehicle_type": vehicle_type_val,
                        "vehicle_description": description_text,
                        "device_id": dev_id,
                        "chassis_number": chassis,
                        "vrn": vrn_val,
                        "odometer": round(float(odometer), 2) if odometer else 0,
                        "last_timestamp": formatted_timestamp,
                    }
                )

            # Success response
            return Response(
                {
                    "message": "Devices fetched successfully.",
                    "count": len(response_data),
                    "data": response_data,
                },
                status=status.HTTP_200_OK,
            )

        # Exception handling
        except ValueError as ve:
            return Response(
                {
                    "error": "Invalid data format.",
                    "details": str(ve),
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        except Exception as e:
            return Response(
                {
                    "error": "An unexpected error occurred while fetching devices.",
                    "details": str(e),
                },
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
