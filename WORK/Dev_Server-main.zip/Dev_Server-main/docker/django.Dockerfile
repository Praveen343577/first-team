# Use official Python image
FROM python:3.11-slim

LABEL version="0.0.1"

RUN rm /etc/apt/apt.conf.d/docker-clean

ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONFAULTHANDLER=1
ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1
ENV DJANGO_SETTINGS_MODULE=ekaConnect.settings
ENV PYTHONPATH=/app

RUN --mount=type=cache,target=/var/cache/apt,id=apt apt-get update && apt-get -y upgrade

WORKDIR /app

RUN apt-get update && apt-get install -y \
    build-essential \
    libpq-dev \
    curl \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .

RUN pip install --upgrade pip && pip install -r requirements.txt

COPY . /app/

RUN python manage.py collectstatic --noinput

EXPOSE 8000

CMD ["daphne", "-b", "0.0.0.0", "-p", "8000", "ekaConnect.asgi:application"]
