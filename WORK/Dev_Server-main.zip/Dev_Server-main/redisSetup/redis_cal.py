from devices.models import DeviceTotalCalculationData
import numpy as np
import re
import pandas as pd
from datetime import datetime, timedelta
from django.utils import timezone
from django.utils.timezone import make_aware, is_naive
from datetime import datetime
from django.utils.timezone import now
import pytz
from pytz import timezone,utc
from django.utils import timezone as dj_timezone
from redisSetup.data_parsing_functions import get_device_details
from devices.models import DailySummaryReport



def safe_float(v):
    try:
        if v in ("N", None, "", "nan"):
            return float("nan")
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def r_initialize_metrics(variant, odometer):

    odometer = safe_float(odometer)

    if np.isnan(odometer) or odometer == 0:
        return {}, False

    electric_ecr = {
        '7M': 0.8,'9M': 1,'12M': 1.3,'13.5M': 1.4,'55T': 1.4,'1.5t':0.35,'3w_6s': 0.08, '5T': 0.35,
    }

    diesel_mileage = {
        '7M': 8,'9M': 4,'12M': 4,'13.5M': 3.5,'55T': 2.5,'1.5t': 6,'3w_6s': 25, '5T': 10,
    }

    battery_capacity_kwh = {
        '7M':100,'9M':200,'12M':300,'13.5M':451,'55T':423,'1.5t':32,'3w_6s':15, '5T':35,
    }

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    liters_per_km = 1 / diesel_mileage[variant]

    co2_saved = (
        liters_per_km * EMISSION_FACTOR_DIESEL
        - electric_ecr[variant] * GRID_CO2_INTENSITY
    )

    cost_saved = (
        liters_per_km * diesel_price
        - electric_ecr[variant] * electricity_price
    )

    factor = electric_ecr.get(variant, 1)

    traction_energy = factor * odometer
    regen_energy = traction_energy * 0.3
    energy_consumption = traction_energy - regen_energy
    charging_units = factor * odometer * 1.1

    runtime = odometer / 30
    idle = runtime * 0.15

    battery_capacity = battery_capacity_kwh.get(variant, 100)
    charging_count = round(charging_units / battery_capacity)

    return {
        "total_distance": odometer,
        "co2_saving": co2_saved * odometer,
        "energy_consumption": energy_consumption,
        "run_time": runtime,
        "traction_energy": traction_energy,
        "regen_energy": regen_energy,
        "idle_time": idle,
        "charging_unit": charging_units,
        "charging_count": charging_count,
        "cost_saved": cost_saved * odometer,
        "last_charging_state": False,
        "last_charging_state_time": None,
        "last_soc": None,
        "db_created": False,
        "db_id": None
    }, True

######## 3w #############
def r_total_calculations_3w(device_data, device_id, odometer, variant, total_data):

    if not device_data:
        return total_data, False

    try:
        odometer = float(odometer)
    except (TypeError, ValueError):
        return total_data, False

    if odometer == 0:
        return total_data, False

    diesel_mileage = {'3w_6s': 25}
    electric_ecr = {'3w_6s': 0.08}

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    liters_per_km = 1 / diesel_mileage[variant]

    co2_saved = (
        liters_per_km * EMISSION_FACTOR_DIESEL
        - electric_ecr[variant] * GRID_CO2_INTENSITY
    )

    cost_saved = (
        liters_per_km * diesel_price
        - electric_ecr[variant] * electricity_price
    )

    total_data["total_distance"] = odometer
    total_data["co2_saving"] = co2_saved * odometer
    total_data["cost_saved"] = cost_saved * odometer

    # ---------- Charging Detection ----------
    charger_vol = device_data.get("Charger_Output_VOL")
    charger_cur = device_data.get("Charger_Output_CUR")

    try:
        charger_vol = float(charger_vol)
    except:
        charger_vol = None

    try:
        charger_cur = float(charger_cur)
    except:
        charger_cur = None

    is_charging = not (charger_vol is None and charger_cur is None)

    # ---------- Timestamp ----------
    current_time = pd.to_datetime(
        device_data.get("timestamp"),
        errors="coerce",
        utc=True
    )

    # ---------- SOC ----------
    try:
        current_soc = float(device_data.get("SOC"))
    except:
        current_soc = None

    last_state = total_data.get("last_charging_state", False)
    last_time = total_data.get("last_charging_state_time")
    last_soc = total_data.get("last_soc")

    if isinstance(last_time, str):
        last_time = pd.to_datetime(last_time, utc=True)

    TIME_GAP_THRESHOLD = 600
    SOC_JUMP_THRESHOLD = 5

    time_diff = None
    if last_time is not None and current_time is not None:
        time_diff = (current_time - last_time).total_seconds()

    if last_time is None:

        if is_charging:
            total_data["charging_count"] += 1
            total_data["last_charging_state_time"] = current_time.isoformat()

        total_data["last_charging_state"] = is_charging

    else:

        if last_state != is_charging:

            if not last_state and is_charging:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1

                total_data["last_charging_state_time"] = current_time.isoformat()

            total_data["last_charging_state"] = is_charging

        # SOC jump detection
        if (
            not is_charging
            and current_soc is not None
            and last_soc is not None
        ):
            if current_soc - last_soc > SOC_JUMP_THRESHOLD:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1
                    total_data["last_charging_state"] = True
                    total_data["last_charging_state_time"] = current_time.isoformat()

    total_data["last_soc"] = current_soc

    # ---------- Energy ----------
    try:
        voltage = float(device_data.get("BatteryVoltage"))
        current = float(device_data.get("BatteryCurrent"))
    except:
        return total_data, False

    energy_kwh = ((voltage / 10000) * (current / 1000) * 10) / (1000 * 3600)

    if is_charging:
        total_data["charging_unit"] += energy_kwh
    else:

        total_data["energy_consumption"] += abs(energy_kwh)

        if energy_kwh > 0:
            total_data["regen_energy"] += energy_kwh
        else:
            total_data["traction_energy"] += abs(energy_kwh)

    # ---------- Speed ----------
    try:
        speed = float(device_data.get("MCU_Speed_Kmph"))
    except:
        speed = None

    if speed is not None:

        if speed > 5:
            total_data["run_time"] += 10 / 3600
        else:
            total_data["idle_time"] += 10 / 3600

    print(f"Updated totals for {device_id}")

    return total_data, True
    

############# 4 Wheeler ##################
 
def r_total_calculations(device_data, device_id, variant, odometer, total_data):

    if not device_data:
        return total_data, False

    try:
        odometer = float(odometer)
    except (TypeError, ValueError):
        return total_data, False

    if odometer == 0:
        return total_data, False

    diesel_mileage = {
        '9M':4,'12M':4,'7M':8,'13.5M':3.5,'55T':2.5,'1.5t':6,'5T':10
    }

    electric_ecr = {
        '9M':1,'12M':1.3,'7M':0.8,'13.5M':1.4,'55T':1.4,'1.5t':0.35,'5T':0.35
    }

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    liters_per_km = 1 / diesel_mileage[variant]

    co2_saved = (
        liters_per_km * EMISSION_FACTOR_DIESEL
        - electric_ecr[variant] * GRID_CO2_INTENSITY
    )

    cost_saved = (
        liters_per_km * diesel_price
        - electric_ecr[variant] * electricity_price
    )

    total_data["total_distance"] = odometer
    total_data["co2_saving"] = co2_saved * odometer
    total_data["cost_saved"] = cost_saved * odometer

    # ---------- VCU FLAG ----------
    try:
        vcu_flag = int(device_data.get("VCU_Flag"))
    except:
        return total_data, False

    is_charging = vcu_flag == 92

    # ---------- Runtime / Idle ----------
    if vcu_flag in (50,51,52,60):
        total_data["run_time"] += 10/3600

    if vcu_flag in (13,70):
        total_data["idle_time"] += 10/3600

    # ---------- Charging Logic ----------
    TIME_GAP_THRESHOLD = 600
    SOC_JUMP_THRESHOLD = 5

    current_time = pd.to_datetime(
        device_data.get("timestamp"),
        errors="coerce",
        utc=True
    )

    current_soc = device_data.get("SOC")

    try:
        current_soc = float(current_soc)
    except:
        current_soc = None

    last_state = total_data.get("last_charging_state", False)
    last_time = total_data.get("last_charging_state_time")
    last_soc = total_data.get("last_soc")

    if isinstance(last_time, str):
        last_time = pd.to_datetime(last_time, utc=True)

    time_diff = None
    if last_time is not None and current_time is not None:
        time_diff = (current_time - last_time).total_seconds()

    if last_time is None:

        if is_charging:
            total_data["charging_count"] += 1
            total_data["last_charging_state_time"] = current_time.isoformat()

        total_data["last_charging_state"] = is_charging

    else:

        if last_state != is_charging:

            if not last_state and is_charging:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1

                total_data["last_charging_state_time"] = current_time.isoformat()

            total_data["last_charging_state"] = is_charging

        # ---------- SOC Jump Detection ----------
        if (
            not is_charging
            and current_soc is not None
            and last_soc is not None
        ):
            if current_soc - last_soc > SOC_JUMP_THRESHOLD:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1
                    total_data["last_charging_state"] = True
                    total_data["last_charging_state_time"] = current_time.isoformat()

    total_data["last_soc"] = current_soc

    # ---------- Packs ----------
    active_packs = {
        '12M':['A','B','C'],
        '9M':['A','B'],
        '7M':['A'],
        '55T':['A'],
        '13.5M':['A']
    }.get(variant, ['A'])

    kwh_total = 0
    regen = 0
    traction = 0
    charging_units = 0

    for pack in active_packs:

        v = device_data.get(f"{pack}_Pack_Voltage_Value")
        c = device_data.get(f"{pack}_Pack_Current_Value")

        try:
            v = float(v)
            c = float(c)
        except:
            continue

        energy = (v * c * 10) / (1000 * 3600)

        if is_charging:
            charging_units += energy
        else:
            kwh_total += energy

            if energy > 0:
                regen += energy
            else:
                traction += energy

    total_data["traction_energy"] += abs(traction)
    total_data["regen_energy"] += regen
    total_data["charging_unit"] += charging_units
    total_data["energy_consumption"] += abs(kwh_total)

    print(f"Updated totals for {device_id}")

    return total_data, True
 
##########################################################################################################################################################################################################


##### For summary calculations #####


IST = dj_timezone.get_fixed_timezone(330)


def make_aware_ist(dt):
    if not dt:
        return None

    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)  # 2025-12-27T10:44:40.153617

    if dj_timezone.is_naive(dt):
        dt = dj_timezone.make_aware(dt, dj_timezone.utc)

    return dj_timezone.localtime(dt, IST)


def get_local_date_from_utc_timestamp(utc_timestamp):
    ist_dt = make_aware_ist(utc_timestamp)
    if not ist_dt:
        return None
    return ist_dt.date()


def r_live_daily_report_4w_calculation(device_details, device_id, variant, end_lat, end_long,timestamp,can_data,daily_report):


    report_date = get_local_date_from_utc_timestamp(
        can_data.get("timestamp") or timestamp
    )

    if not report_date:
        return daily_report,False
    


    today_ist = dj_timezone.localtime(dj_timezone.now(), IST).date()

    # For MMI – only today’s data
    if report_date != today_ist:
        print("Date in can_data is not current date")
        return daily_report,False
    

    if daily_report and daily_report.get("date") != report_date.isoformat():
        daily_report = {}


    
    # Handle empty state
    if not daily_report:

        daily_report = {
            "date": report_date.isoformat(),
            "imei": device_id,
            "vrn": device_details.get("VRN") if device_details else None,
            "vehicle_type": device_details.get("device_type") if device_details else None,
            "vehicle_type_name": device_details.get("device_type_name") if device_details else None,
            "chassis_number": device_details.get("chassis_number") if device_details else None,
            "fleet": device_details.get("fleet") if device_details else None,
            "city": device_details.get("city") if device_details else None,
            "latitude": end_lat,
            "longitude": end_long,
            "start_time_of_day": None,
            "runtime_minutes":0,
            "idle_minutes":0,
            "charging_minutes":0,
            "stoppage_minutes":0,
            "start_odometer":None,
            "end_odometer":None,
            "distance":0,
            "average_speed":0,
            "no_of_movement_sessions":0,
            "no_of_charging_cycles":0,
            "no_of_idle_sessions":0,
            "start_soc":None,
            "end_soc":None,
            "energy_consumed":0,
            "regen_energy":0,
            "motor_ec":0,
            "dcdc_ec":0,
            "ecompressor_and_steering_ec":0,
            "bcs_ec":0,
            "tcs_ec":0,
            "energy_consumption":0,
            "charging_unit":0,
            "depth_of_discharge":0,
            "insufficient_charge":0,
            "battery_temperature":None,     
            "motor_temperature":None,
            "mode":None,
            "sessions": [],
            "db_created": False

        }

    # Handle empty CAN data
    if not can_data:
        daily_report["latitude"] = end_lat
        daily_report["longitude"] = end_long
        daily_report["stop_time_of_day"] = make_aware_ist(datetime.now()).isoformat()

        return daily_report,True # Exit if no CAN data
    

    # Create DataFrame
    # df = pd.DataFrame([device_data.can_data]) 
    # df.replace('N', np.nan, inplace=True)
    # df = df.apply(pd.to_numeric, errors='coerce').fillna(0)

    df = pd.DataFrame([can_data])

    # Vectorized: convert 'N' to NaN
    df = df.where(df != 'N', np.nan)
    df = df.apply(pd.to_numeric, errors='coerce')

    # Return early if VCU_Flag is missing
    if 'VCU_Flag' not in df.columns:
        return daily_report,False
    
    # Return early if ignition is ON and VCU_Flag is null
    if 'Ignition_Sense' in df.columns:
        if df.at[0, 'Ignition_Sense'] == 1 and pd.isna(df.at[0, 'VCU_Flag']):
            return daily_report,False

    # Fill remaining NaNs with 0
    df.fillna(0, inplace=True)
    
    if df.empty:
        return daily_report,False

    # Variant-specific signals
    signal_mapping_variant_wise = {
        "7M": ["A"],
        "9M": ["A", "B"],
        "12M": ["A", "B", "C"],
        "13.5M": ["A"],
        "55T": ["A"],
        "1.5t": ["A"],
        "5T": ["A"]
    }
    soc_cols = ["A_SOC_Value", "B_SOC_Value", "C_SOC_Value"]
    packs_config = ["A", "B", "C"]

    applicable_signals = signal_mapping_variant_wise.get(variant, [])
    if not applicable_signals:
        raise ValueError(f"Unsupported variant: {variant}")

    soc_columns = [col for col in soc_cols if col.split("_")[0] in applicable_signals]
    packs = [col for col in packs_config if col in applicable_signals]

    # Get or create daily report
    # daily_report, created = DailySummaryReport.objects.get_or_create(
    #     imei=device_id, date=report_date
    # )
    # if created:
    #     device = Device.objects.get(device_id=device_id)
    #     daily_report.vrn = device.VRN
    #     daily_report.vehicle_type = device.device_type
    #     daily_report.vehicle_type_name = device.device_type_name
    #     daily_report.chassis_number = device.chassis_number
    #     daily_report.fleet = device.fleet
    #     daily_report.city = device.city



    last_stop_time = daily_report.get("stop_time_of_day")
    if last_stop_time:
        last_stop_time = datetime.fromisoformat(last_stop_time)

    current_timestamp = timestamp

    if daily_report.get("start_time_of_day") is None:
        daily_report["start_time_of_day"] = current_timestamp.isoformat()


    # Handle first entry case
    if last_stop_time is None:
        time_diff_seconds = 0
    else:
        last_stop_time = last_stop_time
        time_diff_seconds = max((current_timestamp - last_stop_time).total_seconds(), 0)
        print("Time Difference:", time_diff_seconds)
        if time_diff_seconds < 1:
            print("Skipping! Time difference is less than 1 second")
            return daily_report,False

    # Mode detection
    charging_mask = df["VCU_Flag"].isin([89, 90, 91, 92])
    not_charging_mask = ~charging_mask

    df["Mode"] = "Unknown"
    ignition_on_mask = df["Ignition_Sense"] == 1
    ignition_off_mask = ~ignition_on_mask

    # Charging/Movement/Idle only if Ignition is on
    df.loc[ignition_on_mask & df["VCU_Flag"].isin([89, 90, 91, 92]), "Mode"] = "Charging"
    df.loc[ignition_on_mask & not_charging_mask & df["VCU_Flag"].isin([50, 51, 52, 60]), "Mode"] = "Movement"
    #vcuflag != 0
    df.loc[ignition_on_mask & not_charging_mask & df["VCU_Flag"].notna() & (df["VCU_Flag"] != 0) & ((df["VCU_Flag"] < 50) | (df["VCU_Flag"] == 70)), "Mode"] = "Idle"

    # If Ignition is off, set Stopped
    df.loc[ignition_off_mask, "Mode"] = "Stopped"
    # df.loc[~df["Mode"].isin(["Charging", "Movement", "Idle"]), "Mode"] = "Stopped"


    default_odo = DailySummaryReport.objects.filter(imei=device_id,end_odometer__gt=0).exclude(date=report_date).order_by('-date').values_list('end_odometer', flat=True).first() or 0

    # SOC and odometer
    df["SOC"] = df[soc_columns].mean(axis=1)
    
    # odoometer checks for the jumps
    last_odometer = daily_report.get("end_odometer") or default_odo
    # jumps > 200 km within 6 hours (~21600 seconds) are ignored
    JUMP_THRESHOLD = 200
    TIME_THRESHOLD_SECONDS = 6 * 3600

    #first_entry = last_stop_time is None or time_diff_seconds == 0
    first_entry = daily_report.get("end_odometer") is None 

    # Try ODOMETER_CRUT first
    odom_crut = float(df.at[0, "ODOMETER_CRUT"]) if "ODOMETER_CRUT" in df.columns else None
    odom = float(df.at[0, "ODOMETER"]) if "ODOMETER" in df.columns else None

    def valid_odom_check(odom_value):
        if odom_value is None or odom_value <= 0:
            return False
        if first_entry:
            return True
        return not (time_diff_seconds < TIME_THRESHOLD_SECONDS and abs(odom_value - last_odometer) > JUMP_THRESHOLD)

    if odom_crut is not None and valid_odom_check(odom_crut):
        current_odometer = odom_crut
    elif odom is not None and valid_odom_check(odom) and odom > last_odometer:
        current_odometer = odom
    else:
        current_odometer = last_odometer




    # Current SOC and mode
    current_soc = df.at[0, "SOC"]
    current_mode = df.at[0, "Mode"]
    prev_mode = daily_report.get("mode") or "Unknown"

    
    # Initialize start values if not set
    if daily_report.get("start_odometer") is None or daily_report.get("start_odometer") == 0:
        daily_report["start_odometer"] = round(current_odometer if current_odometer > 0 else default_odo, 2)


    prev_soc = DailySummaryReport.objects.filter(imei=device_id,end_soc__gt=0).exclude(date=report_date).order_by('-date').values_list('end_soc', flat=True).first() or 0
    if daily_report.get("start_soc") is None or daily_report.get("start_soc") == 0:
        if current_soc is not None and current_soc > 0:
            daily_report["start_soc" ]= current_soc
        else:
            daily_report["start_soc" ]= prev_soc

        

    # Previous end odometer (fallback)
    prev_end_odometer = round(daily_report.get("end_odometer") or current_odometer,2)

    # Calculate incremental distance
    distance_km = max(current_odometer - prev_end_odometer, 0)

    # Update end_odometer only if current_odometer is valid (>0)
    if current_odometer > 0:
        daily_report["end_odometer"] = round(current_odometer, 2)
    elif daily_report.get("end_odometer") is None:
        daily_report["end_odometer" ]= round(default_odo, 2)

    # Always update SOC
    if current_soc is not None and current_soc > 0:
        daily_report["end_soc"] = current_soc
    else:
        daily_report["end_soc"] = daily_report.get("end_soc") or prev_soc

    #Latitude and Longitude
    current_lat = end_lat
    current_long = end_long


    # Energy per pack
    for p in packs:
        df[f"{p}_kWh"] = df[f"{p}_Pack_Voltage_Value"] * df[f"{p}_Pack_Current_Value"] * time_diff_seconds /(3600*1000)

    ec = sum(df.loc[not_charging_mask & (df[f"{p}_kWh"] < 0), f"{p}_kWh"].sum() for p in packs)
    total_ec = (daily_report.get("energy_consumed") or 0) + (-ec)
    regen = sum(df.loc[not_charging_mask & (df[f"{p}_kWh"] > 0), f"{p}_kWh"].sum() for p in packs)
    total_regen = (daily_report.get("regen_energy") or 0) + regen
    ecr_distance = (daily_report.get("distance") or 0) + distance_km
    ecr = (total_ec - total_regen) / ecr_distance if ecr_distance else 0

    # Max temperatures
    battery_temp_cols = [f"{p}_Max_Cell_Temp" for p in packs if f"{p}_Max_Cell_Temp" in df.columns]
    df["Battery_Temp"] = df[battery_temp_cols].max(axis=1)
    max_battery_temp = max(daily_report.get("battery_temperature") or 0, round(df["Battery_Temp"].max(), 2))

    #For sessions battery temp
    session_battery_temp = round(df["Battery_Temp"].max(), 2)
    max_motor_temperature = max(daily_report.get("motor_temperature") or 0, round(df["Motor_Temperature"].max(), 2))
    session_motor_temp = round(df["Motor_Temperature"].max(), 2)

    # Charging units
    charging_units = sum(
        df.at[0, f"{p}_Pack_Voltage_Value"] * df.at[0, f"{p}_Pack_Current_Value"] * time_diff_seconds / ( 3600*1000)
        for p in packs if charging_mask.iloc[0]
    )

    # MCU, DCDC, TCS, BCS, ECompressor
    mcu_energy = df.at[0, "MCU_HighPowerVoltage"] * df.at[0, "MCU_HighPowerCurrent"] * time_diff_seconds / ( 3600*1000)
    kwh_dcdc = df.at[0, "DCDC_Input_Voltage"] * df.at[0, "DCDC_Input_Current"] * time_diff_seconds / ( 3600*1000)
    kwh_bcs = df.at[0, "T2B_HV_Voltage_Input"] * df.at[0, "T2B_HV_Current_Input"] * time_diff_seconds / ( 3600*1000)
    kwh_tcs = df.at[0, "TCS_Energy"] * time_diff_seconds / ( 3600*1000)
    kwh_ecompressor = (df.at[0, "ECompressor_Input_Power"] + df.at[0, "Streering_Input_Power"]) * time_diff_seconds / ( 3600*1000)

    # Minutes
    runtime_minutes = idle_minutes = charging_minutes = stoppage_minutes = 0
    current_minutes = current_timestamp.hour * 60 + current_timestamp.minute + current_timestamp.second / 60
    if current_mode.lower() == "movement":
        runtime_minutes += time_diff_seconds / 60
    elif current_mode.lower() == "idle":
        idle_minutes += time_diff_seconds / 60
    elif current_mode.lower() == "charging":
        charging_minutes += time_diff_seconds / 60
    else:
        stoppage_minutes += time_diff_seconds / 60

    prev_distance = daily_report.get("distance") or 0
    prev_runtime = daily_report.get("runtime_minutes") or 0
    # prev_avg_speed = daily_report.get("average_speed") or 0
    total_runtime_minutes = prev_runtime + runtime_minutes

    if daily_report.get("start_odometer") is None:
        total_distance = 0
    elif daily_report.get("start_odometer") and daily_report.get("start_odometer")<=current_odometer:
        total_distance = current_odometer - daily_report.get("start_odometer")
    else:
        total_distance = daily_report.get("distance") if daily_report.get("distance") else 0

    average_speed = (total_distance / (total_runtime_minutes / 60) if total_runtime_minutes > 0 else 0)
    # max speed session wise
    session_current_speed = df["WheelBasedVehicleSpeed_Rx"].iloc[-1]

    diesel_mileage = {
        '9M': 4,
        '12M': 4,
        '7M': 8,
        '13.5M': 3.5,
        '55T': 2.5,
        '1.5t': 6,
        '5T': 10
    }
 
    electric_ecr = {
        '9M': 1,
        '12M': 1.3,
        '7M': 0.8,
        '13.5M': 1.4,
        '55T': 1.4,
        '1.5t':0.35,
        '5T': 0.35
    }
 
    EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
    GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh
    diesel_price = 90               # ₹ per litre
    electricity_price = 8           # ₹ per kWh
 
    # Fuel/CO2 savings (only for this variant)
    liters_per_km = 1 / diesel_mileage[variant]
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price
 
    ecr_variant = electric_ecr[variant]
    co2_electric = ecr_variant * GRID_CO2_INTENSITY
    cost_electric = ecr_variant * electricity_price
 
    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric

    if total_distance:
        daily_report["co2_saving"] = co2_saved * total_distance
        daily_report["cost_saved" ]= cost_saved * total_distance

    # Insufficient charge & DOD
    charging_ended = prev_mode.lower() == "charging" and current_mode.lower() != "charging"
    if charging_ended:
        last_soc = current_soc if pd.notnull(current_soc) else daily_report.get("end_soc")

        insufficient_charge = 1 if (last_soc is not None and last_soc <= 90) else 0

        dod = 1 if (last_soc is not None and last_soc < 20) else 0
    else:
        insufficient_charge = daily_report.get("insufficient_charge", 0)
        dod = daily_report.get("depth_of_discharge", 0)

    # Sessions
    if not daily_report.get("sessions"):
        daily_report["sessions"] = []

    def make_session_serializable(session):
        # Convert datetime objects to ISO strings
        # for key in ["start_time_val", "end_time_val"]:
        #     if isinstance(session.get(key), datetime):
        #         session[key] = make_aware_ist(session[key]).isoformat()
        # Convert numpy numbers to native Python types
        for key, value in session.items():
            if isinstance(value, (np.integer, np.int64, np.int32)):
                session[key] = int(value)
            elif isinstance(value, (np.floating, np.float64, np.float32)):
                session[key] = float(value)
        return session

    def update_last_session(session, current_timestamp, current_odometer, current_soc, ec, regen, ecr,
                            charging_units,session_current_speed,session_battery_temp,current_lat,current_long):
        # Convert datetime and numpy values immediately
        session["end_time_val"] = make_aware_ist(current_timestamp).isoformat()
        if not session.get("start_odo_val") or session["start_odo_val"] == 0:
            session["start_odo_val"] = round(float(current_odometer), 2)
        session["end_odo_val"] = round(float(current_odometer), 2)
        if not session.get("start_soc_val") or session["start_soc_val"] == 0:
            session["start_soc_val"] = float(current_soc)
        session["end_soc_val"] = float(current_soc)
        session["duration"] = (datetime.fromisoformat(session["end_time_val"]) - datetime.fromisoformat(session["start_time_val"])).total_seconds() / 60
        session["end_latitude"] = current_lat
        session["end_longitude"] = current_long
        session["battery_temperature"] = max(session["battery_temperature"],session_battery_temp)
        if "session_ec" in session:
            session["session_ec"] += float(ec)
        if "distance" in session:
            session["distance"] = max(session["end_odo_val"] - session["start_odo_val"], 0)
            session["session_regen"] += float(regen)
            session["session_ecr"] = (-(session["session_ec"]) + session["session_regen"]) / session["distance"] if session["distance"] else 0
            session["session_traction"] += 0 if mcu_energy < 0 else mcu_energy
            session["max_speed"] = max(session["max_speed"],session_current_speed)
            if "motor_temperature" in session:
                session["motor_temperature"] = max(session["motor_temperature"],session_motor_temp)
        if "deep_discharge" in session and session["deep_discharge"] != 1:
            session["deep_discharge"] = 1 if current_soc < 20 else 0
        if "charging_units" in session:
            session["charging_units"] += charging_units


    start_odo_val = current_odometer if current_odometer and current_odometer > 0 else daily_report.get("start_odometer") or 0
    # Creating a new session
    if prev_mode is None or prev_mode.lower() != current_mode.lower():
        #assignment    
        allow_new_session = False
        if daily_report.get("sessions"):
            sessions = daily_report.setdefault("sessions", [])
            if sessions:
                last_session = sessions[-1]
            # updating the insufficient charge only after charging session is ended.
            if "insufficient_charge" in last_session:
                last_session["insufficient_charge"] = 1 if current_soc < 90 else 0

            last_end_time = datetime.fromisoformat(last_session["end_time_val"])
            duration = (current_timestamp - last_end_time).total_seconds() / 60

            if last_session.get("duration", 0) == 0 and last_session.get("distance", 0) == 0:
                sessions.pop()

                last_session_name = last_session.get("label", "").lower()
                
                if last_session_name == "movement":
                    daily_report["no_of_movement_sessions"] = max((daily_report.get("no_of_movement_sessions", 1) - 1, 0))
                elif last_session_name == "charging":
                    daily_report["no_of_charging_cycles"] = max((daily_report.get("no_of_charging_cycles", 1) - 1, 0))
                elif last_session_name == "idle":
                    daily_report["no_of_idle_sessions"] = max((daily_report.get("no_of_idle_sessions", 1) - 1, 0))


            if duration > 0.1667:  # threshold ~10 sec
                allow_new_session = True
        else:
            allow_new_session = True

        if allow_new_session:
            new_session = {
                "label": current_mode,
                "start_latitude": current_lat,
                "start_longitude": current_long,
                "end_latitude":current_lat,
                "end_longitude":current_long,
                "start_time_val": make_aware_ist(current_timestamp).isoformat(),
                "end_time_val": make_aware_ist(current_timestamp).isoformat(),
                "duration": 0,
                "start_odo_val": round(start_odo_val, 2),
                "end_odo_val": round(start_odo_val, 2),
                "start_soc_val": float(current_soc),
                "end_soc_val": float(current_soc),
                "battery_temperature": session_battery_temp,
            }
            new_session = make_session_serializable(new_session)
            daily_report.setdefault("sessions", []).append(new_session)

        if current_mode.lower() == "movement":
            daily_report["no_of_movement_sessions"] = (daily_report.get("no_of_movement_sessions") or 0) + 1
            # adding session parameters based on the mode
            new_session["distance"] = 0
            new_session["session_ec"] = 0.0
            new_session["session_regen"] = 0.0
            new_session["session_ecr"] = 0.0
            new_session["session_traction"] = 0.0
            new_session["max_speed"] = session_current_speed
            new_session["motor_temperature"] = session_motor_temp
            new_session["deep_discharge"] = 1 if current_soc < 20 else 0

        elif current_mode.lower() == "charging":
            daily_report["no_of_charging_cycles"] = (daily_report.get("no_of_charging_cycles") or 0) + 1
            # adding session parameters based on the mode
            new_session["charging_units"] = charging_units
            new_session["insufficient_charge"] = 0 

        elif current_mode.lower() == "idle":
            daily_report["no_of_idle_sessions"] = (daily_report.get("no_of_idle_sessions") or 0) + 1
            # adding session parameters based on the mode
            new_session["session_ec"] = 0.0
            new_session["deep_discharge"] = 1 if current_soc < 20 else 0

            
    elif daily_report.get("sessions"):
        update_last_session(daily_report["sessions"][-1], current_timestamp, current_odometer, current_soc, ec, regen, ecr,
                            charging_units,session_current_speed,session_battery_temp,current_lat,current_long)

    if daily_report.get("sessions"):
        daily_report["sessions"] = [make_session_serializable(s) for s in daily_report["sessions"]]

    
    device = get_device_details(device_id)

    # Update daily report fields
    daily_report["latitude"] = current_lat
    daily_report["longitude"] = current_long
    daily_report["mode"] = current_mode
    # daily_report.end_odometer = current_odometer
    # daily_report.end_soc = current_soc
    daily_report["stop_time_of_day"] = current_timestamp.isoformat()
    daily_report["distance"] = round(total_distance, 2)
    daily_report["runtime_minutes"] = round((daily_report.get("runtime_minutes") or 0) + runtime_minutes, 2)
    daily_report["idle_minutes"] = round((daily_report.get("idle_minutes") or 0) + idle_minutes, 2)
    daily_report["charging_minutes"] = round((daily_report.get("charging_minutes") or 0) + charging_minutes, 2)
    daily_report["stoppage_minutes"] = round((daily_report.get("stoppage_minutes") or 0) + stoppage_minutes, 2)
    daily_report["average_speed"] = round(average_speed, 2)
    daily_report["energy_consumed"] = round((daily_report.get("energy_consumed") or 0) + (-ec),3,)
    daily_report["regen_energy"] = round((daily_report.get("regen_energy") or 0) + regen,3,)
    daily_report["motor_ec"] = round((daily_report.get("motor_ec") or 0)+ (0 if mcu_energy < 0 else mcu_energy),3,)
    daily_report["dcdc_ec"] = round((daily_report.get("dcdc_ec") or 0) + kwh_dcdc,3,)
    daily_report["bcs_ec"] = round((daily_report.get("bcs_ec") or 0) + kwh_bcs, 3,)
    daily_report["tcs_ec"] = round((daily_report.get("tcs_ec") or 0) + kwh_tcs,3,)
    daily_report["ecompressor_and_steering_ec"] = round((daily_report.get("ecompressor_and_steering_ec") or 0)+ kwh_ecompressor,2,)
    daily_report["energy_consumption"] = round(ecr, 3)
    daily_report["charging_unit"] = round((daily_report.get("charging_unit") or 0)+ charging_units,3,)
    daily_report["battery_temperature"] = max_battery_temp
    daily_report["motor_temperature"] = max_motor_temperature
    daily_report["insufficient_charge"] = insufficient_charge
    daily_report["depth_of_discharge"] = dod


    return daily_report,True


def r_live_daily_report_3w_calculation(device_details,device_id,end_lat, end_long,timestamp,can_data,daily_report):


    # Convert date
    report_date = get_local_date_from_utc_timestamp(can_data.get("timestamp") or timestamp)

    # if not report_date:
    #     return daily_report, False

    if daily_report and daily_report.get("date") != report_date.isoformat():
        daily_report = {}


    # Handle empty state
    if not daily_report:

        daily_report = {
            "date": report_date.isoformat(),
            "imei": device_id,
            "vrn": device_details.get("VRN") if device_details else None,
            "vehicle_type": device_details.get("device_type") if device_details else None,
            "vehicle_type_name": device_details.get("device_type_name") if device_details else None,
            "chassis_number": device_details.get("chassis_number") if device_details else None,
            "fleet": device_details.get("fleet") if device_details else None,
            "city": device_details.get("city") if device_details else None,
            "latitude": end_lat,
            "longitude": end_long,
            "start_time_of_day": None,
            "runtime_minutes":0,
            "idle_minutes":0,
            "charging_minutes":0,
            "stoppage_minutes":0,
            "start_odometer":None,
            "end_odometer":None,
            "distance":0,
            "average_speed":0,
            "no_of_movement_sessions":0,
            "no_of_charging_cycles":0,
            "no_of_idle_sessions":0,
            "start_soc":None,
            "end_soc":None,
            "energy_consumed":0,
            "regen_energy":0,
            "motor_ec":0,
            "dcdc_ec":0,
            "ecompressor_and_steering_ec":0,
            "bcs_ec":0,
            "tcs_ec":0,
            "energy_consumption":0,
            "charging_unit":0,
            "depth_of_discharge":0,
            "insufficient_charge":0,
            "battery_temperature":None,     
            "motor_temperature":None,
            "mode":None,
            "sessions": [],
            "db_created": False

        }

    # Handle empty CAN data
    if not can_data:
        daily_report["latitude"] = end_lat
        daily_report["longitude"] = end_long
        daily_report["stop_time_of_day"] = make_aware_ist(datetime.now()).isoformat()

        return daily_report,True  # Exit if no CAN data

    # Create DataFrame
    df = pd.DataFrame([can_data]) 

    df = df.where(df != 'N', np.nan)
    df = df.apply(pd.to_numeric, errors='coerce')
    df.fillna(0, inplace=True)

    if df.empty:
        return daily_report,False
   

    last_stop_time = daily_report.get("stop_time_of_day")
    if last_stop_time:
        last_stop_time = datetime.fromisoformat(last_stop_time)

    current_timestamp = timestamp

    if daily_report.get("start_time_of_day") is None:
        daily_report["start_time_of_day"] = current_timestamp.isoformat()

    # Handle first entry case
    if last_stop_time is None:
        time_diff_seconds = 0
    else:
        last_stop_time = make_aware_ist(last_stop_time)
        time_diff_seconds = max((current_timestamp - last_stop_time).total_seconds(), 0)
        if time_diff_seconds < 1:
            print("Skipping! Time difference is less than 1 second")
            return daily_report,False


    # Mode detection
    if "Charger_Output_VOL" not in df.columns:
        df["Charger_Output_VOL"] = 0
    if "Charger_Output_CUR" not in df.columns:
        df["Charger_Output_CUR"] = 0

    # Charging mask: either voltage OR current > 0
    charging_mask = (df["Charger_Output_VOL"].notna() & (df["Charger_Output_VOL"] > 0)) | \
                    (df["Charger_Output_CUR"].notna() & (df["Charger_Output_CUR"] > 0))

    # Not charging mask
    not_charging_mask = ~charging_mask

    # Mode detection
    df["Mode"] = np.where(charging_mask, "Charging",
                        np.where((not_charging_mask & (df["IgnitionStatus"] == 1) & (df["MCU_Speed_Kmph"] > 0)), "Movement",
                                np.where((not_charging_mask & (df["IgnitionStatus"] == 1) & (df["MCU_Speed_Kmph"] == 0)), "Idle",
                                            "Stopped")))
    current_soc = df.at[0, "SOC"]
    if "MCU_Odometer_Val" in df.columns and pd.notna(df.at[0, "MCU_Odometer_Val"]) and float(df.at[0, "MCU_Odometer_Val"]) > 0 and float(df.at[0, "MCU_Odometer_Val"]) < 10000000:
        current_odometer = float(df.at[0, "MCU_Odometer_Val"])
    else:
        # Stick with last saved odometer
        current_odometer = daily_report.get("end_odometer") or 0

    current_soc = df.at[0, "SOC"]
    current_mode = df.at[0, "Mode"]
    prev_mode = daily_report.get("mode") or "Unknown"

    # Initialize start values if needed
    if daily_report.get("start_odometer") is None or daily_report.get("start_odometer") == 0:
        daily_report["start_odometer"] = round(current_odometer,2)

    if daily_report.get("start_soc")is None or daily_report.get("start_soc") == 0:
        daily_report["start_soc"] = current_soc

    # Previous end odometer (fallback)
    prev_end_odometer = round(daily_report.get("end_odometer") or current_odometer,2)

    # Calculate incremental distance
    distance_km = max(current_odometer - prev_end_odometer, 0)

    # Update end_odometer only if current_odometer is valid (>0)
    if current_odometer > 0:
        daily_report["end_odometer"] = round(current_odometer,2)

    # Always update SOC
    daily_report["end_soc"] = current_soc if current_soc is not None else (daily_report.get("end_soc") or 0)

    current_lat = end_lat
    current_long = end_long


    # Energy calculations
    df["energy_kwh"] = 0
    df.loc[not_charging_mask, "energy_kwh"] = (df["BatteryVoltage"] / 10000 * df["BatteryCurrent"] / 1000 * time_diff_seconds / 3600000)
    df["charging_energy_kwh"] = 0
    df.loc[charging_mask, "charging_energy_kwh"] = (df["BatteryVoltage"] / 10000 * df["BatteryCurrent"] / 1000 * time_diff_seconds / 3600000)

    charging_units = df.loc[charging_mask, "charging_energy_kwh"].sum()
    ec = df[df["energy_kwh"] < 0]["energy_kwh"].sum()
    total_ec = (daily_report.get("energy_consumed") or 0) + (-ec)
    regen = df[df["energy_kwh"] > 0]["energy_kwh"].sum()
    total_regen = (daily_report.get("regen_energy") or 0) + regen
    ecr_distance = (daily_report.get("distance") or 0) + distance_km
    ecr = (total_ec - total_regen) / ecr_distance if ecr_distance else 0

    temp_columns = ["TS1", "TS2", "TS3", "TS4", "TS5", "TS6"]
    # Max temps
    max_battery_temp = max(daily_report.get("battery_temperature") or 0, round(df[temp_columns].max().max(), 2))
    session_battery_temp = df[temp_columns].max().max()
    max_motor_temperature = max(daily_report.get("motor_temperature") or 0, round(df["MCU_Motor_Temp"].max(), 2))
    session_motor_temp = round(df["MCU_Motor_Temp"].max(), 2)

    # Minutes
    runtime_minutes = idle_minutes = charging_minutes = stoppage_minutes = 0
    current_minutes = current_timestamp.hour * 60 + current_timestamp.minute + current_timestamp.second / 60
    if current_mode.lower() == "movement":
        runtime_minutes += time_diff_seconds / 60
    elif current_mode.lower() == "idle":
        idle_minutes += time_diff_seconds / 60
    elif current_mode.lower() == "charging":
        charging_minutes += time_diff_seconds / 60
    else:
        stoppage_minutes += time_diff_seconds / 60

    # Average speed
    prev_distance = daily_report.get("distance") or 0
    prev_runtime = daily_report.get("runtime_minutes") or 0
    # prev_avg_speed = daily_report.get("average_speed") or 0
    total_runtime_minutes = prev_runtime + runtime_minutes

    total_distance = prev_distance + distance_km
    average_speed = (total_distance / (total_runtime_minutes / 60) if total_runtime_minutes > 0 else 0)

    # max speed session wise
    session_current_speed = df["MCU_Speed_Kmph"].iloc[-1]

    diesel_mileage = {'3w_6s': 25}
    electric_ecr = {'3w_6s': 0.08}
    EMISSION_FACTOR_DIESEL = 2.68  # kg CO2/litre
    GRID_CO2_INTENSITY = 0.2       # kg CO2/kWh
    diesel_price = 90              # ₹ per litre
    electricity_price = 8          # ₹ per kWh
 
    # Calculations
    liters_per_km = 1 / diesel_mileage['3w_6s']
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price
 
    ecr_variant = electric_ecr['3w_6s']
    co2_electric = ecr_variant * GRID_CO2_INTENSITY
    cost_electric = ecr_variant * electricity_price
 
    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric

    if total_distance:
        daily_report["co2_saving"] = co2_saved * total_distance
        daily_report["cost_saved"] = cost_saved * total_distance

    # Insufficient charge & DOD
    charging_ended = prev_mode.lower() == "charging" and current_mode.lower() != "charging"
    if charging_ended:
        last_soc = current_soc if pd.notnull(current_soc) else daily_report.get("end_soc")

        insufficient_charge = 1 if (last_soc is not None and last_soc <= 90) else 0

        dod = 1 if (last_soc is not None and last_soc < 20) else 0
    else:
        insufficient_charge = daily_report.get("insufficient_charge") or 0
        dod = daily_report.get("depth_of_discharge") or 0

    # Sessions
    if not daily_report.get("sessions"):
        daily_report["sessions"] = []

    def make_session_serializable(session):
        # Convert datetime objects to ISO strings
        # for key in ["start_time_val", "end_time_val"]:
        #     if isinstance(session.get(key), datetime):
        #         session[key] = make_aware_ist(session[key]).isoformat()
        # Convert numpy numbers to native Python types
        for key, value in session.items():
            if isinstance(value, (np.integer, np.int64, np.int32)):
                session[key] = int(value)
            elif isinstance(value, (np.floating, np.float64, np.float32)):
                session[key] = float(value)
        return session

    def update_last_session(session, current_timestamp, current_odometer, current_soc, ec, regen, ecr,
                            charging_units,session_current_speed,session_battery_temp,current_lat,current_long):
        # Convert datetime and numpy values immediately
        session["end_time_val"] = make_aware_ist(current_timestamp).isoformat()
        if not session.get("start_odo_val") or session["start_odo_val"] == 0:
            session["start_odo_val"] = round(float(current_odometer), 2)
        session["end_odo_val"] = round(float(current_odometer), 2)
        if not session.get("start_soc_val") or session["start_soc_val"] == 0:
            session["start_soc_val"] = float(current_soc)
        session["end_soc_val"] = float(current_soc)
        session["duration"] = (datetime.fromisoformat(session["end_time_val"]) - datetime.fromisoformat(session["start_time_val"])).total_seconds() / 60
        session["end_latitude"] = current_lat
        session["end_longitude"] = current_long
        session["battery_temperature"] = max(session["battery_temperature"],session_battery_temp)
        if "session_ec" in session:
            session["session_ec"] += float(ec)
        if "distance" in session:
            session["distance"] = max(session["end_odo_val"] - session["start_odo_val"], 0)
            session["session_regen"] += float(regen)
            session["session_ecr"] = (-(session["session_ec"]) + session["session_regen"]) / session["distance"] if session["distance"] else 0
            session["max_speed"] = max(session["max_speed"],session_current_speed)
            if "motor_temperature" in session:
                session["motor_temperature"] = max(session["motor_temperature"],session_motor_temp)
        if "deep_discharge" in session and session["deep_discharge"] != 1:
            session["deep_discharge"] = 1 if current_soc < 20 else 0
        if "charging_units" in session:
            session["charging_units"] += charging_units


    start_odo_val = current_odometer if current_odometer and current_odometer > 0 else daily_report.get("start_odometer") or 0
    # Creating a new session
    if prev_mode is None or prev_mode.lower() != current_mode.lower():
        #assignment    
        allow_new_session = False
        if daily_report.get("sessions"):
            sessions = daily_report.setdefault("sessions", [])
            if sessions:
                last_session = sessions[-1]
            # updating the insufficient charge only after charging session is ended.
            if "insufficient_charge" in last_session:
                last_session["insufficient_charge"] = 1 if current_soc < 90 else 0

            last_end_time = datetime.fromisoformat(last_session["end_time_val"])
            duration = (current_timestamp - last_end_time).total_seconds() / 60

            if last_session.get("duration", 0) == 0 and last_session.get("distance", 0) == 0:
                sessions.pop()

                last_session_name = last_session.get("label", "").lower()
                
                if last_session_name == "movement":
                    daily_report["no_of_movement_sessions"] = max((daily_report.get("no_of_movement_sessions", 1) - 1, 0))
                elif last_session_name == "charging":
                    daily_report["no_of_charging_cycles"] = max((daily_report.get("no_of_charging_cycles", 1) - 1, 0))
                elif last_session_name == "idle":
                    daily_report["no_of_idle_sessions"] = max((daily_report.get("no_of_idle_sessions", 1) - 1, 0))

            if duration > 0.1667:  # threshold ~10 sec
                allow_new_session = True
        else:
            allow_new_session = True

        if allow_new_session:
            new_session = {
                "label": current_mode,
                "start_latitude": current_lat,
                "start_longitude": current_long,
                "end_latitude":current_lat,
                "end_longitude":current_long,
                "start_time_val": make_aware_ist(current_timestamp).isoformat(),
                "end_time_val": make_aware_ist(current_timestamp).isoformat(),
                "duration": 0,
                "start_odo_val": round(start_odo_val, 2),
                "end_odo_val": round(start_odo_val, 2),
                "start_soc_val": float(current_soc),
                "end_soc_val": float(current_soc),
                "battery_temperature": session_battery_temp,
            }
            new_session = make_session_serializable(new_session)
            daily_report.setdefault("sessions", []).append(new_session)

        if current_mode.lower() == "movement":
            daily_report["no_of_movement_sessions"] = (daily_report.get("no_of_movement_sessions") or 0) + 1
            # adding session parameters based on the mode
            new_session["distance"] = 0
            new_session["session_ec"] = 0.0
            new_session["session_regen"] = 0.0
            new_session["session_ecr"] = 0.0
            new_session["max_speed"] = session_current_speed
            new_session["motor_temperature"] = session_motor_temp
            new_session["deep_discharge"] = 1 if current_soc < 20 else 0

        elif current_mode.lower() == "charging":
            daily_report["no_of_charging_cycles"] = (daily_report.get("no_of_charging_cycles") or 0) + 1
            # adding session parameters based on the mode
            new_session["charging_units"] = charging_units
            new_session["insufficient_charge"] = 0 

        elif current_mode.lower() == "idle":
            daily_report["no_of_idle_sessions"] = (daily_report.get("no_of_idle_sessions") or 0) + 1
            # adding session parameters based on the mode
            new_session["session_ec"] = 0.0
            new_session["deep_discharge"] = 1 if current_soc < 20 else 0

            
    elif daily_report.get("sessions"):
        update_last_session(daily_report["sessions"][-1], current_timestamp, current_odometer, current_soc, ec, regen, ecr,
                            charging_units,session_current_speed,session_battery_temp,current_lat,current_long)

    if daily_report.get("sessions"):
        daily_report["sessions"] = [make_session_serializable(s) for s in daily_report["sessions"]]


    # Update daily report fields
    daily_report["latitude"] = current_lat
    daily_report["longitude"] = current_long
    daily_report["mode"] = current_mode
    # daily_report.end_odometer = current_odometer
    # daily_report.end_soc = current_soc
    daily_report["stop_time_of_day"] = current_timestamp.isoformat()
    daily_report["distance"] = round(total_distance, 2)
    daily_report["runtime_minutes"] = round((daily_report.get("runtime_minutes") or 0) + runtime_minutes, 2)
    daily_report["idle_minutes"] = round((daily_report.get("idle_minutes") or 0) + idle_minutes, 2)
    daily_report["charging_minutes"] = round((daily_report.get("charging_minutes") or 0) + charging_minutes, 2)
    daily_report["stoppage_minutes"] = round((daily_report.get("stoppage_minutes") or 0) + stoppage_minutes, 2)
    daily_report["average_speed"] = round(average_speed, 2)
    daily_report["energy_consumed"] = round((daily_report.get("energy_consumed") or 0) + (-ec),3,)
    daily_report["regen_energy"] = round((daily_report.get("regen_energy") or 0) + regen,3,)
    daily_report["energy_consumption"] = round(ecr, 3)
    daily_report["charging_unit"] = round((daily_report.get("charging_unit") or 0)+ charging_units,3,)
    daily_report["battery_temperature"] = max_battery_temp
    daily_report["motor_temperature"] = max_motor_temperature
    daily_report["insufficient_charge"] = insufficient_charge
    daily_report["depth_of_discharge"] = dod

    return daily_report,True








    