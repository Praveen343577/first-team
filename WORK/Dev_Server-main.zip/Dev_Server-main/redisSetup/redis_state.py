import json
import numpy as np
import pandas as pd
from datetime import datetime


def load_state(r, device_id):

    state = {}

    total = r.hgetall(f"device:{device_id}:total_cal")
    if total:
        state["total_cal"] = {k.decode(): json.loads(v) for k,v in total.items()}

    daily = r.hgetall(f"device:{device_id}:daily_summary")
    if daily:
        state["daily_summary"] = {k.decode(): json.loads(v) for k,v in daily.items()}

    alerts = r.hget(f"device:{device_id}", "alerts")
    if alerts:
        state["alerts"] = json.loads(alerts)

    faults = r.hget(f"device:{device_id}", "faults")
    if faults:
        state["faults"] = json.loads(faults)


    return state


def json_serializer(obj):

    if isinstance(obj, (np.bool_,)):
        return bool(obj)

    if isinstance(obj, (np.integer,)):
        return int(obj)

    if isinstance(obj, (np.floating,)):
        return float(obj)

    if isinstance(obj, (pd.Timestamp, datetime)):
        return obj.isoformat()

    return str(obj)


def save_state(r, device_id, state):

    if "total_cal" in state:

        r.delete(f"device:{device_id}:total_cal")

        for k, v in state["total_cal"].items():

            r.hset(
                f"device:{device_id}:total_cal",
                k,
                json.dumps(v, default=json_serializer)
            )

    if "daily_summary" in state:

        r.delete(f"device:{device_id}:daily_summary")

        for k, v in state["daily_summary"].items():

            r.hset(
                f"device:{device_id}:daily_summary",
                k,
                json.dumps(v, default=json_serializer)
            )

    if "alerts" in state:

        r.hset(
            f"device:{device_id}",
            "alerts",
            json.dumps(state["alerts"], default=json_serializer)
        )

    if "faults" in state:

        r.hset(
            f"device:{device_id}",
            "faults",
            json.dumps(state["faults"], default=json_serializer)
        )