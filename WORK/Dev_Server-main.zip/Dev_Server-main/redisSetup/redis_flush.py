from devices.models import Alert, Fault, DailySummaryReport, DeviceTotalCalculationData
from django_redis import get_redis_connection
import time
import json
from redisSetup.redis_state import load_state, save_state
from django.db import close_old_connections
from operations.models import Trips


r = get_redis_connection("streams")


def run():

    while True:

        close_old_connections()

        total_devices = r.smembers("active_total_cal")
        alert_devices = r.smembers("active_alerts")
        fault_devices = r.smembers("active_faults")
        report_devices = r.smembers("active_daily_summary")

        trip_ids = r.smembers("dirty_trips")

        if not (total_devices or alert_devices or fault_devices or report_devices or trip_ids):
            time.sleep(1)
            print("No active devices. Waiting...")
            continue

        total_create = []
        total_update = []
        total_states = []

        alert_create = []
        alert_update = []
        alert_close = []
        alert_states = []

        fault_create = []
        fault_update = []
        fault_close = []
        fault_states = []

        # report_create = []
        # report_update = []
        report_upsert = []

        states_to_update = {}

        all_devices = set()

        all_devices.update(total_devices)
        all_devices.update(alert_devices)
        all_devices.update(fault_devices)
        all_devices.update(report_devices)

        for device_id_bytes in all_devices:

            device_id = device_id_bytes.decode()

            state = load_state(r, device_id)

            if not state:
                continue

            states_to_update[device_id] = state

            # ---------------- TOTAL CAL ----------------

            if device_id_bytes in total_devices:

                total_cal_state = state.get("total_cal", {})

                if total_cal_state:

                    if not total_cal_state.get("db_created"):

                        total_create.append(
                            DeviceTotalCalculationData(
                                device_id=device_id,
                                total_distance=total_cal_state.get("total_distance"),
                                co2_saving=total_cal_state.get("co2_saving"),
                                energy_consumption=total_cal_state.get("energy_consumption"),
                                run_time=total_cal_state.get("run_time"),
                                traction_energy=total_cal_state.get("traction_energy"),
                                regen_energy=total_cal_state.get("regen_energy"),
                                idle_time=total_cal_state.get("idle_time"),
                                charging_unit=total_cal_state.get("charging_unit"),
                                charging_count=total_cal_state.get("charging_count"),
                                cost_saved=total_cal_state.get("cost_saved"),
                            )
                        )

                        total_states.append(total_cal_state)

                    else:

                        db_id = total_cal_state.get("db_id")

                        if db_id:

                            total_update.append(
                                DeviceTotalCalculationData(
                                    id=db_id,
                                    total_distance=total_cal_state.get("total_distance"),
                                    co2_saving=total_cal_state.get("co2_saving"),
                                    energy_consumption=total_cal_state.get("energy_consumption"),
                                    run_time=total_cal_state.get("run_time"),
                                    traction_energy=total_cal_state.get("traction_energy"),
                                    regen_energy=total_cal_state.get("regen_energy"),
                                    idle_time=total_cal_state.get("idle_time"),
                                    charging_unit=total_cal_state.get("charging_unit"),
                                    charging_count=total_cal_state.get("charging_count"),
                                    cost_saved=total_cal_state.get("cost_saved"),
                                )
                            )

            # ---------------- ALERTS ----------------

            if device_id_bytes in alert_devices:

                alerts_state = state.get("alerts", {})

                for alert in alerts_state.get("active", {}).values():

                    if not alert["db_created"] and alert["duration_seconds"] >= 120:

                        alert_create.append(
                            Alert(
                                imei=alert["imei"],
                                name=alert["name"],
                                alert_type=alert["alert_type"],
                                value=alert["value"],
                                start_time=alert["start_time"],
                                end_time=alert["end_time"],
                                duration_seconds=alert["duration_seconds"],
                                device_type_name=alert["device_type_name"],
                                req_data=alert.get("req_data", []),
                                is_active=True,
                            )
                        )

                        alert_states.append(alert)

                    elif alert["db_created"]:

                        if alert.get("db_id"):

                            alert_update.append(
                                Alert(
                                    id=alert["db_id"],
                                    end_time=alert["end_time"],
                                    duration_seconds=alert["duration_seconds"],
                                    req_data=alert.get("req_data", []),
                                )
                            )

                for alert in alerts_state.get("buffer", []):

                    if alert.get("db_id"):

                        alert_close.append(
                            Alert(
                                id=alert["db_id"],
                                end_time=alert["end_time"],
                                duration_seconds=alert["duration_seconds"],
                                is_active=False,
                                req_data=alert.get("req_data", []),
                            )
                        )

                alerts_state["buffer"] = []

            # ---------------- FAULTS ----------------

            if device_id_bytes in fault_devices:

                faults_state = state.get("faults", {})

                for fault in faults_state.get("active", {}).values():

                    if not fault["db_created"]:

                        fault_create.append(
                            Fault(
                                imei=fault["imei"],
                                rule_id=fault["rule_id"],
                                component=fault["component"],
                                data_snapshot=fault.get("data_snapshot"),
                                start_time=fault["start_time"],
                                end_time=fault["end_time"],
                                is_active=True,
                            )
                        )

                        fault_states.append(fault)

                    else:

                        if fault.get("db_id"):

                            fault_update.append(
                                Fault(
                                    id=fault["db_id"],
                                    end_time=fault["end_time"],
                                )
                            )

                for fault in faults_state.get("buffer", []):

                    if fault.get("db_id"):

                        fault_close.append(
                            Fault(
                                id=fault["db_id"],
                                end_time=fault["end_time"],
                                is_active=False,
                            )
                        )

                faults_state["buffer"] = []

            # ---------------- DAILY REPORT ----------------
            try:
                if device_id_bytes in report_devices:

                    report = state.get("daily_summary")

                    if report and report.get("imei") and report.get("date"):

                        report_upsert.append(
                            DailySummaryReport(
                                imei=report["imei"],
                                date=report["date"],
                                vrn=report.get("vrn"),
                                vehicle_type=report.get("vehicle_type"),
                                vehicle_type_name=report.get("vehicle_type_name"),
                                chassis_number=report.get("chassis_number"),
                                fleet=report.get("fleet"),
                                city=report.get("city"),

                                latitude=report.get("latitude"),
                                longitude=report.get("longitude"),

                                start_time_of_day=report.get("start_time_of_day"),
                                start_odometer=report.get("start_odometer"),
                                start_soc=report.get("start_soc"),

                                stop_time_of_day=report.get("stop_time_of_day"),
                                end_odometer=report.get("end_odometer"),
                                end_soc=report.get("end_soc"),

                                distance=report.get("distance"),
                                runtime_minutes=report.get("runtime_minutes"),
                                idle_minutes=report.get("idle_minutes"),
                                charging_minutes=report.get("charging_minutes"),
                                stoppage_minutes=report.get("stoppage_minutes"),

                                energy_consumed=report.get("energy_consumed"),
                                regen_energy=report.get("regen_energy"),
                                energy_consumption=report.get("energy_consumption"),
                                charging_unit=report.get("charging_unit"),

                                motor_ec=report.get("motor_ec"),
                                dcdc_ec=report.get("dcdc_ec"),
                                ecompressor_and_steering_ec=report.get("ecompressor_and_steering_ec"),
                                bcs_ec=report.get("bcs_ec"),
                                tcs_ec=report.get("tcs_ec"),

                                average_speed=report.get("average_speed"),
                                no_of_movement_sessions=report.get("no_of_movement_sessions"),
                                no_of_charging_cycles=report.get("no_of_charging_cycles"),
                                no_of_idle_sessions=report.get("no_of_idle_sessions"),

                                battery_temperature=report.get("battery_temperature"),
                                motor_temperature=report.get("motor_temperature"),

                                depth_of_discharge=report.get("depth_of_discharge"),
                                insufficient_charge=report.get("insufficient_charge"),

                                mode=report.get("mode"),
                                sessions=report.get("sessions", []),

                                co2_saving=report.get("co2_saving"),
                                cost_saved=report.get("cost_saved"),
                            )
                        )
            except Exception as e:
                print(f"Error processing daily report for device {device_id}: {str(e)}")

            


        # ---------------- BULK DB OPERATIONS ----------------

        try:

            if total_create:

                DeviceTotalCalculationData.objects.bulk_create(
                    total_create,
                    update_conflicts=True,
                    update_fields=[
                        "total_distance",
                        "co2_saving",
                        "energy_consumption",
                        "run_time",
                        "traction_energy",
                        "regen_energy",
                        "idle_time",
                        "charging_unit",
                        "charging_count",
                        "cost_saved",
                    ],
                    unique_fields=["device_id"],
                )

                for obj, state_obj in zip(total_create, total_states):

                    state_obj["db_created"] = True

        except Exception as e:

            print("Error in upserting total_cal:", str(e))

        try:
            if total_update:
                DeviceTotalCalculationData.objects.bulk_update(
                    total_update,
                    [
                        "total_distance",
                        "co2_saving",
                        "energy_consumption",
                        "run_time",
                        "traction_energy",
                        "regen_energy",
                        "idle_time",
                        "charging_unit",
                        "charging_count",
                        "cost_saved",
                    ],
                )
        except Exception as e:
            print("Error in updating total_cal:", str(e))

        try:

            if alert_create:

                Alert.objects.bulk_create(alert_create)

                for obj, state_obj in zip(alert_create, alert_states):

                    if obj.id:

                        state_obj["db_created"] = True
                        state_obj["db_id"] = obj.id

        except Exception as e:

            print("Error in bulk creating alerts:", str(e))

        try:

            if alert_update:

                Alert.objects.bulk_update(alert_update, ["end_time", "duration_seconds", "req_data"])

        except Exception as e:

            print("Error in bulk updating alerts:", str(e))

        try:

            if alert_close:

                Alert.objects.bulk_update(alert_close, ["end_time", "duration_seconds", "is_active", "req_data"])

        except Exception as e:

            print("Error in bulk closing alerts:", str(e))

        try:

            if fault_create:

                Fault.objects.bulk_create(fault_create)

                for obj, state_obj in zip(fault_create, fault_states):

                    if obj.id:

                        state_obj["db_created"] = True
                        state_obj["db_id"] = obj.id

        except Exception as e:

            print("Error in bulk creating faults:", str(e))

        try:

            if fault_update:

                Fault.objects.bulk_update(fault_update, ["end_time"])

        except Exception as e:

            print("Error in bulk updating faults:", str(e))

        try:

            if fault_close:

                Fault.objects.bulk_update(fault_close, ["end_time", "is_active"])

        except Exception as e:

            print("Error in bulk closing faults:", str(e))

        try:
            if report_upsert:
                DailySummaryReport.objects.bulk_create(
                    report_upsert,
                    update_conflicts=True,
                    unique_fields=["imei", "date"],
                    update_fields=[
                        "vrn","vehicle_type","vehicle_type_name","chassis_number",
                        "fleet","city","latitude","longitude","start_time_of_day",
                        "stop_time_of_day","runtime_minutes","idle_minutes",
                        "charging_minutes","stoppage_minutes","start_odometer",
                        "end_odometer","distance","average_speed",
                        "no_of_movement_sessions","no_of_charging_cycles",
                        "no_of_idle_sessions","start_soc","end_soc",
                        "energy_consumed","regen_energy","motor_ec","dcdc_ec",
                        "ecompressor_and_steering_ec","bcs_ec","tcs_ec",
                        "energy_consumption","charging_unit","depth_of_discharge",
                        "insufficient_charge","battery_temperature",
                        "motor_temperature","mode","sessions","co2_saving","cost_saved"
                    ],
                )
        except Exception as e:
            print("Report error:", e)


        try: 
            trip_updates = []

            for tid in trip_ids:
                trip_id = tid.decode()

                state = r.get(f"trip:{trip_id}:state")
                if not state:
                    continue

                state = json.loads(state)

                trip_updates.append(
                    Trips(
                        id=trip_id,
                        trip_progress=state.get("trip_progress"),
                        progress=state.get("progress"),
                        status=state.get("status"),
                        delayed_status=False
                    )
                )

            if trip_updates:
                Trips.objects.bulk_update(
                    trip_updates,
                    ["trip_progress", "progress", "status", "delayed_status"]
                )

        except Exception as e:
                print("Trip update error:", e)

        # ---------------- SAVE STATE BACK ----------------

        for device_id, state in states_to_update.items():

            save_state(r, device_id, state)

        # remove processed devices from sets

        if total_devices:
            r.srem("active_total_cal", *total_devices)

        if alert_devices:
            r.srem("active_alerts", *alert_devices)

        if fault_devices:
            r.srem("active_faults", *fault_devices)

        if report_devices:
            r.srem("active_daily_summary", *report_devices)

        if trip_ids:
            r.srem("dirty_trips", *trip_ids)
        

        time.sleep(10)



