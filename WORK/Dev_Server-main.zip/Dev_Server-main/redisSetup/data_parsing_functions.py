import os
from typing import Optional
import cantools
from datetime import datetime
import pandas as pd
from django_redis import get_redis_connection
import json
from devices.models import Device,AlertRule
from django.utils import timezone

r_cache = get_redis_connection("default")

def get_device_details(device_id):
    cache_key = f"device_meta:{device_id}"

    cached = r_cache.get(cache_key)

    if cached:
        if cached == b"NULL":
            return None
        return json.loads(cached)

    try:
        device = Device.objects.get(device_id=device_id)
    except Device.DoesNotExist:
        r_cache.set(cache_key, "NULL", ex=21600)
        return None

    data = {
            "device_id": device.device_id,
            "device_type": device.device_type,
            "device_type_name": device.device_type_name,
            "VRN": device.VRN,
            "chassis_number": device.chassis_number,
            "city": device.city,
            "DOP": device.DOP,
            "reg_date": device.reg_date,
            "city": device.city,
            "battery_type": device.battery_type,
            "battery_make": device.battery_make,
            "refurbished": device.refurbished,
            "expire_on": device.expire_on,
            "payment_model": device.payment_model,
            "fleet_owner": device.fleet_owner,
            "fleet": device.fleet,
            "platform": device.platform,
            "is_connected": device.is_connected,
            "is_active": device.is_active,
            "last_seen": device.last_seen,
            }

    r_cache.set(cache_key, json.dumps(data, default=str), ex=21600)

    return data

#Used for the devices api for cached response of multiple devices details
def get_multiple_device_details(device_ids = None, device_type=None):
    results = {}
    missing_ids = []
    
    for device_id in device_ids:
        cache_key = f"device_meta:{device_id}"
        cached = r_cache.get(cache_key)

        if cached:
            if cached != b"NULL":
                results[device_id] = json.loads(cached)
        else:
            missing_ids.append(device_id)

    if missing_ids:
        devices = Device.objects.filter(device_id__in=missing_ids)

        device_map = {d.device_id: d for d in devices}

        for device_id in missing_ids:
            device = device_map.get(device_id)

            cache_key = f"device_meta:{device_id}"

            if not device:
                r_cache.set(cache_key, "NULL", ex=21600)
                continue

            data = {
                "device_id": device.device_id,
                "device_type": device.device_type,
                "device_type_name": device.device_type_name,
                "VRN": device.VRN,
                "chassis_number": device.chassis_number,
                "city": device.city,
                "DOP": device.DOP,
                "reg_date": device.reg_date,
                "battery_type": device.battery_type,
                "battery_make": device.battery_make,
                "refurbished": device.refurbished,
                "expire_on": device.expire_on,
                "payment_model": device.payment_model,
                "fleet_owner": device.fleet_owner,
                "fleet": device.fleet,
                "platform": device.platform,
                "is_connected": device.is_connected,
                "is_active": device.is_active,
                "last_seen": device.last_seen,
            }

            r_cache.set(cache_key, json.dumps(data, default=str), ex=21600)
            results[device_id] = data

    return results

def get_alert_rules():
    cache_key = "alert_rules"
    cached = r_cache.get(cache_key)

    if cached:
        if cached == b"NULL":
            return None
        return json.loads(cached)

    alert_rules = list(
        AlertRule.objects.all().values(
            "name",
            "condition",
            "description",
            "alert_type",
            "req_signals"
        )
    )

    r_cache.set(cache_key, json.dumps(alert_rules))

    return alert_rules


def extract_device_id(message: str) -> Optional[str]:
    try:
        if isinstance(message, bytes):
            message = message.decode()
        parts = message.split(',')
        if len(parts) >= 7:
            return parts[6]  # 7th element (index 6) is device ID
        else:
            print("Unable to extract device ID - malformed message.")
            return None
    except Exception as e:
        print(f"Error extracting device ID: {e}")
        return None


_dbc_cache = {}

def load_dbc_file(device_type: str):
    if device_type in _dbc_cache:
        return _dbc_cache[device_type]
    
    config = {
        'dbc_paths': {
            '3w': 'dbcs/3w.dbc',
            '4w': 'dbcs/4w.dbc',
        }
    }

    dbc_path = config['dbc_paths'].get(device_type)
    if not dbc_path or not os.path.exists(dbc_path):
        return None

    dbc = cantools.database.load_file(dbc_path)
    _dbc_cache[device_type] = dbc
    return dbc
    
def parse_message(message: str, dbc_file, device_id) -> Optional[pd.DataFrame]:
    try:
        if isinstance(message, bytes):
            message = message.decode()
        # device_id = extract_device_id(message)
        if device_id is None:
            return None  # Skip message if device ID is missing
        parts = message.split(',')
        timestamp = datetime.now().isoformat()
        
        # Basic structure for known fields
        field_names = [ 
            "header", "vendor_id", "version", "packet_type","alert_id", "packet_status", "IMEI",
            "vehicle_reg_no", "gps_fix", "date", "time",
            "latitude", "latitude_dir", "longitude", "longitude_dir",
            "speed","heading","no_of_stattalites", "altitude", "pdop", "hdop",
            "operator","ignition","main_power_status","main_input_voltage","internal_battery_voltage",
            "emergency_status","temper_alert","gsm_strength", "MCC","MNC","LAC",
            "cell_id"   
        ]

        parsed_data = {
            'timestamp': timestamp,
            'device_id': device_id
        }
        
        parsed_data['NMR'] = "|".join(parts[33:44])
        parsed_data['digital_input_status'] = parts[45]
        parsed_data['digital_output_status'] = parts[46]
        parsed_data['analog_input_1'] = parts[47]
        parsed_data['analog_input_2'] = parts[48]
        parsed_data['frame_number'] = parts[49]
        parsed_data['odometer'] = parts[50]
        parsed_data['debug_info'] = parts[56]
        # parsed_data['mis_field_1'] = parts[51]
        # parsed_data['mis_field_3'] = parts[53]
        # parsed_data['mis_field_4'] = parts[54]
        

        parsed_data['mis_field_2'] = parts[52]
        parsed_data['extra_data'] = json.dumps({})

        # Fill parsed_data with fixed fields
        for i, field in enumerate(field_names):
            if i < len(parts):
                if field == 'NMR' or  i >= 33:
                    continue
                else:
                    parsed_data[field] = parts[i]


        can_data_dict = {}
                    
        # Extract CAN section
        can_section = ""
        if parsed_data['mis_field_2'] != '-':
            try:
                can_section = parsed_data['mis_field_2'].split('CAN|')[1].split('|-')[0]
            except IndexError:
                print("Malformed CAN section in the message.")

        can_data = can_section.split('|') if can_section else []
        filtered_can_data = [data if data != 'N' and len(data) > 0 else 'N' for data in can_data]
        # CAN IDs
        can_ids = [
            0x800, 0x801, 0x802, 0x803, 0x804, 0x805, 0x806, 0x807, 0x808, 0x809,
            0x810, 0x811, 0x812, 0x813, 0x814, 0x815, 0x816, 0x817, 0x818, 0x819,
            0x820, 0x821, 0x822, 0x823, 0x824, 0x825, 0x826, 0x827, 0x828, 0x829,
            0x830, 0x831, 0x832, 0x833, 0x834, 0x835, 0x836, 0x837, 0x838, 0x839,
            0x840, 0x841, 0x842, 0x843, 0x844, 0x845, 0x850, 0x851, 0x852, 0x853
        ]
        
        for idx, item in enumerate(filtered_can_data):
            try:
                if ':' in item:
                    # Format: ['000800:n']
                    hex_str = item.strip()
                    can_id_str, hex_data = hex_str.split(":")
                    can_id = int(can_id_str, 16)
                else:
                # Format: ['n', 'AABBCC']
                    can_id = can_ids[idx]
                    hex_data = item.strip()

                if hex_data.lower() == 'n':
                    for signal in dbc_file.get_message_by_frame_id(can_id).signals:
                        can_data_dict[signal.name] = 'N'
                    continue

                can_data_bytes = bytes.fromhex(hex_data)
                decoded = dbc_file.decode_message(can_id, can_data_bytes)

                for signal_name, value in decoded.items():
                    can_data_dict[signal_name] = value
                can_data_dict["timestamp"] = timestamp

            except Exception as e:
                print(f"Error decoding CAN ID {hex(can_id)}: {e}")
        parsed_data.pop("mis_field_2")

        return (parsed_data,can_data_dict)

    except Exception as e:
        print(f"Error parsing message: {e}")
        return None
    
def live_data(device_data, device_type, can_data, device_id):
        can_data = can_data or {}

        if (device_data.get("header") or "").strip() != "$NRM":
            return

        # device_type = device.device_type.strip()

        if device_type == "4w":
            ignition = can_data.get("Ignition_Sense")
        elif device_type == "3w":
            ignition = can_data.get("IgnitionStatus")
        else:
            return

        # parse timestamp
        raw_ts = device_data.get("timestamp")
        last_timestamp = None
        if raw_ts:
            try:
                last_timestamp = datetime.fromisoformat(raw_ts)
                if last_timestamp.tzinfo is None:
                    last_timestamp = timezone.make_aware(last_timestamp, timezone.utc)
            except Exception:
                last_timestamp = timezone.now()

        ignition_off = ignition in (None, 0, "0", "OFF", False, "N")

        defaults = {
            "imei": device_id,
            "last_timestamp": last_timestamp,
            "latitude": device_data.get("latitude"),
            "latitude_dir": device_data.get("latitude_dir"),
            "longitude": device_data.get("longitude"),
            "longitude_dir": device_data.get("longitude_dir"),
            "heading": device_data.get("heading")
        }

        # update CAN only when ignition is valid
        if not ignition_off:
            defaults["can_data"] = can_data


        # can_data = can_data or {}

        # defaults = {
        #     "imei": device_id,
        #     "last_timestamp": last_timestamp,
        #     "latitude": device_data.get("latitude"),
        #     "latitude_dir": device_data.get("latitude_dir"),
        #     "longitude": device_data.get("longitude"),
        #     "longitude_dir": device_data.get("longitude_dir"),
        #     "heading": device_data.get("heading"),
        #     "can_data": can_data
        # }

        return defaults



