from django_redis import get_redis_connection
import redis
import os
import time
from django.db import transaction
import json
from devices.models import DeviceData,Device,LiveData,ExtraDevice   
from redisSetup.data_parsing_functions import (
        extract_device_id,
        get_device_details,
        load_dbc_file,
        parse_message,
        live_data
    )


STREAM = "telematics_raw"
GROUP = "decoder_group"
CONSUMER = f"decoder_{os.getpid()}"
BATCH_SIZE = 10

r = get_redis_connection("streams")


def decoded_msg_to_processor(processor_payload):

    for payload in processor_payload:
        print("Sending to telematics_decoded:")
        r.xadd(
            "telematics_decoded",
            payload,
            maxlen=1000,
            approximate=True
        )


def decode_hex(message):

    device_id = extract_device_id(message)
    if not device_id:
        return {"status": "invalid"}

    device_details = get_device_details(device_id)

    # Device not registered
    if not device_details:
        return {
            "status": "unknown",
            "device_id": device_id
        }

    device_type = device_details.get("device_type")

    dbc = load_dbc_file(device_type)
    if not dbc:
        return {"status": "invalid"}

    result = parse_message(message, dbc, device_id)
    if not result:
        return {"status": "invalid"}

    parsed, can_data = result

    return {
        "status": "valid",
        "device_data": parsed,
        "can_data": can_data,
        "device_type": device_type,
        "device_id": device_id

    }


def update_live_table(live_updates):
    if not live_updates:
        return

    imeis = [item["imei"] for item in live_updates]

    existing = {
        obj.imei: obj
        for obj in LiveData.objects.filter(imei__in=imeis)
    }

    to_create = []
    to_update = []

    for data in live_updates:
        imei = data["imei"]

        if imei in existing:
            obj = existing[imei]
            for key, value in data.items():
                setattr(obj, key, value)
            to_update.append(obj)
        else:
            to_create.append(LiveData(**data))

    if to_create:
        LiveData.objects.bulk_create(to_create)

    if to_update:
        LiveData.objects.bulk_update(
            to_update,
            fields=[
        "last_timestamp",
        "latitude",
        "latitude_dir",
        "longitude",
        "longitude_dir",
        "heading",
        "can_data",
    ],
        )

def normalize(v):
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v

def ensure_group():
    try:
        r.xgroup_create(STREAM, GROUP, id="0", mkstream=True)
        print("Consumer group created")
    except redis.exceptions.ResponseError:
        # Group already exists
        pass


def run():
    ensure_group()

    while True:
        messages = r.xreadgroup(
            GROUP,
            CONSUMER,
            {STREAM: ">"},
            count=BATCH_SIZE,
            block=2000
        )

        if not messages:
            print("No messages, sleeping...")
            continue

        batch = []
        processor_payload = [] 
        live_updates = []
        unknown_ids = set()
        ack_ids = []

        for _, entries in messages:
            for msg_id, data in entries:
                try:
                    payload = data.get(b"payload") or data.get("payload")

                    if not payload:
                        r.xack(STREAM, GROUP, msg_id)
                        continue

                    decoded = decode_hex(payload)

                    if not decoded or decoded["status"] == "invalid":
                        r.xack(STREAM, GROUP, msg_id)
                        continue
                    
                    if decoded["status"] == "unknown":
                        unknown_ids.add(decoded["device_id"])
                        r.xack(STREAM, GROUP, msg_id)
                        continue

                    batch.append(DeviceData(**decoded["device_data"],can_data=decoded["can_data"]))

                    processor_payload.append({**{k: normalize(v) for k, v in decoded["device_data"].items()},"can_data": json.dumps(decoded["can_data"], default=str)})

                    live_row = live_data(
                        device_data=decoded["device_data"],
                        device_type=decoded["device_type"],
                        can_data=decoded["can_data"],
                        device_id=decoded["device_id"],
                    )

                    if live_row:
                        live_updates.append(live_row)

                    ack_ids.append(msg_id)

                except Exception as e:
                    print("Decode error:", e)
                    r.xack(STREAM, GROUP, msg_id)

        if batch or live_updates or unknown_ids:
            try:
                if batch:
                    try:
                        with transaction.atomic():
                            DeviceData.objects.bulk_create(batch, batch_size=BATCH_SIZE)
                    except Exception as e:
                        print(f"DeviceData insert error: {e}")

                # ---- LiveData update ----
                if live_updates:
                    try:
                        with transaction.atomic():
                            update_live_table(live_updates)
                    except Exception as e:
                        print(f"LiveData error: {e}")

                # ---- Unknown devices ----
                if unknown_ids:
                    try:
                        with transaction.atomic():
                            existing = set(
                                ExtraDevice.objects.filter(
                                    device_id__in=unknown_ids
                                ).values_list("device_id", flat=True)
                            )

                            to_create = [
                                ExtraDevice(device_id=did)
                                for did in unknown_ids
                                if did not in existing
                            ]

                            if to_create:
                                ExtraDevice.objects.bulk_create(to_create)
                    except Exception as e:
                        print(f"ExtraDevice error: {e}")

                decoded_msg_to_processor(processor_payload)

                # ACK only after successful DB transaction
                r.xack(STREAM, GROUP, *ack_ids)

            except Exception as e:
                print(f"DB error: {e}")
                # Leave messages pending for retry
                pass