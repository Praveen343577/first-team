import { useRef, useEffect } from 'react'

export default function InputBar({ input, setInput, streaming, onSend, onStop, handleKeyDown, disabled }) {
  const textareaRef = useRef(null)

  // Auto-resize textarea as user types
  useEffect(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = Math.min(el.scrollHeight, 160) + 'px'
  }, [input])

  // Focus input on mount
  useEffect(() => {
    textareaRef.current?.focus()
  }, [])

  return (
    <div className="input-bar">
      <div className="input-bar__inner">
        <textarea
          ref={textareaRef}
          className="input-bar__textarea"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask anything about EKA's HR policies…"
          rows={1}
          disabled={disabled}
          aria-label="Message input"
        />

        {streaming ? (
          <button
            className="input-bar__btn input-bar__btn--stop"
            onClick={onStop}
            aria-label="Stop generating"
          >
            <StopIcon />
          </button>
        ) : (
          <button
            className="input-bar__btn input-bar__btn--send"
            onClick={onSend}
            disabled={!input.trim() || disabled}
            aria-label="Send message"
          >
            <SendIcon />
          </button>
        )}
      </div>

      <p className="input-bar__hint">
        Enter to send &nbsp;·&nbsp; Shift + Enter for new line
      </p>
    </div>
  )
}

function SendIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="22" y1="2" x2="11" y2="13" />
      <polygon points="22 2 15 22 11 13 2 9 22 2" />
    </svg>
  )
}

function StopIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
      <rect x="4" y="4" width="16" height="16" rx="2" />
    </svg>
  )
}