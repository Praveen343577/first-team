export default function TypingIndicator() {
  return (
    <div className="bubble-row bubble-row--assistant">
      <div className="avatar avatar--assistant">HR</div>
      <div className="bubble-content">
        <div className="bubble bubble--assistant typing-bubble">
          <span className="dot" style={{ animationDelay: '0ms' }} />
          <span className="dot" style={{ animationDelay: '160ms' }} />
          <span className="dot" style={{ animationDelay: '320ms' }} />
        </div>
      </div>
    </div>
  )
}