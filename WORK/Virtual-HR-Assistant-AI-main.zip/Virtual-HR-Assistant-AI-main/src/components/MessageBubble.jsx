import { useState } from 'react'

// Strip <think>...</think> blocks from model output
function parseContent(content) {
  const thinkMatch = content.match(/^<think>([\s\S]*?)<\/think>([\s\S]*)$/s)
  if (thinkMatch) {
    return { think: thinkMatch[1].trim(), reply: thinkMatch[2].trim() }
  }
  // Still inside think block (streaming)
  const partialThink = content.match(/^<think>([\s\S]*)$/s)
  if (partialThink) {
    return { think: partialThink[1], reply: null, partial: true }
  }
  return { think: null, reply: content }
}

export default function MessageBubble({ message, isStreaming }) {
  const [thinkOpen, setThinkOpen] = useState(false)
  const isUser = message.role === 'user'
  const { think, reply, partial } = parseContent(message.content)

  return (
    <div className={`bubble-row ${isUser ? 'bubble-row--user' : 'bubble-row--assistant'}`}>

      {/* Avatar */}
      <div className={`avatar ${isUser ? 'avatar--user' : 'avatar--assistant'}`}>
        {isUser ? 'You' : 'HR'}
      </div>

      <div className="bubble-content">

        {/* Thinking block — collapsible */}
        {think && !partial && (
          <div className="think-block">
            <button className="think-toggle" onClick={() => setThinkOpen(o => !o)}>
              <span className="think-icon">{thinkOpen ? '▾' : '▸'}</span>
              <span>Reasoning ({think.split(/\s+/).length} words)</span>
            </button>
            {thinkOpen && (
              <div className="think-body">{think}</div>
            )}
          </div>
        )}

        {/* Thinking in progress */}
        {partial && (
          <div className="think-block">
            <div className="think-toggle think-toggle--active">
              <span className="think-icon">◌</span>
              <span>Thinking...</span>
            </div>
          </div>
        )}

        {/* Main message bubble */}
        {reply !== null && (
          <div className={`bubble ${isUser ? 'bubble--user' : 'bubble--assistant'}`}>
            {reply || (isStreaming ? '' : '…')}
            {isStreaming && !partial && (
              <span className="cursor" aria-hidden="true" />
            )}
          </div>
        )}

      </div>
    </div>
  )
}