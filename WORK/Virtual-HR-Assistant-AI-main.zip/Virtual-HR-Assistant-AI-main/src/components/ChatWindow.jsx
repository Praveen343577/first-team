import { useEffect, useRef } from 'react'
import MessageBubble from './MessageBubble'
import TypingIndicator from './TypingIndicator'

const SUGGESTED_QUESTIONS = [
  'How many casual leaves do I get per year?',
  'What is the notice period for confirmed employees?',
  'How does the ESOP 2025 vesting work?',
  'What is the maternity leave policy?',
  'How do I raise a grievance?',
  'What is the dress code policy?',
]

export default function ChatWindow({ messages, streaming, ollamaStatus, onSuggestionClick }) {
  const bottomRef = useRef(null)
  const containerRef = useRef(null)

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const isEmpty = messages.length === 0

  // Show typing indicator only when streaming has started
  // but the last assistant message is still empty
  const lastMsg = messages[messages.length - 1]
  const showTyping = streaming && lastMsg?.role === 'assistant' && lastMsg?.content === ''

  return (
    <div className="chat-window" ref={containerRef}>

      {/* Connection error banner */}
      {ollamaStatus.ok === false && (
        <div className="status-banner status-banner--error">
          ⚠️ &nbsp;{ollamaStatus.error}
        </div>
      )}

      {/* Empty state */}
      {isEmpty ? (
        <div className="empty-state">
          <div className="empty-state__logo">
            <span className="empty-state__eka">eka</span>
            <span className="empty-state__hr">HR Assistant</span>
          </div>
          <p className="empty-state__subtitle">
            Ask me anything about EKA's policies — leaves, ESOP, benefits, conduct, and more.
          </p>

          <div className="suggestions">
            {SUGGESTED_QUESTIONS.map((q, i) => (
              <button
                key={i}
                className="suggestion-chip"
                onClick={() => onSuggestionClick(q)}
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="messages">
          {messages.map((msg, i) => (
            <MessageBubble
              key={i}
              message={msg}
              isStreaming={streaming && i === messages.length - 1 && msg.role === 'assistant'}
            />
          ))}

          {showTyping && <TypingIndicator />}

          <div ref={bottomRef} />
        </div>
      )}

    </div>
  )
}