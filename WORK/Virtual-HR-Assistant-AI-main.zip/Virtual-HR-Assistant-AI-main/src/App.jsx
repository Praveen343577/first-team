import { useChat } from './hooks/useChat'
import ChatWindow from './components/ChatWindow'
import InputBar from './components/InputBar'

const styles = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=Syne:wght@700;800&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:           #f5f4f0;
    --surface:      #ffffff;
    --surface2:     #eeede8;
    --border:       #dddcd7;
    --accent:       #1a56db;
    --accent-light: #e8effe;
    --accent-dark:  #1240aa;
    --text:         #1a1a1a;
    --text-muted:   #7a7a6e;
    --text-light:   #a8a89c;
    --user-bg:      #1a56db;
    --user-text:    #ffffff;
    --ai-bg:        #ffffff;
    --ai-border:    #dddcd7;
    --error-bg:     #fff1f0;
    --error-border: #ffa39e;
    --error-text:   #cf1322;
    --font-body:    'DM Sans', sans-serif;
    --font-display: 'Syne', sans-serif;
    --radius:       14px;
    --radius-sm:    8px;
    --shadow:       0 1px 3px rgba(0,0,0,0.08), 0 4px 16px rgba(0,0,0,0.04);
    --shadow-lg:    0 4px 24px rgba(0,0,0,0.10);
  }

  html, body, #root {
    height: 100%;
    font-family: var(--font-body);
    background: var(--bg);
    color: var(--text);
    font-size: 15px;
    line-height: 1.6;
    -webkit-font-smoothing: antialiased;
  }

  /* ── LAYOUT ─────────────────────────────────────────────────── */
  .app {
    display: flex;
    flex-direction: column;
    height: 100vh;
    max-width: 820px;
    margin: 0 auto;
    background: var(--surface);
    box-shadow: var(--shadow-lg);
  }

  /* ── HEADER ─────────────────────────────────────────────────── */
  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 24px;
    border-bottom: 1px solid var(--border);
    background: var(--surface);
    flex-shrink: 0;
  }

  .header__brand {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .header__logo {
    width: 36px;
    height: 36px;
    background: var(--accent);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: var(--font-display);
    font-size: 13px;
    font-weight: 800;
    color: white;
    letter-spacing: -0.5px;
  }

  .header__title {
    font-family: var(--font-display);
    font-size: 17px;
    font-weight: 800;
    color: var(--text);
    letter-spacing: -0.3px;
  }

  .header__title span {
    color: var(--accent);
  }

  .header__subtitle {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 1px;
  }

  .header__actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .header__status {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: var(--text-muted);
    padding: 5px 10px;
    background: var(--surface2);
    border-radius: 20px;
  }

  .header__status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--text-light);
    flex-shrink: 0;
  }

  .header__status-dot--online  { background: #52c41a; }
  .header__status-dot--offline { background: #ff4d4f; }
  .header__status-dot--checking {
    background: #faad14;
    animation: pulse 1.2s ease-in-out infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50%       { opacity: 0.3; }
  }

  .clear-btn {
    background: none;
    border: 1px solid var(--border);
    color: var(--text-muted);
    font-family: var(--font-body);
    font-size: 12px;
    padding: 5px 12px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.15s;
  }

  .clear-btn:hover {
    border-color: var(--accent);
    color: var(--accent);
  }

  /* ── CHAT WINDOW ─────────────────────────────────────────────── */
  .chat-window {
    flex: 1;
    overflow-y: auto;
    padding: 24px 24px 8px;
    display: flex;
    flex-direction: column;
    scroll-behavior: smooth;
  }

  .chat-window::-webkit-scrollbar       { width: 5px; }
  .chat-window::-webkit-scrollbar-track { background: transparent; }
  .chat-window::-webkit-scrollbar-thumb { background: var(--border); border-radius: 10px; }

  .status-banner {
    padding: 10px 14px;
    border-radius: var(--radius-sm);
    font-size: 13px;
    margin-bottom: 16px;
    flex-shrink: 0;
  }

  .status-banner--error {
    background: var(--error-bg);
    border: 1px solid var(--error-border);
    color: var(--error-text);
  }

  /* ── EMPTY STATE ─────────────────────────────────────────────── */
  .empty-state {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 40px 20px;
    gap: 16px;
  }

  .empty-state__logo {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
  }

  .empty-state__eka {
    font-family: var(--font-display);
    font-size: 48px;
    font-weight: 800;
    color: var(--accent);
    letter-spacing: -2px;
    line-height: 1;
  }

  .empty-state__hr {
    font-size: 13px;
    font-weight: 500;
    color: var(--text-muted);
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .empty-state__subtitle {
    font-size: 14px;
    color: var(--text-muted);
    max-width: 380px;
    line-height: 1.6;
  }

  .suggestions {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    justify-content: center;
    max-width: 600px;
    margin-top: 8px;
  }

  .suggestion-chip {
    background: var(--surface);
    border: 1px solid var(--border);
    color: var(--text);
    font-family: var(--font-body);
    font-size: 13px;
    padding: 8px 14px;
    border-radius: 20px;
    cursor: pointer;
    transition: all 0.15s;
    text-align: left;
  }

  .suggestion-chip:hover {
    background: var(--accent-light);
    border-color: var(--accent);
    color: var(--accent);
  }

  /* ── MESSAGES ────────────────────────────────────────────────── */
  .messages {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .bubble-row {
    display: flex;
    gap: 12px;
    animation: fadeUp 0.2s ease;
  }

  @keyframes fadeUp {
    from { opacity: 0; transform: translateY(8px); }
    to   { opacity: 1; transform: translateY(0); }
  }

  .bubble-row--user      { flex-direction: row-reverse; }
  .bubble-row--assistant { flex-direction: row; }

  .avatar {
    width: 34px;
    height: 34px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 11px;
    font-weight: 600;
    flex-shrink: 0;
    margin-top: 2px;
    letter-spacing: 0.02em;
  }

  .avatar--user      { background: var(--user-bg); color: white; }
  .avatar--assistant { background: var(--accent-light); color: var(--accent); }

  .bubble-content {
    display: flex;
    flex-direction: column;
    gap: 6px;
    max-width: 75%;
  }

  .bubble-row--user .bubble-content { align-items: flex-end; }

  .bubble {
    padding: 12px 16px;
    border-radius: var(--radius);
    font-size: 14px;
    line-height: 1.65;
    white-space: pre-wrap;
    word-break: break-word;
  }

  .bubble--user {
    background: var(--user-bg);
    color: var(--user-text);
    border-bottom-right-radius: 4px;
  }

  .bubble--assistant {
    background: var(--ai-bg);
    color: var(--text);
    border: 1px solid var(--ai-border);
    border-bottom-left-radius: 4px;
    box-shadow: var(--shadow);
  }

  /* ── THINK BLOCK ─────────────────────────────────────────────── */
  .think-block {
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    overflow: hidden;
    max-width: 100%;
  }

  .think-toggle {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 7px 12px;
    background: none;
    border: none;
    font-family: var(--font-body);
    font-size: 12px;
    color: var(--text-muted);
    cursor: pointer;
    width: 100%;
    text-align: left;
    transition: color 0.15s;
  }

  .think-toggle:hover    { color: var(--accent); }
  .think-toggle--active  { color: var(--accent); cursor: default; }

  .think-icon { font-size: 10px; }

  .think-body {
    padding: 8px 12px 10px;
    font-size: 12px;
    color: var(--text-muted);
    line-height: 1.6;
    white-space: pre-wrap;
    border-top: 1px solid var(--border);
  }

  /* ── TYPING INDICATOR ────────────────────────────────────────── */
  .typing-bubble {
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 14px 16px;
    min-width: 60px;
  }

  .dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--text-light);
    animation: bounce 1.1s ease-in-out infinite;
  }

  @keyframes bounce {
    0%, 80%, 100% { transform: translateY(0);    opacity: 0.4; }
    40%            { transform: translateY(-6px); opacity: 1; }
  }

  /* ── CURSOR ──────────────────────────────────────────────────── */
  .cursor {
    display: inline-block;
    width: 2px;
    height: 15px;
    background: var(--accent);
    margin-left: 3px;
    vertical-align: middle;
    border-radius: 1px;
    animation: blink 0.8s step-end infinite;
  }

  @keyframes blink {
    50% { opacity: 0; }
  }

  /* ── INPUT BAR ───────────────────────────────────────────────── */
  .input-bar {
    padding: 16px 24px 20px;
    border-top: 1px solid var(--border);
    background: var(--surface);
    flex-shrink: 0;
  }

  .input-bar__inner {
    display: flex;
    align-items: flex-end;
    gap: 10px;
    background: var(--surface2);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 10px 10px 10px 16px;
    transition: border-color 0.15s, box-shadow 0.15s;
  }

  .input-bar__inner:focus-within {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(26, 86, 219, 0.08);
  }

  .input-bar__textarea {
    flex: 1;
    background: none;
    border: none;
    outline: none;
    font-family: var(--font-body);
    font-size: 14px;
    color: var(--text);
    resize: none;
    line-height: 1.5;
    min-height: 24px;
    max-height: 160px;
  }

  .input-bar__textarea::placeholder { color: var(--text-light); }
  .input-bar__textarea:disabled     { opacity: 0.5; cursor: not-allowed; }

  .input-bar__btn {
    width: 36px;
    height: 36px;
    border-radius: var(--radius-sm);
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    flex-shrink: 0;
    transition: all 0.15s;
  }

  .input-bar__btn--send {
    background: var(--accent);
    color: white;
  }

  .input-bar__btn--send:hover:not(:disabled) {
    background: var(--accent-dark);
    transform: scale(1.05);
  }

  .input-bar__btn--send:disabled {
    background: var(--border);
    color: var(--text-light);
    cursor: not-allowed;
  }

  .input-bar__btn--stop {
    background: #ff4d4f;
    color: white;
  }

  .input-bar__btn--stop:hover { background: #d9363e; }

  .input-bar__hint {
    font-size: 11px;
    color: var(--text-light);
    margin-top: 8px;
    text-align: center;
    letter-spacing: 0.02em;
  }
`

export default function App() {
  const {
    messages,
    input,
    setInput,
    streaming,
    ollamaStatus,
    send,
    stop,
    clearChat,
    handleKeyDown,
  } = useChat()

  // Status dot state
  const statusDot =
    ollamaStatus.ok === null  ? 'checking' :
    ollamaStatus.ok === true  ? 'online'   : 'offline'

  const statusText =
    ollamaStatus.ok === null  ? 'Connecting…' :
    ollamaStatus.ok === true  ? 'qwen3:14b ready' : 'Ollama offline'

  return (
    <>
      <style>{styles}</style>

      <div className="app">
        {/* ── HEADER ── */}
        <header className="header">
          <div className="header__brand">
            <div className="header__logo">eka</div>
            <div>
              <div className="header__title">EKA <span>HR</span> Assistant</div>
              <div className="header__subtitle">Pinnacle Mobility Solutions Pvt. Ltd.</div>
            </div>
          </div>

          <div className="header__actions">
            <div className="header__status">
              <div className={`header__status-dot header__status-dot--${statusDot}`} />
              {statusText}
            </div>
            {messages.length > 0 && (
              <button className="clear-btn" onClick={clearChat}>
                Clear chat
              </button>
            )}
          </div>
        </header>

        {/* ── CHAT WINDOW ── */}
        <ChatWindow
          messages={messages}
          streaming={streaming}
          ollamaStatus={ollamaStatus}
          onSuggestionClick={(q) => send(q)}
        />

        {/* ── INPUT BAR ── */}
        <InputBar
          input={input}
          setInput={setInput}
          streaming={streaming}
          onSend={send}
          onStop={stop}
          handleKeyDown={handleKeyDown}
          disabled={ollamaStatus.ok === false}
        />
      </div>
    </>
  )
}