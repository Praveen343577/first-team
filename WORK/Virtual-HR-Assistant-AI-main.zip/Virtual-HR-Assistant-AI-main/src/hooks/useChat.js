import { useState, useEffect, useRef, useCallback } from 'react'
import { streamChat, checkOllama } from '../utils/ollama'
import SYSTEM_PROMPT from '../constants/prompts'

/**
 * useChat — manages all chat state and logic
 *
 * Returns:
 *   messages       — array of { role, content }
 *   input          — current input string
 *   setInput       — update input
 *   streaming      — boolean, true while model is generating
 *   ollamaStatus   — { ok, error } connection status
 *   send           — function to send a message
 *   stop           — function to abort current stream
 *   clearChat      — reset conversation
 */
export function useChat() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [streaming, setStreaming] = useState(false)
  const [ollamaStatus, setOllamaStatus] = useState({ ok: null, error: null })

  const abortRef = useRef(null)

  // ── Check Ollama on mount ──────────────────────────────────────────────────
  useEffect(() => {
    checkOllama().then(status => setOllamaStatus(status))
  }, [])

  // ── Send message ──────────────────────────────────────────────────────────
  const send = useCallback(async (textOverride) => {
    const text = (textOverride ?? input).trim()
    if (!text || streaming) return

    // Add user message to history
    const userMsg = { role: 'user', content: text }
    const updatedHistory = [...messages, userMsg]
    setMessages(updatedHistory)
    setInput('')
    setStreaming(true)

    // Placeholder for assistant response
    const assistantIndex = updatedHistory.length
    setMessages(prev => [...prev, { role: 'assistant', content: '' }])

    // Build messages array for Ollama:
    // system prompt first, then full conversation history
    const apiMessages = [
      { role: 'system', content: SYSTEM_PROMPT },
      ...updatedHistory
    ]

    const controller = new AbortController()
    abortRef.current = controller

    try {
      await streamChat(
        apiMessages,
        (chunk) => {
          // Append each streamed chunk to the assistant message
          setMessages(prev => {
            const updated = [...prev]
            updated[assistantIndex] = {
              role: 'assistant',
              content: updated[assistantIndex].content + chunk
            }
            return updated
          })
        },
        controller.signal
      )
    } catch (err) {
      if (err.name === 'AbortError') {
        // User stopped — keep whatever was streamed so far
        return
      }

      // Real error — remove the empty assistant placeholder and show error
      setMessages(prev => {
        const updated = [...prev]
        updated[assistantIndex] = {
          role: 'assistant',
          content: err.message.includes('Failed to fetch')
            ? '⚠️ Cannot connect to Ollama. Make sure `ollama serve` is running.'
            : `⚠️ Error: ${err.message}`
        }
        return updated
      })

      // Re-check Ollama status after an error
      checkOllama().then(status => setOllamaStatus(status))
    } finally {
      setStreaming(false)
      abortRef.current = null
    }
  }, [input, messages, streaming])

  // ── Stop streaming ────────────────────────────────────────────────────────
  const stop = useCallback(() => {
    abortRef.current?.abort()
    setStreaming(false)
  }, [])

  // ── Clear conversation ────────────────────────────────────────────────────
  const clearChat = useCallback(() => {
    if (streaming) abortRef.current?.abort()
    setMessages([])
    setInput('')
    setStreaming(false)
  }, [streaming])

  // ── Keyboard shortcut: Enter to send ─────────────────────────────────────
  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }, [send])

  return {
    messages,
    input,
    setInput,
    streaming,
    ollamaStatus,
    send,
    stop,
    clearChat,
    handleKeyDown,
  }
}