const OLLAMA_BASE_URL = '/ollama'
const MODEL = 'qwen3:14b'

/**
 * Send a chat request to Ollama with streaming.
 * @param {Array} messages - Full conversation history [{ role, content }]
 * @param {Function} onChunk - Called with each text chunk as it streams in
 * @param {AbortSignal} signal - AbortController signal to cancel the request
 */
export async function streamChat(messages, onChunk, signal) {
  const response = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    signal,
    body: JSON.stringify({
      model: MODEL,
      messages,
      stream: true,
      options: {
        num_ctx: 32768,
        temperature: 0.3,
        top_p: 0.8,
      }
    })
  })

  if (!response.ok) {
    const err = await response.text()
    throw new Error(`Ollama error ${response.status}: ${err}`)
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    const chunk = decoder.decode(value, { stream: true })
    const lines = chunk.split('\n').filter(Boolean)

    for (const line of lines) {
      try {
        const json = JSON.parse(line)
        if (json.message?.content) {
          onChunk(json.message.content)
        }
      } catch {
        // incomplete JSON chunk, skip
      }
    }
  }
}

/**
 * Check if Ollama is running and the model is available.
 * Returns { ok: true } or { ok: false, error: string }
 */
export async function checkOllama() {
  try {
    const res = await fetch(`${OLLAMA_BASE_URL}/api/tags`, {
      signal: AbortSignal.timeout(5000)
    })
    if (!res.ok) return { ok: false, error: 'Ollama is not responding.' }

    const data = await res.json()
    const models = data.models?.map(m => m.name) || []
    const hasModel = models.some(m => m.startsWith('qwen3:14b'))

    if (!hasModel) {
      return {
        ok: false,
        error: `Model qwen3:14b not found. Run: ollama pull qwen3:14b`
      }
    }

    return { ok: true }
  } catch (e) {
    return {
      ok: false,
      error: 'Cannot connect to Ollama. Make sure it is running.'
    }
  }
}

export { MODEL }