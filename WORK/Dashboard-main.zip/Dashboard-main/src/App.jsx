import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { LoginPage } from "./features/auth/LoginPage";
import { DashboardLayout } from "./layouts/DashboardLayout";
import { ProtectedRoute } from "./routes/ProtectedRoute"; // Import the guard
import DataValidation from "./layouts/Datavalidation";
// Mock Component
const DashboardHome = () => (
  <div className="glass-panel p-12 text-center text-slate-500 rounded-xl border border-slate-700">
    <p>Dashboard Home Loaded</p>
  </div>
);

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />

        {/* Wrap Dashboard in ProtectedRoute */}
        <Route element={<ProtectedRoute />}>
          <Route path="/" element={<DashboardLayout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardHome />} />
            <Route path="dataValidation" element={<DataValidation />} />
            {/* Other protected routes go here */}
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
