/*
 * TableProvider.jsx
 * * PURPOSE:
 * 1. Manages the global state for all tables in the application.
 * 2. Provides functions to register tables, update their settings, and migrate settings between them.
 * 3. Wraps the application (or dashboard) to provide these capabilities to children.
 */

import { useState, useCallback } from 'react';
import { TableContext, defaultState } from './TableContext'; // Import from the split file

export const TableProvider = ({ children }) => {
  // State Registry: Stores configuration for every table keyed by their unique 'tableId'.
  // Structure: { "active-fleet": { sortConfig: {...}, activeFilters: {...} }, ... }
  const [tableStates, setTableStates] = useState({});

  // ----------------------------------------------------------------
  // Function: registerTable
  // Purpose: Initializes a new entry in the registry for a table if it doesn't exist.
  // ----------------------------------------------------------------
  const registerTable = useCallback((tableId) => {
    setTableStates(prev => {
      // If table already exists, do nothing (idempotent)
      if (prev[tableId]) return prev;
      
      // Otherwise, initialize with default state
      return { ...prev, [tableId]: defaultState };
    });
  }, []); 

  // ----------------------------------------------------------------
  // Function: setTableConfig
  // Purpose: Updates the sort or filter configuration for a specific table.
  // params: 
  //   - tableId: string
  //   - newConfig: object (partial update, e.g., only { sortConfig: ... })
  // ----------------------------------------------------------------
  const setTableConfig = useCallback((tableId, newConfig) => {
    setTableStates(prev => ({
      ...prev,
      [tableId]: { 
        ...(prev[tableId] || defaultState), // Merge with existing or default
        ...newConfig                       // Overwrite with new values
      }
    }));
  }, []);

  // ----------------------------------------------------------------
  // Function: migrateSelections
  // Purpose: The "Apply to All" feature. Copies the state of the Source table
  //          to ALL other registered tables in the registry.
  // ----------------------------------------------------------------
  const migrateSelections = useCallback((sourceTableId) => {
    setTableStates(prev => {
      const sourceState = prev[sourceTableId];
      if (!sourceState) return prev; // Safety check if source doesn't exist

      const newRegistry = {};

      // Iterate through all known tables
      Object.keys(prev).forEach(targetId => {
        if (targetId === sourceTableId) {
          // Leave the source table exactly as is
          newRegistry[targetId] = sourceState;
        } else {
          // For all other tables, deep copy the Source's configuration.
          // We create new Sets to ensure one table's mutation doesn't affect another later.
          newRegistry[targetId] = {
            sortConfig: { ...sourceState.sortConfig },
            activeFilters: {
              types: new Set(sourceState.activeFilters.types),
              fleets: new Set(sourceState.activeFilters.fleets),
              providers: new Set(sourceState.activeFilters.providers),
              timeRanges: new Set(sourceState.activeFilters.timeRanges || [])
            }
          };
        }
      });

      return newRegistry;
    });
  }, []);

  // ----------------------------------------------------------------
  // Function: getTableConfig
  // Purpose: Selector to retrieve state for a specific table.
  // ----------------------------------------------------------------
  const getTableConfig = useCallback((tableId) => {
    return tableStates[tableId] || defaultState;
  }, [tableStates]);

  // Expose all functions and state via the Provider
  return (
    <TableContext.Provider value={{
      registerTable,
      setTableConfig,
      migrateSelections,
      getTableConfig
    }}>
      {children}
    </TableContext.Provider>
  );
};