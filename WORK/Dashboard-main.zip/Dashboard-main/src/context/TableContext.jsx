/*
 * TableContext.jsx
 * * PURPOSE:
 * 1. Creates the React Context object.
 * 2. Defines the 'defaultState' constant used across the provider and consumers.
 * 3. Exports a custom hook 'useTableContext' for easy access to the context.
 */

import { createContext, useContext } from 'react';

// 1. Define the Context Object
export const TableContext = createContext(null);

// 2. Define Shared Constants
// This state object is used to initialize new tables and fallback for unregistered ones.
// It is kept outside the component to ensure referential stability.
export const defaultState = {
  sortConfig: { 
    key: null, 
    direction: 'asc' 
  },
  activeFilters: { 
    types: new Set(), 
    fleets: new Set(), 
    providers: new Set(), 
    timeRanges: new Set()
  }
};

// 3. Custom Hook for Consumption
// Components use this hook to access the context data safely.
export const useTableContext = () => {
  const context = useContext(TableContext);
  
  if (!context) {
    throw new Error('useTableContext must be used within a TableProvider');
  }
  
  return context;
};