import { Navigate, Outlet } from 'react-router-dom';

export const ProtectedRoute = () => {
  // Simple check: exists in localStorage?
  // In a real app, you'd check a Context or Redux state
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <Outlet />;
};