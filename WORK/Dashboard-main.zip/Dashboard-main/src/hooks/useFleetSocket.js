import { useState, useEffect, useRef } from 'react';

// Determines vehicle state (Active/Inactive/NoGPS) based on raw telemetry
const calculateMode = (vehicle) => {
  const lat = parseFloat(vehicle.latitude);
  const lng = parseFloat(vehicle.longitude);
  // const speed = parseFloat(vehicle.speed);

  // Priority 1: Movement. If it's moving, it's active regardless of GPS quality.
  // if (speed > 20) return 'active';
  // if (speed > -1) return 'active';
  
  if (vehicle.isConnected === true) return 'active';
  
  // Priority 2: Data Integrity. If GPS is 0,0, we classify as NoGPS to warn users.
  if (isNaN(lat) || isNaN(lng) || lat === 0 || lng === 0) return 'nogps';
  
  // Default: Stopped but with valid location.
  return 'inactive';
};

export const useFleetSocket = () => {
  const [vehicles, setVehicles] = useState([]);
  const [status, setStatus] = useState('disconnected');
  const ws = useRef(null);

  // ARCHITECTURAL DECISION: Static Data Reference
  // Why useRef instead of useState?
  // 1. Performance: This data (VRN, Fleet, Chassis) never changes during the session.
  //    Putting it in state would cause unnecessary re-renders if we updated it.
  // 2. Lookup Speed: A Map provides O(1) access complexity. When the WebSocket floods us 
  //    with updates, we need to find the matching static details instantly without looping.
  const vehicleDetailsRef = useRef(new Map());

  useEffect(() => {

    // PHASE 1: PRE-LOAD STATIC CONTEXT
    // How: We fetch the full registry of devices from the HTTP API first.
    // Why: The WebSocket stream is lean; it only sends telemetry (speed, loc) to save bandwidth.
    //      It does NOT send human-readable names like "Fleet A" or "Chassis #123".
    //      We need this "Dictionary" ready before the live stream starts so we can label the dots.
    const fetchStaticData = async () => {
      try {
        const apiUrl = import.meta.env.VITE_API_URL;
        const res = await fetch(`${apiUrl}/devices/?username=test@gmail.com`);
        const data = await res.json();
        
        // How: Store in the Ref Map keyed by Device ID.
        // Why: We do NOT call setVehicles() here. 
        //      If we did, we would show hundreds of "Ghost Vehicles" (provisioned but offline)
        //      that would clutter the dashboard with empty data.
        //      By storing in a Ref, we wait until the socket *confirms* a vehicle is alive.
        data.forEach(d => {
          vehicleDetailsRef.current.set(d.device_id, {
            vrn: d.VRN,
            chassisNumber: d.chassis_number,
            deviceTypeName: d.device_type_name,
            fleet: d.fleet,
            city: d.city
          });
        });

        // Initialize state with these devices (even before WS connects)
        setVehicles(data.map(d => ({
          imei: d.device_id,
          name: d.VRN || d.chassis_number,
          vrn: d.VRN,
          chassisNumber: d.chassis_number,
          deviceTypeName: d.device_type_name,
          fleet: d.fleet,
          // [MODIFIED]: Explicitly set null/defaults for missing socket data
          latitude: null,   
          longitude: null,  
          speed: 0, 
          soc: 0, 
          mode: 'inactive',
          lastTimestamp: null // Add this so we can check if it exists later
        })));

      } catch (err) {
        console.error("Failed to fetch static fleet data:", err);
      }
    };

    fetchStaticData();


    // PHASE 2: CONNECT TO LIVE STREAM
    // How: Standard WebSocket connection with auto-reconnect logic.
    const connect = () => {
      setStatus('connecting');

      const url = import.meta.env.VITE_WS_URL || 'ws://192.168.24.130:8002/ws/live-data/';
      ws.current = new WebSocket(url);

      ws.current.onopen = () => {
        setStatus('connected');
        
        // How: Send an immediate auth frame.
        // Why: The backend requires this to identify which tenant's data to stream.
        const handshakeMsg = { username: "test@gmail.com" };
        ws.current.send(JSON.stringify(handshakeMsg));
      };

      ws.current.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          
          // Filter out control messages (like "Connection Established")
          if (payload.message) return;

          // Normalize payload: The server sometimes sends a single object, sometimes an array.
          const updates = Array.isArray(payload) ? payload : (payload.data || [payload]);

          setVehicles(prevVehicles => {
            // How: Map existing state by IMEI for quick merging.
            // Why: We must preserve the state of vehicles that *aren't* in this specific update packet
            //      but were received previously.
            const vehicleMap = new Map(prevVehicles.map(v => [v.imei, v]));
            
            updates.forEach(data => {
              // Standardize ID: Backend sometimes uses 'device_id', sometimes 'imei'.
              const id = data.device_id || data.imei; 
              if (!id) return;

              // LAZY HYDRATION STRATEGY
              // How: We grab the static details from our Ref using the ID.
              // Why: This merges the "Best of Both Worlds":
              //      - Speed/Location from WebSocket (Live)
              //      - Name/Fleet from API (Rich Context)
              //      - If a vehicle is in the static list but NOT the socket, it never enters this loop
              //        and thus never appears in the UI (solving the "Ghost Vehicle" issue).
              const staticDetail = vehicleDetailsRef.current.get(id) || {};
              
              // Get previous state if it exists (to prevent jitter if a field is missing in this specific packet)
              const existing = vehicleMap.get(id) || {};

              // Parse numbers safely once to avoid NaN errors downstream
              const parsedLat = parseFloat(data.latitude);
              const parsedLng = parseFloat(data.longitude);
              const parsedSpeed = parseFloat(data.speed);

              const newVehicle = {
                // Base: Keep existing data (prevents flickering if a field is dropped)
                ...existing,
                // Merge: Apply the rich static data (Name, Fleet, Type)
                ...staticDetail,
                
                imei: id,
                // Display Logic: Prefer VRN, fallback to Chassis, fallback to raw IMEI
                name: staticDetail.vrn || staticDetail.chassisNumber || id, 
                
                // --- LIVE TELEMETRY MERGE ---
                // Why fallbacks? Sometimes the socket sends partial updates. 
                // We keep the old valid value (existing.X) instead of overwriting with 0 or null.
                
                latitude: !isNaN(parsedLat) ? parsedLat : (existing.latitude || 0),
                longitude: !isNaN(parsedLng) ? parsedLng : (existing.longitude || 0),
                speed: !isNaN(parsedSpeed) ? parsedSpeed : (existing.speed || 0),
                heading: parseFloat(data.heading) || existing.heading || 0,
                
                // Case-insensitive checks because backend inconsistency (soc vs SOC)
                soc: data.soc ?? data.SOC ?? existing.soc ?? 0,
                dte: data.dte ?? data.DTE ?? existing.dte ?? 0,
                cellTemp: data.ts ?? data.TS ?? data.cell_temp ?? existing.cellTemp ?? 0,
                odometer: parseFloat(data.odometer) || existing.odometer || 0,
                
                lastTimestamp: data.timestamp || data.last_timestamp || new Date().toISOString(),
                isConnected: data.is_connected ?? existing.isConnected ?? false,
              };

              // Recalculate derived status on every update
              newVehicle.mode = calculateMode(newVehicle);
              
              // Add/Update the map. 
              // This is where "Only WebSocket Vehicles" get added to the state.
              vehicleMap.set(id, newVehicle);
            });

            return Array.from(vehicleMap.values());
          });
        } catch (err) {
          console.error('Socket parse error:', err);
        }
      };

      ws.current.onclose = () => {
        setStatus('disconnected');
        // Why: Exponential backoff or simple delay prevents hammering the server if it goes down.
        setTimeout(connect, 3000); 
      };

      ws.current.onerror = (err) => {
        console.error('Socket error:', err);
        ws.current.close();
      };
    };

    connect();

    // Cleanup: Close socket on unmount to prevent memory leaks/zombie connections
    return () => {
      if (ws.current) ws.current.close();
    };
  }, []);

  return { vehicles, status };
};