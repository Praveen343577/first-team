import React, { useState, useEffect, useMemo, useRef } from "react";
import "./DataValidation.css";

const DataValidation = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [apiError, setApiError] = useState(null);

  // Filters state
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFleet, setSelectedFleet] = useState("");
  const [selectedFaults, setSelectedFaults] = useState([]); // New Filter State
  const [isFaultDropdownOpen, setIsFaultDropdownOpen] = useState(false); // UI State

  // Expanded rows state
  const [expandedRows, setExpandedRows] = useState({});

  // Ref for closing dropdown when clicking outside
  const dropdownRef = useRef(null);

  // 1. Fetch Data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("http://192.168.24.136:8000/results");
        if (!response.ok) throw new Error(`Error: ${response.status}`);
        const result = await response.json();
        const errorOnlyData = result.filter(
          (item) => item.errors_json && item.errors_json.length > 0,
        );
        setData(errorOnlyData);
        setLoading(false);
      } catch (err) {
        setApiError(err.message);
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Close dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsFaultDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // 3. Toggle Row Logic
  const toggleRow = (id) => {
    setExpandedRows((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // --- DYNAMIC DATA EXTRACTION ---

  // Extract Unique Fleets
  const uniqueFleets = useMemo(
    () => [...new Set(data.map((item) => item.fleet))],
    [data],
  );

  // Extract Unique Fault Messages (Optimized)
  const uniqueFaultMessages = useMemo(() => {
    const faultsSet = new Set();
    data.forEach((row) => {
      if (row.errors_json) {
        row.errors_json.forEach((err) => faultsSet.add(err.message));
      }
    });
    return Array.from(faultsSet).sort();
  }, [data]);

  // --- FILTERING LOGIC ---

  const filteredData = useMemo(() => {
    return data.filter((item) => {
      const term = searchTerm.toLowerCase();

      // 1. Search Filter
      const matchesSearch =
        item.VRN.toLowerCase().includes(term) || item.device_id.includes(term);

      // 2. Fleet Filter
      const matchesFleet = selectedFleet ? item.fleet === selectedFleet : true;

      // 3. Fault Multi-Select Filter
      // If nothing selected, return true (show all).
      // If selected, check if row has ANY of the selected faults.
      let matchesFaults = true;
      if (selectedFaults.length > 0) {
        const rowErrors = item.errors_json.map((e) => e.message);
        matchesFaults = rowErrors.some((msg) => selectedFaults.includes(msg));
      }

      return matchesSearch && matchesFleet && matchesFaults;
    });
  }, [data, searchTerm, selectedFleet, selectedFaults]);

  // Handler for Checkbox changes
  const handleFaultChange = (fault) => {
    setSelectedFaults((prev) => {
      if (prev.includes(fault)) {
        return prev.filter((f) => f !== fault); // Uncheck
      } else {
        return [...prev, fault]; // Check
      }
    });
  };

  if (loading)
    return <div className="dv-loading">Loading Validation Data...</div>;
  if (apiError) return <div className="dv-error">API Error: {apiError}</div>;

  return (
    <div className="dv-container">
      <div className="dv-header">
        <h2>Data Validation Errors</h2>
        <span className="dv-count-badge">
          {filteredData.length} Faulty Devices Found
        </span>
      </div>

      {/* --- Filter Toolbar --- */}
      <div className="dv-filter-bar">
        {/* Search Input */}
        <input
          type="text"
          className="dv-input"
          placeholder="Search VRN or Device ID..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />

        {/* Fleet Select */}
        <select
          className="dv-select"
          value={selectedFleet}
          onChange={(e) => setSelectedFleet(e.target.value)}
        >
          <option value="">All Fleets</option>
          {uniqueFleets.map((fleet) => (
            <option key={fleet} value={fleet}>
              {fleet}
            </option>
          ))}
        </select>

        {/* --- Multi-Select Fault Filter --- */}
        <div className="dv-multiselect-container" ref={dropdownRef}>
          <div
            className="dv-input dv-multiselect-btn"
            onClick={() => setIsFaultDropdownOpen(!isFaultDropdownOpen)}
          >
            <span>
              {selectedFaults.length === 0
                ? "Filter by Fault Type"
                : `${selectedFaults.length} types selected`}
            </span>
            <span>▼</span>
          </div>

          <div
            className={`dv-dropdown-menu ${isFaultDropdownOpen ? "open" : ""}`}
          >
            {uniqueFaultMessages.length > 0 ? (
              uniqueFaultMessages.map((fault, idx) => (
                <label key={idx} className="dv-checkbox-item">
                  <input
                    type="checkbox"
                    checked={selectedFaults.includes(fault)}
                    onChange={() => handleFaultChange(fault)}
                  />
                  {fault}
                </label>
              ))
            ) : (
              <div
                style={{ padding: "10px", color: "#999", textAlign: "center" }}
              >
                No faults available
              </div>
            )}
          </div>
        </div>
      </div>

      {/* --- Main Table --- */}
      <div className="dv-table-wrapper">
        <table className="dv-table">
          <thead>
            <tr>
              <th>Status</th>
              <th>VRN</th>
              <th>Device ID</th>
              <th>Fleet</th>
              <th>Type</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.length > 0 ? (
              filteredData.map((row) => {
                const isExpanded = !!expandedRows[row.device_id];
                const errorCount = row.errors_json.length;

                return (
                  <React.Fragment key={row.device_id}>
                    <tr className={isExpanded ? "dv-row-active" : ""}>
                      <td>
                        <span className="dv-badge-error">
                          {errorCount} Errors
                        </span>
                      </td>
                      <td>
                        <strong>{row.VRN}</strong>
                      </td>
                      <td>{row.device_id}</td>
                      <td>{row.fleet}</td>
                      <td>{row.type}</td>
                      <td>{row.data_date}</td>
                      <td>
                        <button
                          className="dv-btn-toggle"
                          onClick={() => toggleRow(row.device_id)}
                        >
                          {isExpanded ? "Hide Details" : "View Errors"}
                        </button>
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr className="dv-nested-row">
                        <td colSpan="7">
                          <div className="dv-nested-container">
                            <h4>Error Report for {row.VRN}</h4>
                            <table className="dv-nested-table">
                              <thead>
                                <tr>
                                  <th>Column</th>
                                  <th>Message</th>
                                  <th>Observed</th>
                                  <th>Count</th>
                                </tr>
                              </thead>
                              <tbody>
                                {row.errors_json.map((err, idx) => (
                                  <tr key={idx}>
                                    <td>
                                      <code>{err.column}</code>
                                    </td>
                                    <td>{err.message}</td>
                                    <td className="dv-warn-text">
                                      {err.observed || "-"}
                                    </td>
                                    <td>{err.occurrences}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })
            ) : (
              <tr>
                <td colSpan="7" className="dv-no-data">
                  No devices found matching your filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataValidation;
