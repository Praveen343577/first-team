import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { Sidebar } from '../components/layout/Sidebar';
import { Table } from '../components/data-display/Table';
import { Search, Bell, Wifi, WifiOff, Loader2 } from 'lucide-react';
import { useFleetSocket } from '../hooks/useFleetSocket';
import { SearchBar } from '../components/common/Search';
import { AvatarMenu } from '../components/layout/AvatarMenu';
import { TableProvider } from '../context/TableProvider';

export const DashboardLayout = () => {
  const location = useLocation();
  const isDashboardHome = location.pathname === '/dashboard';
  
  const { vehicles, status } = useFleetSocket();
  const [searchQuery, setSearchQuery] = useState('');

  // [ADD THIS]: Global Filter Logic
  // This filters the raw list BEFORE it gets split into Active/Inactive
  const filteredVehicles = vehicles.filter(v => {
    if (!searchQuery) return true;
    const lowerQ = searchQuery.toLowerCase();
    return (
      (v.vrn && v.vrn.toLowerCase().includes(lowerQ)) ||
      (v.chassisNumber && v.chassisNumber.toLowerCase().includes(lowerQ)) ||
      (v.fleet && v.fleet.toLowerCase().includes(lowerQ)) ||
      (v.imei && v.imei.toString().includes(lowerQ))
    );
  });

  // [UPDATE THIS]: Use 'filteredVehicles' instead of 'vehicles'
  const activeVehicles = filteredVehicles.filter(v => v.mode === 'active');
  const inactiveVehicles = filteredVehicles.filter(v => v.mode === 'inactive' || v.mode === 'nogps');

  return (
    <TableProvider>
      <div className="min-h-screen bg-brand-bg flex transition-colors duration-300">
        <Sidebar />

        <main className="flex-1 ml-64 p-8 overflow-y-auto h-screen">
          <header className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-3">
                {/* 2. Update Header Text Color */}
                <h2 className="text-2xl font-bold text-brand-text transition-colors duration-300">Fleet Overview</h2>

                {/* Status Badge (Kept semantic Green/Red as they are universal status colors) */}
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-mono border transition-colors duration-300 ${
                  status === 'connected' 
                    ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' 
                    : 'bg-red-500/10 text-brand-red border-red-500/20'
                }`}>
                  {status === 'connected' ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                  {status === 'connected' && `${inactiveVehicles.length + activeVehicles.length} `}
                  {status.toUpperCase()}
                </div>
              </div>
            </div>
              
            <div className="flex items-center gap-2">
              {/* 4. SearchBar*/}
              <SearchBar 
                data={vehicles} 
                onSearch={setSearchQuery} 
              />

              {/* 5. Update Notification Button Hover */}
              {/* <button className="p-2 text-brand-text-muted hover:text-brand-blue transition-colors relative">
                <div className="w-10 h-10 rounded-full bg-brand-blue/10 text-brand-blue flex items-center justify-center font-bold text-xs border border-brand-blue/20 transition-colors duration-300">
                  <Bell className="w-5 h-5" />
                </div>
              </button> */}
              
              {/* 6. Update Avatar to use Brand Blue */}
              {/* <div className="w-10 h-10 rounded-full bg-brand-blue/10 text-brand-blue flex items-center justify-center font-bold text-xs border border-brand-blue/20 transition-colors duration-300">
                AD
              </div> */}
              <AvatarMenu />
            </div>
          </header>

          {isDashboardHome ? (
            <>
              {status === 'connected' && vehicles.length === 0 ? (
                <div className="h-64 flex flex-col items-center justify-center text-brand-text-muted gap-3 border border-dashed border-brand-border rounded-xl transition-colors duration-300">
                  {/* 7. Update Loader to Brand Blue */}
                  <Loader2 className="w-8 h-8 animate-spin text-brand-blue" />
                  <p>Waiting for live stream data...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-8 animate-in fade-in duration-500 slide-in-from-bottom-4">
                  <Table 
                    title="Active Fleet" 
                    // description="Vehicles currently in operation (Speed > 0)"
                    data={activeVehicles}
                    badgeColor="emerald"
                    tableId="active-fleet"
                  />

                  <Table 
                    title="Inactive Fleet" 
                    // description="Vehicles Stopped or Idle (Speed = 0)"
                    data={inactiveVehicles}
                    badgeColor="orange"
                    tableId="inactive-fleet"
                  />
                </div>
              )}
            </>
          ) : (
            <Outlet />
          )}
        </main>
      </div>
    </TableProvider>
  );
};




