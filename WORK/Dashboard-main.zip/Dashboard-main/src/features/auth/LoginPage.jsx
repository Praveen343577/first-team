import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Zap, AlertCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Button } from '../../components/common/Button';
import { Input } from '../../components/common/Input';
// import { ShaderAnimation2 } from '../../components/ui/ShaderAnimation2';

export const LoginPage = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    setTimeout(() => {
      if (email === 'test@gmail.com' && password === 'admin@123') {
        localStorage.setItem('isAuthenticated', 'true');
        navigate('/dashboard');
      } else {
        setError('Invalid credentials. Access denied.');
        setIsLoading(false);
      }
    }, 1500);
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5 }
  };

  return (
    <div className="min-h-screen w-full flex overflow-hidden bg-slate-950 font-sans text-white">
      
      <div className="hidden lg:flex w-1/2 relative flex-col justify-between p-12 overflow-hidden">
        <div className="relative z-10 flex items-center gap-3">
          <div className="p-2.5 bg-white/10 backdrop-blur-md rounded-xl border border-white/10">
            <Zap className="w-6 h-6 text-cyan-400 fill-current" />
          </div>
          <span className="text-xl font-bold tracking-tight">Fleet Command</span>
        </div>
      </div>

      {/* <ShaderAnimation2/> */}
      <div className="flex w-full justify-center items-center gap-16">
        
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 1.8 }}
          className="relative z-10 -translate-x-120"
        >
          <h2 className="text-5xl w-200 font-bold leading-tight mb-6 bg-clip-text text-transparent bg-linear-to-r from-white via-[#E42626] to-[#2563EB]">
            Orchestrate your logistics with precision in real time.
          </h2>

          <div className="space-y-4">
            {['Real-time telemetry', 'Predictive maintenance', 'Global asset tracking'].map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-slate-300">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span className="text-lg">{item}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <div className="
          w-120 h-150 flex items-center justify-center p-7 
          relative z-20 mx-auto -translate-x-50
          rounded-2xl border border-white/20
          bg-white/10 backdrop-blur-xl 
          shadow-[0_0_40px_rgba(255,255,255,0.2),inset_0_0_30px_rgba(255,255,255,0.1)] "
        >

          <motion.div 
            initial="initial"
            animate="animate"
            variants={{
              animate: { transition: { staggerChildren: 0.1 } }
            }}
            className="w-full max-w-md space-y-8"
          >
            <motion.div variants={fadeInUp} className="text-center lg:text-left space-y-2">
              <h1 className="text-3xl font-semibold tracking-tight">Welcome back</h1>
              <p className="text-slate-400">Enter your credentials to access the command center.</p>
            </motion.div>

            <motion.form variants={fadeInUp} onSubmit={handleLogin} className="space-y-6">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 rounded-lg bg-red-500/10 border border-red-500/20 text-red-200 flex items-center gap-3 text-sm"
                >
                  <AlertCircle className="w-4 h-4" />
                  {error}
                </motion.div>
              )}

              <div className="space-y-4">
                <div className="space-y-2">
                  <Input
                    type="email"
                    placeholder="admin@fleet.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-slate-900/50 border-slate-800 focus:border-cyan-500 focus:ring-cyan-500/20 w-full h-15 text-base transition-all duration-200"
                  />
                </div>
                <div className="space-y-2">
                  <Input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-slate-900/50 border-slate-800 focus:border-cyan-500 focus:ring-cyan-500/20 w-full h-15 text-base transition-all duration-200"
                  />
                  <div className="flex justify-end pt-5">
                    <button type="button" className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors">
                      Forgot password?
                    </button>
                  </div>
                </div>
              </div>

              <Button 
                type="submit" 
                isLoading={isLoading}
                className="w-full h-15 bg-white text-slate-950 hover:bg-cyan-50 font-bold transition-all shadow-[0_0_20px_-5px_rgba(255,255,255,0.3)] hover:shadow-[0_0_25px_-5px_rgba(34,211,238,0.5)] border-0"
              >
                <span className="flex items-center justify-center gap-2">
                  {isLoading ? 'Verifying...' : 'Sign In'}
                  {!isLoading && <ArrowRight className="w-4 h-4" />}
                </span>
              </Button>
            </motion.form>

            <motion.div variants={fadeInUp} className="text-center">
              <p className="text-slate-500 text-sm">
                Don't have an account? <button className="text-white hover:underline underline-offset-4">Request Access</button>
              </p>
            </motion.div>
          </motion.div>
        </div>
      </div>

    </div>
  );
};

export default LoginPage;