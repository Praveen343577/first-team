import { useState, useEffect, useRef } from 'react';
import { Filter, ChevronDown, ChevronUp, Check, X } from 'lucide-react';
import { clsx } from 'clsx';

export const FilterDropdown = ({ data = [], selectedFilters, onFilterChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [expandedSection, setExpandedSection] = useState(null); // 'type' | 'fleet' | null
  
  // Selection State
  const selectedTypes = selectedFilters?.types || new Set();
  const selectedFleets = selectedFilters?.fleets || new Set();
  const selectedProviders = selectedFilters?.providers || new Set();
  const selectedTimeRanges = selectedFilters?.timeRanges || new Set();

  const dropdownRef = useRef(null);
  const getProvider = (v) => (v.imei?.toString().length === 7 ? "MapMyIndia" : "Roadpoint");

  const timeOptions = [
    { label: 'Just now (< 1 hr)', value: '0-1h' },
    { label: 'Within 2 days',     value: '1h-48h' },  
    { label: 'Over 2 days',       value: '48h+' }, 
  ];

  // 1. Extract Unique Options from Data
  const uniqueTypes = [...new Set(data.map(v => v.deviceTypeName).filter(Boolean))].sort();
  const uniqueFleets = [...new Set(data.map(v => v.fleet).filter(Boolean))].sort();
  const uniqueProviders = [...new Set(data.map(getProvider))].sort();

  // 2. Handle Click Outside to Close
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
        setExpandedSection(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Toggle Selection Helper
  const toggleSelection = (categoryKey, value) => {
    // 1. Clone the current set from props
    const currentSet = selectedFilters[categoryKey] || new Set();
    const newSet = new Set(currentSet);

    // 2. Toggle logic
    if (newSet.has(value)) newSet.delete(value);
    else newSet.add(value);

    // 3. Trigger Parent Update immediately
    onFilterChange({
      ...selectedFilters,
      [categoryKey]: newSet
    });
  };

  // Toggle Accordion Helper
  const toggleSection = (section) => {
    setExpandedSection(prev => prev === section ? null : section);
  };

  const clearFilters = () => {
    onFilterChange({
      types: new Set(),
      fleets: new Set(),
      providers: new Set(),
      timeRanges: new Set(),
    });
  };

  const hasActiveFilters = selectedTypes.size > 0 || selectedFleets.size > 0 || selectedProviders.size > 0 || selectedTimeRanges.size > 0;

  return (
    <div className="relative" ref={dropdownRef}>
      
      {/* Trigger Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={clsx(
          "px-3 py-2 border rounded-lg text-sm font-medium flex items-center gap-2 transition-all duration-300",
          isOpen || hasActiveFilters
            ? "bg-brand-blue/10 border-brand-blue text-brand-blue" 
            : "bg-brand-bg border-brand-border text-brand-text-muted hover:bg-brand-border hover:text-brand-text"
        )}
      >
        <Filter className="w-4 h-4" />
        Filters
        {hasActiveFilters && (
          <span className="ml-1 flex h-4 w-4 items-center justify-center rounded-full bg-brand-blue text-[10px] text-white">
            {selectedTypes.size + selectedFleets.size + selectedProviders.size + selectedTimeRanges.size}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute top-full mt-2 right-0 w-72 bg-brand-surface border border-brand-border rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
          
          <div className="p-3 border-b border-brand-border flex items-center justify-between bg-brand-bg/50">
            <span className="text-xs font-semibold text-brand-text uppercase tracking-wider">Filter Options</span>
            {hasActiveFilters && (
              <button 
                onClick={clearFilters}
                className="text-xs text-brand-red hover:text-red-600 font-medium transition-colors"
              >
                Clear all
              </button>
            )}
          </div>

          <div className="p-2 space-y-1">
            {/* --- SECTION 1: VEHICLE TYPE --- */}
            <div className="rounded-lg border border-brand-border/50 overflow-hidden">
              <button 
                onClick={() => toggleSection('type')}
                className="w-full flex items-center justify-between p-3 bg-brand-bg/30 hover:bg-brand-bg/50 transition-colors text-sm font-medium text-brand-text"
              >
              <div className="flex items-center gap-2">
                <span>Vehicle Type</span>

                {selectedTypes.size > 0 && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-brand-blue text-[10px] text-white">
                    {selectedTypes.size}
                  </span>
                )}
              </div>
                {expandedSection === 'type' ? <ChevronUp className="w-4 h-4 text-brand-text-muted" /> : <ChevronDown className="w-4 h-4 text-brand-text-muted" />}
              </button>
              
              {expandedSection === 'type' && (
                <div className="bg-brand-bg/10 p-2 space-y-1 max-h-48 overflow-y-auto">
                  {uniqueTypes.length === 0 && <p className="text-xs text-brand-text-muted p-2 italic">No types found</p>}
                  {uniqueTypes.map(type => (
                    <label 
                      key={type} 
                      onClick={(e) => { e.preventDefault(); toggleSelection('types', type); }}
                      className="flex items-center gap-2 p-2 rounded hover:bg-brand-border/30 cursor-pointer transition-colors group"
                    >
                      <div className={clsx(
                        "w-4 h-4 rounded border flex items-center justify-center transition-colors",
                        selectedTypes.has(type) ? "bg-brand-blue border-brand-blue" : "border-brand-text-muted group-hover:border-brand-text"
                      )}>
                        {selectedTypes.has(type) && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="text-sm text-brand-text">{type}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* --- SECTION 2: FLEET --- */}
            <div className="rounded-lg border border-brand-border/50 overflow-hidden">
              <button 
                onClick={() => toggleSection('fleet')}
                className="w-full flex items-center justify-between p-3 bg-brand-bg/30 hover:bg-brand-bg/50 transition-colors text-sm font-medium text-brand-text"
              >
              <div className="flex items-center gap-2">
                <span>Fleet</span>
                
                {selectedFleets.size > 0 && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-brand-blue text-[10px] text-white">
                    {selectedFleets.size}
                  </span>
                )}
              </div>
                
                {expandedSection === 'fleet' ? <ChevronUp className="w-4 h-4 text-brand-text-muted" /> : <ChevronDown className="w-4 h-4 text-brand-text-muted" />}
              </button>
              
              {expandedSection === 'fleet' && (
                <div className="bg-brand-bg/10 p-2 space-y-1 max-h-48 overflow-y-auto">
                  {uniqueFleets.length === 0 && <p className="text-xs text-brand-text-muted p-2 italic">No fleets found</p>}
                  {uniqueFleets.map(fleet => (
                    <label 
                      key={fleet} 
                      onClick={(e) => { e.preventDefault(); toggleSelection('fleets', fleet); }}
                      className="flex items-center gap-2 p-2 rounded hover:bg-brand-border/30 cursor-pointer transition-colors group"
                    >
                      <div className={clsx(
                        "w-4 h-4 rounded border flex items-center justify-center transition-colors",
                        selectedFleets.has(fleet) ? "bg-brand-blue border-brand-blue" : "border-brand-text-muted group-hover:border-brand-text"
                      )}>
                        {selectedFleets.has(fleet) && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="text-sm text-brand-text">{fleet}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/* --- SECTION 3: PROVIDER --- */}
            <div className="rounded-lg border border-brand-border/50 overflow-hidden">
              <button 
                onClick={() => toggleSection('provider')}
                className="w-full flex items-center justify-between p-3 bg-brand-bg/30 hover:bg-brand-bg/50 transition-colors text-sm font-medium text-brand-text"
              >
              <div className="flex items-center gap-2">
                <span>Provider</span>
                {selectedProviders.size > 0 && (
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-brand-blue text-[10px] text-white">
                    {selectedProviders.size}
                  </span>
                )}
              </div>
                {expandedSection === 'provider' ? <ChevronUp className="w-4 h-4 text-brand-text-muted" /> : <ChevronDown className="w-4 h-4 text-brand-text-muted" />}
              </button>
              
              {expandedSection === 'provider' && (
                <div className="bg-brand-bg/10 p-2 space-y-1 max-h-48 overflow-y-auto">
                  {uniqueProviders.map(provider => (
                    <label 
                      key={provider} 
                      onClick={(e) => { e.preventDefault(); toggleSelection('providers', provider); }}
                      className="flex items-center gap-2 p-2 rounded hover:bg-brand-border/30 cursor-pointer transition-colors group"
                    >
                      <div className={clsx(
                        "w-4 h-4 rounded border flex items-center justify-center transition-colors",
                        selectedProviders.has(provider) ? "bg-brand-blue border-brand-blue" : "border-brand-text-muted group-hover:border-brand-text"
                      )}>
                        {selectedProviders.has(provider) && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="text-sm text-brand-text">{provider}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

            {/*  --- SECTION 4: LAST SEEN --- */}
            <div className="rounded-lg border border-brand-border/50 overflow-hidden">
              <button 
                onClick={() => toggleSection('time')}
                className="w-full flex items-center justify-between p-3 bg-brand-bg/30 hover:bg-brand-bg/50 transition-colors text-sm font-medium text-brand-text"
              >
                <div className="flex items-center gap-2">
                  <span>Last Seen</span>
                  {selectedTimeRanges.size > 0 && (
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-brand-blue text-[10px] text-white">
                      {selectedTimeRanges.size}
                    </span>
                  )}
                </div>
                {expandedSection === 'time' ? <ChevronUp className="w-4 h-4 text-brand-text-muted" /> : <ChevronDown className="w-4 h-4 text-brand-text-muted" />}
              </button>
              
              {expandedSection === 'time' && (
                <div className="bg-brand-bg/10 p-2 space-y-1 max-h-48 overflow-y-auto">
                  {timeOptions.map(option => (
                    <label 
                      key={option.value} 
                      onClick={(e) => { e.preventDefault(); toggleSelection('timeRanges', option.value); }}
                      className="flex items-center gap-2 p-2 rounded hover:bg-brand-border/30 cursor-pointer transition-colors group"
                    >
                      <div className={clsx(
                        "w-4 h-4 rounded border flex items-center justify-center transition-colors",
                        selectedTimeRanges.has(option.value) ? "bg-brand-blue border-brand-blue" : "border-brand-text-muted group-hover:border-brand-text"
                      )}>
                        {selectedTimeRanges.has(option.value) && <Check className="w-3 h-3 text-white" />}
                      </div>
                      <span className="text-sm text-brand-text">{option.label}</span>
                    </label>
                  ))}
                </div>
              )}
            </div>

          </div>
        </div>
      )}
    </div>
  );
};