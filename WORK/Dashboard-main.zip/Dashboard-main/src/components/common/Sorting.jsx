import { useState, useEffect, useRef } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown, Check } from 'lucide-react';
import { clsx } from 'clsx';

export const SortDropdown = ({ options = [], activeSort, onSortChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  // Close on click outside (matches Filter.jsx behavior)
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSort = (key) => {
    let newDirection = 'asc';

    if (activeSort?.key === key) {
      newDirection = activeSort.direction === 'asc' ? 'desc' : 'asc';
    }

    const newSort = { key, direction: newDirection };
    
    if (onSortChange) {
      onSortChange(newSort);
    }
  };

  const clearSort = () => {
    const reset = { key: null, direction: 'asc' };
    if (onSortChange) onSortChange(reset);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Trigger Button */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className={clsx(
          "px-3 py-2 border rounded-lg text-sm font-medium flex items-center gap-2 transition-all duration-300",
          isOpen || activeSort.key
            ? "bg-brand-blue/10 border-brand-blue text-brand-blue" 
            : "bg-brand-bg border-brand-border text-brand-text-muted hover:bg-brand-border hover:text-brand-text"
        )}
      >
        <ArrowUpDown className="w-4 h-4" />
        Sort
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute top-full mt-2 right-0 w-56 bg-brand-surface border border-brand-border rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
          
          {/* Header */}
          <div className="p-3 border-b border-brand-border flex items-center justify-between bg-brand-bg/50">
            <span className="text-xs font-semibold text-brand-text uppercase tracking-wider">Sort By</span>
            {activeSort.key && (
              <button 
                onClick={clearSort}
                className="text-xs text-brand-red hover:text-red-600 font-medium transition-colors"
              >
                Reset
              </button>
            )}
          </div>

          {/* Options List */}
          <div className="p-1">
            {options.map((option) => {
              const isActive = activeSort.key === option.key;
              
              return (
                <button
                  key={option.key}
                  onClick={() => handleSort(option.key)}
                  className={clsx(
                    "w-full flex items-center justify-between p-2 rounded-lg text-sm transition-colors",
                    isActive 
                      ? "bg-brand-blue/10 text-brand-blue" 
                      : "text-brand-text hover:bg-brand-bg/50"
                  )}
                >
                  <span className="font-medium">{option.label}</span>
                  
                  {isActive && (
                    <div className="flex items-center bg-brand-blue text-white rounded p-0.5">
                      {activeSort.direction === 'asc' 
                        ? <ArrowUp className="w-3 h-3" /> 
                        : <ArrowDown className="w-3 h-3" />
                      }
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};