import * as XLSX from 'xlsx';
import { Download } from 'lucide-react';

export const ExportData = ({ data, fileName = 'fleet_export' }) => {
  
  const handleExport = () => {
    // 1. Transform data to match specific column requirements
    const exportData = data.map(vehicle => {
      // Replicate logic from Table.jsx for consistency
      const isSevenDigit = vehicle.imei?.toString().length === 7;
      const lastSeenDate = vehicle.lastTimestamp ? new Date(vehicle.lastTimestamp) : null;
      
      return {
        'VRN / Chassis Number': vehicle.vrn || vehicle.chassisNumber || vehicle.imei || '-',
        'Vehicle Type': vehicle.deviceTypeName || 'Unknown',
        'Fleet': vehicle.fleet || '-',
        'Latitude': vehicle.latitude || '0',
        'Longitude': vehicle.longitude || '0',
        'Last Seen': lastSeenDate 
          ? lastSeenDate.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour12: true }) 
          : 'Not Available',
        'Provider': isSevenDigit ? 'MapMyIndia' : 'Roadpoint',
        'Remarks': 'No Remarks'
      };
    });

    // 2. Create Worksheet and Workbook
    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

    // 3. Adjust Column Widths (Optional for better UX)
    const wscols = [
      { wch: 25 }, // VRN
      { wch: 15 }, // Type
      { wch: 25 }, // Fleet
      { wch: 15 }, // Lat
      { wch: 15 }, // Long
      { wch: 25 }, // Last Seen
      { wch: 15 }, // Provider
      { wch: 35 }, // Remarks
    ];
    worksheet['!cols'] = wscols;

    // 4. Trigger Download
    const cleanFileName = fileName.replace(/\s+/g, '_').toLowerCase();
    XLSX.writeFile(workbook, `${cleanFileName}.xlsx`);
  };

  return (
    <button 
      onClick={handleExport}
      className="px-3 py-2 bg-brand-bg border border-brand-border rounded-lg text-brand-text-muted text-sm font-medium hover:bg-brand-border hover:text-brand-text flex items-center gap-2 transition-colors duration-300"
    >
      <Download className="w-4 h-4" />
      Export
    </button>
  );
};