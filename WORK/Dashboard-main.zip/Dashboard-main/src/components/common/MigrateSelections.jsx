/*
 * MigrateSelections.jsx
 * * PURPOSE:
 * Trigger button to broadcast the current table's Sort/Filter state to all other registered tables.
 * Uses the TableContext to execute the 'migrateSelections' function.
 */

import { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { clsx } from 'clsx';
import { useTableContext } from '../../context/TableContext';

export const MigrateSelections = ({ tableId }) => {
  const { migrateSelections } = useTableContext();
  const [isApplied, setIsApplied] = useState(false);

  const handleApply = () => {
    // 1. Trigger the context migration
    migrateSelections(tableId);
    
    // 2. Show feedback state
    setIsApplied(true);
    
    // 3. Reset after delay
    setTimeout(() => setIsApplied(false), 2000);
  };

  return (
    <button
      onClick={handleApply}
      disabled={isApplied}
      title="Apply current Sort and Filters to all other tables"
      className={clsx(
        "px-3 py-2 border rounded-lg text-sm font-medium flex items-center gap-2 transition-all duration-300",
        // Conditional Styling: Success vs Default
        isApplied
          ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-500 cursor-default" 
          : "bg-brand-bg border-brand-border text-brand-text-muted hover:bg-brand-border hover:text-brand-text"
      )}
    >
      {/* Icon Swap on Success */}
      {isApplied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
      
      <span>{isApplied ? "Applied" : "Apply to All"}</span>
    </button>
  );
};