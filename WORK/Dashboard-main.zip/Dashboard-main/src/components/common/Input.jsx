import { clsx } from 'clsx';

export const Input = ({ label, icon: Icon, type = "text", ...props }) => {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-slate-400">{label}</label>
      <div className="relative group">
        {Icon && (
          <Icon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-cyan-400 transition-colors w-5 h-5" />
        )}
        <input
          type={type}
          className={clsx(
            "w-full bg-slate-900/50 border border-slate-700 text-slate-100 rounded-lg p-3 outline-none transition-all duration-300",
            "focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 focus:bg-slate-900",
            Icon && "pl-10"
          )}
          {...props}
        />
      </div>
    </div>
  );
};