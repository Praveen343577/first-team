import { useState, useEffect, useRef } from 'react';
import { Search, X, Truck, Box } from 'lucide-react';
import { clsx } from 'clsx';

export const SearchBar = ({ data = [], onSearch, placeholder = "Search" }) => {
  const [query, setQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef(null);

  // 1. Click Outside Handler to close dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 2. Search Logic
  const handleInputChange = (e) => {
    const value = e.target.value;
    setQuery(value);
    onSearch(value); // Trigger "Auto Filter" in parent immediately

    if (value.trim().length > 1) {
      const lowerVal = value.toLowerCase();
      
      // Filter logic: Check VRN, Chassis, Fleet, or IMEI
      const matches = data.filter(item => {
        const vrn = item.vrn?.toLowerCase() || '';
        const chassis = item.chassisNumber?.toLowerCase() || '';
        const fleet = item.fleet?.toLowerCase() || '';
        const imei = item.imei?.toString() || ''; // IMEI is often a number

        return vrn.includes(lowerVal) || 
               chassis.includes(lowerVal) || 
               fleet.includes(lowerVal) || 
               imei.includes(lowerVal);
      });

      setSuggestions(matches.slice(0, 5)); // Limit to top 5 suggestions
      setIsOpen(true);
    } else {
      setSuggestions([]);
      setIsOpen(false);
    }
  };

  // 3. Select Logic (Auto Complete)
  const handleSelect = (item) => {
    // Prefer VRN, fallback to Chassis, then IMEI
    const value = item.vrn || item.chassisNumber || item.imei;
    setQuery(value);
    onSearch(value); // Hard filter the table to this exact result
    setIsOpen(false);
  };

  const handleClear = () => {
    setQuery('');
    onSearch('');
    setSuggestions([]);
    setIsOpen(false);
  };

  return (
    <div className="relative w-75" ref={wrapperRef}>
      {/* Input Field */}
      <div className="relative group">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-brand-text-muted group-focus-within:text-brand-blue transition-colors duration-300" />
        
        <input 
          type="text" 
          value={query}
          onChange={handleInputChange}
          placeholder={placeholder}
          className="w-full bg-brand-surface border border-brand-border rounded-full pl-10 pr-9 py-2.5 text-sm text-brand-text placeholder:text-brand-text-muted focus:outline-none focus:border-brand-blue focus:ring-1 focus:ring-brand-blue/20 transition-all duration-300"
        />

        {query && (
          <button 
            onClick={handleClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-brand-text-muted hover:text-brand-red transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* Auto-Suggestion Dropdown */}
      {isOpen && suggestions.length > 0 && (
        <div className="absolute top-full mt-2 right-0 w-75 bg-brand-surface border border-brand-border rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
          <div className="py-1">
            {/* <div className="px-3 py-2 text-[10px] font-semibold text-brand-text-muted uppercase tracking-wider bg-brand-bg/50 border-b border-brand-border">
              Suggestions
            </div> */}
            
            {suggestions.map((item) => (
              <button
                key={item.imei}
                onClick={() => handleSelect(item)}
                className="w-full text-left px-3 py-2.5 hover:bg-brand-blue/7 border-l-2 border-transparent hover:border-brand-blue transition-all duration-200 group flex items-start gap-3"
              >          
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-brand-text truncate">
                      {item.vrn || item.chassisNumber || "Unknown ID"}
                    </p>
                    <span className="text-[10px] bg-brand-bg px-1.5 py-0.5 rounded border border-brand-border text-brand-text-muted">
                      {item.fleet || "No Fleet"}
                    </span>
                  </div>
                  <p className="text-xs text-brand-text-muted truncate font-mono mt-0.5">
                    imei: {item.imei}
                  </p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};