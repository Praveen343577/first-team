import { useState, useRef, useEffect } from 'react';
import { LogOut, Settings, HelpCircle, Lock, User } from 'lucide-react';

export const AvatarMenu = () => {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef(null);

  // Handle click outside to close
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={menuRef}>
      {/* Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="outline-none focus:ring-2 focus:ring-brand-blue/20 rounded-full transition-all duration-200"
      >
        <div className="w-10 h-10 rounded-full bg-brand-blue/10 text-brand-blue flex items-center justify-center font-bold text-xs border border-brand-blue/20 hover:bg-brand-blue/20 transition-colors duration-300">
          AD
        </div>
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-brand-surface border border-brand-border rounded-xl shadow-xl z-50 animate-in fade-in zoom-in-95 duration-200">
          
          {/* User Profile Header */}
          <div className="p-4 border-b border-brand-border">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-brand-bg border border-brand-border flex items-center justify-center text-brand-text-muted">
                <User className="w-5 h-5" />
              </div>
              <div className="overflow-hidden">
                <h4 className="text-sm font-semibold text-brand-text truncate">Admin</h4>
                <p className="text-xs text-brand-text-muted truncate">test@gmail.com</p>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <div className="p-2 space-y-0.5">
            <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-brand-text-muted hover:text-brand-text hover:bg-brand-bg rounded-lg transition-colors">
              <Lock className="w-4 h-4" />
              Change Password
            </button>
            
            <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-brand-text-muted hover:text-brand-text hover:bg-brand-bg rounded-lg transition-colors">
              <Settings className="w-4 h-4" />
              Settings
            </button>

            <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-brand-text-muted hover:text-brand-text hover:bg-brand-bg rounded-lg transition-colors">
              <HelpCircle className="w-4 h-4" />
              Help Center
            </button>

            <div className="h-px bg-brand-border my-1 mx-2"></div>

            <button className="w-full flex items-center gap-3 px-3 py-2 text-sm text-red-500 hover:bg-red-500/10 rounded-lg transition-colors">
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};