import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, CreditCard, Box, Settings, BarChart3, Zap } from 'lucide-react';
import { clsx } from 'clsx';

const menuItems = [
  { icon: LayoutDashboard, label: "Overview", path: "/dashboard" },
  { icon: BarChart3, label: "Data Validation", path: "/dataValidation" },
  // { icon: Users, label: "User redeem", path: "/users", active: true }, 
  // { icon: CreditCard, label: "Transactions", path: "/transactions" },
  // { icon: Box, label: "Products", path: "/products" },
];

export const Sidebar = () => {
  return (
    <aside className="w-64 h-screen fixed left-0 top-0 bg-brand-bg border-r border-brand-border flex flex-col z-20 transition-colors duration-300">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-blue to-brand-red flex items-center justify-center">
          <Zap className="w-5 h-5 text-white" fill="currentColor" />
        </div>
        <span className="font-bold text-lg tracking-wide text-brand-text transition-colors duration-300">EKA</span>
      </div>

      <div className="p-5">

        {/* Super Admin Panel */}
        {/* <div className="glass-panel p-3 rounded-xl mb-6 flex items-center gap-3 transition-colors duration-300">
           <div className="w-8 h-8 rounded-full bg-brand-surface overflow-hidden border border-brand-border">
             <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="Admin" />
           </div>
           <div className="flex-1">
             <h4 className="text-sm font-medium text-brand-text transition-colors duration-300">Philips Woody</h4>
             <p className="text-xs text-brand-text-muted transition-colors duration-300">Super Admin</p>
           </div>
        </div> */}

        <nav className="space-y-1">
          <p className="px-5 text-sm font-semibold text-brand-text-muted mb-2 uppercase tracking-wider transition-colors duration-300">General</p>
          {menuItems.map((item) => (
            <NavLink
              key={item.label}
              to={item.path}
              className={({ isActive }) => clsx(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200",
                isActive || item.active 
                  ? "bg-brand-blue/10 text-brand-blue border border-brand-blue/20" 
                  : "text-brand-text-muted hover:text-brand-text hover:bg-brand-surface"
              )}
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-4 border-t border-brand-border transition-colors duration-300">
        <button className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-brand-text-muted hover:text-brand-red transition-colors w-full">
          <Settings className="w-5 h-5" />
          System Settings
        </button>
      </div>
    </aside>
  );
};