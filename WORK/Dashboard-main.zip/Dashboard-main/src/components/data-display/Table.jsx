import { useState, useCallback, useEffect } from 'react';
import { MoreVertical, ArrowDown, ArrowUp, Edit2, Trash2, Filter, Download, Plus, Truck, Clock } from 'lucide-react';
import { clsx } from 'clsx';
import { Button } from '../common/Button';
import { LocationCell } from './Location';
import { FilterDropdown } from '../common/Filter';
import { SortDropdown } from '../common/Sorting';
import { useTableContext } from '../../context/TableContext';
import { MigrateSelections } from '../common/MigrateSelections';
import { ExportData } from '../common/ExportData';

export const Table = ({ title, description, data = [], badgeColor = "gray", tableId }) => {
  const [selectedRows, setSelectedRows] = useState(new Set());
  
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 12;

  const { registerTable, setTableConfig, getTableConfig } = useTableContext();

  useEffect(() => {
    if (tableId) registerTable(tableId);
  }, [tableId, registerTable]);

  const { sortConfig, activeFilters } = getTableConfig(tableId);

  const handleFilterChange = useCallback(
    (filters) => {
      setTableConfig(tableId, { activeFilters: filters });
      setCurrentPage(1);
    },
    [setTableConfig, tableId, setCurrentPage]
  );

  const handleSortChange = (newSort) => {
    setTableConfig(tableId, { sortConfig: newSort });
  };


  const filteredData = data.filter(vehicle => {
    const typeMatch = activeFilters.types.size === 0 || activeFilters.types.has(vehicle.deviceTypeName);
    const fleetMatch = activeFilters.fleets.size === 0 || activeFilters.fleets.has(vehicle.fleet);
    
    const providerName = vehicle.imei?.toString().length === 7 ? "MapMyIndia" : "Roadpoint";
    const providerMatch = activeFilters.providers.size === 0 || activeFilters.providers.has(providerName);

    // ADD: Time Range Match Logic
    const timeMatch = (!activeFilters.timeRanges || activeFilters.timeRanges.size === 0) || (() => {
      if (!vehicle.lastTimestamp) return false;
      
      const now = new Date();
      const lastSeen = new Date(vehicle.lastTimestamp);
      const diffInMs = now - lastSeen;
      const diffHours = diffInMs / (1000 * 60 * 60);

      return Array.from(activeFilters.timeRanges).some(range => {
        switch(range) {
          case '0-1h':   return diffHours < 1;
          case '1h-48h': return diffHours >= 1 && diffHours <= 48;
          case '48h+':   return diffHours > 48;
          default: return false;
        }
      });
    })();

    return typeMatch && fleetMatch && providerMatch && timeMatch;
  });

  const sortOptions = [
    { label: 'VRN / Chassis Number', key: 'name' }, 
    { label: 'Vehicle Type', key: 'deviceTypeName' },
    { label: 'Fleet', key: 'fleet' },
    { label: 'Last Seen', key: 'lastTimestamp' },
    // Add other keys as needed
  ];

  // Sorting Logic
  const sortedData = [...filteredData].sort((a, b) => {
    if (!sortConfig.key) return 0;

    const valA = a[sortConfig.key] ?? '';
    const valB = b[sortConfig.key] ?? '';

    // 2. Use a smart comparator that handles Mixed Types & "Natural" Numbers
    const comparison = String(valA).localeCompare(String(valB), 'en', {
      numeric: true,       // Sorts "Fleet 2" before "Fleet 10" (Natural sort)
      sensitivity: 'base'  // Ignores case (A == a)
    });

    // 1. Determine Direction Multiplier
    // Default: Ascending = 1, Descending = -1
    let directionMultiplier = sortConfig.direction === 'asc' ? 1 : -1;

    // 2. EXCEPTION: Reverse logic for Last Seen
    // Why: Ascending usually means "Smallest Number". 
    // For "Time Ago", "5 mins" is smaller than "10 mins", but "5 mins" implies a NEWER (Larger) timestamp.
    if (sortConfig.key === 'lastTimestamp') {
      directionMultiplier = -directionMultiplier; 
    }

    return comparison * directionMultiplier;
  });

  const totalPages = Math.ceil(sortedData.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const currentData = sortedData.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const goToNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
  };

  const goToPrevPage = () => {
    if (currentPage > 1) setCurrentPage(prev => prev - 1);
  };

  // Toggle All (Modified to select only visible rows on current page)
  const toggleAll = () => {
    // If all currently visible rows are selected, clear selection
    // NOTE: Using 'imei' as the unique key based on your data structure
    const allVisibleSelected = currentData.every(item => selectedRows.has(item.imei));
    
    if (allVisibleSelected) {
      const newSelected = new Set(selectedRows);
      currentData.forEach(item => newSelected.delete(item.imei));
      setSelectedRows(newSelected);
    } else {
      // Select all visible
      const newSelected = new Set(selectedRows);
      currentData.forEach(item => newSelected.add(item.imei));
      setSelectedRows(newSelected);
    }
  };

  // Toggle Single Selection
  const toggleRow = (id) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedRows(newSelected);
  };

  return (
    <div className="bg-brand-surface border border-brand-border rounded-xl overflow-visible shadow-sm h-full flex flex-col transition-colors duration-300">

      <div className="p-5 border-b border-brand-border flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-semibold text-brand-text transition-colors duration-300">{title}</h3>
            <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium border ${badgeColor === 'emerald' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-orange-500/10 text-orange-500 border-orange-500/20'}`}>
              {filteredData.length} / {data.length} vehicles
            </span>
          </div>
          {description && <p className="text-brand-text-muted text-sm mt-1 transition-colors duration-300">{description}</p>}
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3">
          <SortDropdown options={sortOptions} activeSort={sortConfig} onSortChange={handleSortChange} />
          <FilterDropdown data={data} selectedFilters={activeFilters} onFilterChange={handleFilterChange}  />
          <MigrateSelections tableId={tableId} />
          <ExportData data={sortedData} fileName={title}  />
        </div>

      </div>

      {/* Table Content */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left border-collapse min-w-[1200px]">
          <thead>
            <tr className="bg-brand-bg/50 border-b border-brand-border transition-colors duration-300">
              <th className="p-4 w-12">
                <input 
                  type="checkbox" 
                  className="rounded bg-brand-bg border-brand-border text-brand-blue focus:ring-0 focus:ring-offset-0 transition-colors duration-300"
                  checked={currentData.length > 0 && currentData.every(item => selectedRows.has(item.imei))}
                  onChange={toggleAll}
                />
              </th>
              {/* Specific Columns as requested */}
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">VRN / Chassis Number</th>
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Vehicle Type</th>
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Fleet</th>
              {/* <th className="p-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Status</th> */}
              {/* <th className="p-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Speed</th> */}
              {/* <th className="p-4 text-xs font-medium text-slate-400 uppercase tracking-wider">SOC</th> */}
              {/* <th className="p-4 text-xs font-medium text-slate-400 uppercase tracking-wider">Odometer</th> */}
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Location (Lat, Long)</th>
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Last Seen</th>
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Provider</th>
              <th className="p-4 text-xs font-medium text-brand-text-muted uppercase tracking-wider transition-colors duration-300">Remarks</th>
            </tr>
          </thead>

          {/* <tbody className="divide-y divide-brand-border"> */}
          <tbody>
            {currentData.map((vehicle, index) => {
              const isSelected = selectedRows.has(vehicle.imei);
              const isSevenDigit = vehicle.imei?.toString().length === 7;

              // Parse safely. If invalid, 0, or effectively 0 (e.g. "0.000000"), return null flag.
              const getSafeCoord = (val) => {
                const num = parseFloat(val);
                if (isNaN(num) || num === 0) return null; 
                return num.toFixed(8);
              };

              const latDisplay = getSafeCoord(vehicle.latitude);
              const lngDisplay = getSafeCoord(vehicle.longitude);

              return (
                <tr 
                  key={index} 
                  className={clsx(
                    "group transition-colors duration-300",
                    isSelected ? "bg-brand-blue/5" : "hover:bg-brand-bg/50"
                  )}
                >
                  <td className="p-4">
                    <input 
                      type="checkbox" 
                      className="rounded bg-brand-bg border-brand-border text-brand-blue focus:ring-0 focus:ring-offset-0 transition-colors duration-300"
                      checked={isSelected}
                      onChange={() => toggleRow(vehicle.imei)}
                    />
                  </td>
                                    
                  {/* 1. Vehicle Details */}
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      {/* Logic: Check if IMEI is exactly 7 characters */}
                      <div className={clsx(
                        "w-10 h-10 rounded-full flex items-center justify-center border transition-all duration-300",
                        vehicle.imei?.toString().length === 7 
                          ? "bg-amber-500/20 border-amber-500 text-amber-500" // 7-Digit Style for MapMyIndia
                          : "bg-pink-500/20 border-pink-500 text-pink-500" // Standard 15-Digit Style for Roadpoint
                      )}>
                        <Truck className="w-5 h-5" />
                      </div>
                      
                        {/* Title: VRN / Chassis / IMEI */}
                        <div className="font-medium text-brand-text transition-colors duration-300">
                          {vehicle.vrn || vehicle.chassisNumber || vehicle.imei}
                        </div>
                    </div>
                  </td>

                  {/* 2. Vehicle Type */}    
                  <td className="p-4 font-medium text-brand-text transition-colors duration-300">
                     {vehicle.deviceTypeName || "Unknown Type"}
                  </td>

                  {/* 3. Fleet Name */}
                  <td className="p-4 font-medium text-brand-text transition-colors duration-300">
                    {vehicle.fleet || "-"}
                  </td>

                  {/* 2. Connection Status */}
                  {/* <td className="p-4">
                     <span className={clsx(
                      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border",
                      vehicle.isConnected 
                        ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" 
                        : "bg-slate-700/50 text-slate-400 border-slate-700"
                    )}>
                      <span className={clsx("w-1.5 h-1.5 rounded-full mr-1.5", vehicle.isConnected ? "bg-emerald-400" : "bg-slate-400")}></span>
                      {vehicle.isConnected ? "Online" : "Offline"}
                    </span>
                  </td> */}

                  {/* 3. Speed (Whole Number) */}
                  {/* <td className="p-4 text-sm text-slate-300 font-mono">
                    {formatWhole(vehicle.speed)} km/h
                  </td> */}

                  {/* 4. SOC (Whole Number + Bar) */}
                  {/* <td className="p-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className={clsx(
                            "h-full rounded-full transition-all duration-500", 
                            vehicle.soc <= 30 ? "bg-red-500" :
                            vehicle.soc <= 65 ? "bg-orange-400" :
                            "bg-emerald-500"
                          )} 
                          style={{ width: `${Math.min(vehicle.soc, 100)}%` }}
                        />
                      </div>
                      <span className="text-sm text-slate-300 font-mono">{Math.round(vehicle.soc)}%</span>
                    </div>
                  </td> */}

                  {/* 5. Odometer (Whole Number) */}
                  {/* <td className="p-4 text-sm text-slate-300 font-mono">
                    {formatWhole(vehicle.odometer).toLocaleString()} km
                  </td> */}

                  {/* 4. Location (Lat, Long) */}
                  {/* <td className="p-4">
                    <div className="flex flex-col gap-0.5">
                      {!latDisplay || !lngDisplay ? (
                        <span className="text-xs text-brand-text-muted">not available</span>
                      ) : (
                        <>
                          <div className="text-xs text-slate-800 font-mono">Lat: {latDisplay}</div>
                          <div className="text-xs text-slate-800 font-mono">Lng: {lngDisplay}</div>
                        </>
                      )}
                    </div>
                  </td> */}
                  <td className="p-4">
                    <LocationCell 
                      lat={vehicle.latitude} 
                      lng={vehicle.longitude} 
                      imei={vehicle.imei}
                    />
                  </td>

                  {/* 7. Last Seen */}
                  <td className="p-4">
                    {!vehicle.lastTimestamp ? (
                      <span className="text-xs text-brand-text-muted pl-4">not available</span>
                    ) : (() => {
                      const now = new Date();
                      const lastSeen = new Date(vehicle.lastTimestamp);
                      const diffInMs = now - lastSeen;
                      const diffInHours = diffInMs / (1000 * 60 * 60);

                      // Color Logic
                      let clockColor = "text-gray-500"; // Default 
                      if (diffInHours < 48) clockColor = "text-[#2563EB]";   // Blue
                      else if (diffInHours >= 48) clockColor = "text-[#F40000]";  // Red
                      // if (diffInHours < 2) clockColor = "text-[#6DD435]";   // Green
                      // else if (diffInHours < 12) clockColor = "text-[#2563EB]";   // Blue
                      // else if (diffInHours < 48) clockColor = "text-[#FF8C00]";   // Orange
                      // else if (diffInHours < 168) clockColor = "text-[#F40000]";  // Red

                      return (
                        <div className="flex flex-col gap-0.5 min-w-[140px]">
                          <div className="flex items-center gap-1.5">
                            {/* [MODIFIED] Dynamic Clock Color */}
                            <Clock className={`w-4.5 h-4.5 shrink-0 transition-colors duration-300 ${clockColor}`} />
                            
                            <span className="text-sm text-brand-text font-medium leading-snug">
                              {/* Text Logic */}
                              {(() => {
                                const diffInMins = Math.floor(diffInMs / (1000 * 60));
                                const hoursFloor = Math.floor(diffInHours);
                                
                                if (diffInMins < 3) return "Just now";
                                if (hoursFloor < 1) return `${diffInMins} mins ago`;
                                if (hoursFloor === 1) return `${hoursFloor} hour ago`;
                                if (hoursFloor < 24) return `${hoursFloor} hours ago`;
                                const diffInDays = Math.floor(hoursFloor / 24);
                                return `${diffInDays} days ago`;
                              })()}
                            </span>
                          </div>

                      
                          {/* Subtitle: Exact Date/Time */}
                          <div className="pl-5 text-[10px] text-brand-text-muted font-mono transition-colors duration-300">
                            {lastSeen.toLocaleString('en-IN', {
                              timeZone: 'Asia/Kolkata',
                              hour12: true,
                              day: '2-digit', month: '2-digit', year: 'numeric',
                              hour: '2-digit', minute: '2-digit'
                            })}
                          </div>
                        </div>
                      );
                    })()}
                  </td>

                  {/* 6. Provider Name */}
                  <td className="p-4">
                    <span className={clsx(
                      "px-2.5 py-1.5 rounded-full text-xs font-medium border transition-colors duration-300",
                      isSevenDigit 
                        ? "bg-amber-500/20 border-amber-500 text-amber-500" 
                        : "bg-pink-500/20 border-pink-500 text-pink-500"
                    )}>
                      {isSevenDigit ? "MapMyIndia" : "Roadpoint"}
                    </span>
                  </td>

                  {/* 7. Remarks */}
                  <td className="p-4 text-sm text-brand-text-muted transition-colors duration-300">
                    No Remarks
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
        
      {/* Pagination Footer */}
      <div className="p-4 border-t border-brand-border flex items-center justify-between bg-brand-bg/30 transition-colors duration-300">

        {/* LEFT GROUP */}
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setCurrentPage(1)} 
            disabled={currentPage === 1}
            className="px-3 py-1.5 border border-brand-border rounded-lg text-sm text-brand-text-muted hover:bg-brand-bg hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >  
            First
          </button>

          <button
            onClick={goToPrevPage}
            disabled={currentPage === 1}
            className="px-3 py-1.5 border border-brand-border rounded-lg text-sm text-brand-text-muted hover:bg-brand-bg hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Previous
          </button>
        </div>

        {/* PAGE INDICATOR */}
        <span className="text-sm text-brand-text-muted transition-colors duration-300">
          Page <span className="text-brand-text font-medium">{currentPage}</span>
          {' '}of{' '}
          <span className="text-brand-text font-medium">{totalPages || 1}</span>
        </span>

        {/* RIGHT GROUP */}
        <div className="flex items-center gap-2">
          <button
            onClick={goToNextPage}
            disabled={currentPage === totalPages || totalPages === 0}
            className="px-3 py-1.5 border border-brand-border rounded-lg text-sm text-brand-text-muted hover:bg-brand-bg hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Next
          </button>

          <button 
            onClick={() => setCurrentPage(totalPages)} 
            disabled={currentPage === totalPages || totalPages === 0}
            className="px-3 py-1.5 border border-brand-border rounded-lg text-sm text-brand-text-muted hover:bg-brand-bg hover:text-brand-text disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-300"
          >
            Last
          </button>
        </div>
      </div>
    </div>
  );
};
