import { useState, useEffect, useRef } from 'react';
import { MapPin, Loader2 } from 'lucide-react';

// --- GLOBAL PROXIMITY CACHE ---
// Key: IMEI
// Value: { lat: 18.52, lng: 73.85, address: "Pune, MH", timestamp: 12345678 }
const vehicleAddressCache = new Map();

// 0.0005 degrees is approximately 55 meters
const hasMovedSignificantly = (lat1, lng1, lat2, lng2) => {
  const THRESHOLD = 0.0005; 
  const dLat = Math.abs(lat1 - lat2);
  const dLng = Math.abs(lng1 - lng2);
  // Euclidean distance check for speed
  return Math.sqrt(dLat * dLat + dLng * dLng) > THRESHOLD;
};

export const LocationCell = ({ lat, lng, imei }) => {
  // Logic: Check for Invalid/Zero coordinates immediately
  const isNoGps = parseFloat(lat) === 0 && parseFloat(lng) === 0;

  // INITIALIZATION STATE STRATEGY:
  // Initialize state directly from cache to prevent "Loading..." flash on page swaps
  const [addressState, setAddressState] = useState(() => {

    // If No GPS, we don't need cache or loading
    if (isNoGps) return { address: null, loading: false };

    const cached = vehicleAddressCache.get(imei);
    if (cached && !hasMovedSignificantly(lat, lng, cached.lat, cached.lng)) {
      return { address: cached.address, loading: false };
    }
    return { address: null, loading: true };
  });

  const isMounted = useRef(true);

  // Subtitle coordinates (Always live)
  const displayLat = parseFloat(lat).toFixed(6);
  const displayLng = parseFloat(lng).toFixed(6);

  useEffect(() => {
    if (isNoGps) return;
    isMounted.current = true;

    const resolveLocation = async () => {
      // 1. CHECK CACHE (By ID & Distance)
      const cached = vehicleAddressCache.get(imei);
      
      // If we have a cached address AND vehicle hasn't moved > 50m from where we fetched it:
      if (cached && !hasMovedSignificantly(lat, lng, cached.lat, cached.lng)) {
        // If state matches cache, do nothing (avoid re-render)
        if (addressState.address !== cached.address) {
           if (isMounted.current) setAddressState({ address: cached.address, loading: false });
        }
        return;
      }

      // 2. FETCH NEW (Moved > 50m or First Load)
      try {
        if (isMounted.current) setAddressState(prev => ({ ...prev, loading: true }));

        const apiKey = import.meta.env.VITE_GOOGLE_API_KEY;
        if (!apiKey) throw new Error("No API Key");

        const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`;
        const response = await fetch(url);
        const data = await response.json();

        if (data.status === "OK" && data.results?.[0]) {
          const newAddress = data.results[0].formatted_address;
          
          // Update Cache with NEW Location anchor
          vehicleAddressCache.set(imei, {
            lat: parseFloat(lat),
            lng: parseFloat(lng),
            address: newAddress,
            timestamp: Date.now()
          });
          
          if (isMounted.current) {
            setAddressState({ address: newAddress, loading: false });
          }
        }
      } catch (error) {
        console.error("Geocoding error", error);
        if (isMounted.current) setAddressState(prev => ({ ...prev, loading: false }));
      }
    };

    resolveLocation();

    return () => { isMounted.current = false; };
  }, [lat, lng, imei]); // Re-run only if these change

  // A. No GPS Signal (Pill Style)
  if (isNoGps) {
    return (
      <span className="px-4 py-2 rounded-full text-xs font-medium border bg-brand-red/10 border-brand-red/20 text-brand-red transition-colors duration-300 whitespace-nowrap">
        No GPS Signal
      </span>
    );
  }

  // B. Valid Location (Standard View)
  return (
    <div className="flex flex-col gap-0.5 min-w-[200px]">
      <div className="flex items-start gap-1.5" title={addressState.address || "Resolving..."}>
        <MapPin 
          className={`w-4.5 h-4.5 mt-0.2 shrink-0 transition-colors duration-300 ${addressState.loading ? 'text-brand-text-muted animate-pulse' : 'text-brand-red'}`} 
        />
        
        {addressState.loading && !addressState.address ? (
          <span className="text-xs text-brand-text-muted italic transition-colors duration-300">Resolving location...</span>
        ) : (
          <span className="text-xs text-brand-text font-medium leading-snug break-words transition-colors duration-300">
            {addressState.address || "Unknown Location"}
          </span>
        )}
      </div>

      <div className="pl-5 text-[10px] text-brand-text-muted font-mono transition-colors duration-300">
        {displayLat}, {displayLng}
      </div>
    </div>
  );
};