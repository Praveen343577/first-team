# syntax = docker/dockerfile:1.2

FROM python:3.10-slim-bookworm

# ARG ENV

LABEL version="0.0.1"

RUN rm /etc/apt/apt.conf.d/docker-clean

ENV DEBIAN_FRONTEND=noninteractive
ENV PYTHONFAULTHANDLER=1
ENV PYTHONDONTWRITEBYTECODE 1
ENV PYTHONUNBUFFERED 1

RUN --mount=type=cache,target=/var/cache/apt,id=apt apt-get update && apt-get -y upgrade

# Create a non-root user
RUN useradd --create-home app
USER app
WORKDIR /home/app/app

COPY --chown=app:app ./src/requirements.txt .
RUN --mount=type=cache,target=/home/app/.cache/pip,id=pip \
    pip install --no-cache-dir -r ./requirements.txt

COPY --chown=app:app . .

EXPOSE 8000

ENTRYPOINT [  ]

# CMD [ "./entrypoint.sh" ]