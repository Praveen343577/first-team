# mqtt_processor/routing.py
from django.urls import re_path
from devices.consumers import DeviceCanDataConsumer, LiveDataConsumer, TotalCalculationConsumer

websocket_urlpatterns = [
    re_path(r'ws/live-data/$', LiveDataConsumer.as_asgi()),
    re_path(r'ws/can_data/$',DeviceCanDataConsumer.as_asgi()),
    re_path(r'ws/total_data/$',TotalCalculationConsumer.as_asgi())
]
