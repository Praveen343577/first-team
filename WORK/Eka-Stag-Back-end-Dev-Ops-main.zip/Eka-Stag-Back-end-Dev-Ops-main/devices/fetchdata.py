from flask import Flask,jsonify
import requests
# import mysql.connector
# from mysql.connector import Error
from datetime import datetime
# import threading
import time
from flask_cors import CORS
import pytz
from django.utils.timezone import make_aware
from devices.models import DeviceData
# from threading import Lock
import logging, time
from devices.models import LiveData,Device,ExtraDevice
from django.utils import timezone
from django_redis import get_redis_connection
import json



r = get_redis_connection("streams")
r_live = get_redis_connection("default")
logger = logging.getLogger("apscheduler")


#redis state for the live data
LIVE_DATA_KEY = "live_data"
CHANGED_DEVICES_KEY = "changed_devices"
CURRENTLY_CONNECTED_DEVICES_KEY = "currently_connected_devices"


ist = pytz.timezone("Asia/Kolkata")

def decoded_mmi_msg_to_processor(processor_payload):
    print("fetch data to the stream has been called..")
    for payload in processor_payload:
        msg_id = r.xadd(
            "telematics_decoded",
            payload,
            maxlen=1000,
            approximate=True
        )
        print(f"Added to stream: {msg_id}")


def get_bus():
   
    url = 'https://outpost.mappls.com/api/security/oauth/token'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'iamdarksied'
    }
    data = {
        'grant_type': 'client_credentials',
        'client_id': '96dHZVzsAutF3i3hEM7_kQPFBJF62pwFEg3x8EZiVMdh-J9N_Q48nUYTz7HoFQ4XzIycB5XzrFnnrnrA0JrzfQ==',
        'client_secret': 'lrFxI-iSEg8wly5-rTWGeVjEDOe6oD1TQr7pxi95htnYcHxpwfhdRT7-9M5dRTn0NIIB8lhW6XvI83I9vmcq-YlZBb0x-4YA'
    }

    response = requests.post(url, headers=headers, data=data,timeout = 10)
    if response.status_code != 200:
        print("access token error")
        return jsonify({'error': 'Failed to retrieve access token'}), response.status_code
    else:
        print("access token generated")

    json_data = response.json()
    token = json_data.get('access_token')

    url = 'https://intouch.mapmyindia.com/iot/api/devices'
    headers = {'Authorization': 'Bearer' + token}

    response1 = requests.get(url, headers=headers,timeout=10)
    if response1.status_code == 200:
        data = response1.json()
        return data
    else:
        print("failed to retrieve device data")
        return jsonify({'error': 'Failed to retrieve device data'}), response1.status_code
    

# def live_data(row, device, can_data, device_id):
#         can_data = can_data or {}

#         if (row.get("header") or "").strip() != "$NRM":
#             return

#         device_type = device.device_type.strip()

#         if device_type == "4w":
#             ignition = can_data.get("Ignition_Sense")
#         elif device_type == "3w":
#             ignition = can_data.get("IgnitionStatus")
#         else:
#             return

#         # parse timestamp
#         raw_ts = can_data.get("timestamp")
#         last_timestamp = None
#         if raw_ts:
#             try:
#                 last_timestamp = datetime.fromisoformat(raw_ts)
#                 if last_timestamp.tzinfo is None:
#                     last_timestamp = timezone.make_aware(last_timestamp, timezone.utc)
#             except Exception:
#                 last_timestamp = timezone.now()

#         ignition_off = ignition in (None, 0, "0", "OFF", False, "N")

#         defaults = {
#             "last_timestamp": last_timestamp,
#             "latitude": row.get("latitude"),
#             "latitude_dir": row.get("latitude_dir"),
#             "longitude": row.get("longitude"),
#             "longitude_dir": row.get("longitude_dir"),
#             "heading": row.get("heading"),
#         }

#         # update CAN only when ignition is valid
#         if not ignition_off:
#             defaults["can_data"] = can_data if not ignition_off else {}

#         LiveData.objects.update_or_create(
#             imei=device_id,
#             defaults=defaults,
#         )

def live_data(row, device, can_data, device_id):

    can_data = can_data or {}

    # Header check
    if (getattr(row, "header", "") or "").strip() != "$NRM":
        return

    device_type = (device.device_type or "").strip()
    

    if device_type == "4w":
        ignition = can_data.get("Ignition_Sense")
    elif device_type == "3w":
        ignition = can_data.get("IgnitionStatus")
    else:
        return

    # Parse timestamp
    raw_ts = can_data.get("timestamp")
    last_timestamp = None

    if raw_ts:
        try:
            last_timestamp = datetime.fromisoformat(raw_ts)

            if last_timestamp.tzinfo is None:
                last_timestamp = timezone.make_aware(
                    last_timestamp, timezone.utc
                )

        except Exception:
            last_timestamp = timezone.now()

    ignition_off = ignition in (None, 0, "0", "OFF", False, "N")

    # Defaults for LiveData
    defaults = {
        "last_timestamp": last_timestamp,
        "latitude": getattr(row, "latitude", None),
        "latitude_dir": getattr(row, "latitude_dir", None),
        "longitude": getattr(row, "longitude", None),
        "longitude_dir": getattr(row, "longitude_dir", None),
        "heading": getattr(row, "heading", None),
        "ignition": str(ignition) if ignition is not None else None,
    }

    # Update CAN only when ignition ON
    if not ignition_off:
        defaults["can_data"] = can_data
    # else:
    #     defaults["can_data"] = {}

    LiveData.objects.update_or_create(
        imei=device_id,
        defaults=defaults,
    )

    defaults.update({
    "imei": device_id,
    "device_type": device.device_type,
    "device_type_name": device.device_type_name,
    })

    return defaults


def normalize(v):
    if isinstance(v, dict):
        return json.dumps(v, default=str)
    if isinstance(v, datetime):
        return v.isoformat()
    return v


def store_data_in_db(devices_data):
    from django.db import close_old_connections
    from django.core.cache import cache


    close_old_connections()

    processor_payload = []

    if devices_data is None:
        return
    if devices_data: 
        cache.set("buffer_data", devices_data, timeout=120)
        print("inserted into cache")

    timestamp_dict = {}
    specific_dict = {}
    for item in devices_data.get("data", []):  
        location = item.get('location', {})
        device_details = item.get('deviceDetails', {})
        alerts = item.get('alerts', {})
        can_data = item.get('canInfo', {})
        todaysDrive = item.get('todaysDrive', {})
        status_value = item.get('status', '-')
        alarm_type_value = alerts.get('alarmType', '-')
        # mapped_alarm_type = alarm_mapping.get(alarm_type_value, '-')

        
        if can_data is None:
            print(f"No CAN data for device_id {id}")
            return 
        
        id = device_details.get('trackingCode')
        ts = location.get('gpsTime')
        if not ts:
            print("Timestamp missing, skipping this record")
            continue
        # dt = datetime.strptime(str(ts), "%Y-%m-%d %H:%M:%S")
        dt = datetime.fromtimestamp(int(ts))
        if isinstance(ts, (int, float)):
            timestamp = datetime.fromtimestamp(ts, tz=timezone.utc)

        else:
            # dt = datetime.strptime(str(ts), "%Y-%m-%d %H:%M:%S")
            timestamp = make_aware(dt, timezone.utc)


        instance = LiveData.objects.filter(imei=id).first()

        prev_timestamp = instance.last_timestamp if instance else None

        try:
            device_obj = Device.objects.get(device_id=id)
        except Device.DoesNotExist:
            ExtraDevice.objects.get_or_create(device_id=id)
            print(f"Unknown device stored to ExtraDevice: {id}")
            continue
        
        # print(timestamp_dict)
        if prev_timestamp is None or timestamp != prev_timestamp:
            # timestamp_dict[id] = timestamp
            common_fields = {"timestamp":timestamp,
                            "device_id":id,
                            "header":'$NRM',
                            "IMEI":item.get('id'),
                            "latitude":location.get('latitude'),
                            "latitude_dir":'N', 
                            "longitude":location.get('longitude'),
                            "longitude_dir":'E',
                            "heading":location.get('heading'),
                            "altitude":location.get('altitude'),
                            "packet_status":"L",
                            "extra_data":{}
                            }
            
            odo1 = int(can_data.get('TRANSFORMERTEMP') or 0)
            odo2 = int(can_data.get('SecondarymosfetTemperature') or 0)
            odo3 = int(can_data.get('PrimarymosfetTemperature') or 0)
            odometer = int(f"{odo1:02d}{odo2:02d}{odo3:02d}")

            
            req_fields = {"timestamp":dt.isoformat(),
                        "Ignition_Sense":int(can_data.get('IgnitionSense',0)),
                        # "ODOMETER":int(f"{int(float(can_data.get('TRANSFORMERTEMP') or 0))}{int(float(can_data.get('SecondarymosfetTemperature') or 0))}{int(float(can_data.get('PrimarymosfetTemperature') or 0))}"),
                        "ODOMETER":odometer,
                        "WheelBasedVehicleSpeed_Rx":can_data.get('WheelBasedVehicleSpeedRx'),
                        "DTE":can_data.get('AInsulationValue'),
                        "VCU_Flag":can_data.get('VCUFlag'),
                        "MCU_HighPowerVoltage":can_data.get('MCUHighPowerVoltage'),
                        "MCU_HighPowerCurrent":can_data.get('MCUHighPowerCurrent'),
                        "DCDC_Input_Voltage":can_data.get('DCDCInputVoltage'),
                        "DCDC_Input_Current":can_data.get('DCDCInputCurrent'),
                        "BCS_Compressor_Input_Voltage":can_data.get('BCScompressorinputvoltage'),
                        "BCS_Compressor_Input_Current":can_data.get('BCScompressorinputcurrent'),
                        "T2B_HV_Voltage_Input":can_data.get('BCScompressorinputvoltage'),
                        "T2B_HV_Current_Input":can_data.get('BCScompressorinputcurrent'),
                        "TCS_Energy": 0,
                        "ECompressor_Input_Power":can_data.get('ECompressorInputPower'),
                        "Streering_Input_Power":can_data.get('StreeringinputPower'),
                        "HVAC_Status":can_data.get('InHVACdetection'),
                        "Motor_Temperature":can_data.get('MCUMotorTemperature'),
                        "MCU_Temperature":can_data.get('MCUTemperature'),
                        "Ecomp_Actual_Heat_Sink_Temp":can_data.get('EcompActualHeatSinkTemp'),
                        "Steering_Actual_Heat_Sink_Temp":can_data.get('SteeringActualHeatSinkTemp'),
                        "TCS_Flag":can_data.get('TCSFlag'),
                        "TCS_Pump_Temperature":can_data.get('PumpTemp'),
                        "Pump_Speed":can_data.get('PumpSpeed'),
                        "Pump_Current":can_data.get('PumpCurrent'),
                        "TCS_Thermistor":can_data.get('TCSThermistor'),
                        "BCS_Flag":can_data.get('BCSFlag'),
                        "BCS_Status":can_data.get('BCSdetection'),
                        "BCS_Compressor_Speed": can_data.get('Speedofcompressor'),
                        "Brake_Tank_Pressure_1":can_data.get('ServiceBrakeCircuit1AirPres'),
                        "Brake_Tank_Pressure_2":can_data.get('ServiceBrakeCircuit2AirPres'),
                        "Gun_Detection_1":can_data.get('ChargerGunDetected2'),
                        "Gun_Detection_2":can_data.get('ChargerGunDetected2'),
                        "Pump_Voltage":can_data.get('PumpVoltage')
                        }
            

            device_type = str(device_details.get('name'))

            if device_type.startswith('7M'):
                specific_dict = {"A_SOC_Value" : can_data.get('ASOCValue'),"A_Max_Cell_Temp": can_data.get('AMaxCellTemp'),
                                "A_Pack_Voltage_Value" : can_data.get('APackVoltageValue'),"A_Pack_Current_Value" : can_data.get('APackCurrentValue'),
                                "BCS_Thermistor_1" : can_data.get('BCSThermistor1'),"A_Coolant_Inlet_Temp" : can_data.get('BMinCellTemp','BMaxCellTemp')
                                }
                
            elif device_type.startswith('9M'):
                specific_dict = {"A_SOC_Value" : can_data.get('ASOCValue'),"B_SOC_Value" : can_data.get('BSOCValue') ,
                                "A_Max_Cell_Temp": can_data.get('AMaxCellTemp'),"B_Max_Cell_Temp": can_data.get('AMaxCellTemp'),
                                "A_Pack_Voltage_Value" : can_data.get('APackVoltageValue'),"B_Pack_Voltage_Value" : can_data.get('BPackVoltageValue'),
                                "A_Pack_Current_Value" : can_data.get('APackCurrentValue'),"B_Pack_Current_Value" : can_data.get('BPackCurrentValue'),
                                "BCS_Thermistor_1": can_data.get('BCSThermistor1'),"BCS_Thermistor_2": can_data.get('BCSThermistor2'),
                                "A_Coolant_Inlet_Temp":can_data.get('BMaxCellTemp'),"B_Coolant_Intlet_Temp":can_data.get('BMinCellTemp')}
                
            elif device_type.startswith('12M'):
                pack_voltage = (float(can_data.get('APackVoltageValue') or 0) + float(can_data.get('BPackVoltageValue') or 0))/2
                pack_current = (int(can_data.get('BPackCurrentValue') or 0))/2
                coolant_temp = (int(can_data.get('BMinCellTemp') or 0) + int(can_data.get('BMaxCellTemp') or 0))/2
                specific_dict = {"A_SOC_Value" : can_data.get('ASOCValue'),"B_SOC_Value" : can_data.get('BSOCValue'),"C_SOC_Value" : can_data.get('BrakePedalPosition'),
                                "A_Max_Cell_Temp": can_data.get('AMaxCellTemp'),"B_Max_Cell_Temp": can_data.get('AMaxCellTemp'),"C_Max_Cell_Temp": can_data.get('AMaxCellTemp'),
                                "A_Pack_Voltage_Value" : pack_voltage,"B_Pack_Voltage_Value" : pack_voltage,"C_Pack_Voltage_Value" : pack_voltage,
                                "A_Pack_Current_Value" : can_data.get('APackCurrentValue'),"B_Pack_Current_Value" : pack_current,"C_Pack_Current_Value" : pack_current,
                                "BCS_Thermistor_1": can_data.get('BCSThermistor1'),"BCS_Thermistor_2": can_data.get('BCSThermistor2'),"BCS_Thermistor_3": can_data.get('BCSThermistor2'),
                                "A_Coolant_Intlet_Temp":coolant_temp,"B_Coolant_Intlet_Temp":coolant_temp,"C_Coolant_Intlet_Temp":coolant_temp}


            all_fields = {**req_fields,**specific_dict,**can_data}

            common_fields["can_data"] = all_fields
                
            data = DeviceData.objects.create(**common_fields)
            print(common_fields)
          
            can_data_updated = data.can_data

            normalized_payload = {**{k: normalize(v) for k, v in common_fields.items()},"can_data": json.dumps(common_fields.get("can_data", {}), default=str)}

            processor_payload.append(normalized_payload) 
            print(f"inside for loop {len(processor_payload)}")

            live_row = live_data(data, device_obj, can_data_updated, id)

            if live_row:
                existing_payload = r_live.hget(
                    LIVE_DATA_KEY,
                    id
                )

                if existing_payload:
                    try:
                        existing_payload = json.loads(existing_payload)
                    except Exception:
                        existing_payload = {}
                else:
                    existing_payload = {}

                existing_can_data = (
                    existing_payload.get("can_data") or {}
                )

                current_can_data = (
                    live_row.get("can_data") or {}
                )

                live_row["can_data"] = {
                    **existing_can_data,
                    **current_can_data
                }

                pipe = r_live.pipeline()

                pipe.hset(
                    LIVE_DATA_KEY,
                    id,
                    json.dumps(live_row, default=str)
                )

                pipe.sadd(
                    CHANGED_DEVICES_KEY,
                    id
                )

                pipe.sadd(
                    CURRENTLY_CONNECTED_DEVICES_KEY,
                    id
                )

                pipe.execute()
        else:
            print("Skipped process timestamp already exists.")
            continue
    print(f"outside for loop {len(processor_payload)}")
    if processor_payload:
        decoded_mmi_msg_to_processor(processor_payload)   
    # print(timestamp_dict)
            


def store_data():
    try:
        devices_data = get_bus()
        
        if not devices_data:
            print("[INFO] No data returned from get_bus")
            return

        if isinstance(devices_data, tuple):
            devices_data = {'status': devices_data[0], 'data': devices_data[1]}

        if devices_data and isinstance(devices_data, dict):
            store_data_in_db(devices_data)
    except requests.exceptions.Timeout:
        print("[TIMEOUT] get_bus exceeded 10 seconds")
    except Exception as e:
        logger.error(f"JOB ERROR: {e}", exc_info=True)
    finally:
        logger.warning("STORE_DATA END")