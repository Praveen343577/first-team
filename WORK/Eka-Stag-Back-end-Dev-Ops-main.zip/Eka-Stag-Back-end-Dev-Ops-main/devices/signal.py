import traceback
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from devices.models import DeviceData, AlertRule, Alert, Fault,Device,DeviceTotalCalculationData, FaultRule, LiveData
from django.utils import timezone
from devices.calculation import (
    combine_dtc_fields,
    total_calculations,
    total_calculations_3w,
    initialize_metrics
)
from devices.summary import live_daily_report_4w_calculation,live_daily_report_3w_calculation
import traceback
from datetime import timedelta,datetime
import unicodedata

# @receiver(post_save, sender=DeviceData, dispatch_uid="live_data_signal")
def live_data(sender,instance,created,**kwargs):

    can_data = instance.can_data or {}
    try:
        device = Device.objects.get(device_id=instance.device_id)
    except Device.DoesNotExist: 
        return
    if  can_data is None:
        return
    device_type = device.device_type.strip()
    #For 4w
    if device_type == '4w' and instance.header == '$NRM':
        ignition = can_data.get("Ignition_Sense",0)
        if ignition in (None, 0, "0", "OFF", False,"N"):
            return
        odometer = (
            can_data.get("ODOMETER_CRUT")
            if "ODOMETER_CRUT" in can_data and can_data.get("ODOMETER_CRUT") not in [None, 0, "N"]
            else can_data.get("ODOMETER") if can_data.get("ODOMETER") not in [None, 0, "N"] else 0
        )
        speed = can_data.get("WheelBasedVehicleSpeed_Rx",0)
        signal_mapping_variant_wise = {"7M": ["A"],"9M": ["A", "B"],"12M": ["A", "B", "C"],"13.5M": ["A"],"55T": ["A"],"1.5t": ["A"],}
        variant = device.device_type_name 
        prefixes = signal_mapping_variant_wise.get(variant, [])

        # Directly build SOC keys and temp keys based on the variants
        soc_keys = [f"{p}_SOC_Value" for p in prefixes]
        temp_keys = [f"{p}_Max_Cell_Temp" for p in prefixes]

        soc_values = []
        for key in soc_keys:
            value = can_data.get(key)
            if value is None:
                continue
            try:
                soc_values.append(float(value))
            except (TypeError, ValueError):
                pass

        if not soc_values:
            soc = 0
        else:
            soc = sum(soc_values) / len(soc_values)
        #for temperature
        temp_values = []
        for key in temp_keys:
            value = can_data.get(key)
            if value is None:
                continue
            try:
                temp_values.append(float(value))
            except (TypeError, ValueError):
                pass
        if temp_values:
            cell_temp = max(temp_values)
        else:
            cell_temp = 0
        
        dte = dte = float(can_data.get("DTE")) if str(can_data.get("DTE")).replace('.', '', 1).lstrip('-').isdigit() else 0
        ts = 0
        #Common fields
        latitude = instance.latitude
        latitude_dir = instance.latitude_dir
        longitude = instance.longitude
        longitude_dir = instance.longitude_dir
        heading = instance.heading
        
        time_stamp = can_data.get("timestamp")

        if time_stamp:
            time_stamp = datetime.fromisoformat(time_stamp)   # naive datetime
            time_stamp = timezone.make_aware(time_stamp, timezone.utc) # explicitly IST-aware

        last_timestamp = time_stamp

        try:
            obj,created = LiveData.objects.update_or_create(imei=instance.device_id,defaults={"last_timestamp":last_timestamp,"latitude":latitude,"latitude_dir":latitude_dir,
                                            "longitude":longitude,"longitude_dir":longitude_dir,"heading":heading,
                                            "odometer" : odometer,"speed" : speed,"soc":soc,"ts":ts,"cell_temp":cell_temp,"dte" : dte,
                                            "can_data": can_data,})
            if created:
                print(f"[Live Data] CREATED for {device} for type 4w")
            else:
                print(f"[Live Data] UPDATED for {device}for type 4w")
        except Exception as e:
            print(f"[Live Data] ERROR for {instance.device_id}: {e}")


    #For 3w
    elif device_type == '3w' and instance.header == '$NRM':
        ignition = can_data.get("IgnitionStatus")
        if ignition in (None, 0, "0", "OFF", False,"N"):
            return
        odometer = can_data.get("MCU_Odometer_Val")
        speed = can_data.get("MCU_Speed_Kmph")
        soc = can_data.get("SOC")
        ts_columns = ['TS1','TS1','TS3','TS4','TS5','TS6']
        ts_values = []
        for col in ts_columns:
            value = can_data.get(col)
            if value not  in (None,"N"):
                ts_values.append(value)
            else:
                continue
        if ts_values:
            ts = max(ts_values)
        else:
            ts = 0
        
        dte = float(can_data.get("Vehicle_DTE_Km")) if str(can_data.get("Vehicle_DTE_Km")).replace('.', '', 1).lstrip('-').isdigit() else 0
        cell_temp = 0
        print(f"Inserted live data for {device}")
            #Common fields
        latitude = instance.latitude
        latitude_dir = instance.latitude_dir
        longitude = instance.longitude
        longitude_dir = instance.longitude_dir
        heading = instance.heading

        time_stamp = can_data.get("timestamp")

        if time_stamp:
            time_stamp = datetime.fromisoformat(time_stamp)   # naive datetime
            time_stamp = timezone.make_aware(time_stamp, timezone.utc) # explicitly IST-aware

        last_timestamp = time_stamp

        
        try:
            obj,created = LiveData.objects.update_or_create(imei=instance.device_id,defaults={"last_timestamp":last_timestamp,"latitude":latitude,"latitude_dir":latitude_dir,
                                            "longitude":longitude,"longitude_dir":longitude_dir,"heading":heading,
                                            "odometer" : odometer,"speed" : speed,"soc":soc,"ts":ts,"cell_temp":cell_temp,"dte" : dte,
                                            "can_data": can_data,})
            if created:
                print(f"[Live Data] CREATED for {device} for type 3w")
            else:
                print(f"[Live Data] UPDATED for {device} for type 3w")
        except Exception as e:
            print(f"[Live Data] ERROR for {instance.device_id}: {e}")

    else:
        print("[Live Data] unpexpected header")
        return
    

# @receiver(post_save, sender=DeviceData)
def check_alerts_on_device_data_save(sender, instance, created, **kwargs):
    can_data = instance.can_data or {}
    if not can_data:
        return
    
    ignition_value = can_data.get("Ignition_Sense")

    if ignition_value in (None, 0, "0", "OFF", False,"N"):
        print("[INFO] Ignition OFF — skipping alert checks.")
        return

    try:
        device = Device.objects.get(device_id=instance.device_id)
    except Device.DoesNotExist:
        print(f"[ALERT SKIP] No Device row for device_id={instance.device_id}")
        return

    if device.device_type != '4w':
        return

    TEN_MIN = timedelta(minutes=10)
    THREE_MIN = timedelta(minutes=3)
    MIN_DURATION_BY_TYPE = {"Alert": TEN_MIN}
    DEFAULT_MIN_DURATION = THREE_MIN

    def to_num(v, default=0.0):
        try:
            if v in (None, '', 'null', 'None', 'NaN', 'nan', 'N'):
                return default
            x = float(v)
            return x if x == x and x not in (float('inf'), float('-inf')) else default
        except (TypeError, ValueError):
            return default

    class SafeDict(dict):
        def get(self, key, default=0.0):
            return to_num(super().get(key, default), default)
        def __getitem__(self, key):
            return to_num(super().get(key, 0.0), 0.0)
    safe_can = SafeDict(can_data)
    PARAM_MAP = {
        "7M": ["A"],
        "9M": ["A", "B"],
        "12M": ["A", "B", "C"],
        "13.5M": ["A"],
        "55T": ["A"],
        "1.5t": ["A"],
    }

    prefixes = PARAM_MAP.get(device.device_type_name, [])
    #For soc values you can use this in the rules 
    soc_values = [
        safe_can.get(f"{p}_SOC_Value")
        for p in prefixes
        if safe_can.get(f"{p}_SOC_Value") is not None
    ]

    #For temperatures
    temp_values = [
        safe_can.get(f"{p}_Max_Cell_Temp")
        for p in prefixes
        if safe_can.get(f"{p}_Max_Cell_Temp") is not None
    ]

    MAX_CELL_TEMP = max(temp_values) if temp_values else 0

    #For voltages 
    voltage_values = [
        safe_can.get(f"{p}_Pack_Voltage_Value")
        for p in prefixes
        if safe_can.get(f"{p}_Pack_Voltage_Value") is not None
    ]

    #For currents
    current_values = [
        safe_can.get(f"{p}_Pack_Current_Value")
        for p in prefixes
        if safe_can.get(f"{p}_Pack_Current_Value") is not None
    ]
    bcs = ['BCS_Thermistor_1','BCS_Thermistor_2','BCS_Thermistor_3']
    #For dcdc
    bcs_values = [
        safe_can.get(d)
        for d in bcs
        if safe_can.get(d) is not None
    ]
    SAFE_FUNCS = {
        "float": float, "int": int, "str": str,
        "max": max, "min": min, "abs": abs, "round": round,
        "sum": sum, "any": any, "all": all, "bool": bool
    }

    def _normalize_rule_text(s: str) -> str:
        return unicodedata.normalize("NFKC", (s or "")).strip()

    def _eval_rule(rule_text: str, ctx: dict) -> bool:
        rt = _normalize_rule_text(rule_text)
        code = compile(rt, "<rule>", "eval")
        safe_globals = {"__builtins__": {},  **ctx,}

        return bool(eval(code, safe_globals, {}))

    now = timezone.now()

    active_by_key = {(a.imei, a.name): a
        for a in Alert.objects.filter(imei=device.device_id, is_active=True)
    }

    alert_rules = AlertRule.objects.all()
    print("[INFO] Checking for alerts.")

    for rule in alert_rules:
        try:
            ctx = {
                "can_data": safe_can,
                "device": instance,
                "timezone": timezone,
                "device_type_name": device.device_type_name,
                "soc_values": soc_values,
                "temp_values": temp_values,
                "voltage_values": voltage_values,
                "current_values": current_values,
                "bcs_values": bcs_values,
                **SAFE_FUNCS,
            }
            condition_true = _eval_rule(rule.condition, ctx)
            key = (device.device_id, rule.name)
            open_alert = active_by_key.get(key)

            if condition_true:
                if not open_alert:
                    a = Alert.objects.create(
                        alert_type=rule.alert_type,
                        value=rule.description,
                        start_data_instance=can_data,
                        start_time=now,
                        end_time=now,
                        is_active=True,
                        imei=device.device_id,
                        duration_seconds=0,
                        name=rule.name,
                        device_type_name = device.device_type_name
                    )
                    active_by_key[key] = a
                    print(f"[Alert OPENED] {rule.name}")
                else:
                    open_alert.end_time = now
                    dur = now - open_alert.start_time
                    open_alert.duration_seconds = int(dur.total_seconds())
                    open_alert.save(update_fields=["end_time", "duration_seconds"])

            else:
                if open_alert:
                    open_alert.end_time = now
                    dur = now - open_alert.start_time
                    open_alert.duration_seconds = int(dur.total_seconds())
                    open_alert.is_active = False
                    open_alert.end_data_instance = can_data
                    open_alert.save(update_fields=["end_time", "duration_seconds", "is_active"])

                    min_required = MIN_DURATION_BY_TYPE.get(rule.alert_type, DEFAULT_MIN_DURATION)
                    if dur < min_required:
                        open_alert.delete()
                        print(f"[Alert DROPPED <{int(min_required.total_seconds()/60)}m] {rule.name}")
                    else:
                        print(f"[Alert CLOSED] {rule.name} duration={dur}")

                    # Remove from cache
                    active_by_key.pop(key, None)

        except Exception as e:
            print(f"[ALERT ERROR] {rule.name}: {e}")

# @receiver(post_save, sender=DeviceData)
# def check_alerts_on_device_data_save(sender, instance, created, **kwargs):
#     alert_rules = AlertRule.objects.all()
    
#     for rule in alert_rules:
#         try:
#             device = instance.device_id
#             can_data = instance.can_data or {}
#             # Evaluate the condition safely
#             condition_result = eval(rule.condition, {}, {
#                 "can_data": can_data,
#                 "device": device,
#                 "timezone": timezone,
#             })
#             if condition_result:
#                 Alert.objects.create(
#                     device=instance,
#                     alert_type=rule.alert_type,
#                     value=rule.description,
#                 )
#                 print(f'[Alert Created Success] {rule.name}')
#         except Exception as e:
#             print(f"[ALERT ERROR] {rule.name}: {str(e)}")

# @receiver(post_save, sender=DeviceData)
# def create_fault_alert(sender, instance, created, **kwargs):
#     can_data = instance.can_data
#     if not can_data:
#         return

#     all_faults = Fault.objects.all()

#     for fault in all_faults:
#         fault_key = fault.name.lower()

#         # Check key match
#         if any(fault_key in str(k).lower() for k in can_data.keys()) or \
#            any(fault_key in str(v).lower() for v in can_data.values()):

#             FaultAlert.objects.create(
#                 device=instance,
#                 fault=fault,
#                 can_data_snapshot=can_data
#             )

# @receiver(post_save, sender=DeviceData)
def create_device_calculated_data(sender, instance, created, **kwargs):
    can_data = instance.can_data
    try:
        device = Device.objects.get(device_id=instance.device_id)
        device_type = device.device_type
        device_type_name = device.device_type_name
        if DeviceTotalCalculationData.objects.filter(device_id=instance.device_id).exists():
            print(f"[Device Calculated Data] Already exists for {instance.device_id}, skipping...")
            
        
        else:
            if device.device_type == "3w":
                odometer = can_data.get("MCU_Odometer_Val", 0)
                initialize_metrics(device.device_id, "3w_6s", odometer)
            else:
                variant = '7m'
                for size in ['7m', '9m', '12m', 'coach', '55T_truck', '1.5t']:
                    if size in device_type_name:
                        variant = size
                odometer = can_data.get("ODOMETER", 0)
                initialize_metrics(device.device_id, variant, odometer)

        if device_type == '3w':
            odometer = can_data.get("MCU_Odometer_Val", 0)
            # print('check 3w')
            total_calculations_3w(
                can_data,
                instance.device_id,
                odometer,
                '3w_6s'  # TODO: make this dynamic
            )
            # print(f"[Device Calculated Data] Processed for 3w device: {instance.device_id}")

        elif device_type == '4w':
            odometer = can_data.get("ODOMETER", 0)
            print('check 4w')
            variant = '7m'
            Type = 7
            for size in ['7m', '9m', '12m', 'coach', '55T_truck', '1.5t']:
                if size in device_type_name:
                    variant = size
            for size in [7, 9, 12]:
                if str(size) in device_type_name:
                    Type = size

            total_calculations(
                can_data,
                instance.device_id,
                variant,
                odometer
            )
            # print(f"[Device Calculated Data] Processed for 4w device: {instance.device_id}")

        else:
            print(f"[Device Calculated Data] Skipped for device_type: {device_type}")

    except Device.DoesNotExist:
        print(f"[Device Calculated Data] Device with ID {instance.device_id} not found.")
    except Exception as e:
        print(f"[Device Calculated Data] Error while processing: {e}")

# @receiver(post_save, sender=DeviceData)
# def create_device_calculated_data(sender, instance, created, **kwargs):
#     can_data = instance.can_data
#     try:
#         device = Device.objects.get(device_id=instance.device_id)
#         device_type = device.device_type
#         device_type_name = device.device_type_name
#         if device.device_type == '3w':
#             odometer = can_data.get("MCU_Odometer_Val",0)
#             print('check 3w')
#             total_calculations_3w(can_data,instance.device_id,odometer,'3w_6s') #TODO for now its static we have to change to dynamic
#             print(f"[Device Calculated Data] Processed for 3w device: {instance.device_id}")
#         elif device.device_type == '4w':
#             odometer = can_data.get("ODOMETER",0)
#             print('check 4w')
#             variant = '7m'
#             Type = 7
#             for size in ['7m', '9m', '12m','coach','55T_truck','1.5t']:
#                 if size in device_type_name:
#                     variant = size
#             for size in [7, 9, 12]:
#                 if str(size) in device_type_name:
#                     Type = size
#             total_calculations(can_data, instance.device_id, variant,odometer)
#             print(f"[Device Calculated Data] Processed for 4w device: {instance.device_id}")
#         else:
#             print(f"[Device Calculated Data] Skipped for device_type: {device.device_type}")
#     except Device.DoesNotExist:
#         print(f"[Device Calculated Data] Device with ID {instance.device_id} not found.")
#     except Exception as e:
#         print(f"[Device Calculated Data] Error while processing: {e}")


# @receiver(post_save, sender=DeviceData)
def create_data_summary(sender, instance, created, **kwargs):
    # print(f"[DEBUG] create_data_summary called for device_id={instance.device_id}, created={created}")
    
    try:
        device = Device.objects.get(device_id=instance.device_id)
        device_data = instance
        device_id = instance.device_id
        end_lat = instance.latitude
        end_long = instance.longitude
        header = instance.header

        if device.device_type == "3w" and header == "$NRM":
            # print(f"[DEBUG] Calling live_daily_report_3w_calculation for {device_id}")
            live_daily_report_3w_calculation(device_data, device_id, end_lat, end_long)

        elif device.device_type == "4w" and header == "$NRM":
            # Determine variant from device_type_name
            variants = ['7M', '9M', '12M', '13.5M', '55T', '1.5t']
            variant = next((v for v in variants if v in device.device_type_name), '7m')
            # print(f"[DEBUG] Calling live_daily_report_4w_calculation for {device_id} with variant={variant}")
            live_daily_report_4w_calculation(device_data, device_id, variant, end_lat, end_long)

    except Exception as e:
        print(f"[ERROR] Exception in create_data_summary: {e}")
        traceback.print_exc()

def build_snapshot(instance):
    from django.forms.models import model_to_dict
    return model_to_dict(instance)

# @receiver(post_save, sender=DeviceData)
def detect_faults_from_can_data(sender, instance, created, **kwargs):
    print("Faults")
    if not created:
        return  # Only new DeviceData rows
 
    if not instance.can_data:
        return  # No CAN data to process
 
    try:
        device = Device.objects.get(device_id=instance.device_id)
    except Device.DoesNotExist:
        return  # No linked device, skip
 
    vehicle_type = str(device.device_type)
    # print("Type",vehicle_type,"Device id",instance.device_id)
    if vehicle_type.lower() == '4w':
        dtc_fields = combine_dtc_fields(instance.can_data)  
        # print("\t\t# DTC Found",dtc_fields,instance.device_id)
        for component, identifier in dtc_fields.items():
            component = component.split('_DTC')[0].upper()
            if float(identifier) < 50:
                identifier = str(float(identifier)+50)
            rule_qs = FaultRule.objects.filter(
                vehicle_type='4W',
                component=component,
                identifier=identifier
            )
            if rule_qs.exists():
                rule = rule_qs.first()
                Fault.objects.create(
                    device=device,
                    rule=rule,
                    component=component,
                    identifier=identifier,
                    data_snapshot=build_snapshot(instance)
                )
    #Working for 3W Faults
    elif vehicle_type.lower() == '3w':
        # Get all FaultRule identifiers for 3W once
        valid_identifiers = FaultRule.objects.filter(vehicle_type='3W').values_list('identifier', flat=True)
 
        # Check only those keys in can_data which are in the fault rules
        for col_name in valid_identifiers:
            if col_name in instance.can_data:
                value = instance.can_data[col_name]
                if value in ['1', 1, True, 'True', 'true']:  # Adjust to match your fault flags
                    rule_qs = FaultRule.objects.filter(
                        vehicle_type='3W',
                        identifier=col_name
                    )
                    if rule_qs.exists():
                        rule = rule_qs.first()
                        Fault.objects.create(
                            device=device,
                            rule=rule,
                            component=rule.component,
                            identifier=col_name,
                            data_snapshot=build_snapshot(instance)
                        )



