from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
from django.db import connections


class Device(models.Model):
    device_id = models.CharField(_("DeviceId"),max_length=5000, unique=True, blank=True)
    device_type = models.CharField(_("DeviceType"),max_length=500,null=True,blank=True)
    device_type_name = models.CharField(_("DeviceSpecificType"),max_length=500)
    VRN = models.CharField(_("VRN"),max_length=500,null=True,blank=True)
    chassis_number = models.CharField(_("Chassis_Number"),max_length=500,null=True,blank=True)
    city = models.CharField(_("City"),max_length=500,null=True,blank=True)
    DOP = models.DateField(_("Date_Of_Purchase"), auto_now_add=True)
    reg_date = models.DateField(_("Registration_Date"), auto_now_add=True)
    city = models.CharField(_("City"),max_length=500,null=True,blank=True)
    battery_type = models.CharField(_("Battery_Type"),max_length=500,null=True,blank=True)
    battery_make = models.CharField(_("Battery_Make"),max_length=500,null=True,blank=True)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
    refurbished = models.CharField(_("Refurbished"),max_length=500,null=True,blank=True)
    expire_on = models.DateTimeField(_("AMC_Expire_On"), auto_now_add=True)
    payment_model = models.CharField(_("Payment_Model"),max_length=500,null=True,blank=True)
    fleet_owner  = models.CharField(_("Fleet_Owner"),max_length=500,null=True,blank=True)
    fleet = models.CharField(_("Fleet"),null=True, blank=True, max_length=500)
    platform = models.CharField(_("Platform"),null=True, blank=True, max_length=500)
    is_connected = models.BooleanField(_("Connected"),default=False)
    is_active = models.BooleanField(_("Active"),default=True)
    last_seen = models.DateTimeField(_("Last_Login"), auto_now_add=True)
    ventilation_type = models.CharField(_("Ventilation_Type"),max_length=10,null=True,blank=True)


    def __str__(self):
        return self.device_id
    
    def save(self, *args, **kwargs):
        using = kwargs.pop('using', 'default')

        super().save(*args, using=using, **kwargs)

        if using == 'default':
            try:
                connections['replica'].ensure_connection()                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      

                clone = self.__class__.objects.using('default').get(pk=self.pk)
                clone.save(using='replica')

            except Exception as e:
                print("Replica unavailable:", str(e))
            
class ReplicaDevices(Device):
    class Meta:
        proxy = True
        verbose_name = "Replica Device"
        verbose_name_plural = "Replica Devices"
    
class ExtraDevice(models.Model):
    device_id = models.CharField(_("DeviceId"),max_length=5000, unique=True)
    last_seen = models.DateTimeField(_("Last_Login"), auto_now_add=True)
    is_notified = models.BooleanField(_("Notified"),default=False)
    
    def __str__(self):
        return self.device_id
    
    def save(self, *args, **kwargs):
        using = kwargs.pop('using', 'default')
        super().save(*args, using=using, **kwargs)

        try:
            if using == 'default':
                clone = self.__class__.objects.using('default').get(pk=self.pk)
                clone.pk = self.pk
                clone.save(using='replica')
        except Exception as e:
                print("Replica unavailable:", str(e))
    

class LiveData(models.Model):
    imei = models.CharField(max_length=500, unique=True)
    last_timestamp = models.DateTimeField(auto_now=False,null=True)
    latitude = models.CharField(max_length=500, null=True, blank=True)
    latitude_dir = models.CharField(max_length=500, null=True, blank=True)
    longitude = models.CharField(max_length=500, null=True, blank=True)
    longitude_dir = models.CharField(max_length=500, null=True, blank=True)
    odometer = models.FloatField(null=True, blank=True)
    ignition = models.CharField(max_length=5, null=True, blank=True)
    speed = models.FloatField(null=True, blank=True)
    heading = models.CharField(max_length=500, null=True, blank=True)
    soc = models.FloatField(null=True, blank=True)
    ts = models.FloatField(null=True, blank=True)
    cell_temp = models.FloatField(null=True, blank=True)
    dte = models.FloatField(null=True, blank=True)
    can_data = models.JSONField(null=True)




class DeviceData(models.Model):
    timestamp = models.DateTimeField(_("time_stamp"), auto_now_add=True)
    device_id = models.CharField(max_length=500, null=True, blank=True)
    NMR = models.CharField(max_length=500, null=True, blank=True)
    digital_input_status = models.CharField(max_length=500, null=True, blank=True)
    digital_output_status = models.CharField(max_length=500, null=True, blank=True)
    analog_input_1 = models.CharField(max_length=500, null=True, blank=True)
    analog_input_2 = models.CharField(max_length=500, null=True, blank=True)
    frame_number = models.CharField(max_length=500, null=True, blank=True)
    odometer = models.CharField(max_length=500, null=True, blank=True)
    debug_info = models.CharField(max_length=500, null=True, blank=True)
    header = models.CharField(max_length=500, null=True, blank=True)
    vendor_id = models.CharField(max_length=500, null=True, blank=True)
    version = models.CharField(max_length=500, null=True, blank=True)
    packet_type = models.CharField(max_length=500, null=True, blank=True)
    alert_id = models.CharField(max_length=500, null=True, blank=True)
    packet_status = models.CharField(max_length=500, null=True, blank=True)
    IMEI = models.CharField(max_length=500, null=True, blank=True)
    vehicle_reg_no = models.CharField(max_length=500, null=True, blank=True)
    gps_fix = models.CharField(max_length=500, null=True, blank=True)
    date = models.CharField(max_length=500, null=True, blank=True)
    time = models.CharField(max_length=500, null=True, blank=True)
    latitude = models.CharField(max_length=500, null=True, blank=True)
    latitude_dir = models.CharField(max_length=500, null=True, blank=True)
    longitude = models.CharField(max_length=500, null=True, blank=True)
    longitude_dir = models.CharField(max_length=500, null=True, blank=True)
    speed = models.CharField(max_length=500, null=True, blank=True)
    heading = models.CharField(max_length=500, null=True, blank=True)
    no_of_stattalites = models.CharField(max_length=500, null=True, blank=True)
    altitude = models.CharField(max_length=500, null=True, blank=True)
    pdop = models.CharField(max_length=500, null=True, blank=True)
    hdop = models.CharField(max_length=500, null=True, blank=True)
    operator = models.CharField(max_length=500, null=True, blank=True)
    ignition = models.CharField(max_length=500, null=True, blank=True)
    main_power_status = models.CharField(max_length=500, null=True, blank=True)
    main_input_voltage = models.CharField(max_length=500, null=True, blank=True)
    internal_battery_voltage = models.CharField(max_length=500, null=True, blank=True)
    emergency_status = models.CharField(max_length=500, null=True, blank=True)
    temper_alert = models.CharField(max_length=500, null=True, blank=True)
    gsm_strength = models.CharField(max_length=500, null=True, blank=True)
    MCC = models.CharField(max_length=500, null=True, blank=True)
    MNC = models.CharField(max_length=500, null=True, blank=True)
    LAC = models.CharField(max_length=500, null=True, blank=True)
    cell_id = models.CharField(max_length=500, null=True, blank=True)
    extra_data = models.JSONField()
    can_data = models.JSONField()
    processed = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        using = kwargs.pop('using', 'default')
        super().save(*args, using=using, **kwargs)

        if using == 'default':
            try:
                clone = self.__class__.objects.using('default').get(pk=self.pk)
                clone.pk = self.pk
                clone.save(using='replica')
            except Exception as e:
                print("Replica unavailable:", str(e))

                
class ReplicaDevicesData(DeviceData):
    class Meta:
        proxy = True
        verbose_name = "Replica DeviceData"
        verbose_name_plural = "Replica DevicesData"

class Alert(models.Model):
    alert_type = models.CharField(max_length=100)  # e.g., "Low Temperature"
    name = models.CharField(max_length=50,null=True) 
    value = models.CharField(max_length=100)       # e.g., "9.2"
    imei = models.CharField(max_length=500, null=True, blank=True)
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    duration_seconds = models.IntegerField(null=True, blank=True)
    req_data = models.JSONField(null=True)
    device_type_name = models.CharField(max_length=15,null=True)

from django.contrib.postgres.fields import ArrayField
class AlertRule(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    condition = models.TextField()  # e.g., 'can_data.get("temp", 0) < 10'
    alert_type = models.CharField(max_length=100)  # e.g., 'LOW_TEMP'
    req_signals = ArrayField(models.CharField(max_length=1000),default=list,blank=True)


        
# class Fault(models.Model):
#     name = models.CharField(max_length=100, unique=True)
#     description = models.TextField(blank=True, null=True)
#     created_at = models.DateTimeField(auto_now_add=True)

#     def __str__(self):
#         return self.name

class Fault(models.Model):
    imei = models.CharField(max_length=20,blank=True, null = True)
    rule = models.ForeignKey('FaultRule', on_delete=models.SET_NULL, null=True)
    component = models.CharField(max_length=100,blank=True, null=True)
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    duration_seconds = models.IntegerField(null=True, blank=True)
    data_snapshot = models.JSONField(blank=True, null=True)  # Full snapshot of the DeviceData row

    def __str__(self):
        return f"{self.device.device_id} - {self.component}:{self.identifier} at {self.created_at}"
    

# class FaultAlert(models.Model):
#     device = models.ForeignKey('DeviceData', on_delete=models.CASCADE, related_name='fault_alerts')
#     fault = models.ForeignKey(Fault, on_delete=models.CASCADE, related_name='alerts')
#     can_data_snapshot = models.JSONField()
#     timestamp = models.DateTimeField(auto_now_add=True)

#     def __str__(self):
#         return f"{self.fault.name} on {self.device.device_id} at {self.timestamp}"

class CanKeyPatterns(models.Model):
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    device_id = models.ForeignKey(Device, on_delete=models.CASCADE, related_name='can_key_patterns',blank=True,null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class DeviceTotalCalculationData(models.Model):
    device_id = models.CharField(max_length=500, unique=True)#
    total_distance = models.FloatField(default=0, null=True, blank=True)#
    co2_saving = models.FloatField(default=0, null=True, blank=True)
    energy_consumption = models.FloatField(default=0,null=True,blank=True)#
    run_time = models.FloatField(default=0,null=True,blank=True)#
    traction_energy = models.FloatField(default=0,null=True,blank=True)#
    regen_energy = models.FloatField(default=0,null=True,blank=True)#
    idle_time = models.FloatField(default=0,null=True,blank=True)#
    charging_unit = models.FloatField(default=0,null=True,blank=True)#
    charging_count = models.FloatField(default=0,null=True,blank=True)
    cost_saved = models.FloatField(default=0,null=True, blank=True)
    last_charging_state = models.BooleanField(default=False)
    last_charging_state_time = models.DateTimeField(null=True, blank=True)
    last_soc = models.FloatField(null=True, blank=True) 
    
    def __str__(self):
        return self.device_id


class DailySummaryReport(models.Model):
    date = models.DateField()
    imei = models.CharField(max_length=500, null=True, blank=True)
    vrn = models.CharField(max_length=500, null=True, blank=True)
    chassis_number = models.CharField(max_length=500,null=True,blank=True)
    vehicle_type = models.CharField(max_length=50, null=True, blank=True)
    vehicle_type_name = models.CharField(max_length=50, null=True, blank=True)
    fleet = models.CharField(max_length=50, null=True, blank=True)
    city = models.CharField(max_length=200, null=True, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    start_time_of_day = models.DateTimeField(null=True, blank=True)
    stop_time_of_day = models.DateTimeField(null=True, blank=True)
    runtime_minutes = models.FloatField(null=True, blank=True)
    idle_minutes = models.FloatField(null=True, blank=True)
    charging_minutes = models.FloatField(null=True, blank=True)
    stoppage_minutes = models.FloatField(null=True, blank=True)
    start_odometer = models.FloatField(null=True, blank=True)
    end_odometer = models.FloatField(null=True, blank=True)
    distance = models.FloatField(null=True, blank=True)
    average_speed = models.FloatField(null=True, blank=True)
    no_of_movement_sessions = models.IntegerField(null=True, blank=True)
    no_of_charging_cycles = models.IntegerField(null=True, blank=True)
    no_of_idle_sessions = models.IntegerField(null=True, blank=True)
    start_soc = models.FloatField(null=True, blank=True)
    end_soc = models.FloatField(null=True, blank=True)
    energy_consumed = models.FloatField(null=True, blank=True)
    regen_energy = models.FloatField(null=True, blank=True)
    motor_ec = models.FloatField(default=None,null=True, blank=True)
    dcdc_ec = models.FloatField(default=None,null=True, blank=True)
    ecompressor_and_steering_ec = models.FloatField(default=None,null=True, blank=True)
    bcs_ec = models.FloatField(default=None,null=True, blank=True)
    tcs_ec = models.FloatField(default=None,null=True, blank=True)
    energy_consumption = models.FloatField(null=True, blank=True)
    charging_unit = models.FloatField(null=True, blank=True)
    depth_of_discharge = models.BooleanField(default=False)
    insufficient_charge = models.BooleanField(default=False)
    battery_temperature = models.FloatField(null=True, blank=True)
    motor_temperature = models.FloatField(null=True, blank=True)
    co2_saving = models.FloatField(null=True)
    cost_saved = models.FloatField(null=True)
    mode = models.CharField(max_length=10,null=True, default = False, blank = True)
    sessions = models.JSONField(null=True, blank=True)
 
    def __str__(self):
        return f'{self.IMEI} - {self.VRN} - {self.vehicle_type}'
 
    class Meta:
        db_table = "DailySummaryReport"
        constraints = [
            models.UniqueConstraint(fields=['date', 'imei'], name='unique_date_imei')
        ]


class MaintenanceTickets(models.Model):
    device = models.ForeignKey('Device', on_delete=models.CASCADE,blank=True, null=True)
    vrn = models.CharField(max_length=50)
    device_specific_type = models.CharField(max_length=100)
    chassis_number = models.CharField(max_length=100,null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    scheduled_date = models.DateField(null=True, blank=True)
    location = models.TextField(max_length=55,null=True, blank=True)
    priority = models.CharField(max_length=25)
    category = models.CharField(max_length=25)
    description = models.TextField(max_length=255) #Detail description of the issue
    odometer = models.PositiveIntegerField()  
    status = models.BooleanField(default=False) # Active or Inactive
    resolved_date = models.DateField(null=True, blank=True)# when was this issue closed
    resolved_by = models.CharField(max_length=55,null=True, blank=True) # By whom was the issue resolved

    def __str__(self):
        return f"Ticket {self.vrn} - {self.device_specific_type} ({self.priority})"
    




class FaultRule(models.Model):
    vehicle_type = models.CharField(max_length=10)
    component = models.CharField(max_length=100,blank=True, null=True)
    identifier = models.CharField(max_length=100)
    details = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

