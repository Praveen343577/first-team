from django.contrib import admin

from devices.models import (
    Device,
    DeviceTotalCalculationData,
    ReplicaDevices,
    DeviceData,
    ReplicaDevicesData,
    ExtraDevice,
    Alert, 
    AlertRule,
    Fault,
    # FaultAlert,
    CanKeyPatterns,
    FaultRule
)

admin.site.site_header = "Eka Connect Admin Panel"
admin.site.site_title = "Eka Connect Admin Portal"
admin.site.index_title = "Welcome to Eka Connect"

@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    fields = ['device_id', 'device_type', 'device_type_name', 'is_connected', 'is_active', 'last_seen','VRN','chassis_number','city','DOP','battery_type','battery_make','refurbished','payment_model','fleet_owner','fleet','platform','ventilation_type']
    list_display = (
        'id', 'device_id', 'is_connected', 'is_active', 'last_seen','VRN'
    )
    list_filter = ('device_id', 'is_connected', 'is_active', 'last_seen')
    search_fields = ('device_id', 'is_connected', 'is_active', 'last_seen')
    readonly_fields = ('id', 'is_connected', 'is_active', 'last_seen','DOP')
    
    list_per_page = 10
    
    show_full_result_count = False
    
    def get_queryset(self, request):
        return super().get_queryset(request).using('default')

    def save_model(self, request, obj, form, change):
        obj.save(using='default')

    def delete_model(self, request, obj):
        obj.delete(using='default')
   
@admin.register(ReplicaDevices)     
class ReplicaDeviceAdmin(admin.ModelAdmin):
    fields = ['device_id', 'device_type', 'device_type_name', 'is_connected', 'is_active', 'last_seen']
    list_display = (
        'id', 'device_id', 'is_connected', 'is_active', 'last_seen'
    )
    list_filter = ('device_id', 'is_connected', 'is_active', 'last_seen')
    search_fields = ('id', 'device_id', 'is_connected', 'is_active', 'last_seen')
    readonly_fields = ('id', 'is_connected', 'is_active', 'last_seen')

    list_per_page = 10
    
    show_full_result_count = False

    def get_queryset(self, request):
        return super().get_queryset(request).using('replica')

    def save_model(self, request, obj, form, change):
        obj.save(using='replica')

    def delete_model(self, request, obj):
        obj.delete(using='replica')

@admin.register(DeviceData)
class DeviceDataAdmin(admin.ModelAdmin):
    list_display = ('device_id', 'latitude', 'longitude', 'timestamp')  
    list_filter = ('device_id',) 
    search_fields = ('device_id',) 
    readonly_fields = ('device_id',)

    list_per_page = 10  

    show_full_result_count = False  

    def get_queryset(self, request):
        qs = super().get_queryset(request).using('default')
        return qs.select_related('device_id') if hasattr(self.model, 'device') else qs

    def save_model(self, request, obj, form, change):
        obj.save(using='default')

    def delete_model(self, request, obj):
        obj.delete(using='default')

@admin.register(ReplicaDevicesData)
class ReplicaDeviceDataAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'device_id', 'latitude', 'longitude'
    )
    list_filter = ('id', 'device_id')
    search_fields = ('id', 'device_id')
    readonly_fields = ('id', 'device_id')
    
    list_per_page = 10
    
    show_full_result_count = False
    
    def get_queryset(self, request):
        return super().get_queryset(request).using('replica')

    def save_model(self, request, obj, form, change):
        obj.save(using='replica')

    def delete_model(self, request, obj):
        obj.delete(using='replica')

@admin.register(ExtraDevice)
class ExtraDeviceAdmin(admin.ModelAdmin):
    list_display = (
        'id', 'device_id'
    )
    list_filter = ('device_id',)
    search_fields = ('device_id',)
    readonly_fields = ('device_id',)

    list_per_page = 10
    
    show_full_result_count = False

@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = ('id', 'alert_type', 'name', 'value', 'start_time', 'end_time', 'is_active')
    list_filter = ('alert_type', 'start_time')
    search_fields = ('device__device_id', 'alert_type', 'value')
    ordering = ('-start_time',)
    
    list_per_page = 10
    
    show_full_result_count = False

@admin.register(AlertRule)
class AlertRuleAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'alert_type', 'condition', 'description')
    search_fields = ('name', 'alert_type', 'condition')
    list_filter = ('alert_type',)
    
    list_per_page = 10
    
    show_full_result_count = False

# @admin.register(Fault)
# class FaultAdmin(admin.ModelAdmin):
#     list_display = ('name', 'description', 'created_at')
#     list_per_page = 10
    
#     show_full_result_count = False

# @admin.register(FaultAlert)
# class FaultAlertAdmin(admin.ModelAdmin):
#     list_display = ('device', 'fault', 'timestamp')
#     list_per_page = 10
    
#     show_full_result_count = False

@admin.register(FaultRule) #New
class FaultRuleAdmin(admin.ModelAdmin):
    list_display = ('vehicle_type','component','identifier','details','created_at')
    search_fields = ('component','identifier')

@admin.register(Fault) #New
class FaultAdmin(admin.ModelAdmin):
    list_display = ('rule',)



@admin.register(CanKeyPatterns)
class CanKeyPatternsAdmin(admin.ModelAdmin):
    fields = ['name', 'description', 'device_id']
    readonly_fields = ['created_at']
    list_display = ('id', 'name', 'device_id', 'created_at')
    search_fields = ('name', 'description')
    list_filter = ('device_id', 'created_at')
    list_per_page = 10
    
    show_full_result_count = False

@admin.register(DeviceTotalCalculationData)
class DeviceTotalCalculationDataAdmin(admin.ModelAdmin):
    fields = [
        'device_id', 'total_distance', 'co2_saving', 'energy_consumption',
        'run_time', 'traction_energy', 'regen_energy', 'idle_time',
        'charging_unit', 'charging_count', 'cost_saved'
    ]
    list_display = (
        'device_id', 'total_distance', 'co2_saving', 'energy_consumption',
        'run_time', 'traction_energy', 'regen_energy', 'idle_time',
        'charging_unit', 'charging_count', 'cost_saved'
    )
    search_fields = ('device_id',)
    list_filter = ('device_id',)
    list_per_page = 10
    
    show_full_result_count = False
