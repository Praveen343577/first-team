from collections import defaultdict
import re
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from django.utils import timezone
from devices.models import DeviceTotalCalculationData

def format_duration(duration):
    hours = int(duration // 3600)
    minutes = int((duration % 3600) // 60)
    seconds = int(duration % 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

def convert_timestamp(df, time_col): 
    if time_col in df.columns: 
        df[time_col] = pd.to_datetime(df[time_col]) 
    return df

def check_values_smaller_than_20(df, column_name):
    """
    Returns:
        - Boolean: Whether any value < 20 (and > 0) exists
        - Last SOC value that matches the condition
        - Corresponding timestamp
    """
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' not found in DataFrame.")
    
    filtered = df[(df[column_name] < 20) & (df[column_name] != 0)]
    
    if filtered.empty:
        return False, None, None

    last_row = filtered.iloc[-1]
    return True, last_row[column_name], last_row['timestamp']

def format_timestamp(ts):
    return ts.strftime('%Y-%m-%d %H:%M:%S')

def initialize_metrics(device_id,variant,odometer):
    total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)
    #converting the odometer into a floating point
    try:
        odometer = float(odometer)
        if odometer == 0 or np.isnan(odometer):
            return False
    except (TypeError, ValueError):
        return False
   
    #currently Declared inside the function in the next version use data from the Table
    electric_ecr = {
        '7m': 0.8,
        '9m': 1,
        '12m': 1.3,
        'coach': 1.4,
        '55T_truck': 1.4,
        '1.5t':0.35,
        '3w_6s': 0.08,
    }
    diesel_mileage = {
        '7m': 8,
        '9m': 4,
        '12m': 4,
        'coach': 3.5,
        '55T_truck': 2.5,
        '1.5t': 6,  
        '3w_6s': 25    
    }
    battery_capacity_kwh ={
 
        '7m': 100,
        '9m': 200,
        '12m': 300,
        'coach': 451,
        '55T_truck': 423,
        '1.5t': 32,  
        '3w_6s': 15    
 
    }
    total_distance_km = odometer
 
 
    EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
    GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh (CO2 emissions for producing electricity)
    diesel_price = 90               # ₹ per litre
    electricity_price = 8           # ₹ per kWh
   
 
    # Diesel CO2 emissions + cost
    liters_per_km = 1 / diesel_mileage[variant]
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price
 
    #Electric CO2 emissions + cost
    ecr = electric_ecr[variant]
    co2_electric = ecr * GRID_CO2_INTENSITY
    cost_electric = ecr * electricity_price
 
    #Savings for 1 km
    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric
 
 
    #Total for total distance , Take this from the stored values o
    total_co2_saved = co2_saved * total_distance_km
    total_cost_saved = cost_saved * total_distance_km
 
    factor = electric_ecr.get(variant, 1)
    traction_energy = factor * odometer
    regeneration_energy = traction_energy * 0.3
    energy_consumption = traction_energy - regeneration_energy  
    charging_units = ecr * odometer * 1.1
    runtime_hrs = odometer / 30 # Assuming speed= 30km/h
    idletime_hr = runtime_hrs * 0.15 #Assuming 15% idle time
 
    battery_capacity = battery_capacity_kwh.get(variant, 100)  # fallback: 100 kWh
    charging_count = round(charging_units / battery_capacity)
 
    total_data.total_distance = odometer
    total_data.traction_energy = (total_data.traction_energy or 0) + traction_energy
    total_data.regen_energy = (total_data.regen_energy or 0) + regeneration_energy
    total_data.run_time = (total_data.run_time or 0) + runtime_hrs
    total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
    total_data.idle_time = (total_data.idle_time or 0) + idletime_hr
    total_data.energy_consumption = (total_data.energy_consumption or 0) +  energy_consumption
    total_data.co2_saving =  total_co2_saved
    total_data.cost_saved =  total_cost_saved
    total_data.charging_count = (total_data.charging_count or 0) + charging_count
    total_data.save()
 
    return True
 
#updated on 26th Sept 7PM
def total_calculations_3w(device_data, device_id, odometer, variant):
   
    if not device_data:
        return
   
    total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)
 
    df = pd.DataFrame([device_data])
    df = df.replace('N', np.nan)
 
    if df.empty:
        return {}
 
    # Config values
    diesel_mileage = {'3w_6s': 25}
    electric_ecr = {'3w_6s': 0.08}
    EMISSION_FACTOR_DIESEL = 2.68  # kg CO2/litre
    GRID_CO2_INTENSITY = 0.2       # kg CO2/kWh
    diesel_price = 90              # ₹ per litre
    electricity_price = 8          # ₹ per kWh
 
    # Calculations
    liters_per_km = 1 / diesel_mileage[variant]
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price
 
    ecr = electric_ecr[variant]
    co2_electric = ecr * GRID_CO2_INTENSITY
    cost_electric = ecr * electricity_price
 
    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric
 
    total_distance_km = float(odometer) if (odometer is not None and odometer != 0) else (total_data.total_distance or 0) #Considering valid odometer
    if total_distance_km:
        total_data.total_distance = total_distance_km
        total_data.co2_saving = co2_saved * total_distance_km
        total_data.cost_saved = cost_saved * total_distance_km
 
 
    # Charging Condition
    is_charging = not (pd.isna(df.at[0, 'Charger_Output_VOL']) and pd.isna(df.at[0, 'Charger_Output_CUR']))
    current_time = pd.to_datetime(device_data.get('timestamp'), errors='coerce', utc = True)
    current_soc = device_data.get('SOC', None)
 
    TIME_GAP_THRESHOLD = 10 * 60  # 10 minutes in seconds
    SOC_JUMP_THRESHOLD = 5        # % jump to consider as charging
 
    last_state = total_data.last_charging_state if total_data.last_charging_state is not None else False
    last_time = total_data.last_charging_state_time
    last_soc = total_data.last_soc if total_data.last_soc is not None else current_soc
 
    if last_time is not None and current_time is not None:
        time_diff = (current_time - last_time).total_seconds()
    else:
        time_diff = None
 
    if last_time is None:
        if is_charging:
            total_data.charging_count = (total_data.charging_count or 0) + 1
            total_data.last_charging_state_time = current_time
        total_data.last_charging_state = is_charging
 
    else:
        if last_state != is_charging: #State Change
            if not last_state and is_charging:
                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data.charging_count = (total_data.charging_count or 0) + 1
                total_data.last_charging_state_time = current_time
            total_data.last_charging_state = is_charging
           
 
        # SOC jump fallback only if not charging
        if (not is_charging) and (current_soc is not None) and (last_soc is not None):
            soc_diff = current_soc - last_soc
            if soc_diff > SOC_JUMP_THRESHOLD:
                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data.charging_count = (total_data.charging_count or 0) + 1
                    total_data.last_charging_state = True
                    total_data.last_charging_state_time = current_time
 
    # Update state tracking
    total_data.last_soc = current_soc
 
    # --- Energy Calculations ---
    df['energy_kwh'] = (
        (df['BatteryVoltage'] / 10000) *
        (df['BatteryCurrent'] / 1000) *
        10
    ) / (1000 * 3600)
 
    not_charging_mask = df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()
    charge_df = df[~not_charging_mask].copy()
    charging_units = charge_df['energy_kwh'].sum() if not charge_df.empty else 0
 
    movement_df = df[not_charging_mask].copy()
    energy_kwh = movement_df['energy_kwh'].sum()
    regen_energy = movement_df.loc[movement_df['energy_kwh'] > 0, 'energy_kwh'].sum()
    traction_energy = movement_df.loc[movement_df['energy_kwh'] < 0, 'energy_kwh'].sum()
 
    run_time_hrs = (movement_df['MCU_Speed_Kmph'][movement_df['MCU_Speed_Kmph'] > 5].count() * 10) / 3600
    idle_time_hrs = (movement_df['MCU_Speed_Kmph'][movement_df['MCU_Speed_Kmph'] < 5].count() * 10) / 3600
 
    # --- Store all data ---
    total_data.traction_energy = (total_data.traction_energy or 0) + abs(traction_energy)
    total_data.regen_energy = (total_data.regen_energy or 0) + regen_energy
    total_data.run_time = (total_data.run_time or 0) + run_time_hrs
    total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
    total_data.idle_time = (total_data.idle_time or 0) + idle_time_hrs
    total_data.energy_consumption = (total_data.energy_consumption or 0) + abs(energy_kwh)
 
    total_data.save()
 
    print(f"Updated totals for {device_id}: Traction={total_data.traction_energy:.2f} kWh, Regen={total_data.regen_energy:.2f} kWh, ChargingCount={total_data.charging_count}")
    return True
 
############# 4 Wheeler Calculations ##################
 
def total_calculations(device_data, device_id, variant, odometer):
   
    if not device_data:
        return
 
    total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)
   
    df = pd.DataFrame([device_data])
 
    # Replace 'N' with NaN for all numeric columns
    df = df.replace('N', np.nan)
   
    if df.empty or 'VCU_Flag' not in df.columns:
        return {}
 
    # Convert all numeric columns to numbers where possible
    timestamp_col = 'timestamp'
    cols_to_convert = [col for col in df.columns if col != timestamp_col]
 
    df[cols_to_convert] = df[cols_to_convert].apply(pd.to_numeric, errors='coerce')
   
    diesel_mileage = {
        '9m': 4,
        '12m': 4,
        '7m': 8,
        'coach': 3.5,
        '55T_truck': 2.5,
        '1.5t': 6,
    }
 
    electric_ecr = {
        '9m': 1,
        '12m': 1.3,
        '7m': 0.8,
        'coach': 1.4,
        '55T_truck': 1.4,
        '1.5t':0.35
    }
 
    EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
    GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh
    diesel_price = 90               # ₹ per litre
    electricity_price = 8           # ₹ per kWh
 
    # Fuel/CO2 savings (only for this variant)
    liters_per_km = 1 / diesel_mileage[variant]
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price
 
    ecr_variant = electric_ecr[variant]
    co2_electric = ecr_variant * GRID_CO2_INTENSITY
    cost_electric = ecr_variant * electricity_price
 
    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric
   
   
   
    total_distance_km = float(odometer) if (odometer is not None and odometer != 0) else (total_data.total_distance or 0) #Considering valid odometer
    if total_distance_km:
        total_data.total_distance = total_distance_km
        total_data.co2_saving = co2_saved * total_distance_km
        total_data.cost_saved = cost_saved * total_distance_km
 
 
    # Active battery packs
    active_packs = {
        '12m': ['A', 'B', 'C'],
        '9m': ['A', 'B'],
        '7m': ['A'],
        "55T_truck":['A'],
        "coach":['A']
    }.get(variant, ['A'])
 
    # # Charging
    charge_df = df[df['VCU_Flag'] == 92].copy()
    # Movement
    movement_df = df[df['VCU_Flag'] != 92].copy()
    # Runtime
    runtime_hours = (df['VCU_Flag'].isin([50, 51, 52, 60]).sum() * 10) / 3600
    # Idle time
    idletime_hours = (df['VCU_Flag'].isin([13, 70]).sum() * 10) / 3600
 
    # Charging condition (True if charge_df not empty)
    is_charging = not charge_df.empty
 
   
   
 
    # Time gap threshold in seconds to count as a new cycle (e.g., 10 minutes)
    TIME_GAP_THRESHOLD = 10 * 60  # 10 minutes in seconds
 
 
    current_time = pd.to_datetime(device_data.get('timestamp'), errors='coerce', utc=True)
 
    is_charging = df.iloc[0]['VCU_Flag'] == 92  # exactly 92 as in code 1
 
    last_state = total_data.last_charging_state if total_data.last_charging_state is not None else False
    last_time = total_data.last_charging_state_time
 
    # If no previous charging time and currently charging, initialize timestamp and increment count
    if last_time is None and is_charging:
        total_data.last_charging_state_time = current_time
        total_data.last_charging_state = is_charging
        total_data.charging_count = (total_data.charging_count or 0) + 1
    else:
        if last_time is not None and current_time is not None:
            time_diff = (current_time - last_time).total_seconds()
        else:
            time_diff = None
 
    # Check for state change
    if last_state != is_charging:
        if not last_state and is_charging:
            # Charging started
            if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                total_data.charging_count = (total_data.charging_count or 0) + 1
            # Update last charging start time only on charging start
            total_data.last_charging_state_time = current_time
       
        # Update charging state on any change
        total_data.last_charging_state = is_charging
 
    # --- End charging count logic ---
 
    # Energy consumption from packs
    kwh_total  = 0
    pack_regen = 0
    pack_traction = 0
    charging_units = 0
    for pack in active_packs:
        kwh_col = f"{pack}_kWh"
        movement_df[kwh_col] = (movement_df[f"{pack}_Pack_Voltage_Value"] * movement_df[f"{pack}_Pack_Current_Value"]) * 10 / (1000 * 3600)
        pack_regen += movement_df.loc[movement_df[kwh_col] > 0, kwh_col].sum(skipna=True)
        pack_traction += movement_df.loc[movement_df[kwh_col] < 0, kwh_col].sum(skipna=True)
        if not charge_df.empty:
            charging_units += (charge_df[f"{pack}_Pack_Voltage_Value"]* charge_df[f"{pack}_Pack_Current_Value"] * 10 / (1000 * 3600)).sum(skipna=True)
        kwh_total += movement_df[kwh_col].sum(skipna=True)
 
    # Update cumulative totals
    total_data.traction_energy = (total_data.traction_energy or 0) + abs(pack_traction)
    total_data.regen_energy = (total_data.regen_energy or 0) + pack_regen
    total_data.run_time = (total_data.run_time or 0) + runtime_hours
    total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
    total_data.idle_time = (total_data.idle_time or 0) + idletime_hours
    total_data.energy_consumption = (total_data.energy_consumption or 0) + abs(kwh_total)
    #saving
    total_data.save()
 
    print(f"Updated totals for {device_id}: Traction={total_data.traction_energy}, Regen={total_data.regen_energy}, ChargingCount={total_data.charging_count}")
    return True

def report_calculations_cooling_4w(device_data, device_id,variant):
    if not device_data:
        print("No data for device:")
        return {}
 
    # Create DataFrame
    df = pd.DataFrame(device_data)
   
    if 'VCU_Flag' not in df.columns:
        return {}
 
    df = df.replace('N',np.nan)
    # Convert all columns to numeric if possible, replace non-numeric with NaN
    for col in df.columns:
        if col != 'timestamp':
            df[col] = pd.to_numeric(df[col], errors='coerce')
   
    df = convert_timestamp(df,'timestamp')
   
    if not df['timestamp'].is_monotonic_increasing: # Ensure chronological order
        df = df.sort_values(by='timestamp').reset_index(drop=True)
   
    active_packs = {
        '12m': ['A', 'B', 'C'],
        '9m': ['A', 'B'],
        '7m': ['A'],
        'coach': ['A'],
        '55T_truck': ['A'],
        '1.5t': ['A']
    }[variant]
   
    ac_bus = True if df['HVAC_Status'].any() else False
    BCS_Params=['BCS_Flag','HVAC_BCS_DTC_1','HVAC_BCS_DTC_2',]
    if ac_bus:
        #Adding HVAC Params
        BCS_Params.extend([
                            'HVAC_Status',
                            'T2B_Tin',
                            'T2B_Tout',
                            'T2B_Mode',
                            'T2B_TMS_Work_Mode',
                            'T2B_BMS_Work_Mode',
                            'T2B_Pump_Rly_Output',
                            'T2B_HV_Voltage_Input',
                            'T2B_HV_Current_Input',
                            'T2B_AC_Mode',
                            'T2B_PTC_Status',
                            'T2B_Comp_Frequency',
                            'T2B_Comp_Current',
                            'T2B_Comp_Voltage'
                    ])
    else:
        #Adding BCS Params
        BCS_Params.extend([
                    'BCS_Status',
                    'ATC_Compressor_Enable',
                    'BCS_HVIL_Out',
                    'BCS_Relay_Coil_GND_LSO7',
                    'BCS_HVAC_Energy',
                    'BCS_Compressor_Input_Voltage',
                    'BCS_Compressor_Input_Current',
                    'BCS_Compressor_Speed',
                    'BCS_Compressor_Controller_Temp',
                ])
 
    #Adding BCS Params based on battery packs
    BCS_Params.extend([f"BCS_Thermistor_{i+1}" for i in range(len(active_packs))]+[f"{pack}_Coolant_Inlet_Temp" for pack in active_packs]+[f"{pack}_Coolant_Outlet_Temp" for pack in active_packs])
 
 
 
    TCS_Params =[
                'TCS_Flag',
                'TCS_Status',
                'TCS_DTC_1',
                'TCS_DTC_2',
                'TCS_Rad_Fan_FB',
                'TCS_Coolent_Level_SW',
                'TCS_Thermistor',
                'HV_TCS_FAN_LSO4',
                'HV_TCS_Elctronic_On_Relay_LSO5',
                'TCS_Pump_Temperature',
    ]
   
    params_to_check={
        'DCDC_Temp_Max':75,
        'Ecomp_Actual_Heat_Sink_Temp':73,
        'Steering_Actual_Heat_Sink_Temp':73,
        'Motor_Temperature':150,
        'MCU_Temperature':70,
    }
   
    #Considering max of all DCDC temps
    for col in ['DCDC_Temp_1', 'DCDC_Temp_2', 'DCDC_Temp_3', 'DCDC_Temp_4']:
        if col not in df.columns:
            df[col] = 0
   
    df['DCDCTemperature_Max'] = df[['DCDC_Temp_1','DCDC_Temp_2','DCDC_Temp_3','DCDC_Temp_4']].max(axis=1)
   
    #Adding Battery Temperatures based on active packs
    params_to_check = {**params_to_check, **{f"{pack}_Max_Cell_Temp": 40 for pack in active_packs}}
   
    results = []
    for component,threshold in params_to_check.items():
        temp_df = df[df[component]>threshold]
        temp_df['Time_difference_seconds'] = temp_df['timestamp'].diff().dt.total_seconds().fillna(0)
        temp_df['session_break'] = temp_df['Time_difference_seconds'] > 900 # 15 minutes
        for _, session in temp_df.groupby(temp_df['session_break'].cumsum()):
            duration = session['Time_difference_seconds'].sum()
            if duration > 180 : # 3 minutes
                results.append({
                    'Date':session['timestamp'].iloc[0].date(),
                    'VRN': device_id,
                    'Component':component,
                    'Temperature':f"{session[component].iloc[0]} - {session[component].iloc[-1]}",
                    'Threshold':threshold,
                    'TimePeriod':f"{session['timestamp'].iloc[0]}  -  {session['timestamp'].iloc[-1]}",
                    'BCS': {param: f"{session[param].iloc[0]} - {session[param].iloc[-1]}" for param in BCS_Params if param in session.columns},
                    'TCS': {param: f"{session[param].iloc[0]} - {session[param].iloc[-1]}" for param in TCS_Params if param in session.columns},
                })
 
 
    return results

#use this for cooling report 
# def report_calculations_cooling_4w(device_data, device_id, date):
#     if not device_data:
#         print("No data for device:", device_id)
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     if df.empty:
#         print("No Data")
#         return {}

#     # Define thresholds
#     conditions = {
#         'A_Max_Cell_Temp': 35,
#         'B_Max_Cell_Temp': 35, 
#         'C_Max_Cell_Temp': 35,
#         'MotorTemperature': 150,
#         'MCUTemperature': 70,
#         'DCDC_Temp1': 75,
#         'DCDC_Temp2': 75,
#         'DCDC_Temp3': 75,
#         'DCDC_Temp4': 75,
#         'Ecomp_Actual_Heat_Sink_Temp': 73,
#         'Steering_Actual_Heat_Sink_Temp': 73
#     }

#     insulation_cols = [
#         'A_Insulation_Value', 
#         'B_Insulation_Value', 
#         'C_Insulation_Value'
#     ]

#     all_cols = [
#         col for col in list(conditions.keys()) + insulation_cols if col in df.columns
#     ]

#     results = []

#     # Check conditions
#     for column, threshold in conditions.items():
#         if column in df.columns and (df[column] > threshold).any():
#             print(f"Warning: {column}")
#             row = df.loc[df[column].idxmax()]
#             result_row = {
#                 'Date': date,
#                 'Name': device_id,
#                 'Issue': f"{column} exceeded {threshold}",
#                 **row[all_cols].to_dict()
#             }
#             results.append(result_row)

#     # Check insulation values
#     for col in insulation_cols:
#         if col in df.columns and (df[col] < 150).any():
#             print(f"Warning: {col} low insulation")
#             row = df.loc[df[col].idxmin()]
#             result_row = {
#                 'Date': date,
#                 'Name': device_id,
#                 'Issue': f"{col} below 150",
#                 **row[all_cols].to_dict()
#             }
#             results.append(result_row)

#     return results

#latest on 8-9-2025
def report_calculations_charging_duration_4w(device_data,device_id,variant,energy_unit_conversion_factor=1):
    if not device_data:
        print("No data for device:", device_id)
        return []
    
    # Create DataFrame
    df = pd.DataFrame(device_data)
    if 'VCU_Flag' not in df.columns:
        return []
    # Replace 'N' with NaN
    df = df.replace('N',np.nan)
    # Convert all columns to numeric if possible, replace non-numeric with NaN
    for col in df.columns:
        if col != 'timestamp': 
            df[col] = pd.to_numeric(df[col], errors='coerce')

    # Replace NaN values with 0
    df = convert_timestamp(df, 'timestamp')
    #Fill NaN values with 0
    
    if df.empty:
        return {}
    if 'VCU_Flag' not in df.columns:
        return {}
    
    df = df.reset_index(drop=True)
    if not df['timestamp'].is_monotonic_increasing: # Ensure chronological order
        df = df.sort_values(by='timestamp').reset_index(drop=True)
    
    variant_config = {
        '7m':['A'],
        '9m':['A','B'],
        '12m':['A','B','C',],
        "55T_truck":['A'],
        "coach":['A'],
        "1.5t":['A']
    }
    if variant not in variant_config:
        raise ValueError(f"Unsupported variant: {variant}")
    
    battery_modules = variant_config.get(variant,['A'])
    start_timestamp = None
    charging_periods = []
    total_energy_consumed = 0

    for index, row in df.iterrows():
        if row['VCU_Flag'] == 92 and start_timestamp is None:
            start_timestamp = row['timestamp']
            start_soc = {mod: row[f'{mod}_SOC_Value'] for mod in battery_modules}
            start_kwh = {mod: row[f'{mod}_KWh_Remain'] for mod in battery_modules}

        elif row['VCU_Flag'] != 92 and start_timestamp is not None:
            # Move backward to find the last 92
            prev_index = index - 1
            prev_row = df.iloc[prev_index]
            while prev_index > 0 and prev_row['VCU_Flag'] != 92:
                prev_index -= 1
                prev_row = df.iloc[prev_index]

            end_timestamp = prev_row['timestamp']
            end_soc = {mod: prev_row[f'{mod}_SOC_Value'] for mod in battery_modules}
            end_kwh = {mod: prev_row[f'{mod}_KWh_Remain'] for mod in battery_modules}

            duration_seconds = (end_timestamp - start_timestamp).total_seconds()
            duration_formatted = format_duration(duration_seconds)

            energy_consumed = {}
            for mod in battery_modules:
                energy_consumed[mod] = end_kwh[mod] - start_kwh[mod]
                total_energy_consumed += energy_consumed[mod]

            # Build dict for DataFrame
            period_data = {
                'Model':device_id,
                'Start Time': start_timestamp,
                'End Time': end_timestamp,
                'Duration': duration_formatted
            }
            for mod in battery_modules:
                period_data[f'{mod}_Start_SOC'] = start_soc[mod]
                period_data[f'{mod}_End_SOC'] = end_soc[mod]
                period_data[f'{mod}_Energy_Consumed'] = energy_consumed[mod] if energy_consumed[mod] > 0 else 0

            charging_periods.append(period_data)
            start_timestamp = None

    # Handle last charging period if still active
    if df.iloc[-1]['VCU_Flag'] == 92 and start_timestamp is not None:
        end_row = df.iloc[-1]
        end_timestamp = end_row['timestamp']
        end_soc = {mod: end_row[f'{mod}_SOC_Value'] for mod in battery_modules}
        end_kwh = {mod: end_row[f'{mod}_KWh_Remain'] for mod in battery_modules}
        duration_seconds = (end_timestamp - start_timestamp).total_seconds()
        duration_formatted = format_duration(duration_seconds)

        energy_consumed = {}
        units_consumed = {}
        for mod in battery_modules:
            energy_consumed[mod] = end_kwh[mod] - start_kwh[mod]
            units_consumed[mod] = energy_consumed[mod] * energy_unit_conversion_factor
            total_energy_consumed += energy_consumed[mod]

        period_data = {
            'Model':device_id,
            'Start Time': start_timestamp,
            'End Time': end_timestamp,
            'Duration': duration_formatted
        }
        for mod in battery_modules:
            period_data[f'{mod}_Start_SOC'] = start_soc[mod]
            period_data[f'{mod}_End_SOC'] = end_soc[mod]
            period_data[f'{mod}_Energy_Consumed'] = energy_consumed[mod] if energy_consumed[mod] > 0 else 0

        charging_periods.append(period_data)
    # Convert to DataFrame
    charging_df = pd.DataFrame(charging_periods)
    # charging_df = charging_df[charging_df['Start Time'] != charging_df['End Time']] # Remove zero-duration entries
    if charging_df.empty:
        return {}
    charging_df = charging_df[
    (charging_df['End Time'] - charging_df['Start Time']) > pd.Timedelta(minutes=5)
    ].reset_index(drop=True)  # Keep entries with duration > 5 minutes
    charging_df['Total Energy Consumed (kWh)']=charging_df[[i for i in charging_df.columns if '_Energy_Consumed' in i]].sum(axis=1)
    
    def check_insufficient(row):
        for mod in battery_modules:
            end_soc_col = f'{mod}_End_SOC'
            if row.get(end_soc_col, 100) < 90:
                return True
        return False
    
    charging_df['Insufficient Charging'] = charging_df.apply(check_insufficient, axis=1).astype(bool)
    charging_df['Charging Cycle'] = charging_df.index + 1
    charging_df.insert(0,'Charging Cycle',charging_df.pop('Charging Cycle'))
    return charging_df

#latest on 8-9-2025
def report_calculations_dod_4w(device_data,devie_id, variant):
    '''
    This function checks if the SOC value for any battery module drops below 20% at any point in time,
    and returns Deep_Discharge flag and (conditionally) the last low SOC value and timestamp.
    '''
    if not device_data:
        print("No data for device")
        return {}

    df = pd.DataFrame(device_data)
    
    if df.empty:
        print("No Data")
        return {}
    if 'VCU_Flag' not in df.columns:
        return []
    df = df.replace('N', np.nan)


    for col in df.columns:
        if col != 'timestamp':
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df = convert_timestamp(df, 'timestamp')

    if not df['timestamp'].is_monotonic_increasing:
        df = df.sort_values(by='timestamp').reset_index(drop=True)

    signal_mapping_variant_wise = {
        '7m': ['A'],
        '9m': ['A', 'B'],
        '12m': ['A', 'B', 'C'],
        'coach': ['A'],
        '55T_truck': ['A'],
        '1.5t': ['A']
    }

    columns_of_interest = [f'{i}_SOC_Value' for i in signal_mapping_variant_wise.get(variant, [])]
    
    df[columns_of_interest] = df[columns_of_interest].ffill().bfill()  # Forward & Backward fill SOC columns
    
    num_cols = df.select_dtypes(include=['number']).columns
    df[num_cols] = df[num_cols].fillna(0)
    
    result_data = {
        'Model': devie_id,
        'Date': df['timestamp'].iloc[0]
    }

    for col in columns_of_interest:
        signal_name = col.split('_')[0]
        has_low_soc, last_soc, last_time = check_values_smaller_than_20(df, col)

        result_data[f"{signal_name}_Deep_Discharge"] = has_low_soc

        if has_low_soc:
            result_data[f"{signal_name}_Last_SOC_<20"] = f"{last_soc:.1f}"
            result_data[f"{signal_name}_Last_SOC_Timestamp"] = last_time

    result_df = pd.DataFrame([result_data])

    if result_df.empty:
        return {}

    # Filter: Keep rows where any Deep_Discharge flag is True
    filter_condition = ~(
        (result_df[[f"{col.split('_')[0]}_Deep_Discharge" for col in columns_of_interest]] == False)
        .all(axis=1)
    )
    result_df = result_df[filter_condition]

    if result_df.empty:
        return {}

    return result_df

#latest on 8-9-2025
def report_calculations_daily_4w(device_data,variant,start_lat,start_long,end_lat,end_long):
    if not device_data:
        print("No data for device:")
        return []

    # Create DataFrame
    df = pd.DataFrame(device_data)
    if df.empty:
        return {}
    if 'VCU_Flag' not in df.columns:
        return []
    df = df.replace('N',None)
    # Convert all columns to numeric if possible, replace non-numeric with NaN
    for col in df.columns:
        if col != 'timestamp': 
            df[col] = pd.to_numeric(df[col], errors='coerce')

    df = convert_timestamp(df,'timestamp')
    

    if not df['timestamp'].is_monotonic_increasing: # Ensure chronological order
        df = df.sort_values(by='timestamp').reset_index(drop=True)
    
    if (df['ODOMETER'].max() - df['ODOMETER'][df['ODOMETER'] >0].min()) > 5 :
        on_road = True 
    else:
        on_road = False
    
    signal_mapping_variant_wise = {
        '7m': ['A'],
        '9m': ['A', 'B'],
        '12m': ['A', 'B', 'C'],
        'coach': ['A'],
        '55T_truck': ['A'],
        '1.5t': ['A']
    }
    
    temp_columns = ['A_Max_Cell_Temp', 'B_Max_Cell_Temp', 'C_Max_Cell_Temp']
    soc_columns = ['A_SOC_Value', 'B_SOC_Value', 'C_SOC_Value']
    
    applicable_signals = signal_mapping_variant_wise.get(variant)
    if not applicable_signals:
        raise ValueError(f"Unsupported variant: {variant}")

    soc_columns = [col for col in soc_columns if col.split('_')[0] in applicable_signals]
    temp_columns = [col for col in temp_columns if col.split('_')[0] in applicable_signals]
    df[soc_columns+temp_columns] = df[soc_columns+temp_columns].ffill().bfill() # Forward fill SOC and Temp columns
    num_cols = df.select_dtypes(include=['number']).columns
    df[num_cols] = df[num_cols].fillna(0)

    
    # Remove charging data
    charging_mask =  (df['VCU_Flag'].isin([89,90,91,92]))
    #considering only discharing 
    df = df[~charging_mask].copy()
    
    df['odo_diff'] = df['ODOMETER'].diff().abs()
    df['time_diff'] = df['timestamp'].diff().dt.total_seconds()
    
    # Define thresholds
    odo_threshold = 100     # kilometers
    time_threshold = 300    # seconds (5 minutes)
    
    # Abnormal condition: large odo jump in short time
    df['abnormal_odo_jump'] = (df['odo_diff'] > odo_threshold) & (df['time_diff'] < time_threshold)
    #remove abnormal rows
    df = df[~df['abnormal_odo_jump']].copy()
    df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

    # Identify sessions by time gap > 900 sec (15 min)
    session_break = df['time_diff_seconds'] > 900
    df['discharging_session'] = session_break.cumsum()

    result_list = []
    result_list.append({'on_road': on_road})
    trip_count = 1
    
    for session_id, session in df.groupby('discharging_session'):
        session = session.reset_index(drop=True)
        if session['timestamp'].notna().any():
            start_row = session.loc[session['timestamp'].idxmin()]
            end_row = session.loc[session['timestamp'].idxmax()]
        else:
            start_row = session.iloc[0]
            end_row = session.iloc[-1]
        
        is_valid=(end_row['timestamp']-start_row['timestamp']>timedelta(minutes=5))
        
        if session.empty or not is_valid :
            continue
        
        is_moving = session['VCU_Flag'].isin([50, 51, 52, 60]) & (session['WheelBasedVehicleSpeed_Rx'].fillna(0) > 1)
        run_time_sec = session.loc[is_moving, 'time_diff_seconds'].sum()

        is_idle = session['VCU_Flag'].isin([70, 13])
        idle_time_sec = session.loc[is_idle, 'time_diff_seconds'].sum()

        distance_travelled = session['ODOMETER'].max() - session['ODOMETER'][session['ODOMETER']>0].min()

        max_speed = session['WheelBasedVehicleSpeed_Rx'].max()
        avg_speed = session.loc[is_moving, 'WheelBasedVehicleSpeed_Rx'].mean() if is_moving.any() else 0

        # Mean SOC at start and end
        start_soc_values = [session[col].iloc[0] for col in soc_columns if col in session.columns and not session[col].isna().all()]
        start_soc = np.nanmean(start_soc_values) if start_soc_values else None

        end_soc_values = [session[col].iloc[-1] for col in soc_columns if col in session.columns and not session[col].isna().all()]
        end_soc = np.nanmean(end_soc_values) if end_soc_values else None

        # Mean battery temperature at start
        avg_battery_temp = np.nanmean([session[col].mean() for col in temp_columns if col in session.columns and not session[col].isna().all()])


        result_list.append({
            'Trip id': int(trip_count),
            'Start SOC': int(round(start_soc)) if start_soc is not None and not np.isnan(start_soc) else None,
            'End SOC': int(round(end_soc)) if end_soc is not None and not np.isnan(end_soc) else None,
            'Start Time': start_row['timestamp'],
            'End Time': end_row['timestamp'],
            'Start Address': (float(start_lat), float(start_long)) if start_lat and start_long else None,
            'End Address': (float(end_lat), float(end_long)) if end_lat and end_long else None,
            'Average Battery Temp (°C)': float(round(avg_battery_temp, 2)) if not np.isnan(avg_battery_temp) else None,
            'Distance (km)': float(distance_travelled) if distance_travelled is not None and not np.isnan(distance_travelled) else None,
            'Run Time (HH:MM)': format_duration(run_time_sec),
            'Idle Time (HH:MM)': format_duration(idle_time_sec),
            'Max Speed (kmph)': int(round(max_speed)) if not np.isnan(max_speed) else None,
            'Average Speed (kmph)': float(round(avg_speed, 2)) if not np.isnan(avg_speed) else None,
            'Deep Discharge': bool(end_soc < 20) if end_soc is not None and not np.isnan(end_soc) else None,
        })
        trip_count += 1

    return result_list if len(result_list)>1 else [{'on_road': False}]

#latest on 8-9-2025
def report_calculations_energy_consumption_4w(device_data, variant, start_lat, start_long, end_lat, end_long):
    if not device_data:
        print("No data for device:")
        return []

    df = pd.DataFrame(device_data)
    if df.empty:
        print("No Data")
        return {}
    if 'VCU_Flag' not in df.columns:
        return []

    df = df.replace('N', np.nan)

    # Type conversion
    for col in df.columns:
        if col != 'timestamp':
            df[col] = pd.to_numeric(df[col], errors='coerce')

    df = convert_timestamp(df, 'timestamp')

    if not df['timestamp'].is_monotonic_increasing:
        df = df.sort_values(by='timestamp').reset_index(drop=True)

    # Define which battery packs are active for each variant
    active_packs = {
        '12m': ['A', 'B', 'C'],
        '9m': ['A', 'B'],
        '7m': ['A'],
        'coach': ['A'],
        '55T_truck': ['A'],
        '1.5t': ['A']
    }[variant]

    soc_cols = [f'{i}_SOC_Value' for i in active_packs]
    df[soc_cols] = df[soc_cols].ffill().bfill()

    # Replace NaN with 0
    num_cols = df.select_dtypes(include=['number']).columns
    df[num_cols] = df[num_cols].fillna(0)

    # Remove charging rows
    charging_mask = df['VCU_Flag'].isin([89, 90, 92])
    df = df[~charging_mask].copy()

    df['odo_diff'] = df['ODOMETER'].diff().abs()
    df['time_diff'] = df['timestamp'].diff().dt.total_seconds()

    # Remove abnormal jumps
    df['abnormal_odo_jump'] = (df['odo_diff'] > 100) & (df['time_diff'] < 300)
    df = df[~df['abnormal_odo_jump']].copy()

    on_road = (df['ODOMETER'].max() - df['ODOMETER'][df['ODOMETER'] > 0].min()) > 5

    df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
    df['discharging_session'] = (df['time_diff_seconds'] > 900).cumsum()

    resultlist = [{'on_road': on_road}]
    trip_count = 1

    for _, session in df.groupby('discharging_session'):
        session = session.reset_index(drop=True)
        start_row = session.loc[session['timestamp'].idxmin()]
        end_row = session.loc[session['timestamp'].idxmax()]
        is_valid = (end_row['timestamp'] - start_row['timestamp'] > timedelta(minutes=5))

        if session.empty or not is_valid:
            continue

        # Energy calculations (unchanged)
        for pack in ['A', 'B', 'C']:
            if pack in active_packs:
                v_col = f"{pack}_Pack_Voltage_Value"
                c_col = f"{pack}_Pack_Current_Value"
                session[f'{pack}_kWh'] = (
                    session[v_col] * session[c_col] * 10 / (1000 * 3600)
                    if v_col in session.columns and c_col in session.columns
                    else 0
                )
            else:
                session[f'{pack}_kWh'] = 0

        session['MCU_kWh'] = (
            (session['MCU_HighPowerVoltage'] * session['MCU_HighPowerCurrent']) * 10 / (1000 * 3600)
            if all(c in session.columns for c in ['MCU_HighPowerVoltage', 'MCU_HighPowerCurrent'])
            else 0
        )

        session['DCDC_kWh'] = (
            (session['DCDC_Input_Voltage'] * session['DCDC_Input_Current']) * 10 / (1000 * 3600)
            if all(c in session.columns for c in ['DCDC_Input_Voltage', 'DCDC_Input_Current'])
            else 0
        )

        session['BCS_kWh'] = (
            (session['BCS_Compressor_Input_Current'] * session['BCS_Compressor_Input_Voltage']) * 10 / (1000 * 3600)
            if all(c in session.columns for c in ['BCS_Compressor_Input_Current', 'BCS_Compressor_Input_Voltage'])
            else 0
        )

        session['HVAC_kWh'] = (
            np.where(
                session['HVAC_Status'].astype(int) == 1,
                (session['T2B_HV_Current_Input'] * session['T2B_HV_Voltage_Input']) * 10 / (1000 * 3600),
                0,
            )
            if all(c in session.columns for c in ['HVAC_Status', 'T2B_HV_Current_Input', 'T2B_HV_Voltage_Input'])
            else 0
        )

        session['ECompressor_kWh'] = (
            session['ECompressor_Input_Power'] * 10 / (1000 * 3600)
            if 'ECompressor_Input_Power' in session.columns
            else 0
        )

        session['Steering_kWh'] = (
            session['Streering_Input_Power'] * 10 / (1000 * 3600)
            if 'Streering_Input_Power' in session.columns
            else 0
        )

        def pack_sums(pack):
            kwh_col = f'{pack}_kWh'
            total = session[kwh_col].sum() if kwh_col in session else 0
            regen = session.loc[session[kwh_col] > 0, kwh_col].sum() if kwh_col in session else 0
            traction = session.loc[session[kwh_col] < 0, kwh_col].sum() if kwh_col in session else 0
            return total, regen, traction

        kwh_A, regen_A, traction_A = pack_sums('A') if 'A' in active_packs else (0, 0, 0)
        kwh_B, regen_B, traction_B = pack_sums('B') if 'B' in active_packs else (0, 0, 0)
        kwh_C, regen_C, traction_C = pack_sums('C') if 'C' in active_packs else (0, 0, 0)

        kwh_MCU = session['MCU_kWh'].sum()
        mcu_traction = session.loc[session['MCU_kWh'] > 0, 'MCU_kWh'].sum()
        mcu_regen = session.loc[session['MCU_kWh'] < 0, 'MCU_kWh'].sum()

        kwh_dcdc = session['DCDC_kWh'].sum()
        kwh_ecompressor = session['ECompressor_kWh'].sum()
        kwh_steering = session['Steering_kWh'].sum()
        kwh_bcs = session['BCS_kWh'].sum()
        kwh_hvac = session['HVAC_kWh'].sum()

        distance = (
            session['ODOMETER'].max() - session['ODOMETER'][session['ODOMETER'] > 0].min()
            if 'ODOMETER' in session.columns
            else 0
        )

        cooling_system_type = 'HVAC' if session.get('HVAC_Status', pd.Series()).astype(int).any() else 'BCS'
        cooling_kwh = kwh_hvac if cooling_system_type == 'HVAC' else kwh_bcs

        start_soc_values = [session[col].iloc[0] for col in soc_cols if col in session.columns]
        end_soc_values = [session[col].iloc[-1] for col in soc_cols if col in session.columns]
        start_soc = np.nanmean(start_soc_values) if start_soc_values else np.nan
        end_soc = np.nanmean(end_soc_values) if end_soc_values else np.nan

        edict = {
            'Trip id': trip_count,
            'Start Time': start_row['timestamp'],
            'End Time': end_row['timestamp'],
            'Start Address': (start_lat, start_long),
            'End Address': (end_lat, end_long),
            'Start SOC': round(start_soc) if not np.isnan(start_soc) else None,
            'End SOC': round(end_soc) if not np.isnan(end_soc) else None,
            'Distance': distance,
            'BatteryNetDischarge': kwh_A + kwh_B + kwh_C,
            'BatteryRegeneration': regen_A + regen_B + regen_C,
            'BatteryTraction': traction_A + traction_B + traction_C,
            'Net Motor': mcu_traction + (-mcu_regen),
            'MotorTraction': mcu_traction,
            'MCURegeneration': mcu_regen,
            'DCDC': kwh_dcdc,
            'Ecomp_and_Steering_M': kwh_ecompressor + kwh_steering,
            'Energy to Aux': (-mcu_regen) - (regen_A + regen_B + regen_C),
            cooling_system_type: cooling_kwh,
            'ECR': ((kwh_A + kwh_B + kwh_C) / distance) * -1 if distance else None,
        }

        resultlist.append(edict)
        trip_count += 1

    # ✅ Safe JSON conversion (moved OUTSIDE the loop)
    import math
    def make_json_safe(data):
        if isinstance(data, dict):
            return {k: make_json_safe(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [make_json_safe(i) for i in data]
        elif isinstance(data, (np.float32, np.float64)):
            return None if np.isnan(data) or np.isinf(data) else float(data)
        elif isinstance(data, (np.int32, np.int64)):
            return int(data)
        elif isinstance(data, float):
            return None if math.isnan(data) or math.isinf(data) else data
        else:
            return data

    resultlist = make_json_safe(resultlist)
    return resultlist



############### 3 Wheeler Calculations ###############
# use this for energy consumption report
def report_calculations_energy_consumption_3w(device_data,start_lat,start_long,end_lat,end_long):
    if not device_data:
        print("No data for device:")
        return []

    # Create DataFrame
    df = pd.DataFrame(device_data)
    
    df = df.replace('N',np.nan)
    if df.empty:
        print("\tNo DATA")
        return []
    if 'VCU_Flag' not in df.columns:
        return []
    # Convert all columns to numeric if possible, replace non-numeric with NaN
    for col in df.columns:
        if col != 'timestamp':
            df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df = convert_timestamp(df,'timestamp')
    
    if not df['timestamp'].is_monotonic_increasing: # Ensure chronological order
        df = df.sort_values(by='timestamp').reset_index(drop=True)
    
    not_charging_mask = (df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()) | (df['MCU_Drive_Mode'].isin([1,2,3]))
    df = df[not_charging_mask].copy()

    df['odo_diff'] = df['MCU_Odometer_Val'].diff().abs()
    df['time_diff'] = df['timestamp'].diff().dt.total_seconds()
    
    # Define thresholds
    odo_threshold = 100     # kilometers
    time_threshold = 300    # seconds (5 minutes)
    
    # Abnormal condition: large odo jump in short time
    df['abnormal_odo_jump'] = (df['odo_diff'] > odo_threshold) & (df['time_diff'] < time_threshold)
    
    # Remove abnormal rows
    df = df[~df['abnormal_odo_jump']].copy()

    # Replace NaN values with 0
    num_cols = df.select_dtypes(include=['number']).columns
    df[num_cols] = df[num_cols].fillna(0)

    if 'timestamp' in df.columns and not df['timestamp'].empty:
        df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
    else:
        # If df['timestamp'] is missing or empty
        df['time_diff_seconds'] = [0] * len(df)
    # df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

    session_break = df['time_diff_seconds'] > 900
    df['discharging_session'] = session_break.cumsum()

    session_results = [];trip_count=1
    
    for session_id, session in df.groupby('discharging_session'):
        session = session.reset_index(drop=True)
        if session['timestamp'].notna().any():
            start_row = session.loc[session['timestamp'].idxmin()]
            end_row = session.loc[session['timestamp'].idxmax()]
        else:
            start_row = session.iloc[0]
            end_row = session.iloc[-1]
        is_valid=(end_row['timestamp']-start_row['timestamp']>timedelta(minutes=5))
        
        if session.empty or not is_valid:
            continue

        session['Time_difference_seconds'] = session['timestamp'].diff().dt.total_seconds().fillna(0)
        distance = session['MCU_Odometer_Val'].max() - session['MCU_Odometer_Val'][session['MCU_Odometer_Val'] > 0].min()


        if distance <= 0:
            continue

        session['energy_kwh'] = (
            (session['BatteryVoltage'] / 10000) *
            (session['BatteryCurrent'] / 1000) *
            session['Time_difference_seconds']
        ) / (1000 * 3600)

        energy_kwh = session['energy_kwh'].sum()
        regen_energy = session.loc[session['energy_kwh'] > 0, 'energy_kwh'].sum()
        traction_energy = session.loc[session['energy_kwh'] < 0, 'energy_kwh'].sum()

        ecr = abs(energy_kwh / distance) if distance > 0 else None
        session_results.append({
            'Trip id': trip_count,
            'Start Time': start_row['timestamp'],
            'End Time': end_row['timestamp'],
            'Start SOC': start_row['SOC'],
            'End SOC': end_row['SOC'],
            'Start Address': (start_lat, start_long),
            'End Address': (end_lat, end_long),
            'BatteryNetEnergy': energy_kwh,
            'Traction Energy': traction_energy,
            'Regeneration Energy': regen_energy,
            'Distance': distance,
            'ECR': ecr 
        })
        trip_count+=1

    return session_results

# use this for daily summary
def report_calculations_daily_3w(device_data,start_lat,start_long,end_lat,end_long):
    if not device_data:
        print("No data for device:")
        return []

    # Create DataFrame
    df = pd.DataFrame(device_data)
    df = df.replace('N', np.nan)
    # Convert all columns to numeric if possible, replace non-numeric with NaN
    for col in df.columns:
        if col != 'timestamp':
            df[col] = pd.to_numeric(df[col], errors='coerce')

    df = convert_timestamp(df, 'timestamp')
    if not df['timestamp'].is_monotonic_increasing: # Ensure chronological order
        df = df.sort_values(by='timestamp').reset_index(drop=True)
    
    not_charging_mask = (df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()) | (df['MCU_Drive_Mode'].isin([1,2,3]))
    df = df[not_charging_mask].copy()
    
    df['odo_diff'] = df['MCU_Odometer_Val'].diff().abs()
    df['time_diff'] = df['timestamp'].diff().dt.total_seconds()
    
    # Define thresholds
    odo_threshold = 100     # kilometers
    time_threshold = 300    # seconds (5 minutes)
    
    # Abnormal condition: large odo jump in short time
    df['abnormal_odo_jump'] = (df['odo_diff'] > odo_threshold) & (df['time_diff'] < time_threshold)
    
    #Remove abnormal rows
    df = df[~df['abnormal_odo_jump']].copy()

    on_road = True if (df['MCU_Odometer_Val'].max() - df['MCU_Odometer_Val'][df['MCU_Odometer_Val']!=0].min()) > 5 else False 
    num_cols = df.select_dtypes(include=['number']).columns
    df[num_cols] = df[num_cols].fillna(0)
    if df.empty:
        print("\tNo DATA")
        return []
    
    result_list = []
    result_list.append({'on_road':on_road})
    
    if 'timestamp' in df.columns and not df['timestamp'].empty:
        df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
    else:
        df['time_diff_seconds'] = [0] * len(df)
    # df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

    session_break = df['time_diff_seconds'] > 900
    df['discharging_session'] = session_break.cumsum()
    trip_count=1
    for session_id, session in df.groupby('discharging_session'):
        session = session.reset_index(drop=True)
        if session['timestamp'].notna().any():
            start_row = session.loc[session['timestamp'].idxmin()]
            end_row = session.loc[session['timestamp'].idxmax()]
        else:
            start_row = session.iloc[0]
            end_row = session.iloc[-1]
        is_valid=(end_row['timestamp']-start_row['timestamp']>timedelta(minutes=5))
        
        if session.empty or not is_valid :
            continue

        session['time_diff_seconds'] = session['timestamp'].diff().dt.total_seconds().fillna(0)

        distance_travelled = session['MCU_Odometer_Val'].max() - session['MCU_Odometer_Val'][session['MCU_Odometer_Val'] > 0].min()

        max_battery_temp = round(session[['TS1', 'TS2', 'TS3', 'TS4', 'TS5', 'TS6']].max().max(), 2)
        max_mcu_temp = round(session['MCU_Motor_Temp'].max(), 2)

        max_speed = round(session['MCU_Speed_Kmph'].max(), 2)
        avg_speed = round(session['MCU_Speed_Kmph'].mean(), 2)

        movement_mask = session['MCU_Speed_Kmph'] > 5
        idle_mask = session['MCU_Speed_Kmph'] <= 5

        run_time_sec = session.loc[movement_mask, 'time_diff_seconds'].sum()
        idle_time_sec = session.loc[idle_mask, 'time_diff_seconds'].sum()

        result_list.append({
            'Trip id':trip_count,
            'Start SOC': session['SOC'].iloc[0],
            'End SOC': session['SOC'].iloc[-1],
            'Start Time': start_row['timestamp'],
            'End Time': end_row['timestamp'],
            'Start Address': (start_lat, start_long),
            'End Address': (end_lat, end_long),
            'Distance': distance_travelled,
            'Run Time': format_duration(run_time_sec),#round(run_time_sec / 60, 2),
            'Idle Time': format_duration(idle_time_sec),#round(idle_time_sec / 60, 2),
            'Max Speed': max_speed,
            'Average Speed': avg_speed,
            'Max Battery Temp': max_battery_temp,
            'Max Motor Temp ': max_mcu_temp
        })
        trip_count+=1
    return result_list

#use this for charging report
def report_calculations_charging_report_3w(device_data,start_lat,start_long,end_lat,end_long):
    if not device_data:
        print("No data for device:")
        return []

    # Create DataFrame
    df = pd.DataFrame(device_data)
    
    df = df.replace('N', np.nan)
    if df.empty:
        return []
    # Convert all columns to numeric if possible, replace non-numeric with NaN
    for col in df.columns:
        if col != 'timestamp':
            df[col] = pd.to_numeric(df[col], errors='coerce')

    df = convert_timestamp(df, 'timestamp')

    if not df['timestamp'].is_monotonic_increasing: # Ensure chronological order
        df = df.sort_values(by='timestamp').reset_index(drop=True)
    # Replace NaN values with 0
    if 'Charger_Output_VOL' in df.columns and 'Charger_Output_CUR' in df.columns:
        not_charging_mask = (
            (df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()) |
            (df['MCU_Drive_Mode'].isin([1, 2, 3]))
        )
        charging_df = df[~not_charging_mask].copy()
    else:
        charging_df= pd.DataFrame()
    if  charging_df.empty:
        return []
    # charging_df = df[df['Charger_Output_VOL'].notna() & df['Charger_Output_CUR'].notna()].copy()
    # df[['latitude','longitude']]=df[['latitude','longitude']].ffill().bfill()
    
    num_cols = df.select_dtypes(include=['number']).columns
    df[num_cols] = df[num_cols].fillna(0)
    
    if charging_df.empty:
        return {}
    
    resultlist=[]
    insufficient_charge = False
    total_units_charged = 0
    charging_df['time_diff_seconds'] = charging_df['timestamp'].diff().dt.total_seconds().fillna(0)
    session_break = charging_df['time_diff_seconds'] > 300  # 5 minutes
    charging_df['charging_session'] = session_break.cumsum()
    # total_charging_time_hours = round(charging_df['time_diff_seconds'].sum() / 3600, 2)
    charging_cycle=0
    for _, session in charging_df.groupby('charging_session'):
        session = session.reset_index(drop=True)
        if session['timestamp'].notna().any():
            start_row = session.loc[session['timestamp'].idxmin()]
            end_row = session.loc[session['timestamp'].idxmax()]
        else:
            start_row = session.iloc[0]
            end_row = session.iloc[-1]
        #considering session only if the duration is greater than 5 min
        is_valid=(end_row['timestamp']-start_row['timestamp']>timedelta(minutes=5))
        if session.empty or not is_valid :
            continue
        max_soc = session['SOC'].max()
        if max_soc < 90:
            insufficient_charge = True
        session['time_diff_seconds'] = session['timestamp'].diff().dt.total_seconds().fillna(0)
        session['energy_kwh'] = (
            (session['BatteryVoltage'] / 10000) *
            (session['BatteryCurrent'] / 1000) *
            session['time_diff_seconds']
        ) / (1000 * 3600)
        units_session = -session['energy_kwh'].sum()
        total_units_charged += units_session
        resultlist.append({
            'Charging Cycles':charging_cycle,
            'Start Time':start_row['timestamp'],
            'End Time':end_row['timestamp'],
            'Charging Units':units_session,
            'Charging Duration':session['time_diff_seconds'].sum(),
            'Start SOC':start_row['SOC'],
            'End SOC':end_row['SOC'],
            'Location':(start_lat, start_long),
            "End Location":(end_lat, end_long),
            'Insufficient Charge':insufficient_charge
        })
        charging_cycle += 1

    return resultlist

def combine_dtc_fields(device_data):
    combined = {}
 
    # Process Dual_Aux_DTC separately
    spn_keys = [f"Dual_Aux_DTC_{i}" for i in range(1, 4)]
    fmi_key = "Dual_Aux_DTC_4"
 
    if all(device_data.get(k) not in [None, 'N'] for k in spn_keys + [fmi_key]):
        combined["DualAux_SPN_DTC"] = ''.join(str(device_data[k]) for k in spn_keys)
        combined["DualAux_FMI_DTC"] = str(device_data[fmi_key])
    # EBS
   
   
    for key in device_data:
        if key.startswith("Dual_Aux_DTC") or not key.endswith("_1") or  not re.search('dtc',key,re.IGNORECASE):
            continue
        base = key.rsplit("_", 1)[0]
        val1 = device_data.get(f"{base}_1")
        val2 = device_data.get(f"{base}_2")
        #Converting into str
        if isinstance(val1, (int, float)):
            val1 = str(int(val1))
        if isinstance(val2, (int, float)):
            val2 = str(int(val2))
        if val1 and val2 and val1 != 'N' and val2 != 'N':
            val2_padded = val2.ljust(2, '0') if len(val2) == 1 else val2
            combined[f"{base}"] = f"{val1}.{val2_padded}"
 
    return combined
 
 
 

# import pandas as pd
# import numpy as np
# from datetime import datetime
# from django.utils import timezone
# from devices.models import DeviceTotalCalculationData

# #Helper Functions
# def format_duration(duration):
#     hours = int(duration // 3600)
#     minutes = int((duration % 3600) // 60)
#     seconds = int(duration % 60)
#     return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

# def check_values_smaller_than_20(df, column_name):
#     if column_name not in df.columns:
#         raise ValueError(f"Column '{column_name}' not found in DataFrame.")
#     smaller_than_20 = df[(df[column_name] < 20) & (df[column_name] != 0)]
#     count = len(smaller_than_20)
#     return 'Yes' if count > 0 else 'No'

# def total_calculations_3w(device_data, device_id,odometer,variant):
#     total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)
#     if not device_data:
#         print("No data for device:", device_id)
#         return

#     df = pd.DataFrame([device_data])

#     # Replace 'N' with NaN for all numeric columns
#     df = df.replace('N', np.nan)
    
#     diesel_mileage = {
#         '9m': 4,
#         '12m': 4,
#         '7m': 8,
#         'coach': 3.5,          
#         '55T_truck': 2.5,      
#         '3w_6s': 25    
#     }

#     electric_ecr = {
#         '9m': 1,
#         '12m': 1.3,
#         '7m': 0.8,
#         'coach': 1.4,           
#         '55T_truck': 1.4,       
#         '3w_6s': 0.08    
#     }


#     total_distance_km = total_data.total_distance

#     EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
#     GRID_CO2_INTENSITY = 0.708      # kg CO2/kWh (CO2 emissions for producing electricity) 
#     diesel_price = 90               # ₹ per litre
#     electricity_price = 8           # ₹ per kWh
    
#     for variant in diesel_mileage:
#         # Diesel CO2 emissions + cost
#         liters_per_km = 1 / diesel_mileage[variant]
#         co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
#         cost_diesel = liters_per_km * diesel_price
    
#         #Electric CO2 emissions + cost
#         ecr = electric_ecr[variant]
#         co2_electric = ecr * GRID_CO2_INTENSITY
#         cost_electric = ecr * electricity_price
    
#         #Savings
#         co2_saved = co2_diesel - co2_electric
#         cost_saved = cost_diesel - cost_electric
    
    
#         #Total for total distance , Take this from the stored values o
#         total_co2_diesel = co2_diesel * total_distance_km
#         total_co2_electric = co2_electric * total_distance_km
#         total_co2_saved = co2_saved * total_distance_km
    
#         total_cost_diesel = cost_diesel * total_distance_km
#         total_cost_electric = cost_electric * total_distance_km
#         total_cost_saved = cost_saved * total_distance_km
    
#         #store and return the results
#         returning_dict = {
#             'variant': variant,
#             'total_co2_saved': total_co2_saved,
#             'total_cost_saved': total_cost_saved,
#         }

    
#     df['timestamp'] = timezone.now()
#     df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
#     df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
#     df['Distance'] = 1
#     df['Time_difference_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     distance = df['Distance'].sum()


#     df['energy_kwh'] = (
#         (df['BatteryVoltage'] / 10000) *
#         (df['BatteryCurrent'] / 1000) *
#         df['Time_difference_seconds']
#     ) / (1000 * 3600)

#     energy_kwh = df['energy_kwh'].sum()
#     regen_energy = df.loc[df['energy_kwh'] > 0, 'energy_kwh'].sum()
#     traction_energy = df.loc[df['energy_kwh'] < 0, 'energy_kwh'].sum()
#     units_session = -df['energy_kwh'].sum()
#     ECR = energy_kwh / distance if distance > 0 else None

#     movement_mask = df['MCU_Speed_Kmph'] > 5
#     idle_mask = df['MCU_Speed_Kmph'] <= 5
    
#     run_time_sec = df.loc[movement_mask, 'time_diff_seconds'].sum()
#     idle_time_sec = df.loc[idle_mask, 'time_diff_seconds'].sum()

    
#     odometer = float(odometer)
#     total_data.total_distance = odometer
#     total_data.traction_energy = (total_data.traction_energy or 0) + traction_energy
#     total_data.regen_energy = (total_data.regen_energy or 0) + regen_energy
#     total_data.run_time = (total_data.run_time or 0) + run_time_sec
#     total_data.charging_unit = (total_data.charging_unit or 0) + units_session
#     total_data.idle_time = (total_data.idle_time or 0) + idle_time_sec
#     total_data.total_distance = odometer
#     total_data.energy_consumption = (total_data.energy_consumption or 0) + (ECR if ECR else 0)
#     total_data.co2_saving = (total_data.co2_saving or 0) + total_co2_saved
#     total_data.cost_saved = (total_data.cost_saved or 0) + total_cost_saved
#     total_data.save()

#     print(f"Updated totals for {device_id}: Traction={total_data.traction_energy}, Regen={total_data.regen_energy}")
#     return True
    
    
# ############# 4 Wheeler Calculations ##################
    
# def total_calculations(device_data, device_id, variant,odometer):
#     if not device_data:
#         print("No data for device:", device_id)
#         return

#     df = pd.DataFrame([device_data])

#     # Replace 'N' with NaN for all numeric columns
#     df = df.replace('N', np.nan)

#     # Convert all numeric columns to numbers where possible
#     df = df.apply(pd.to_numeric, errors='ignore')
#     odometer = float(odometer)
#     diesel_mileage = {
#         '9m': 4,
#         '12m': 4,
#         '7m': 8,
#         'coach': 3.5,
#         '55T_truck': 2.5,
#         '3w_6s': 25
#     }

#     electric_ecr = {
#         '9m': 1,
#         '12m': 1.3,
#         '7m': 0.8,
#         'coach': 1.4,
#         '55T_truck': 1.4,
#         '3w_6s': 0.08
#     }

#     EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
#     GRID_CO2_INTENSITY = 0.708      # kg CO2/kWh
#     diesel_price = 90               # ₹ per litre
#     electricity_price = 8           # ₹ per kWh

#     # Active battery packs
#     active_packs = {
#         '12m': ['A', 'B', 'C'],
#         '9m': ['A', 'B'],
#         '7m': ['A'],
#         "55T_truck":['A'],
#         "coach":['A']
#     }.get(variant, [])

#     pack_current = 0
#     voltage_columns = []
#     for pack in active_packs:
#         current_col = f"{pack}_Pack_Current_Value"
#         voltage_col = f"{pack}_Pack_Voltage_Value"
#         pack_current += pd.to_numeric(df[current_col], errors='coerce').fillna(0)
#         voltage_columns.append(voltage_col)

#     df['Pack_Current'] = pack_current
#     df['Pack_Voltage'] = df[voltage_columns].max(axis=1, skipna=True)

#     # Charging
#     charge_df = df[df['VCU_Flag'] == 92]
#     charge_df['pack_kwh'] = (charge_df['Pack_Voltage'] * charge_df['Pack_Current'] * 10) / (1000 * 3600)
#     charging_units = charge_df['pack_kwh'].sum(skipna=True)

#     # Movement
#     movement_df = df[df['VCU_Flag'] != 92]
#     movement_df['pack_kwh'] = (movement_df['Pack_Voltage'] * movement_df['Pack_Current'] * 10) / (1000 * 3600)
#     regen_units = movement_df.loc[movement_df['pack_kwh'] > 0, 'pack_kwh'].sum(skipna=True)
#     movement_df['motor_kwh'] = (movement_df['MCU_HighPowerVoltage'] * movement_df['MCU_HighPowerCurrent'] * 10) / (1000 * 3600)
#     traction_units = abs(movement_df.loc[movement_df['motor_kwh'] < 0, 'motor_kwh'].sum(skipna=True))

#     # Runtime
#     runtime_hours = (df['VCU_Flag'].isin([50, 51, 52, 60]).sum() * 10) / 3600

#     # Idle time
#     idletime_hours = (df['VCU_Flag'].isin([13, 70]).sum() * 10) / 3600

#     # Energy consumption from packs
#     kwh_total = 0
#     for pack in active_packs:
#         kwh_col = f"{pack}_kWh"
#         df[kwh_col] = (df[f"{pack}_Pack_Voltage_Value"] * df[f"{pack}_Pack_Current_Value"]) * 10 / (1000 * 3600)
#         kwh_total += df[kwh_col].sum(skipna=True)

#     # # Odometer
#     # odometer = pd.to_numeric(df['ODOMETER'], errors='coerce').dropna()
#     # odometer_val = odometer.max() if not odometer.empty else None
#     ECR = ((kwh_total / odometer) * -1) if odometer else None

#     # Fetch or create database entry
#     total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)

#     # Fuel/CO2 savings (only for this variant)
#     liters_per_km = 1 / diesel_mileage[variant]
#     co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
#     cost_diesel = liters_per_km * diesel_price

#     ecr_variant = electric_ecr[variant]
#     co2_electric = ecr_variant * GRID_CO2_INTENSITY
#     cost_electric = ecr_variant * electricity_price

#     co2_saved = co2_diesel - co2_electric
#     cost_saved = cost_diesel - cost_electric

#     total_distance_km = odometer

#     total_co2_saved = co2_saved * total_distance_km
#     total_cost_saved = cost_saved * total_distance_km

#     # Update cumulative totals
#     total_data.traction_energy = (total_data.traction_energy or 0) + traction_units
#     total_data.regen_energy = (total_data.regen_energy or 0) + regen_units
#     total_data.run_time = (total_data.run_time or 0) + runtime_hours
#     total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
#     total_data.idle_time = (total_data.idle_time or 0) + idletime_hours
#     total_data.total_distance = odometer
#     total_data.energy_consumption = (total_data.energy_consumption or 0) + (ECR if ECR else 0)
#     total_data.co2_saving = (total_data.co2_saving or 0) + total_co2_saved
#     total_data.cost_saved = (total_data.cost_saved or 0) + total_cost_saved

#     total_data.save()

#     print(f"Updated totals for {device_id}: Traction={total_data.traction_energy}, Regen={total_data.regen_energy}")
#     return True

# def report_calculations_cooling_4w(device_data, device_id, date):
#     if not device_data:
#         print("No data for device:", device_id)
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)

#     # Define thresholds
#     conditions = {
#         'A_Max_Cell_Temp': 35,
#         'B_Max_Cell_Temp': 35, 
#         'C_Max_Cell_Temp': 35,
#         'MotorTemperature': 150,
#         'MCUTemperature': 70,
#         'DCDC_Temp1': 75,
#         'DCDC_Temp2': 75,
#         'DCDC_Temp3': 75,
#         'DCDC_Temp4': 75,
#         'Ecomp_Actual_Heat_Sink_Temp': 73,
#         'Steering_Actual_Heat_Sink_Temp': 73
#     }

#     insulation_cols = [
#         'A_Insulation_Value', 
#         'B_Insulation_Value', 
#         'C_Insulation_Value'
#     ]

#     all_cols = [
#         col for col in list(conditions.keys()) + insulation_cols if col in df.columns
#     ]

#     results = []

#     # Check conditions
#     for column, threshold in conditions.items():
#         if column in df.columns and (df[column] > threshold).any():
#             print(f"Warning: {column}")
#             row = df.loc[df[column].idxmax()]
#             result_row = {
#                 'Date': date,
#                 'Name': device_id,
#                 'Issue': f"{column} exceeded {threshold}",
#                 **row[all_cols].to_dict()
#             }
#             results.append(result_row)

#     # Check insulation values
#     for col in insulation_cols:
#         if col in df.columns and (df[col] < 150).any():
#             print(f"Warning: {col} low insulation")
#             row = df.loc[df[col].idxmin()]
#             result_row = {
#                 'Date': date,
#                 'Name': device_id,
#                 'Issue': f"{col} below 150",
#                 **row[all_cols].to_dict()
#             }
#             results.append(result_row)

#     return results

# def report_calculations_charging_duration_4w(device_data,device_id,variant,energy_unit_conversion_factor=1):
#     if not device_data:
#         print("No data for device:", device_id)
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     df = df.reset_index(drop=True)
#     model_name=variant
#     variant_config = {
#         '7m':['A'],
#         '9m':['A','B'],
#         '12m':['A','B','C',]
#     }

#     battery_modules = variant_config.get(variant,['A', 'B'])
#     if battery_modules is None:
#         raise ValueError(f"Unsupported variant: {variant}")

#     start_timestamp = None
#     charging_periods = []
#     total_energy_consumed = 0

#     for index, row in df.iterrows():
#         if row['VCU_Flag'] == 92 and start_timestamp is None:
#             start_timestamp = pd.to_datetime(row['timestamp'])
#             start_soc = {mod: row[f'{mod}_SOC_Value'] for mod in battery_modules}
#             start_kwh = {mod: row[f'{mod}KWh_Remain'] for mod in battery_modules}

#         elif row['VCU_Flag'] != 92 and start_timestamp is not None:
#             # Move backward to find the last 92
#             prev_index = index - 1
#             prev_row = df.iloc[prev_index]
#             while prev_index > 0 and prev_row['VCU_Flag'] != 92:
#                 prev_index -= 1
#                 prev_row = df.iloc[prev_index]

#             end_timestamp = pd.to_datetime(prev_row['timestamp'])
#             end_soc = {mod: prev_row[f'{mod}_SOC_Value'] for mod in battery_modules}
#             end_kwh = {mod: prev_row[f'{mod}KWh_Remain'] for mod in battery_modules}

#             duration_seconds = (end_timestamp - start_timestamp).total_seconds()
#             duration_formatted = format_duration(duration_seconds)

#             energy_consumed = {}
#             for mod in battery_modules:
#                 energy_consumed[mod] = end_kwh[mod] - start_kwh[mod]
#                 total_energy_consumed += energy_consumed[mod]

#             # Build dict for DataFrame
#             period_data = {
#                 'Model':model_name,
#                 'Start Time': start_timestamp,
#                 'End Time': end_timestamp,
#                 'Duration': duration_formatted
#             }
#             for mod in battery_modules:
#                 period_data[f'{mod}_Start_SOC'] = start_soc[mod]
#                 period_data[f'{mod}_End_SOC'] = end_soc[mod]
#                 period_data[f'{mod}_Energy_Consumed'] = energy_consumed[mod]

#             charging_periods.append(period_data)
#             start_timestamp = None

#     # Handle last charging period if still active
#     if df.iloc[-1]['VCU_Flag'] == 92 and start_timestamp is not None:
#         end_row = df.iloc[-1]
#         end_timestamp = pd.to_datetime(end_row['timestamp'])
#         end_soc = {mod: end_row[f'{mod}_SOC_Value'] for mod in battery_modules}
#         end_kwh = {mod: end_row[f'{mod}KWh_Remain'] for mod in battery_modules}
#         duration_seconds = (end_timestamp - start_timestamp).total_seconds()
#         duration_formatted = format_duration(duration_seconds)

#         energy_consumed = {}
#         units_consumed = {}
#         for mod in battery_modules:
#             energy_consumed[mod] = end_kwh[mod] - start_kwh[mod]
#             units_consumed[mod] = energy_consumed[mod] * energy_unit_conversion_factor
#             total_energy_consumed += energy_consumed[mod]

#         period_data = {
#             'Model':model_name,
#             'Start Time': start_timestamp,
#             'End Time': end_timestamp,
#             'Duration': duration_formatted
#         }
#         for mod in battery_modules:
#             period_data[f'{mod}_Start_SOC'] = start_soc[mod]
#             period_data[f'{mod}_End_SOC'] = end_soc[mod]
#             period_data[f'{mod}_Energy_Consumed'] = energy_consumed[mod]

#         charging_periods.append(period_data)
#     # Convert to DataFrame
#     charging_df = pd.DataFrame(charging_periods)
#     charging_df['Total Energy Consumed (kWh)']=charging_df[[i for i in charging_df.columns if 'energy_consumed' in i.lower()]].sum(axis=1)
    
#     def check_insufficient(row):
#         for mod in battery_modules:
#             end_soc_col = f'{mod}_End_SOC'
#             if row.get(end_soc_col, 100) < 90:
#                 return True
#         return False
    
#     charging_df['Insufficient Charging'] = charging_df.apply(check_insufficient, axis=1).astype(bool)
#     return charging_df

# def report_calculations_dod_4w(device_data,variant):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)

#     result_list=[]
#     signal_mapping_variant_wise={
#         '7m':['A'],
#         '9m':['A','B'],
#         '12m':['A','B','C',]
#     }
#     columns_of_interest=[f'{i}_SOC_Value' for i in signal_mapping_variant_wise.get(variant)]
#     df['Date Time']=pd.to_datetime(df['Date Time'])
#     df['Date']=df['Date Time'].dt.date
#     max_values = {'Model': variant, 'Date': df['Date'].iloc[0]}
#     for col in columns_of_interest:
#         result = check_values_smaller_than_20(df[columns_of_interest], col)
#         max_values[col + '_smaller_than_20'] = result
#     result_list.append(max_values)
#     result_df=pd.DataFrame(result_list)
#     filter_condition = ~(
#         (result_df[[f"{col}_smaller_than_20" for col in columns_of_interest]] == 'No')
#         .all(axis=1)
#     )

#     result_df = result_df[filter_condition]

#     return result_df

# def report_calculations_charging_report_4w(device_data, device_id, Type):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)

#     start_timestamp = None
#     charging_periods = []
#     total_energy_consumed = 0
#     for index, row in df.iterrows():
#         if row['VCU_Flag'] == 92 and start_timestamp is None:
#             start_timestamp = pd.to_datetime(row['timestamp'])

#             if Type == 7:
#                 start_soc_a = row['A_SOC_Value']
#                 start_kwh_a = row['A_KWh_Remain']
#                 start_soc_b = start_soc_c = start_kwh_b = start_kwh_c = None
#             elif Type == 9:
#                 start_soc_a = row['A_SOC_Value']
#                 start_soc_b = row['B_SOC_Value']
#                 start_kwh_a = row['A_KWh_Remain']
#                 start_kwh_b = row['B_KWh_Remain']
#                 start_soc_c = start_kwh_c = None
#             elif Type == 12:
#                 start_soc_a = row['A_SOC_Value']
#                 start_soc_b = row['B_SOC_Value']
#                 start_soc_c = row['C_SOC_Value']
#                 start_kwh_a = row['A_KWh_Remain']
#                 start_kwh_b = row['B_KWh_Remain']
#                 start_kwh_c = row['C_KWh_Remain']
#             else:
#                 continue

#         elif row['VCU_Flag'] != 92 and start_timestamp is not None:
#             prev_index = index - 1
#             while prev_index > 0 and df.iloc[prev_index]['VCU_Flag'] != 92:
#                 prev_index -= 1
#             if prev_index >= 0:
#                 prev_row = df.iloc[prev_index]
#                 end_timestamp = pd.to_datetime(prev_row['timestamp'])
#                 if Type == 7:
#                     end_soc_a = prev_row['A_SOC_Value']
#                     end_kwh_a = prev_row['A_KWh_Remain']
#                     end_soc_b = end_soc_c = end_kwh_b = end_kwh_c = None
#                 elif Type == 9:
#                     end_soc_a = prev_row['A_SOC_Value']
#                     end_soc_b = prev_row['B_SOC_Value']
#                     end_kwh_a = prev_row['A_KWh_Remain']
#                     end_kwh_b = prev_row['B_KWh_Remain']
#                     end_soc_c = end_kwh_c = None
#                 elif Type == 12:
#                     end_soc_a = prev_row['A_SOC_Value']
#                     end_soc_b = prev_row['B_SOC_Value']
#                     end_soc_c = prev_row['C_SOC_Value']
#                     end_kwh_a = prev_row['A_KWh_Remain']
#                     end_kwh_b = prev_row['B_KWh_Remain']
#                     end_kwh_c = prev_row['C_KWh_Remain']
#                 else:
#                     continue

#                 duration_seconds = (end_timestamp - start_timestamp).total_seconds()
#                 duration_formatted = format_duration(duration_seconds)
#                 energy_consumed_a = (end_kwh_a - start_kwh_a) if end_kwh_a is not None and start_kwh_a is not None else None
#                 energy_consumed_b = (end_kwh_b - start_kwh_b) if end_kwh_b is not None and start_kwh_b is not None else None
#                 energy_consumed_c = (end_kwh_c - start_kwh_c) if end_kwh_c is not None and start_kwh_c is not None else None

#                 total_energy_consumed += sum([e for e in [energy_consumed_a, energy_consumed_b, energy_consumed_c] if e is not None])


#                 charging_periods.append((
#                     device_id,
#                     start_timestamp, end_timestamp,
#                     start_soc_a, end_soc_a,
#                     start_soc_b, end_soc_b,
#                     start_soc_c, end_soc_c,
#                     duration_formatted,
#                     energy_consumed_a, energy_consumed_b, energy_consumed_c,total_energy_consumed
#                 ))
#             start_timestamp = None

#     # Handle case where last row is still charging
#     if len(df) > 0 and df.iloc[-1]['VCU_Flag'] == 92 and start_timestamp is not None:
#         end_timestamp = pd.to_datetime(df.iloc[-1]['timestamp'])
#         if Type == 7:
#             end_soc_a = df.iloc[-1]['A_SOC_Value']
#             end_kwh_a = df.iloc[-1]['A_KWh_Remain']
#             end_soc_b = end_soc_c = end_kwh_b = end_kwh_c = None
#         elif Type == 9:
#             end_soc_a = df.iloc[-1]['A_SOC_Value']
#             end_soc_b = df.iloc[-1]['B_SOC_Value']
#             end_kwh_a = df.iloc[-1]['A_KWh_Remain']
#             end_kwh_b = df.iloc[-1]['B_KWh_Remain']
#             end_soc_c = end_kwh_c = None
#         elif Type == 12:
#             end_soc_a = df.iloc[-1]['A_SOC_Value']
#             end_soc_b = df.iloc[-1]['B_SOC_Value']
#             end_soc_c = df.iloc[-1]['C_SOC_Value']
#             end_kwh_a = df.iloc[-1]['A_KWh_Remain']
#             end_kwh_b = df.iloc[-1]['B_KWh_Remain']
#             end_kwh_c = df.iloc[-1]['C_KWh_Remain']
#         else:
#             pass

#         duration_seconds = (end_timestamp - start_timestamp).total_seconds()
#         duration_formatted = format_duration(duration_seconds)
#         energy_consumed_a = (end_kwh_a - start_kwh_a) if end_kwh_a is not None and start_kwh_a is not None else None
#         energy_consumed_b = (end_kwh_b - start_kwh_b) if end_kwh_b is not None and start_kwh_b is not None else None
#         energy_consumed_c = (end_kwh_c - start_kwh_c) if end_kwh_c is not None and start_kwh_c is not None else None

#         total_energy_consumed += sum([e for e in [energy_consumed_a, energy_consumed_b, energy_consumed_c] if e is not None])

#         charging_periods.append((
#             device_id,
#             start_timestamp, end_timestamp,
#             start_soc_a, end_soc_a,
#             start_soc_b, end_soc_b,
#             start_soc_c, end_soc_c,
#             duration_formatted,
#             energy_consumed_a, energy_consumed_b, energy_consumed_c,total_energy_consumed

#         ))
#     columns = [
#             'Device ID',
#             'Start Time', 'End Time',
#             'Start SoC A', 'End SoC A',
#             'Start SoC B', 'End SoC B',
#             'Start SoC C', 'End SoC C',
#             'Duration',
#             'Energy Consumed A', 'Energy Consumed B', 'Energy Consumed C','Total Energy Consumed'
#         ]
#     charge_df = pd.DataFrame(charging_periods, columns=columns)
#     # Build DataFrame based on Type
#     if Type == 7:
#         columns = [
#             'Device ID',
#             'Start Time', 'End Time',
#             'Start SoC A', 'End SoC A',
#             'Duration',
#             'Energy Consumed A', 'Total Energy Consumed'
#         ]
#         # Only A columns are relevant, B and C will be None
#     elif Type == 9:
#         columns = [
#             'Device ID',
#             'Start Time', 'End Time',
#             'Start SoC A', 'End SoC A',
#             'Start SoC B', 'End SoC B',
#             'Duration',
#             'Energy Consumed A', 'Energy Consumed B', 'Total Energy Consumed'
#         ]
#         # Only A and B columns are relevant, C will be None
#     elif Type == 12:
#         columns = [
#             'Device ID',
#             'Start Time', 'End Time',
#             'Start SoC A', 'End SoC A',
#             'Start SoC B', 'End SoC B',
#             'Start SoC C', 'End SoC C',
#             'Duration',
#             'Energy Consumed A', 'Energy Consumed B', 'Energy Consumed C','Total Energy Consumed'
#         ]
#     else:
#         columns = []
#     charge_df=charge_df[columns]
#     charge_df['Date'] = charge_df['Start Time'].dt.date
#     daily_counts = charge_df.groupby('Date').size().rename('Charging Cycles')
#     charge_df = charge_df.merge(daily_counts, on='Date')
#     return  charge_df

# def report_calculations_energy_consumption_4w(device_data,variant):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     dataframe = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in dataframe.columns:
#         dataframe[col] = pd.to_numeric(dataframe[col], errors='coerce')

#     # Replace NaN values with 0
#     dataframe = dataframe.fillna(0)
#     df = dataframe.copy()
#     # Base columns required for calculations
#     base_cols = [
#         'MCU_HighPowerVoltage', 'DCDC_Input_Voltage',
#         'DCDC_Input_Current', 'BCS_Compressor_Input_Current', 'BCS_Compressor_Input_Voltage',
#         'MCU_HighPowerCurrent', 'ECompressor_Input_Power', 'Streering_Input_Power',
#         'VCU_Flag', 'MCU_Motor_Speed','Gun_Detection_1','Gun_Detection_2',
#         'ODOMETER', 'timestamp', 'HVAC_Status', 'T2B_HV_Current_Input',
#         'T2B_HV_Voltage_Input', 
#         ]

#     # Battery pack columns for each pack
#     battery_cols = {
#         'A': ['A_Pack_Voltage_Value', 'A_Pack_Current_Value'],
#         'B': ['B_Pack_Voltage_Value', 'B_Pack_Current_Value'],
#         'C': ['C_Pack_Voltage_Value', 'C_Pack_Current_Value']
#     }
#     # Convert base columns to integer type
#     df[base_cols] = df[base_cols].astype('int')
#     # Define which battery packs are active for each variant
#     active_packs = {
#         '12m': ['A', 'B', 'C'],
#         '9m': ['A', 'B'],
#         '7m': ['A'],
#         'coach': ['A'],
#         '55T_truck': ['A'],
#         'i_puma': ['A']
#     }[variant]

#     # Collect all columns needed for the selected variant
#     cols = base_cols.copy()
#     for pack in active_packs:
#         cols.extend(battery_cols[pack])

#     # Handle empty dataframe
#     if df.empty:
#         print("No Data")
#         return None
#     # Remove rows where charging is detected
#     charging_mask = ((df['Gun_Detection_1'] == 1) | (df['Gun_Detection_2'] == 1)) & df['VCU_Flag'].isin([89, 90, 92])
#     df = df[~charging_mask].copy()


#     # Calculate time difference between consecutive rows in seconds
#     df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     # Identify session breaks where time gap > 900 seconds (15 minutes)
#     session_break = df['time_diff_seconds'] > 900
#     df['discharging_session'] = session_break.cumsum()
#     resultlist = []
#     trip_count = 0
#     # Process each discharging session separately
#     for session_id, session in df.groupby('discharging_session'):
#         if session.empty:
#             continue
#         print(f'\tNo of rows: {len(session)}')
#         # Energy calculations for each battery pack
#         if 'A' in active_packs:
#             session['A_kWh'] = (session['A_Pack_Voltage_Value'] * session['A_Pack_Current_Value']) * 10 / (1000 * 3600)
#         if 'B' in active_packs:
#             session['B_kWh'] = (session['B_Pack_Voltage_Value'] * session['B_Pack_Current_Value']) * 10 / (1000 * 3600)
#         if 'C' in active_packs:
#             session['C_kWh'] = (session['C_Pack_Voltage_Value'] * session['C_Pack_Current_Value']) * 10 / (1000 * 3600)
#         # MCU energy calculation
#         if 'MCU_HighPowerVoltage' in session.columns and 'MCU_HighPowerCurrent' in session.columns:
#             session['MCU_kWh'] = (session['MCU_HighPowerVoltage'] * session['MCU_HighPowerCurrent']) * 10 / (1000 * 3600)
#         # DCDC converter energy calculation
#         if 'DCDC_Input_Voltage' in session.columns and 'DCDC_Input_Current' in session.columns:
#             session['DCDC_kWh'] = (session['DCDC_Input_Voltage'] * session['DCDC_Input_Current']) * 10 / (1000 * 3600)
#         # BCS compressor energy calculation
#         if 'BCS_Compressor_Input_Current' in session.columns and 'BCS_Compressor_Input_Voltage' in session.columns:
#             session['BCS_kWh'] = (session['BCS_Compressor_Input_Current'] * session['BCS_Compressor_Input_Voltage']) * 10 / (1000 * 3600)
#         # HVAC energy calculation (only when HVAC is ON)
#         if 'HVAC_Status' in session.columns and 'T2B_HV_Current_Input' in session.columns and 'T2B_HV_Voltage_Input' in session.columns:
#             session['HVAC_kwh'] = np.where(
#                 session['HVAC_Status'].astype('int') == 1,
#                 (session['T2B_HV_Current_Input'] * session['T2B_HV_Voltage_Input']) * 10 / (1000 * 3600),
#                 0
#             )
#         # E-Compressor energy calculation
#         if 'ECompressor_Input_Power' in session.columns:
#             session['ECompressor_kWh'] = session['ECompressor_Input_Power'] * 10 / (1000 * 3600)
#         # Steering energy calculation
#         if 'Streering_Input_Power' in session.columns:
#             session['Steering_kWh'] = session['Streering_Input_Power'] * 10 /(1000 * 3600)
    
#         # Sum up energy for each battery pack
#         kwh_A = session['A_kWh'].sum() if 'A' in active_packs else 0
#         regen_A = session.loc[session['A_kWh'] > 0, 'A_kWh'].sum() if 'A' in active_packs else 0
#         traction_A = session.loc[session['A_kWh'] < 0, 'A_kWh'].sum() if 'A' in active_packs else 0
    
#         kwh_B = session['B_kWh'].sum() if 'B' in active_packs else 0
#         regen_B = session.loc[session['B_kWh'] > 0, 'B_kWh'].sum() if 'B' in active_packs else 0
#         traction_B = session.loc[session['B_kWh'] < 0, 'B_kWh'].sum() if 'B' in active_packs else 0
    
#         kwh_C = session['C_kWh'].sum() if 'C' in active_packs else 0
#         regen_C = session.loc[session['C_kWh'] > 0, 'C_kWh'].sum() if 'C' in active_packs else 0
#         traction_C = session.loc[session['C_kWh'] < 0, 'C_kWh'].sum() if 'C' in active_packs else 0
    
#         # MCU energy: total, traction, and regeneration
#         kwh_MCU = session['MCU_kWh'].sum()
#         mcu_traction = session.loc[session['MCU_kWh'] > 0, 'MCU_kWh'].sum()
#         mcu_regen = session.loc[session['MCU_kWh'] < 0, 'MCU_kWh'].sum()
    
#         # Other energy consumers
#         kwh_dcdc = session['DCDC_kWh'].sum()
#         kwh_ecompressor = session['ECompressor_kWh'].sum()
#         kwh_steering = session['Steering_kWh'].sum()
#         kwh_bcs = session['BCS_kWh'].sum()
#         kwh_hvac = session['HVAC_kwh'].sum()
    
#         # Calculate distance covered in this session
#         distance = session['ODOMETER'].max() - session['ODOMETER'].min()
        
#         # Determine which cooling system is used
#         cooling_system_type = 'HVAC' if session['HVAC_Status'].any() else 'BCS'
#         cooling_kwh = kwh_hvac if cooling_system_type == 'HVAC' else kwh_bcs
        
#         # Prepare result dictionary for this session
#         edict = {
#             'Date': datetime.date(),
#             'Trip No': trip_count,
#             'Distance': distance,
#             'BatteryNetDischarge': kwh_A + kwh_B + kwh_C,
#             'BatteryRegeneration': regen_A + regen_B + regen_C,
#             'BatteryTraction': traction_A + traction_B + traction_C,
#             'Net Motor': mcu_traction + (-mcu_regen),
#             'MotorTraction': mcu_traction,
#             'MCURegeneration': -mcu_regen,
#             'DCDC': kwh_dcdc,
#             'Ecomp_and_Steering_M': kwh_ecompressor + kwh_steering,
#             'Energy to Aux': (-mcu_regen) - (regen_A + regen_B + regen_C),
#             cooling_system_type: cooling_kwh,
#         }
    
#         # Calculate Energy Consumption Rate (ECR)
#         edict['ECR'] = ((kwh_A + kwh_B + kwh_C) / distance) * -1 if distance else None
#         # Append result to list
#         resultlist.append(edict)
#         trip_count += 1

#     return resultlist

# def report_calculations_daily_4w(device_data,variant):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     signal_mapping_variant_wise = {
#         '7m': ['A'],
#         '9m': ['A', 'B'],
#         '12m': ['A', 'B', 'C']
#     }
    
#     batterytempcols = ['A_Max_Cell_Temp', 'B_Max_Cell_Temp', 'C_Max_Cell_Temp']
#     soc_cols = ['A_SOC_Value', 'B_SOC_Value', 'C_SOC_Value']
    
#     applicable_signals = signal_mapping_variant_wise.get(variant, [])
#     if not applicable_signals:
#         raise ValueError(f"Unsupported variant: {variant}")

#     soc_columns = [col for col in soc_cols if col.split('_')[0] in applicable_signals]
#     temp_columns = [col for col in batterytempcols if col.split('_')[0] in applicable_signals]

#     if df.empty:
#         return pd.DataFrame()

#     df = df.copy()
#     df['timestamp'] = pd.to_datetime(df['timestamp'])

#     # Remove charging data
#     charging_mask = ((df['Gun_Detection_1'] == 1) | (df['Gun_Detection_2'] == 1)| (df['Gun_Detection_3'] == 1))
#     df = df[~charging_mask].copy()

#     df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     # Identify sessions by time gap > 900 sec (15 min)
#     session_break = df['time_diff_seconds'] > 900
#     df['discharging_session'] = session_break.cumsum()

#     result_list = []
#     trip_count = 1

#     for session_id, session in df.groupby('discharging_session'):
#         if len(session) < 2:
#             continue

#         is_moving = session['VCU_Flag'].isin([50, 51, 52, 60]) & (session['WheelBasedVehicleSpeed_Rx'].fillna(0) > 1)
#         run_time_sec = session.loc[is_moving, 'time_diff_seconds'].sum()

#         is_idle = session['VCU_Flag'] == 70
#         idle_time_sec = session.loc[is_idle, 'time_diff_seconds'].sum()

#         distance_travelled = session['ODOMETER'].iloc[-1] - session['ODOMETER'].iloc[0]

#         max_speed = session['WheelBasedVehicleSpeed_Rx'].max()
#         avg_speed = session.loc[is_moving, 'WheelBasedVehicleSpeed_Rx'].mean() if is_moving.any() else 0

#         # Mean SOC at start and end
#         start_soc_values = [session[col].iloc[0] for col in soc_columns if col in session.columns and not session[col].isna().all()]
#         start_soc = np.nanmean(start_soc_values) if start_soc_values else np.nan

#         end_soc_values = [session[col].iloc[-1] for col in soc_columns if col in session.columns and not session[col].isna().all()]
#         end_soc = np.nanmean(end_soc_values) if end_soc_values else np.nan

#         # Mean battery temperature at start
#         start_battery_temps = [session[col].iloc[0] for col in temp_columns if col in session.columns and not session[col].isna().all()]
#         start_battery_temp = np.nanmean(start_battery_temps) if start_battery_temps else np.nan

#         result_list.append({
#             'Trip id': trip_count,
#             'Start SOC': round(start_soc, 2) if not np.isnan(start_soc) else np.nan,
#             'End SOC': round(end_soc, 2) if not np.isnan(end_soc) else np.nan,
#             'Start Battery Temp (°C)': round(start_battery_temp, 2) if not np.isnan(start_battery_temp) else np.nan,
#             'Distance (km)': round(distance_travelled, 2),
#             'Run Time (hrs)': round(run_time_sec / 3600, 2),
#             'Idle Time (hrs)': round(idle_time_sec / 3600, 2),
#             'Max Speed (kmph)': round(max_speed, 2),
#             'Average Speed (kmph)': round(avg_speed, 2),
#         })
#         trip_count += 1

#     return result_list

# ############### 3 Wheeler Calculations ###############

# def report_calculations_energy_consumption_3w(device_data):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     if df.empty:
#         print("\tNo DATA")
#         return []
#     not_charging_mask = df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()
#     df = df[not_charging_mask].copy()

#     df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
#     if 'timestamp' in df.columns and not df['timestamp'].empty:
#         df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
#     else:
#         # If df['timestamp'] is missing or empty
#         df['time_diff_seconds'] = [0] * len(df)
#     # df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     session_break = df['time_diff_seconds'] > 900
#     df['discharging_session'] = session_break.cumsum()

#     session_results = []

#     for session_id, session in df.groupby('discharging_session'):
#         if session.empty:
#             continue

#         session = session.copy()
#         session['Distance'] = session['MCU_odometer_val'].fillna(method='ffill').diff().fillna(0)
#         session['Time_difference_seconds'] = session['timestamp'].diff().dt.total_seconds().fillna(0)

#         distance = session['Distance'].sum()

#         if distance <= 0:
#             continue

#         session['energy_kwh'] = (
#             (session['BatteryVoltage'] / 10000) *
#             (session['BatteryCurrent'] / 1000) *
#             session['Time_difference_seconds']
#         ) / (1000 * 3600)

#         energy_kwh = session['energy_kwh'].sum()
#         regen_energy = session.loc[session['energy_kwh'] > 0, 'energy_kwh'].sum()
#         traction_energy = session.loc[session['energy_kwh'] < 0, 'energy_kwh'].sum()

#         ecr = energy_kwh / distance if distance > 0 else None

#         session_results.append({
#             'Trip No': int(session_id),
#             'BatteryNetEnergy': energy_kwh,
#             'Traction Energy': traction_energy,
#             'Regeneration Energy': regen_energy,
#             'Distance': distance,
#             'ECR': ecr
#         })

#     return session_results

# def report_calculations_daily_3w(device_data):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     if df.empty:
#         print("\tNo DATA")
#         return []
    
#     result_list = []

#     not_charging_mask = df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()
#     df = df[not_charging_mask].copy()
#     if 'timestamp' in df.columns and not df['timestamp'].empty:
#         df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
#     else:
#         df['time_diff_seconds'] = [0] * len(df)
#     # df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     session_break = df['time_diff_seconds'] > 900
#     df['discharging_session'] = session_break.cumsum()
#     trip_count=1
#     for session_id, session in df.groupby('discharging_session'):
#         if session.empty:
#             continue

#         session = session.copy()
#         session['time_diff_seconds'] = session['timestamp'].diff().dt.total_seconds().fillna(0)

#         distance_travelled = session['MCU_Odometer_Val'].max() - session['MCU_Odometer_Val'].min()

#         max_battery_temp = round(session[['TS1', 'TS2', 'TS3', 'TS4', 'TS5', 'TS6']].max().max(), 2)
#         max_mcu_temp = round(session['MCU_Motor_Temp'].max(), 2)

#         max_speed = round(session['MCU_Speed_Kmph'].max(), 2)
#         avg_speed = round(session['MCU_Speed_Kmph'].mean(), 2)

#         movement_mask = session['MCU_Speed_Kmph'] > 5
#         idle_mask = session['MCU_Speed_Kmph'] <= 5

#         run_time_sec = session.loc[movement_mask, 'time_diff_seconds'].sum()
#         idle_time_sec = session.loc[idle_mask, 'time_diff_seconds'].sum()

#         result_list.append({
#             'Trip id':trip_count,
#             'Start SOC': session['SOC'].iloc[0],
#             'End SOC': session['SOC'].iloc[-1],
#             'Distance (km)': round(distance_travelled, 2),
#             'Run Time (min)': round(run_time_sec / 60, 2),
#             'Idle Time (min)': round(idle_time_sec / 60, 2),
#             'Max Speed (kmph)': max_speed,
#             'Average Speed (kmph)': avg_speed,
#             'Max Battery Temp (°C)': max_battery_temp,
#             'Max Motor Temp (°C)': max_mcu_temp
#         })
#         trip_count+=1
#     return result_list

# def report_calculations_charging_report_3w(device_data):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     not_charging_mask = df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()
#     charging_df = df[~not_charging_mask].copy()

#     df = df.fillna(0)
    
#     if charging_df.empty:
#         return {}
#     resultlist=[]
#     insufficient_charge = False
#     total_units_charged = 0
#     charging_df['time_diff_seconds'] = charging_df['timestamp'].diff().dt.total_seconds().fillna(0)
#     session_break = charging_df['time_diff_seconds'] > 300  # 5 minutes
#     charging_df['charging_session'] = session_break.cumsum()
#     total_charging_time_hours = round(charging_df['time_diff_seconds'].sum() / 3600, 2)
#     charging_cycle=0
#     for _, session in charging_df.groupby('charging_session'):
#         max_soc = session['SOC'].max()
#         if max_soc < 90:
#             insufficient_charge = True
#         session['time_diff_seconds'] = session['timestamp'].diff().dt.total_seconds().fillna(0)
#         session['energy_kwh'] = (
#             (session['BatteryVoltage'] / 10000) *
#             (session['BatteryCurrent'] / 1000) *
#             session['time_diff_seconds']
#         ) / (1000 * 3600)
#         units_session = -session['energy_kwh'].sum()
#         total_units_charged += units_session
#         resultlist.append({
#             'Charging Cycle':charging_cycle,
#             'Start Time':session['timestamp'].iloc[0],
#             'End Time':session['timestamp'].iloc[-1],
#             'Charging Units':units_session,
#             'Charging Duration':session['time_diff_seconds'].sum(),
#             'Start SOC':session['SOC'].iloc[0],
#             'End SOC':session['SOC'].iloc[-1],
#             'Location':(session['latitude'].iloc[0],session['longitude'].iloc[0]),
#             'Insufficient Charge':insufficient_charge
#         })
#     return resultlist

# def total_calculations_3w(device_data, device_id,odometer,variant):#the signal for odmeter is MCU_Odometer_Val 
#     odometer = float(odometer)
#     total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)
#     if not device_data:
#         print("No data for device:", device_id)
#         return

#     df = pd.DataFrame([device_data])

#     # Replace 'N' with NaN for all numeric columns
#     df = df.replace('N', np.nan)
    
#     if df.empty:
#         print("No Data")
#         return {}
    
#     diesel_mileage = {   
#         '3w_6s': 25    
#     }

#     electric_ecr = {
#         '3w_6s': 0.08    
#     }

#     total_distance_km = odometer if odometer > 0 else total_data.total_distance

#     EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
#     GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh (CO2 emissions for producing electricity) 
#     diesel_price = 90               # ₹ per litre
#     electricity_price = 8           # ₹ per kWh
    

#     # Diesel CO2 emissions + cost
#     liters_per_km = 1 / diesel_mileage[variant]
#     co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
#     cost_diesel = liters_per_km * diesel_price

#     #Electric CO2 emissions + cost
#     ecr = electric_ecr[variant]
#     co2_electric = ecr * GRID_CO2_INTENSITY
#     cost_electric = ecr * electricity_price

#     #Savings for 1 km
#     co2_saved = co2_diesel - co2_electric
#     cost_saved = cost_diesel - cost_electric


#     #Total for total distance , Take this from the stored values o
#     total_co2_saved = co2_saved * total_distance_km
#     total_cost_saved = cost_saved * total_distance_km
    
#     df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
#     # df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
#     # df['Time_difference_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     df['energy_kwh'] = (
#         (df['BatteryVoltage'] / 10000) *
#         (df['BatteryCurrent'] / 1000) *
#         10
#     ) / (1000 * 3600)
    
#     not_charging_mask = df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()

#     charge_df= df[~not_charging_mask].copy()

#     if not charge_df.empty:
#         charging_units = charge_df['energy_kwh'].sum()
#     else:
#         charging_units = 0 
    
#     movement_df = df[not_charging_mask].copy()

#     energy_kwh = movement_df['energy_kwh'].sum() 
#     regen_energy = movement_df.loc[movement_df['energy_kwh'] > 0, 'energy_kwh'].sum()
#     traction_energy = movement_df.loc[movement_df['energy_kwh'] < 0, 'energy_kwh'].sum() 
#     run_time_hrs = (movement_df['MCU_Speed_Kmph'][movement_df['MCU_Speed_Kmph'].gt(5)].sum()*10)/3600
#     idle_time_hrs = (movement_df['MCU_Speed_Kmph'][movement_df['MCU_Speed_Kmph'].lt(5)].sum()*10)/3600


#     total_data.total_distance = odometer
#     total_data.traction_energy = (total_data.traction_energy or 0) + abs(traction_energy)
#     total_data.regen_energy = (total_data.regen_energy or 0) + regen_energy
#     total_data.run_time = (total_data.run_time or 0) + run_time_hrs
#     total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
#     total_data.idle_time = (total_data.idle_time or 0) + idle_time_hrs
#     total_data.energy_consumption = (total_data.energy_consumption or 0) +  abs(energy_kwh)
#     total_data.co2_saving =  total_co2_saved
#     total_data.cost_saved =  total_cost_saved
#     total_data.save()

#     print(f"Updated totals for {device_id}: Traction={total_data.traction_energy}, Regen={total_data.regen_energy}")
#     return True


# def total_calculations_3w(device_data, device_id,odometer,variant):#the signal for odmeter is MCU_Odometer_Val 
#     odometer = float(odometer)
#     total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)
#     if not device_data:
#         print("No data for device:", device_id)
#         return

#     df = pd.DataFrame([device_data])

#     # Replace 'N' with NaN for all numeric columns
#     df = df.replace('N', np.nan)
    
#     if df.empty:
#         print("No Data")
#         return {}
    
#     diesel_mileage = {   
#         '3w_6s': 25    
#     }

#     electric_ecr = {
#         '3w_6s': 0.08    
#     }

#     total_distance_km = odometer

#     EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
#     GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh (CO2 emissions for producing electricity) 
#     diesel_price = 90               # ₹ per litre
#     electricity_price = 8           # ₹ per kWh
    

#     # Diesel CO2 emissions + cost
#     liters_per_km = 1 / diesel_mileage[variant]
#     co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
#     cost_diesel = liters_per_km * diesel_price

#     #Electric CO2 emissions + cost
#     ecr = electric_ecr[variant]
#     co2_electric = ecr * GRID_CO2_INTENSITY
#     cost_electric = ecr * electricity_price

#     #Savings for 1 km
#     co2_saved = co2_diesel - co2_electric
#     cost_saved = cost_diesel - cost_electric


#     #Total for total distance , Take this from the stored values o
#     total_co2_saved = co2_saved * total_distance_km
#     total_cost_saved = cost_saved * total_distance_km
    
#     df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
#     df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)
#     df['Time_difference_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     df['energy_kwh'] = (
#         (df['BatteryVoltage'] / 10000) *
#         (df['BatteryCurrent'] / 1000) *
#         df['Time_difference_seconds']
#     ) / (1000 * 3600)
    
#     not_charging_mask = df['Charger_Output_VOL'].isna() & df['Charger_Output_CUR'].isna()

#     charge_df= df[~not_charging_mask].copy()

#     if not charge_df.empty:
#         charging_units = charge_df['energy_kwh'].sum()
#     else:
#         charging_units = 0 
    
#     movement_df = df[not_charging_mask].copy()

#     energy_kwh = movement_df['energy_kwh'].sum() 
#     regen_energy = movement_df.loc[movement_df['energy_kwh'] > 0, 'energy_kwh'].sum()
#     traction_energy = movement_df.loc[movement_df['energy_kwh'] < 0, 'energy_kwh'].sum() 
#     movement_mask = movement_df['MCU_Speed_Kmph'] > 5
#     idle_mask = movement_df['MCU_Speed_Kmph'] <= 5
#     run_time_hrs = round((movement_df.loc[movement_mask, 'time_diff_seconds'].sum())/3600,2)
#     idle_time_hrs = round((movement_df.loc[idle_mask, 'time_diff_seconds'].sum())/3600,2)

    
    
#     total_data.total_distance = odometer
#     total_data.traction_energy = (total_data.traction_energy or 0) + abs(traction_energy)
#     total_data.regen_energy = (total_data.regen_energy or 0) + regen_energy
#     total_data.run_time = (total_data.run_time or 0) + run_time_hrs
#     total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
#     total_data.idle_time = (total_data.idle_time or 0) + idle_time_hrs
#     total_data.energy_consumption = (total_data.energy_consumption or 0) +  abs(energy_kwh)
#     total_data.co2_saving =  total_co2_saved
#     total_data.cost_saved =  total_cost_saved
#     total_data.save()

#     print(f"Updated totals for {device_id}: Traction={total_data.traction_energy}, Regen={total_data.regen_energy}")
#     return True
    
# def total_calculations(device_data, device_id, variant,odometer):
#     if not device_data:
#         print("No data for device:", device_id)
#         return

#     df = pd.DataFrame([device_data])

#     # Replace 'N' with NaN for all numeric columns
#     df = df.replace('N', np.nan)
    
#     if df.empty:
#         print("No Data")
#         return {}
#     # Convert all numeric columns to numbers where possible
#     df = df.apply(pd.to_numeric, errors='ignore')
#     odometer = float(odometer)
#     diesel_mileage = {
#         '9m': 4,
#         '12m': 4,
#         '7m': 8,
#         'coach': 3.5,
#         '55T_truck': 2.5,
#         '1.5t': 6,
#     }

#     electric_ecr = {
#         '9m': 1,
#         '12m': 1.3,
#         '7m': 0.8,
#         'coach': 1.4,
#         '55T_truck': 1.4,
#         '1.5t':0.35
#     }

#     EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
#     GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh
#     diesel_price = 90               # ₹ per litre
#     electricity_price = 8           # ₹ per kWh

#     # Fuel/CO2 savings (only for this variant)
#     liters_per_km = 1 / diesel_mileage[variant]
#     co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
#     cost_diesel = liters_per_km * diesel_price

#     ecr_variant = electric_ecr[variant]
#     co2_electric = ecr_variant * GRID_CO2_INTENSITY
#     cost_electric = ecr_variant * electricity_price

#     co2_saved = co2_diesel - co2_electric
#     cost_saved = cost_diesel - cost_electric

#     total_data, _ = DeviceTotalCalculationData.objects.get_or_create(device_id=device_id)

#     total_distance_km = odometer if odometer > 0 else total_data.total_distance

#     total_co2_saved = co2_saved * total_distance_km
#     total_cost_saved = cost_saved * total_distance_km

#     # Active battery packs
#     active_packs = {
#         '12m': ['A', 'B', 'C'],
#         '9m': ['A', 'B'],
#         '7m': ['A'],
#         "55T_truck":['A'],
#         "coach":['A']
#     }.get(variant, ['A'])

#     # # Charging
#     charge_df = df[df['VCU_Flag'] == 92].copy()
#     # Movement
#     movement_df = df[df['VCU_Flag'] != 92].copy()
#     # Runtime
#     runtime_hours = (df['VCU_Flag'].isin([50, 51, 52, 60]).sum() * 10) / 3600
#     # Idle time
#     idletime_hours = (df['VCU_Flag'].isin([13, 70]).sum() * 10) / 3600

#     # Energy consumption from packs
#     kwh_total  = 0 
#     pack_regen = 0
#     pack_traction = 0
#     charging_units = 0
#     for pack in active_packs:
#         kwh_col = f"{pack}_kWh"
#         movement_df[kwh_col] = (movement_df[f"{pack}_Pack_Voltage_Value"] * movement_df[f"{pack}_Pack_Current_Value"]) * 10 / (1000 * 3600)
#         pack_regen += movement_df.loc[movement_df[kwh_col] > 0, kwh_col].sum(skipna=True)
#         pack_traction += movement_df.loc[movement_df[kwh_col] < 0, kwh_col].sum(skipna=True)
#         charging_units += (charge_df[f"{pack}_Pack_Voltage_Value"]* charge_df[f"{pack}_Pack_Current_Value"] * 10 / (1000 * 3600)).sum(skipna=True) if charge_df.empty == False else 0
#         # charging_units += charge_df[f"{pack}_Pack_Voltage_Value"]* charge_df[f"{pack}_Pack_Current_Value"] * 10 / (1000 * 3600) if charge_df.empty == False else 0
#         kwh_total += movement_df[kwh_col].sum(skipna=True)

#     # Update cumulative totals
#     total_data.traction_energy = (total_data.traction_energy or 0) + abs(pack_traction)
#     total_data.regen_energy = (total_data.regen_energy or 0) + pack_regen
#     total_data.run_time = (total_data.run_time or 0) + runtime_hours
#     total_data.charging_unit = (total_data.charging_unit or 0) + charging_units
#     total_data.idle_time = (total_data.idle_time or 0) + idletime_hours
#     total_data.total_distance = odometer
#     total_data.energy_consumption = (total_data.energy_consumption or 0) + abs(kwh_total)
#     total_data.co2_saving =  total_co2_saved
#     total_data.cost_saved =  total_cost_saved

#     total_data.save()

#     print(f"Updated totals for {device_id}: Traction={total_data.traction_energy}, Regen={total_data.regen_energy}")
#     return True


#use this for charging report
# def report_calculations_charging_duration_4w(device_data,device_id,variant,energy_unit_conversion_factor=1):
#     if not device_data:
#         print("No data for device:", device_id)
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     if df.empty:
#         print("No Data")
#         return {}
    
#     df = df.reset_index(drop=True)
#     model_name=variant
#     variant_config = {
#         '7m':['A'],
#         '9m':['A','B'],
#         '12m':['A','B','C',],
#         "55T_truck":['A'],
#         "coach":['A'],
#         "1.5t":['A']
#     }

#     battery_modules = variant_config.get(variant,['A', 'B'])
#     if battery_modules is None:
#         raise ValueError(f"Unsupported variant: {variant}")

#     start_timestamp = None
#     charging_periods = []
#     total_energy_consumed = 0

#     for index, row in df.iterrows():
#         if row['VCU_Flag'] == 92 and start_timestamp is None:
#             start_timestamp = pd.to_datetime(row['timestamp'])
#             start_soc = {mod: row[f'{mod}_SOC_Value'] for mod in battery_modules}
#             start_kwh = {mod: row[f'{mod}KWh_Remain'] for mod in battery_modules}

#         elif row['VCU_Flag'] != 92 and start_timestamp is not None:
#             # Move backward to find the last 92
#             prev_index = index - 1
#             prev_row = df.iloc[prev_index]
#             while prev_index > 0 and prev_row['VCU_Flag'] != 92:
#                 prev_index -= 1
#                 prev_row = df.iloc[prev_index]

#             end_timestamp = pd.to_datetime(prev_row['timestamp'])
#             end_soc = {mod: prev_row[f'{mod}_SOC_Value'] for mod in battery_modules}
#             end_kwh = {mod: prev_row[f'{mod}KWh_Remain'] for mod in battery_modules}

#             duration_seconds = (end_timestamp - start_timestamp).total_seconds()
#             duration_formatted = format_duration(duration_seconds)

#             energy_consumed = {}
#             for mod in battery_modules:
#                 energy_consumed[mod] = end_kwh[mod] - start_kwh[mod]
#                 total_energy_consumed += energy_consumed[mod]

#             # Build dict for DataFrame
#             period_data = {
#                 'Model':model_name,
#                 'Start Time': start_timestamp,
#                 'End Time': end_timestamp,
#                 'Duration': duration_formatted
#             }
#             for mod in battery_modules:
#                 period_data[f'{mod}_Start_SOC'] = start_soc[mod]
#                 period_data[f'{mod}_End_SOC'] = end_soc[mod]
#                 period_data[f'{mod}_Energy_Consumed'] = energy_consumed[mod]

#             charging_periods.append(period_data)
#             start_timestamp = None

#     # Handle last charging period if still active
#     if df.iloc[-1]['VCU_Flag'] == 92 and start_timestamp is not None:
#         end_row = df.iloc[-1]
#         end_timestamp = pd.to_datetime(end_row['timestamp'])
#         end_soc = {mod: end_row[f'{mod}_SOC_Value'] for mod in battery_modules}
#         end_kwh = {mod: end_row[f'{mod}KWh_Remain'] for mod in battery_modules}
#         duration_seconds = (end_timestamp - start_timestamp).total_seconds()
#         duration_formatted = format_duration(duration_seconds)

#         energy_consumed = {}
#         units_consumed = {}
#         for mod in battery_modules:
#             energy_consumed[mod] = end_kwh[mod] - start_kwh[mod]
#             units_consumed[mod] = energy_consumed[mod] * energy_unit_conversion_factor
#             total_energy_consumed += energy_consumed[mod]

#         period_data = {
#             'Model':model_name,
#             'Start Time': start_timestamp,
#             'End Time': end_timestamp,
#             'Duration': duration_formatted
#         }
#         for mod in battery_modules:
#             period_data[f'{mod}_Start_SOC'] = start_soc[mod]
#             period_data[f'{mod}_End_SOC'] = end_soc[mod]
#             period_data[f'{mod}_Energy_Consumed'] = energy_consumed[mod]

#         charging_periods.append(period_data)
#     # Convert to DataFrame
#     charging_df = pd.DataFrame(charging_periods)
#     if charging_df.empty:
#         return {}
#     charging_df['Total Energy Consumed (kWh)']=charging_df[[i for i in charging_df.columns if '_Energy_Consumed' in i]].sum(axis=1)
    
#     def check_insufficient(row):
#         for mod in battery_modules:
#             end_soc_col = f'{mod}_End_SOC'
#             if row.get(end_soc_col, 100) < 90:
#                 return True
#         return False
    
#     charging_df['Insufficient Charging'] = charging_df.apply(check_insufficient, axis=1).astype(bool)
#     charging_df['Date'] = charging_df['Start Time'].dt.date
#     daily_counts = charging_df.groupby('Date').size().rename('Charging Cycles')
#     charging_df = charging_df.merge(daily_counts, on='Date')
    
#     return charging_df


# use this for Depth of Discharge report 
# def report_calculations_dod_4w(device_data,variant):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     if df.empty:
#         print("No Data")
#         return {}

#     result_list=[]
#     signal_mapping_variant_wise={
#         '7m':['A'],
#         '9m':['A','B'],
#         '12m':['A','B','C',],
#         'coach': ['A'],
#         '55T_truck': ['A'],
#         '1.5t': ['A']
#     }
#     columns_of_interest=[f'{i}_SOC_Value' for i in signal_mapping_variant_wise.get(variant)]
#     df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
#     df['Date Time']=pd.to_datetime(df['timestamp'])
#     df['Date']=df['Date Time'].dt.date
#     max_values = {'Model': variant, 'Date': df['Date'].iloc[0]}
#     for col in columns_of_interest:
#         result = check_values_smaller_than_20(df[columns_of_interest], col)
#         max_values[col + '_smaller_than_20'] = result
#     result_list.append(max_values)
#     result_df=pd.DataFrame(result_list)
#     if result_df.empty:
#         return {}
#     filter_condition = ~(
#         (result_df[[f"{col}_smaller_than_20" for col in columns_of_interest]] == 'No')
#         .all(axis=1)
#     )

#     result_df = result_df[filter_condition]
#     if result_df.empty:
#         return {}
#     return result_df


# #use this for daily summary
# def report_calculations_daily_4w(device_data,variant,start_lat,start_long,end_lat,end_long):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     df = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in df.columns:
#         df[col] = pd.to_numeric(df[col], errors='coerce')

#     # Replace NaN values with 0
#     df = df.fillna(0)
    
#     if df.empty:
#         print("No Data")
#         return {}
    
#     signal_mapping_variant_wise = {
#         '7m': ['A'],
#         '9m': ['A', 'B'],
#         '12m': ['A', 'B', 'C'],
#         'coach': ['A'],
#         '55T_truck': ['A'],
#         '1.5t': ['A']
#     }
    
#     batterytempcols = ['A_Max_Cell_Temp', 'B_Max_Cell_Temp', 'C_Max_Cell_Temp']
#     soc_cols = ['A_SOC_Value', 'B_SOC_Value', 'C_SOC_Value']
    
#     applicable_signals = signal_mapping_variant_wise.get(variant, [])
#     if not applicable_signals:
#         raise ValueError(f"Unsupported variant: {variant}")

#     soc_columns = [col for col in soc_cols if col.split('_')[0] in applicable_signals]
#     temp_columns = [col for col in batterytempcols if col.split('_')[0] in applicable_signals]

#     if df.empty:
#         return pd.DataFrame()

#     df = df.copy()
#     df['timestamp'] = pd.to_datetime(df['timestamp'],errors='coerce')

#     # Remove charging data
#     charging_mask = ((df['Gun_Detection_1'] == 1) | (df['Gun_Detection_2'] == 1)| (df['Gun_Detection_3'] == 1))
#     df = df[~charging_mask].copy()
#     df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     # Identify sessions by time gap > 900 sec (15 min)
#     session_break = df['time_diff_seconds'] > 900
#     df['discharging_session'] = session_break.cumsum()

#     result_list = []
#     trip_count = 1

#     for session_id, session in df.groupby('discharging_session'):
#         if session.empty or len(session) <= 5:
#             continue
#         if session['timestamp'].notna().any():
#             start_row = session.loc[session['timestamp'].idxmin()]
#             end_row = session.loc[session['timestamp'].idxmax()]
#         else:
#             start_row = session.iloc[0]
#             end_row = session.iloc[-1]
#         is_moving = session['VCU_Flag'].isin([50, 51, 52, 60]) & (session['WheelBasedVehicleSpeed_Rx'].fillna(0) > 1)
#         run_time_sec = session.loc[is_moving, 'time_diff_seconds'].sum()

#         is_idle = session['VCU_Flag'].isin([70, 13])
#         idle_time_sec = session.loc[is_idle, 'time_diff_seconds'].sum()

#         distance_travelled = session['ODOMETER'].max() - session['ODOMETER'].min()

#         max_speed = session['WheelBasedVehicleSpeed_Rx'].max()
#         avg_speed = session.loc[is_moving, 'WheelBasedVehicleSpeed_Rx'].mean() if is_moving.any() else 0

#         # Mean SOC at start and end
#         start_soc_values = [session[col].iloc[0] for col in soc_columns if col in session.columns and not session[col].isna().all()]
#         start_soc = np.nanmean(start_soc_values) if start_soc_values else np.nan

#         end_soc_values = [session[col].iloc[-1] for col in soc_columns if col in session.columns and not session[col].isna().all()]
#         end_soc = np.nanmean(end_soc_values) if end_soc_values else np.nan

#         # Mean battery temperature at start
#         avg_battery_temp = np.nanmean([session[col].mean() for col in temp_columns if col in session.columns and not session[col].isna().all()])


#         result_list.append({
#             'Trip id': trip_count,
#             'Start SOC': round(start_soc, 2) if not np.isnan(start_soc) else np.nan,
#             'End SOC': round(end_soc, 2) if not np.isnan(end_soc) else np.nan,
#             'Start Time': start_row['timestamp'],
#             'End Time': end_row['timestamp'],
#             'Start Address': (start_lat, start_long),
#             'End Address': (end_lat, end_long),
#             'Average Battery Temp (°C)': round(avg_battery_temp, 2) if not np.isnan(avg_battery_temp) else np.nan,
#             'Distance (km)': round(distance_travelled, 2),
#             'Run Time (hrs)': round(run_time_sec / 3600, 2),
#             'Idle Time (hrs)': round(idle_time_sec / 3600, 2),
#             'Max Speed (kmph)': round(max_speed, 2),
#             'Average Speed (kmph)': round(avg_speed, 2),
#             'Deep Discharge': True if end_soc < 20 else False,
#         })
#         trip_count += 1

#     return result_list

# #use this for energy consumption report
# def report_calculations_energy_consumption_4w(device_data,variant,start_lat,start_long,end_lat,end_long):
#     if not device_data:
#         print("No data for device:")
#         return []

#     # Create DataFrame
#     dataframe = pd.DataFrame(device_data)

#     # Convert all columns to numeric if possible, replace non-numeric with NaN
#     for col in dataframe.columns:
#         dataframe[col] = pd.to_numeric(dataframe[col], errors='coerce')


#     # Replace NaN values with 0
#     dataframe = dataframe.fillna(0)
    
    
#     df = dataframe.copy()
#     # Base columns required for calculations
#     if df.empty:
#         print("No Data")
#         return {}
#     base_cols = [
#         'MCU_HighPowerVoltage', 'DCDC_Input_Voltage',
#         'DCDC_Input_Current', 'BCS_Compressor_Input_Current', 'BCS_Compressor_Input_Voltage',
#         'MCU_HighPowerCurrent', 'ECompressor_Input_Power', 'Streering_Input_Power',
#         'VCU_Flag', 'MCU_Motor_Speed','Gun_Detection_1','Gun_Detection_2',
#         'ODOMETER', 'timestamp', 'HVAC_Status', 'T2B_HV_Current_Input',
#         'T2B_HV_Voltage_Input', 
#         ]

#     # Battery pack columns for each pack
#     battery_cols = {
#         'A': ['A_Pack_Voltage_Value', 'A_Pack_Current_Value'],
#         'B': ['B_Pack_Voltage_Value', 'B_Pack_Current_Value'],
#         'C': ['C_Pack_Voltage_Value', 'C_Pack_Current_Value']
#     }
#     # Convert base columns to integer type
#     df[base_cols] = df[base_cols].astype('int')
#     # Define which battery packs are active for each variant
#     active_packs = {
#         '12m': ['A', 'B', 'C'],
#         '9m': ['A', 'B'],
#         '7m': ['A'],
#         'coach': ['A'],
#         '55T_truck': ['A'],
#         '1.5t': ['A']
#     }[variant]

#     #NEW
#     for pack in active_packs:
#         base_cols.extend(battery_cols[pack])
#     soc_cols=[f'{pack}_SOC_Value' for pack in active_packs]

#     # Collect all columns needed for the selected variant
#     cols = base_cols.copy()
#     for pack in active_packs:
#         cols.extend(battery_cols[pack])

#     # Handle empty dataframe
#     if df.empty:
#         print("No Data")
#         return {}
#     # Remove rows where charging is detected
#     charging_mask = ((df['Gun_Detection_1'] == 1) | (df['Gun_Detection_2'] == 1)) & df['VCU_Flag'].isin([89, 90, 92])
#     df = df[~charging_mask].copy()

#     df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

#     df['time_diff_seconds'] = df['timestamp'].diff().dt.total_seconds().fillna(0)

#     session_break = df['time_diff_seconds'] > 900
#     df['discharging_session'] = session_break.cumsum()
#     resultlist = []
#     trip_count = 0
    
#     df['SOC'] = df[soc_cols].mean(axis=1)
#     for session_id, session in df.groupby('discharging_session'):
#         if session.empty or len(session)<=5:
#             continue

#         start_row = session.loc[session['timestamp'].idxmin()]
#         end_row = session.loc[session['timestamp'].idxmax()]
#         # Energy calculations for each battery pack
#         for pack in ['A', 'B', 'C']:
#             if pack in active_packs:
#                 voltage_col = f"{pack}_Pack_Voltage_Value"
#                 current_col = f"{pack}_Pack_Current_Value"
#                 if voltage_col in session.columns and current_col in session.columns:
#                     session[f'{pack}_kWh'] = (session[voltage_col] * session[current_col]) * 10 / (1000 * 3600)
#                 else:
#                     session[f'{pack}_kWh'] = 0

#         # MCU energy calculation
#         if 'MCU_HighPowerVoltage' in session.columns and 'MCU_HighPowerCurrent' in session.columns:
#             session['MCU_kWh'] = (session['MCU_HighPowerVoltage'] * session['MCU_HighPowerCurrent']) * 10 / (1000 * 3600)
#         else:
#             session['MCU_kWh'] = 0

#         # DCDC converter
#         if 'DCDC_Input_Voltage' in session.columns and 'DCDC_Input_Current' in session.columns:
#             session['DCDC_kWh'] = (session['DCDC_Input_Voltage'] * session['DCDC_Input_Current']) * 10 / (1000 * 3600)
#         else:
#             session['DCDC_kWh'] = 0

#         # BCS compressor
#         if 'BCS_Compressor_Input_Current' in session.columns and 'BCS_Compressor_Input_Voltage' in session.columns:
#             session['BCS_kWh'] = (session['BCS_Compressor_Input_Current'] * session['BCS_Compressor_Input_Voltage']) * 10 / (1000 * 3600)
#         else:
#             session['BCS_kWh'] = 0

#         # HVAC (only when ON)
#         if all(col in session.columns for col in ['HVAC_Status', 'T2B_HV_Current_Input', 'T2B_HV_Voltage_Input']):
#             session['HVAC_kWh'] = np.where(
#                 session['HVAC_Status'].astype(int) == 1,
#                 (session['T2B_HV_Current_Input'] * session['T2B_HV_Voltage_Input']) * 10 / (1000 * 3600),
#                 0
#             )
#         else:
#             session['HVAC_kWh'] = 0

#         # E-Compressor
#         if 'ECompressor_Input_Power' in session.columns:
#             session['ECompressor_kWh'] = session['ECompressor_Input_Power'] * 10 / (1000 * 3600)
#         else:
#             session['ECompressor_kWh'] = 0

#         # Steering 
#         if 'Streering_Input_Power' in session.columns:
#             session['Steering_kWh'] = session['Streering_Input_Power'] * 10 / (1000 * 3600)
#         else:
#             session['Steering_kWh'] = 0

#         # Battery Pack Energy Summaries
#         def pack_sums(pack):
#             kwh_col = f'{pack}_kWh'
#             total = session[kwh_col].sum() if kwh_col in session else 0
#             regen = session.loc[session[kwh_col] > 0, kwh_col].sum() if kwh_col in session else 0
#             traction = session.loc[session[kwh_col] < 0, kwh_col].sum() if kwh_col in session else 0
#             return total, regen, traction

#         kwh_A, regen_A, traction_A = pack_sums('A') if 'A' in active_packs else (0, 0, 0)
#         kwh_B, regen_B, traction_B = pack_sums('B') if 'B' in active_packs else (0, 0, 0)
#         kwh_C, regen_C, traction_C = pack_sums('C') if 'C' in active_packs else (0, 0, 0)

#         # MCU
#         kwh_MCU = session['MCU_kWh'].sum()
#         mcu_traction = session.loc[session['MCU_kWh'] > 0, 'MCU_kWh'].sum()
#         mcu_regen = session.loc[session['MCU_kWh'] < 0, 'MCU_kWh'].sum()

#         # Other consumers
#         kwh_dcdc = session['DCDC_kWh'].sum()
#         kwh_ecompressor = session['ECompressor_kWh'].sum()
#         kwh_steering = session['Steering_kWh'].sum()
#         kwh_bcs = session['BCS_kWh'].sum()
#         kwh_hvac = session['HVAC_kWh'].sum()

#         # Distance calculation
#         # distance = (session['ODOMETER'].max() - session['ODOMETER'].min()) if 'ODOMETER' in session.columns else 0
#         distance = (session['ODOMETER'].max() - session['ODOMETER'][session['ODOMETER'] != 0].min()) if 'ODOMETER' in session.columns else 0

#         # Cooling system
#         cooling_system_type = 'HVAC' if session.get('HVAC_Status', pd.Series()).astype(int).any() else 'BCS'
#         # cooling_kwh = kwh_hvac if cooling_system_type == 'HVAC' else kwh_bcs

#         # Final result dictionary
#         edict = {
#             'Date': datetime.now().date(),
#             'Trip id': trip_count,
#             'Start Time':start_row['timestamp'],
#             'End Time':end_row['timestamp'],
#             'Start Address': (start_lat, start_long),
#             'End Address':(end_lat, end_long),
#             'Distance': distance,
#             'Start SOC': start_row['SOC'],
#             'End SOC': end_row['SOC'],
#             'BatteryNetDischarge': kwh_A + kwh_B + kwh_C,
#             'BatteryRegeneration': regen_A + regen_B + regen_C,
#             'BatteryTraction': traction_A + traction_B + traction_C,
#             'Net Motor': mcu_traction + (-mcu_regen),
#             'MotorTraction': mcu_traction,
#             'MCURegeneration': abs(mcu_regen),
#             'DCDC': kwh_dcdc,
#             'Ecomp_and_Steering_M': kwh_ecompressor + kwh_steering,
#             'Energy to Aux': (-mcu_regen) - (regen_A + regen_B + regen_C),
#             cooling_system_type: kwh_bcs,
#         }
    
#         # Calculate Energy Consumption Rate (ECR)
#         edict['ECR'] = ((kwh_A + kwh_B + kwh_C) / distance) * -1 if distance else None
#         # Append result to list
#         resultlist.append(edict)
#         trip_count += 1

#     return resultlist




