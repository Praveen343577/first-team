from devices.models import DailySummaryReport,Alert,Fault, FaultRule,Device
from collections import defaultdict
from datetime import datetime
from rest_framework.response import Response
from rest_framework import status
from datetime import datetime, time
from django.utils.timezone import make_aware
from datetime import timedelta

def parse_ts(ts):
    return datetime.fromisoformat(ts)

#Trip calculations
TRIP_GAP_MIN = 15  

def build_trip_objects(sessions):
    trips = []
    current = []

    for i, s in enumerate(sessions):
        current.append(s)

        if i == len(sessions) - 1:
            trips.append(current)
            break

        cur_end = parse_ts(s["end_time_val"])
        next_start = parse_ts(sessions[i + 1]["start_time_val"])
        diff = (next_start - cur_end).total_seconds() / 60

        if diff >= TRIP_GAP_MIN:
            trips.append(current)
            current = []

    final_trips = []

    for trip_no, trip in enumerate(trips, start=1):
        trip_start = parse_ts(trip[0]["start_time_val"])
        trip_end = parse_ts(trip[-1]["end_time_val"])

        total_energy = 0
        movement_distance = 0
        movement_duration = 0
        idle_duration = 0

        for s in trip:
            total_energy += s.get("energy_consumed", 0)

            if s["label"] == "Movement":
                movement_distance += s.get("distance", 0)
                movement_duration += s.get("duration", 0)

            elif s["label"] == "Idle":
                idle_duration += s.get("duration", 0)

        
        if movement_duration > 0:
            avg_speed = movement_distance / (movement_duration / 60)
        else:
            avg_speed = 0

        final_trips.append({
            "trip_no": trip_no,
            "start_time": trip[0]["start_time_val"],
            "end_time": trip[-1]["end_time_val"],
            "duration_minutes": (trip_end - trip_start).total_seconds() / 60,
            "movement_distance": movement_distance,
            "movement_duration": movement_duration,
            "idle_duration": idle_duration,
            "energy_consumed": total_energy,
            "avg_speed": avg_speed,
        })

    return final_trips

def daily_summary_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","distance","runtime_minutes",
                                            "idle_minutes","stoppage_minutes","start_odometer","end_odometer","sessions")
    if not qs.exists():
        return {}
    
    date_grouped = defaultdict(list)

    for row in qs:
        sessions = row.sessions or []
        movement_sessions = [
            s for s in sessions
            if s.get("label") == "Movement"
        ]


        if not movement_sessions:
            continue

        # Add session numbers
        for no, s in enumerate(movement_sessions, 1):
            s["session_no"] = no

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "session_count": len(movement_sessions),
            "city":row.city,
            "distance":row.distance,
            "runtime":row.runtime_minutes,
            "avg_speed":row.average_speed,
            "idletime":row.idle_minutes,
            "stoppagetime":row.stoppage_minutes,
            "start_odometer":row.start_odometer,
            "end_odometer":row.end_odometer,
            "trips": movement_sessions
        })

    return date_grouped

def charging_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","charging_minutes",
                                             "charging_unit","insufficient_charge","sessions")
        
    if not qs.exists():
        return {}

    date_grouped = defaultdict(list)

    for row in qs:
        sessions = row.sessions or []
        charging_sessions = [
            s for s in sessions
            if s.get("label") == "Charging"
        ]

        if not charging_sessions:
            continue

        # Add session numbers
        for no, s in enumerate(charging_sessions, 1):
            s["session_no"] = no

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "session_count": len(charging_sessions),
            "city":row.city,
            "charging_time":row.charging_minutes,
            "charging_unit":row.charging_unit,
            "Insufficient_charge":row.insufficient_charge,
            "sessions": charging_sessions
        })
    return date_grouped



def energy_consumpumtion_report(vehicle_list,start_date,end_date=None):
    qs = DailySummaryReport.objects.filter(
    imei__in=vehicle_list,
    date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","runtime_minutes","idle_minutes",
                                             "energy_consumed","regen_energy","energy_consumption","sessions")
    
    if not qs.exists():
        return {}

    date_grouped = defaultdict(list)

    for row in qs:
        all_sessions = row.sessions or []
        all_sessions = all_sessions if isinstance(all_sessions, list) else []

        filtered = [
            s for s in all_sessions
            if isinstance(s, dict) and s.get("label") in ("Movement", "Idle") 
        ]

        if not filtered:
            continue

        filtered.sort(key=lambda x: x["start_time_val"])

        trips = build_trip_objects(filtered)

        date_grouped[str(row.date)].append({
            "vrn": row.vrn,
            "chassis_number": row.chassis_number,
            "city": row.city,
            "trip_count": len(trips),
            "distance": row.distance,
            "runtime": row.runtime_minutes,
            "ideltime": row.idle_minutes,
            "ec": row.energy_consumed,
            "regen": row.regen_energy,
            "ecr": row.energy_consumption,
            "trips": trips
        })
    return date_grouped

# def vehicle_status_report(vehicle_list,start_date,end_date=None):
#     qs = DailySummaryReport.objects.filter(
#     imei__in=vehicle_list,
#     date__range=[start_date, end_date]).only("vrn","chassis_number","vehicle_type_name","city","start_time_of_day","stop_time_of_day","distance","runtime_minutes",
#                                             "idle_minutes","stoppage_minutes","charging_minutes","no_of_movement_sessions","no_of_charging_cycles","no_of_idle_sessions",
#                                             "start_odometer","end_odometer","battery_temperature","motor_temperature","sessions")
#     if not qs.exists():
#         return {}
    
#     date_grouped = defaultdict(list)

#     for row in qs:
#         sessions = row.sessions or []
#         all_sessions = [
#             s for s in sessions
#         ]

#         if not all_sessions:
#             continue

#         # Add session numbers
#         for no, s in enumerate(all_sessions, 1):
#             s["session_no"] = no

#         date_grouped[str(row.date)].append({
#             "vrn": row.vrn,
#             "chassis_number": row.chassis_number,
#             "session_count": len(all_sessions),
#             "city":row.city,
#             "start_time_of_day":row.start_time_of_day,
#             "stop_time_of_day":row.stop_time_of_day,
#             "distance":row.distance,
#             "runtime":row.runtime_minutes,
#             "idletime":row.idle_minutes,
#             "stoppagetime":row.stoppage_minutes,
#             "chargetime":row.charging_minutes,
#             "no_of_movement_sessions":row.no_of_movement_sessions,
#             "no_of_charging_cycles":row.no_of_charging_cycles,
#             "no_of_idle_sessions":row.no_of_idle_sessions,
#             "start_odometer":row.start_odometer,
#             "end_odometer":row.end_odometer,
#             "max_battery_temperature":row.battery_temperature,
#             "max_motor_temperature":row.motor_temperature,
#             "sessions": all_sessions
#         })

#     return date_grouped


def vehicle_status_report(vehicle_list, start_date, end_date=None):

    def is_invalid_odo(value):
        return value in [0, None, "0", "n/a", ""]

    qs = DailySummaryReport.objects.filter(
        imei__in=vehicle_list,
        date__range=[start_date, end_date]
    )

    if not qs.exists():
        return {}
#################################################################################################################################################
    # invalid_imeis = set()
    # for row in qs:
    #     if is_invalid_odo(row.start_odometer) or is_invalid_odo(row.end_odometer):
    #         invalid_imeis.add(row.imei)


    # fallback_dict = {}
    # if invalid_imeis:
    #     fallback_qs = DailySummaryReport.objects.filter(
    #         imei__in=invalid_imeis,
    #         date__lt=start_date,
    #         end_odometer__isnull=False
    #     ).exclude(end_odometer=0).order_by('imei', '-date').distinct('imei')

    #     fallback_dict = {r.imei: r for r in fallback_qs}
#######################################################################################################################################################

    #updates for the missing imei records per day
    
    devices = Device.objects.filter(device_id__in=vehicle_list).values('device_id', 'VRN', 'chassis_number','city')

    date_grouped = defaultdict(list)

    reports_dict = {
        (r.imei, r.date): r
        for r in qs
    }

    devices_dict = {d['device_id']: d for d in devices}


    current_date = datetime.strptime(start_date, "%Y-%m-%d").date()
    last_date = datetime.strptime(end_date, "%Y-%m-%d").date()

    while current_date <= last_date:
        for imei in vehicle_list:

            row = reports_dict.get((imei, current_date))

            if row:
                sessions = row.sessions or []

                for no, s in enumerate(sessions, 1):
                    s["session_no"] = no

                # start_odo = 0 if is_invalid_odo(row.start_odometer) else row.start_odometer
                # end_odo = 0 if is_invalid_odo(row.end_odometer) else row.end_odometer

                date_grouped[str(current_date)].append({
                    "vrn": row.vrn,
                    "chassis_number": row.chassis_number,
                    "session_count": len(sessions),
                    "city": row.city,
                    "start_time_of_day": row.start_time_of_day,
                    "stop_time_of_day": row.stop_time_of_day,
                    "distance": row.distance,
                    "average_speed": row.average_speed,
                    "runtime": row.runtime_minutes,
                    "idletime": row.idle_minutes,
                    "stoppagetime": row.stoppage_minutes,
                    "chargetime": row.charging_minutes,
                    "no_of_movement_sessions": row.no_of_movement_sessions,
                    "no_of_charging_cycles": row.no_of_charging_cycles,
                    "no_of_idle_sessions": row.no_of_idle_sessions,
                    "start_odometer": row.start_odometer,
                    "end_odometer": row.end_odometer,
                    "energy_consumed": row.energy_consumed,
                    "regen_energy": row.regen_energy,
                    "motor_ec": row.motor_ec,
                    "dcdc_ec": row.dcdc_ec,
                    "ecompressor_and_steering_ec": row.ecompressor_and_steering_ec,
                    "bcs_ec": row.bcs_ec,
                    "tcs_ec": row.tcs_ec,
                    "energy_consumption": row.energy_consumption,
                    "charging_unit": row.charging_unit,
                    "max_battery_temperature": row.battery_temperature,
                    "max_motor_temperature": row.motor_temperature,
                    "sessions": sessions,
                })

            else:
                device = devices_dict.get(imei, {})

                date_grouped[str(current_date)].append({
                    "imei": imei,
                    "vrn": device.get("VRN") or "-",
                    "chassis_number": device.get("chassis_number") or "-",
                    "session_count": 0,
                    "city": device.get("city") or "-",
                    "start_time_of_day": "-",
                    "stop_time_of_day": "-",
                    "distance": "-",
                    "average_speed": "-",
                    "runtime": "-",
                    "idletime": "-",
                    "stoppagetime": 1440,  # 24 hours in minutes
                    "chargetime": "-",
                    "no_of_movement_sessions": "-",
                    "no_of_charging_cycles": "-",
                    "no_of_idle_sessions": "-",
                    "start_odometer": "-",
                    "end_odometer": "-",
                    "energy_consumed": "-",
                    "regen_energy": "-",
                    "motor_ec": "-",
                    "dcdc_ec": "-",
                    "ecompressor_and_steering_ec": "-",
                    "bcs_ec": "-",
                    "tcs_ec": "-",
                    "energy_consumption": "-",
                    "charging_unit": "-",
                    "max_battery_temperature": "-",
                    "max_motor_temperature": "-",
                    "sessions": [],
                })

        current_date += timedelta(days=1)

    return date_grouped


def cooling_report(vehicle_list,start_date,end_date=None):
    pass

def alert_report(vehicle_list,start_date,end_date=None):
    from django.utils.dateparse import parse_date
    start_date = parse_date(start_date)
    end_date = parse_date(end_date)
    start_dt = make_aware(datetime.combine(start_date, time.min))
    end_dt = make_aware(datetime.combine(end_date, time.max))
    
    qs = Alert.objects.filter(imei__in=vehicle_list,start_time__date__range = [start_dt, end_dt],duration_seconds__gt=120)

    if not qs.exists():
        return {}

    date_grouped = defaultdict(list)
    for row in qs:
        row_time = row.start_time
        row_time = row_time.date()
        date_grouped[str(row_time)].append({
        "alert_type": row.alert_type,
        "name": row.name,
        "value": row.value,
        "imei": row.imei,
        "start_time": row.start_time,
        "end_time": row.end_time,
        "is_active": row.is_active,
        "duration_seconds": row.duration_seconds,
        "req_data": row.req_data,
        "device_type_name": row.device_type_name
        })

    return date_grouped

def fault_report(request,vehicle_list,start_date,paged,end_date):
    # from django.utils.dateparse import parse_date
    from rest_framework.pagination import PageNumberPagination
    from devices.pagination import FaultReportPagination
    # start_date =   start_date.date()
    # end_date = end_date.date()
    # start_dt = make_aware(datetime.combine(start_date, time.min))
    # end_dt = make_aware(datetime.combine(end_date, time.max))
    
    qs = Fault.objects.filter(imei__in=vehicle_list,start_time__date__range = [start_date, end_date])

    if not qs.exists():
        return Response({"No data found"})
    
    if paged:
        paginator = FaultReportPagination()
        page = paginator.paginate_queryset(qs, request)

        date_grouped = defaultdict(list)

        for row in page:
            row_time = row.start_time.date().isoformat()
            
            # Fault Rule Query set
            fr_qs = FaultRule.objects.get(id=row.rule_id).details
            date_grouped[row_time].append({
                "imei": row.imei,
                "start_time": row.start_time,
                "end_time": row.end_time,
                "is_active": row.is_active,
                "duration_seconds": (row.end_time - row.start_time).total_seconds(),
                "data_snapshot": row.data_snapshot,
                "component": row.component,
                "details": fr_qs
            })

        return paginator.get_paginated_response(date_grouped)
    
    else:
        date_grouped = defaultdict(list)
        for row in qs:
            time_diff = (row.end_time - row.start_time).total_seconds()
            row_time = row.start_time
            row_time = row_time.date()
            date_grouped[str(row_time)].append({
            "imei": row.imei,
            "start_time": row.start_time,
            "end_time": row.end_time,
            "is_active": row.is_active,
            "duration_seconds": time_diff,
            # "data_snapshot": row.data_snapshot,
            "component":row.component
            })
        return date_grouped


#For excel report grouping by vehicle wise
def group_by_vehicle(data):
    vehicle_map = {}
    all_summaries = []
    faults_alerts_counter = defaultdict(int)


    for date, items in data.items():
        for v in items:
            if not isinstance(v, dict):
                continue

            vehicle_key = v.get("vrn") or v.get("chassis_number") or v.get("imei")
            if not vehicle_key:
                continue   

            if vehicle_key not in vehicle_map:
                vehicle_map[vehicle_key] = []

            trips = v.get("trips") or []
            sessions = v.get("sessions") or []

            # summary = v.copy()
            if "trips" in v or "sessions" in v:
                summary = v.copy()
                for k in ("trips", "sessions"):
                    summary.pop(k, None)

                summary["Date"] = date
                summary["Vehicle No"] = vehicle_key

                all_summaries.append(summary)

            elif "data_snapshot" in v or "req_data" in v:
                faults_alerts_counter[(vehicle_key, date)] += 1


                
            # Trips
            if isinstance(trips, list):
                for t in trips:
                    if isinstance(t, dict):
                        vehicle_map[vehicle_key].append({"date": date,"vrn/chassis_number": vehicle_key,**t})

            # Sessions
            if isinstance(sessions, list):
                for s in sessions:
                    if isinstance(s, dict):
                        vehicle_map[vehicle_key].append({"date": date,"vrn/chassis_number": vehicle_key,**s})

            # No trips or sessions
            if not trips and not sessions:
                vehicle_map[vehicle_key].append({"date": date,"vrn/chassis_number": vehicle_key,**v})

    for (vehicle_key, dt), count in faults_alerts_counter.items():

        all_summaries.append({
            "Date": dt,
            "Vehicle No": vehicle_key,
            "Total No.of events detected": count
        })

    return vehicle_map,all_summaries


import json
from datetime import datetime, date

def make_excel_safe(value):
    if value is None:
        return ""

    if isinstance(value, (list, dict, set, tuple)):
        return json.dumps(value)
    
    if isinstance(value, (datetime)):
        if value.tzinfo is not None:
            return value.replace(tzinfo=None)
        return value

    return value



#For excel report generation
def export_excel(data, filename_prefix):
    import openpyxl
    from openpyxl.utils import get_column_letter
    from django.http import HttpResponse

    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default sheet

    vehicle_map,summary = group_by_vehicle(data)


    if not vehicle_map:
        ws = wb.create_sheet("No_Data")
        ws.append(["No data available"])


    for vrn, rows in vehicle_map.items():
        ws = wb.create_sheet(title=vrn[:31])  # sheet name limit

        if not rows:
            ws.append(["No Data"])
            continue

        header = list(rows[0].keys())
        ws.append(header)

        for r in rows:

            ws.append([
                make_excel_safe(r.get(col, ""))
                for col in header
            ])

        # Auto width
        for idx, col in enumerate(header, 1):
            ws.column_dimensions[get_column_letter(idx)].width = min(40, len(col) + 5)

    #For summary page in reports
    if summary:
        summary_ws = wb.create_sheet(title="Summary", index = 0)

        if summary:
            header = list(summary[0].keys())
            summary_ws.append(header)

            for row in summary:
                summary_ws.append([
                make_excel_safe(row.get(col, ""))
                for col in header
            ])

            for idx, col in enumerate(header, 1):
                summary_ws.column_dimensions[get_column_letter(idx)].width = min(40, len(col) + 5)
        else:
            summary_ws.append(["No Summary Data"])

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = f'attachment; filename="{filename_prefix}.xlsx"'
    wb.save(response)
    return response




