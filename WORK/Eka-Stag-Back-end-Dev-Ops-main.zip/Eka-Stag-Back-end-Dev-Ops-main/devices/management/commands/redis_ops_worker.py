from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "trip worker for live trip progress calculation"

    def handle(self, *args, **kwargs):
        from redisSetup.redis_trip import run
        run()