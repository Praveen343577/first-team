from django.core.management.base import BaseCommand

from redisSetup.redis_tcp import VehicleTCPServer


class Command(BaseCommand):
    help = "Starts the tcp data storing"

    def handle(self, *args, **options):
        VehicleTCPServer().start()