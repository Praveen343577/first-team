from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "Starts the data parsing and batch inserts from redis"

    def handle(self, *args, **kwargs):
        from redisSetup.redis_decoder import run
        run()