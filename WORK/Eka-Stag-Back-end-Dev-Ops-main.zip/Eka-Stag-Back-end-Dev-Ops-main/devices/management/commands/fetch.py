from django.core.management.base import BaseCommand
from devices.fetchdata import store_data
from apscheduler.schedulers.blocking import BlockingScheduler
import logging
import time

logger = logging.getLogger("apscheduler")
class Command(BaseCommand):
    help = "Runs store_data() only once for testing"

    def handle(self, *args, **kwargs):
        scheduler = BlockingScheduler(timezone="Asia/Kolkata")
        scheduler.add_job(
            store_data,
            trigger='interval',
            seconds=87,
            id='store_data_job',
            replace_existing=True,
            coalesce=True,
            max_instances=1
        )
        if not scheduler.running:
            scheduler.start()
            logger.warning("Scheduler started")
        self.stdout.write(self.style.SUCCESS("Scheduler is running..."))
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            scheduler.shutdown()
            logger.warning("Scheduler stopped")
