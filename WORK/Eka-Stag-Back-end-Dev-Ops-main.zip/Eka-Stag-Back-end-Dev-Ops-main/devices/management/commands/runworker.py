from django.core.management.base import BaseCommand
from devices.worker import run_worker

class Command(BaseCommand):
    def handle(self, *args, **kwargs):
        run_worker()