from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "Starts the data parsing and batch inserts from redis"

    def handle(self, *args, **kwargs):
        print("Flush worker command started")
        from redisSetup.redis_flush import run
        run()