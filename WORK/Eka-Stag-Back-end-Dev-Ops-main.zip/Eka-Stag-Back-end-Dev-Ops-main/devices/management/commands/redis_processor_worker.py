from django.core.management.base import BaseCommand

class Command(BaseCommand):
    help = "Live processor for total calculation,alerts,faults and Daily reports"

    def handle(self, *args, **kwargs):
        from redisSetup.redis_processor import run
        run()