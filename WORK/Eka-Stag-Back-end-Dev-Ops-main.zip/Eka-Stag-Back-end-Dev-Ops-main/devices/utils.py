from datetime import timedelta, timezone as dt_timezone

from django.utils import timezone


def get_is_connected(last_timestamp):

    if not last_timestamp:
        return False

    try:

        if isinstance(last_timestamp, str):
            last_ts = timezone.datetime.fromisoformat(last_timestamp)
        else:
            last_ts = last_timestamp

    except:
        return False

    if timezone.is_aware(last_ts):
        last_ts_utc = last_ts.astimezone(dt_timezone.utc)
    else:
        last_ts_utc = timezone.make_aware(last_ts, dt_timezone.utc)

    now_utc = timezone.now()

    return last_ts_utc >= now_utc - timedelta(minutes=2)


def calc_4w(can, variant):

    odometer = (
        can.get("ODOMETER_CRUT")
        if can.get("ODOMETER_CRUT") not in (None, 0, "N")
        else can.get("ODOMETER", 0)
    )

    try:
        speed = float(can.get("WheelBasedVehicleSpeed_Rx"))
    except:
        speed = 0

    variant_map = {
        "7M": ["A"],
        "9M": ["A", "B"],
        "12M": ["A", "B", "C"],
        "13.5M": ["A"],
        "55T": ["A"],
        "1.5t": ["A"],
        "5T": ["A"]
    }

    prefixes = variant_map.get(variant, [])

    soc_vals = []

    for p in prefixes:

        try:
            soc_vals.append(float(can.get(f"{p}_SOC_Value")))
        except:
            pass

    soc = sum(soc_vals) / len(soc_vals) if soc_vals else 0

    temp_vals = []

    for p in prefixes:

        try:
            temp_vals.append(float(can.get(f"{p}_Max_Cell_Temp")))
        except:
            pass

    cell_temp = max(temp_vals) if temp_vals else 0

    try:
        dte = float(can.get("DTE"))
    except:
        dte = 0

    ts = 0

    return {
        "odometer": odometer,
        "speed": speed,
        "soc": soc,
        "ts": ts,
        "cell_temp": cell_temp,
        "dte": dte,
    }


def calc_3w(can):

    try:
        odometer = float(can.get("MCU_Odometer_Val"))
    except:
        odometer = 0

    try:
        speed = float(can.get("MCU_Speed_Kmph"))
    except:
        speed = 0

    try:
        soc = float(can.get("SOC"))
    except:
        soc = 0

    ts_vals = []

    for k in ["TS1", "TS2", "TS3", "TS4", "TS5", "TS6"]:

        v = can.get(k)

        if v not in (None, "N"):

            try:
                ts_vals.append(float(v))
            except:
                pass

    ts = max(ts_vals) if ts_vals else 0

    try:
        dte = float(can.get("Vehicle_DTE_Km"))
    except:
        dte = 0

    return {
        "odometer": odometer,
        "speed": speed,
        "soc": soc,
        "ts": ts,
        "cell_temp": 0,
        "dte": dte,
    }


def transform_live_data(raw_data, custom_params=None):

    can = raw_data.get("can_data") or {}

    device_type = raw_data.get("device_type")
    variant = raw_data.get("device_type_name")

    if device_type == "4w":
        calculated = calc_4w(can, variant)
    else:
        calculated = calc_3w(can)

    response = {
        "imei": raw_data.get("imei"),
        "last_timestamp": raw_data.get("last_timestamp"),
        "latitude": raw_data.get("latitude"),
        "latitude_dir": raw_data.get("latitude_dir"),
        "longitude": raw_data.get("longitude"),
        "longitude_dir": raw_data.get("longitude_dir"),
        "heading": raw_data.get("heading"),
        "odometer": calculated["odometer"],
        "speed": calculated["speed"],
        "soc": calculated["soc"],
        "ts": calculated["ts"],
        "cell_temp": calculated["cell_temp"],
        "dte": calculated["dte"],
        "is_connected": get_is_connected(
            raw_data.get("last_timestamp")
        )
    }

    # Custom user params
    if custom_params:

        for out_key, can_key in custom_params.items():

            if can_key in can:
                response[out_key] = can.get(can_key)

    return response