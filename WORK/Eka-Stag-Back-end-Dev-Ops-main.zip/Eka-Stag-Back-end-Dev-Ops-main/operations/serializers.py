from rest_framework import serializers
from operations.models import Routes,Drivers,Trips,VehicleStatus


class RouteSerializer(serializers.ModelSerializer):

    class Meta:
        model = Routes
        fields = "__all__"
        read_only_fields = ["user"]


class DriverSerializer(serializers.ModelSerializer):

    class Meta:
        model = Drivers
        fields = "__all__"
        read_only_fields = ["user"]

class TripSerializer(serializers.ModelSerializer):

    class Meta:
        model = Trips
        fields = "__all__"
        read_only_fields = ["user"]




class VehicleStatusSerializer(serializers.ModelSerializer):

    class Meta:
        model = VehicleStatus
        fields = "__all__"

