from django.urls import path
from operations.views import RouteAPI,DriverAPI,TripAPI,VehicleStatusAPI,AssignmentAPI

urlpatterns = [
    path("routes/", RouteAPI.as_view()),
    path("routes/<str:route_id>/", RouteAPI.as_view()),
    path("drivers/", DriverAPI.as_view()),
    path("drivers/<str:driver_id>/", DriverAPI.as_view()),
    path("trips/", TripAPI.as_view()),
    path("trips/<str:trip_id>/", TripAPI.as_view()),
    path("vehicles/", VehicleStatusAPI.as_view()),
    path("vehicles/<int:vehicle_id>/status/", VehicleStatusAPI.as_view()),
    path("Assignments/", AssignmentAPI.as_view())
]