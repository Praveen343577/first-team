from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from users.models import User,UserDeviceAssignment
from devices.models import Device
from operations.models import Routes,Drivers,Trips,VehicleStatus
from operations.serializers import RouteSerializer,DriverSerializer,TripSerializer
from django.utils import timezone 
from django.db.models import Q
from datetime import datetime
from django.db.models import Max
from django.utils.timezone import get_current_timezone
from datetime import timezone as dt_timezone



# helper for ISO parsing
def parse_iso(dt):
    if not dt:
        return None
    parsed = datetime.fromisoformat(dt.replace("Z", "+00:00"))
    return parsed.astimezone(dt_timezone.utc) if parsed.tzinfo else timezone.make_aware(parsed, dt_timezone.utc)


def ensure_aware(dt):
    if not dt:
        return None
    if timezone.is_naive(dt):
        return timezone.make_aware(dt, dt_timezone.utc)
    return dt.astimezone(dt_timezone.utc)


def combine_datetime(date_str, time_str):
    if not time_str:
        return None

    if "T" in time_str:
        return ensure_aware(parse_iso(time_str))

    dt = datetime.fromisoformat(f"{date_str}T{time_str}")
    return timezone.make_aware(dt, dt_timezone.utc)


class RouteAPI(APIView):

    def get(self, request):
        username = request.query_params.get("username")

        try:
            user = User.objects.get(email=username)
        except User.DoesNotExist:
            return Response({"error": "Invalid username"}, status=400)

        routes = Routes.objects.filter(user=user)
        return Response(RouteSerializer(routes, many=True).data)

    def post(self, request):
        username = request.data.get("username")

        try:
            user = User.objects.get(email=username)
        except User.DoesNotExist:
            return Response({"error": "Invalid username"}, status=400)

        route_id = request.data.get("route_id")

        if Routes.objects.filter(user=user, route_id=route_id).exists():
            return Response({"error": "Route already exists"}, status=400)

        serializer = RouteSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save(user=user)
            return Response(serializer.data, status=201)

        return Response(serializer.errors, status=400)

    def put(self, request, route_id):
        username = request.data.get("username")

        try:
            user = User.objects.get(email=username)
            route = Routes.objects.get(user=user, route_id=route_id)
        except (User.DoesNotExist, Routes.DoesNotExist):
            return Response({"error": "Route not found"}, status=404)

        serializer = RouteSerializer(route, data=request.data, partial=True)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        return Response(serializer.errors, status=400)

    def delete(self, request, route_id):
        username = request.query_params.get("username")

        try:
            user = User.objects.get(email=username)
            route = Routes.objects.get(user=user, route_id=route_id)
        except (User.DoesNotExist, Routes.DoesNotExist):
            return Response({"error": "Route not found"}, status=404)

        route.delete()
        return Response({"message": "Route deleted"})


class DriverAPI(APIView):

    def get(self, request):
        username = request.query_params.get("username")

        try:
            user = User.objects.get(email=username)
        except User.DoesNotExist:
            return Response({"error": "Invalid username"}, status=400)

        drivers = Drivers.objects.filter(user=user)
        return Response(DriverSerializer(drivers, many=True).data)

    def post(self, request):
        username = request.data.get("username")

        try:
            user = User.objects.get(email=username)
        except User.DoesNotExist:
            return Response({"error": "Invalid username"}, status=400)

        driver_id = request.data.get("driver_id")

        if Drivers.objects.filter(user=user, driver_id=driver_id).exists():
            return Response({"error": "Driver exists"}, status=400)

        serializer = DriverSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save(user=user)
            return Response(serializer.data, status=201)

        return Response(serializer.errors, status=400)

    def put(self, request, driver_id):
        username = request.data.get("username")

        try:
            user = User.objects.get(email=username)
            driver = Drivers.objects.get(user=user, driver_id=driver_id)
        except (User.DoesNotExist, Drivers.DoesNotExist):
            return Response({"error": "Driver not found"}, status=404)

        serializer = DriverSerializer(driver, data=request.data, partial=True)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

        return Response(serializer.errors, status=400)

    def delete(self, request, driver_id):
        username = request.query_params.get("username")

        try:
            user = User.objects.get(email=username)
            driver = Drivers.objects.get(user=user, driver_id=driver_id)
        except (User.DoesNotExist, Drivers.DoesNotExist):
            return Response({"error": "Driver not found"}, status=404)

        driver.delete()
        return Response({"message": "Driver deleted"})


class VehicleStatusAPI(APIView):

    def get(self, request):
        username = request.query_params.get("username")

        assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
        if not assignment:
            return Response({"error": "No devices assigned"}, status=400)

        devices = Device.objects.filter(device_id__in=assignment.devices)

        response = []

        for v in devices:
            status, _ = VehicleStatus.objects.get_or_create(vehicle=v)

            response.append({
                "vehicle_id": v.device_id,
                "status": status.status
            })

        return Response(response)

    def patch(self, request, vehicle_id):
        username = request.query_params.get("username")
        status_val = request.data.get("status")

        if status_val not in ["available", "off_road", "maintenance"]:
            return Response({"error": "Invalid status"}, status=400)

        assignment = UserDeviceAssignment.objects.filter(user__email=username).first()
        if not assignment or str(vehicle_id) not in assignment.devices:
            return Response({"error": "Not allowed"}, status=400)

        vehicle = Device.objects.get(device_id=vehicle_id)

        obj, _ = VehicleStatus.objects.get_or_create(vehicle=vehicle)
        obj.status = status_val
        obj.status_updated_at = timezone.now()
        obj.save()

        return Response({"vehicle_id": vehicle_id, "status": obj.status})


class AssignmentAPI(APIView):

    def get(self, request):

        username = request.query_params.get("username")
        start = parse_iso(request.query_params.get("start_time"))
        end = parse_iso(request.query_params.get("stop_time"))

        user = User.objects.get(email=username)

        assignment = UserDeviceAssignment.objects.filter(user=user).first()
        device_ids = assignment.devices if assignment else []

        drivers = Drivers.objects.filter(
            user=user,
            availability_status="available"
        ).filter(
            Q(next_available_at__lte=start) | Q(next_available_at__isnull=True)
        ).exclude(
            trips__user=user,
            trips__status__in=["scheduled", "started", "paused"],
            trips__start_time__lt=end,
            trips__end_time__gt=start
        ).values_list("driver_id", flat=True)


        vehicles = VehicleStatus.objects.filter(
            vehicle__device_id__in=device_ids,
            status="available"
        ).filter(
            Q(next_available_at__lte=start) | Q(next_available_at__isnull=True)
        ).exclude(
            vehicle__trips__user=user,
            vehicle__trips__status__in=["scheduled", "started", "paused"],
            vehicle__trips__start_time__lt=end,
            vehicle__trips__end_time__gt=start
        ).values_list("vehicle__device_id", flat=True)

        return Response({
            "drivers": list(drivers),
            "vehicles": list(vehicles)
        })


class TripAPI(APIView):

    def get(self, request):
        username = request.query_params.get("username")
        date = request.query_params.get("date")

        user = User.objects.get(email=username)

        trips = Trips.objects.filter(user=user).select_related(
            "driver", "vehicle", "route"
        )

        if date:
            date = parse_iso(date).date()
            trips = trips.filter(date=date)

        return Response(TripSerializer(trips, many=True).data)

    def post(self, request):
        data = request.data
        user = User.objects.get(email=data.get("username"))

        if Trips.objects.filter(user=user, trip_id=data.get("trip_id")).exists():
            return Response({"error": "Trip exists"}, status=400)

        driver = Drivers.objects.get(user=user, driver_id=data.get("driver"))
        vehicle = Device.objects.get(device_id=data.get("vehicle"))
        route = Routes.objects.get(user=user, route_id=data.get("route"))

        start = ensure_aware(parse_iso(data.get("start_time")))
        end = ensure_aware(parse_iso(data.get("end_time")))

        if not start or not end or start >= end:
            return Response({"error": "Invalid time range"}, status=400)

        # conflict check 
        conflict = Trips.objects.filter(
            user=user,
            status__in=["scheduled", "started", "paused"],
            start_time__lt=end,
            end_time__gt=start
        ).filter(Q(driver=driver) | Q(vehicle=vehicle)).exists()

        if conflict:
            return Response({"error": "Conflict"}, status=400)

        # stop processing
        stops = data.get("stop_schedule", [])
        converted = []
        prev_time = None
        orders = []

        for s in stops:
            orders.append(s.get("stop_order"))

            arr = combine_datetime(data.get("date"), s.get("arrival_time"))
            dep = combine_datetime(data.get("date"), s.get("departure_time"))

            current = arr or dep
            if prev_time and current and current < prev_time:
                return Response({"error": "Invalid stop sequence"}, status=400)

            prev_time = dep or arr

            converted.append({
                **s,
                "arrival_time": arr.isoformat() if arr else None,
                "departure_time": dep.isoformat() if dep else None
            })

        if sorted(orders) != list(range(1, len(orders)+1)):
            return Response({"error": "Invalid stop order"}, status=400)

        payload = data.copy()
        payload.update({
            "user": user.id,
            "driver": driver.id,
            "vehicle": vehicle.id,
            "route": route.id,
            "start_time": start,
            "end_time": end,
            "stop_schedule": converted
        })

        serializer = TripSerializer(data=payload)

        if serializer.is_valid():
            trip = serializer.save(user=user)

            driver.next_available_at = end
            driver.save(update_fields=["next_available_at"])

            vs, _ = VehicleStatus.objects.get_or_create(vehicle=vehicle)
            vs.next_available_at = end
            vs.save(update_fields=["next_available_at"])

            return Response(serializer.data, status=201)

        return Response(serializer.errors, status=400)

    def put(self, request, trip_id):
        user = User.objects.get(email=request.data.get("username"))
        trip = Trips.objects.get(trip_id=trip_id, user=user)

        if request.data.get("status") != "cancelled":
            return Response({"error": "Only cancel allowed"}, status=400)

        trip.status = "cancelled"
        trip.save(update_fields=["status"])

        now = timezone.now()

        trip.driver.next_available_at = now
        trip.driver.save(update_fields=["next_available_at"])

        vs, _ = VehicleStatus.objects.get_or_create(vehicle=trip.vehicle)
        vs.next_available_at = now
        vs.save(update_fields=["next_available_at"])

        return Response({"message": "Cancelled"})

    def delete(self, request, trip_id):
        username = request.query_params.get("username")
        user = User.objects.get(email=username)

        trip = Trips.objects.get(trip_id=trip_id, user=user)

        if trip.status != "scheduled":
            return Response({"error": "Cannot delete active trip"}, status=400)

        driver = trip.driver
        vehicle = trip.vehicle

        # delete first
        trip.delete()

        now = timezone.now()

        driver_trips = Trips.objects.filter(
            driver=driver,
            status__in=["scheduled", "started", "paused"],
            end_time__gt=now  
        )

        if driver_trips.exists():
            latest_end = driver_trips.aggregate(max_end=Max("end_time"))["max_end"]
            driver.next_available_at = latest_end
        else:
            driver.next_available_at = now

        driver.save(update_fields=["next_available_at"])

        vehicle_trips = Trips.objects.filter(
            vehicle=vehicle,
            status__in=["scheduled", "started", "paused"],
            end_time__gt=now
        )

        if vehicle_trips.exists():
            latest_end = vehicle_trips.aggregate(max_end=Max("end_time"))["max_end"]
            next_available = latest_end
        else:
            next_available = now

        from operations.models import VehicleStatus
        vs, _ = VehicleStatus.objects.get_or_create(vehicle=vehicle)
        vs.next_available_at = next_available
        vs.save(update_fields=["next_available_at"])

        return Response({"message": "Deleted"})
