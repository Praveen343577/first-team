from django.db import models
from users.models import User
from devices.models import Device

class Routes(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='routes')
    route_id = models.CharField(max_length=10)
    route_name = models.CharField(max_length=30)
    stop_count = models.IntegerField()
    stops = models.JSONField()
    # created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "route_id")

    def __str__(self):
        return f"{self.user.email} - {self.route_id}"


class Drivers(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='drivers')
    driver_id = models.CharField(max_length=20)
    name = models.CharField(max_length=30, blank=True)
    age = models.IntegerField()
    phone_number = models.CharField(max_length=15)
    email = models.CharField(max_length=30, blank=True, null=True)
    address = models.CharField(max_length=500)
    license_no = models.CharField(max_length=20)
    license_exp_date = models.DateField(null=True)
    license_validation = models.BooleanField(default=False)

    status_choices = [
        ("available", "Available"),
        ("unavailable", "Unavailable")
    ]
    availability_status = models.CharField(max_length=20, choices=status_choices, null=True)
    status_updated_at = models.DateTimeField(null=True, blank=True)

    hours_scheduled = models.FloatField(null=True, blank=True)
    total_scheduled_hours = models.FloatField(null=True, blank=True)

    next_available_at = models.DateTimeField(null=True, blank=True)
    # created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "driver_id")

    def __str__(self):
        return f"{self.user.email} - {self.driver_id}"


class Trips(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='trips')
    trip_id = models.CharField(max_length=30)

    vehicle = models.ForeignKey('devices.Device', on_delete=models.SET_NULL, null=True, related_name='trips')
    driver = models.ForeignKey(Drivers, on_delete=models.CASCADE)
    route = models.ForeignKey(Routes, on_delete=models.SET_NULL, null=True, blank=True, related_name='trips')

    route_name = models.CharField(max_length=30)
    date = models.DateField()

    status_choices = [
        ("scheduled", "Scheduled"),
        ("started", "Started"),
        ("paused", "Paused"),
        ("completed", "Completed"),
        ("cancelled", "Cancelled")
    ]
    status = models.CharField(max_length=20, choices=status_choices, default="scheduled")

    delayed_status = models.BooleanField(default=False)

    start_time = models.DateTimeField(null=True)
    end_time = models.DateTimeField(null=True)

    progress = models.FloatField(null=True)

    stop_schedule = models.JSONField()
    trip_progress = models.JSONField(null=True)

    # created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "trip_id")
        indexes = [
            models.Index(fields=["vehicle", "start_time", "end_time"]),
            models.Index(fields=["driver", "start_time", "end_time"]),
        ]

    def __str__(self):
        return f"{self.user.email} - {self.trip_id}"


class VehicleStatus(models.Model):
    status_choices = [
        ("available", "Available"),
        ("off_road", "Off Road"),
        ("maintenance", "Maintenance"),
    ]

    vehicle = models.OneToOneField('devices.Device', on_delete=models.CASCADE, related_name="availability")
    status = models.CharField(max_length=20, choices=status_choices, default="available")
    status_updated_at = models.DateTimeField(auto_now_add=True)

    next_available_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.vehicle} - {self.status}"

