import traceback
from devices.models import DeviceData, AlertRule, Alert, Fault,Device,DeviceTotalCalculationData, FaultRule, LiveData
from django.utils import timezone
from devices.calculation import (
    combine_dtc_fields,
    total_calculations,
    total_calculations_3w,
    initialize_metrics
)
from redisSetup.redis_cal import (r_initialize_metrics,r_total_calculations,r_total_calculations_3w,
                                  r_live_daily_report_3w_calculation,r_live_daily_report_4w_calculation)
                                  
import traceback
from datetime import timedelta,datetime
import unicodedata
from redisSetup.redis_state import load_fault_rules


def processor_device_calculations(device_id, device_type, device_type_name, can_data, total_cal_state):
    try:
        updated = False

        variant = "3w_6s" if device_type == "3w" else (device_type_name or "7M")
        odometer = can_data.get("MCU_Odometer_Val", 0) if device_type == "3w" else can_data.get("ODOMETER", 0)



        # initialize state
        if not total_cal_state:
            total_cal_state, updated = r_initialize_metrics(variant, odometer)

            if not total_cal_state:
                return total_cal_state, False
        # calculations
        if device_type == "3w":
            total_cal_state, updated = r_total_calculations_3w(
                can_data, device_id, odometer, variant, total_cal_state
            )
        elif device_type == "4w":
            total_cal_state, updated = r_total_calculations(
                can_data, device_id, variant, odometer, total_cal_state
            )

        return total_cal_state, updated

    except Exception as e:
        print(f"[Device Calculated Data] Error: {e}")
        return total_cal_state, False

from django.db import close_old_connections
def processor_data_summary(device_details,device_id,device_type,device_type_name,header,packet_status,latitude,longitude,timestamp,can_data,daily_summary_state):
    close_old_connections()
    daily_summary_state.setdefault("imei", device_id)
    try:
        if device_type == "3w" and header == "$NRM" and packet_status == "L":
            daily_summary_state, updated = r_live_daily_report_3w_calculation(device_details, device_id, latitude, longitude,timestamp,can_data,daily_summary_state)
            return daily_summary_state, updated

        elif device_type == "4w" and header == "$NRM" and packet_status == "L":
            variants = ['7M', '9M', '12M', '13.5M', '55T', '1.5t']
            variant = next((v for v in variants if v in device_type_name), '7M')
            daily_summary_state, updated = r_live_daily_report_4w_calculation(device_details, device_id, variant, latitude, longitude,timestamp,can_data,daily_summary_state)
            return daily_summary_state, updated
        else:
            return daily_summary_state, False

    except Exception as e:
        print(f"[ERROR] Exception in create_data_summary: {e}")
        traceback.print_exc()
        return daily_summary_state, False

def processor_alerts(device_id, device_type, device_type_name, header, latitude, longitude, timestamp, can_data, alerts_state):

    from redisSetup.data_parsing_functions import get_alert_rules

    # Ensure correct state structure
    if not isinstance(alerts_state, dict):
        alerts_state = {"active": {}, "buffer": []}

    if not can_data:
        return alerts_state, False

    ignition_value = can_data.get("Ignition_Sense")

    if ignition_value in (None, 0, "0", "OFF", False, "N"):
        return alerts_state, False

    if device_type != "4w":
        return alerts_state, False

    FIVE_MIN = timedelta(minutes=5)
    THREE_MIN = timedelta(minutes=3)

    MIN_DURATION_BY_TYPE = {"Alert": FIVE_MIN}
    DEFAULT_MIN_DURATION = THREE_MIN

    def to_num(v, default=0.0):
        try:
            if v in (None, "", "null", "None", "NaN", "nan", "N"):
                return default
            x = float(v)
            return x if x == x and x not in (float("inf"), float("-inf")) else default
        except (TypeError, ValueError):
            return default

    class SafeDict(dict):

        def get(self, key, default=0.0):
            return to_num(super().get(key, default), default)

        def __getitem__(self, key):
            return to_num(super().get(key, 0.0), 0.0)

    safe_can = SafeDict(can_data)

    PARAM_MAP = {
        "7M": ["A"],
        "9M": ["A", "B"],
        "12M": ["A", "B", "C"],
        "13.5M": ["A"],
        "55T": ["A"],
        "1.5t": ["A"],
        "5T": ["A"]
    }

    prefixes = PARAM_MAP.get(device_type_name, [])

    soc_values = [
        safe_can.get(f"{p}_SOC_Value")
        for p in prefixes
        if safe_can.get(f"{p}_SOC_Value") is not None
    ]

    temp_values = [
        safe_can.get(f"{p}_Max_Cell_Temp")
        for p in prefixes
        if safe_can.get(f"{p}_Max_Cell_Temp") is not None
    ]

    MAX_CELL_TEMP = max(temp_values) if temp_values else 0

    voltage_values = [
        safe_can.get(f"{p}_Pack_Voltage_Value")
        for p in prefixes
        if safe_can.get(f"{p}_Pack_Voltage_Value") is not None
    ]

    current_values = [
        safe_can.get(f"{p}_Pack_Current_Value")
        for p in prefixes
        if safe_can.get(f"{p}_Pack_Current_Value") is not None
    ]

    bcs = ["BCS_Thermistor_1", "BCS_Thermistor_2", "BCS_Thermistor_3"]

    bcs_values = [
        safe_can.get(d)
        for d in bcs
        if safe_can.get(d) is not None
    ]

    SAFE_FUNCS = {
        "float": float,
        "int": int,
        "str": str,
        "max": max,
        "min": min,
        "abs": abs,
        "round": round,
        "sum": sum,
        "any": any,
        "all": all,
        "bool": bool,
    }

    def _normalize_rule_text(s: str) -> str:
        return unicodedata.normalize("NFKC", (s or "")).strip()

    def _eval_rule(rule_text: str, ctx: dict) -> bool:

        rt = _normalize_rule_text(rule_text)

        code = compile(rt, "<rule>", "eval")

        safe_globals = {"__builtins__": {}, **ctx}

        return bool(eval(code, safe_globals, {}))

    now = timezone.now()

    active_alerts = alerts_state.setdefault("active", {})
    alert_buffer = alerts_state.setdefault("buffer", [])

    alert_rules = get_alert_rules()

    for rule in alert_rules:

        try:

            req_signals = list(rule.get("req_signals") or [])

            snapshot = {signal: can_data.get(signal) for signal in req_signals}

            ctx = {
                "can_data": safe_can,
                "timezone": timezone,
                "device_type_name": device_type_name,
                "soc_values": soc_values,
                "temp_values": temp_values,
                "voltage_values": voltage_values,
                "current_values": current_values,
                "bcs_values": bcs_values,
                **SAFE_FUNCS,
            }

            condition_true = _eval_rule(rule["condition"], ctx)

            open_alert = active_alerts.get(rule["name"])

            if condition_true:

                if not open_alert:

                    active_alerts[rule["name"]] = {
                        "imei": device_id,
                        "name": rule["name"],
                        "alert_type": rule["alert_type"],
                        "value": rule["description"],
                        "start_time": now.isoformat(),
                        "end_time": now.isoformat(),
                        "duration_seconds": 0,
                        "device_type_name": device_type_name,
                        "req_data": [snapshot] if snapshot else [],
                        "db_created": False,
                        "db_id": None,
                    }

                else:

                    start_time = datetime.fromisoformat(open_alert["start_time"])

                    duration = now - start_time

                    open_alert["end_time"] = now.isoformat()

                    open_alert["duration_seconds"] = int(duration.total_seconds())

                    if snapshot:
                        open_alert["req_data"].append(snapshot)

            else:

                if open_alert:

                    start_time = datetime.fromisoformat(open_alert["start_time"])

                    duration = now - start_time

                    min_required = MIN_DURATION_BY_TYPE.get(
                        rule["alert_type"], DEFAULT_MIN_DURATION
                    )

                    if duration >= min_required:

                        alert_buffer.append(
                            {
                                "imei": device_id,
                                "name": rule["name"],
                                "alert_type": rule["alert_type"],
                                "value": rule["description"],
                                "device_type_name": device_type_name,
                                "start_time": start_time.isoformat(),
                                "end_time": now.isoformat(),
                                "duration_seconds": int(duration.total_seconds()),
                                "req_data": open_alert.get("req_data", []),
                            }
                        )

                    # else:

                    #     print(
                    #         f"[Alert DROPPED <{int(min_required.total_seconds()/60)}m] {rule['name']}"
                    #     )

                    active_alerts.pop(rule["name"], None)

        except Exception as e:

            print(f"[ALERT ERROR] {rule['name']}: {e}")

    return alerts_state, True





def processor_faults(device_id, device_type, device_type_name, header, latitude, longitude, timestamp, can_data, faults_state):
    from redisSetup.redis_state import get_fault_rules

    FAULT_GAP_SECONDS = 300
    now = timestamp
    now_iso = now.isoformat()

    if not can_data:
        return faults_state, False

    fault_rules_4w, fault_rules_3w = get_fault_rules()
    # Ensure valid state structure
    if not isinstance(faults_state, dict):
        faults_state = {
            "active": {},
            "buffer": []
        }

    active_faults = faults_state.setdefault("active", {})
    buffer_faults = faults_state.setdefault("buffer", [])

    # 4W FAULTS
    if str(device_type) == "4w":

        ignition = can_data.get("Ignition_Sense", 0)

        if ignition in (None, 0, "0", "OFF", False, "N"):
            return faults_state, False

        dtc_fields = combine_dtc_fields(can_data)

        current_keys = set()

        for component, identifier in dtc_fields.items():

            component = component.split('_DTC')[0].upper()

            try:
                identifier_val = float(identifier)
            except:
                continue

            if identifier_val < 50:
                identifier = str(identifier_val + 50)
            else:
                identifier = str(identifier_val)

            # rule = FaultRule.objects.filter(
            #     vehicle_type="4W",
            #     identifier=identifier,
            #     component=component
            # ).first()

            rule = fault_rules_4w.get((component, identifier))

            if not rule:
                continue

            key = str(rule["id"])
            current_keys.add(key)

            active_fault = active_faults.get(key)

            if active_fault:

                last_end = datetime.fromisoformat(active_fault["end_time"])
                gap = (now - last_end).total_seconds()

                if gap <= FAULT_GAP_SECONDS:
                    active_fault["end_time"] = now_iso
                    continue

                else:
                    active_fault["is_active"] = False
                    buffer_faults.append(active_fault)
                    active_faults.pop(key)

            active_faults[key] = {
                "imei": device_id,
                "rule_id": rule["id"],
                "component": component,
                "data_snapshot": can_data,
                "start_time": now_iso,
                "end_time": now_iso,
                "is_active": True,
                "db_created": False,
                "db_id": None
            }

        # Close faults no longer present
        for key in list(active_faults.keys()):

            if key not in current_keys:

                f = active_faults.pop(key)

                f["is_active"] = False
                f["end_time"] = now_iso

                buffer_faults.append(f)


    # 3W FAULTS
    elif str(device_type).lower() == "3w":

        ignition = can_data.get("IgnitionStatus")

        if ignition in (None, 0, "0", "OFF", False, "N"):
            return faults_state, False

        # rules = FaultRule.objects.filter(vehicle_type="3W")
        # rules_map = {r.identifier: r for r in rules}

        rules_map = fault_rules_3w

        for identifier, rule in rules_map.items():

            value = can_data.get(identifier)

            key = str(rule["id"])

            active_fault = active_faults.get(key)

            # Fault ON
            if value in (1, "1", True, "True", "true"):

                if active_fault:

                    active_fault["end_time"] = now_iso

                else:

                    active_faults[key] = {
                        "imei": device_id,
                        "rule_id": rule["id"],
                        "component": rule["component"],
                        "data_snapshot": can_data,
                        "start_time": now_iso,
                        "end_time": now_iso,
                        "is_active": True,
                        "db_created": False,
                        "db_id": None
                    }

            # Fault OFF
            else:

                if active_fault:

                    active_fault["is_active"] = False
                    active_fault["end_time"] = now_iso

                    buffer_faults.append(active_fault)

                    active_faults.pop(key)

    return faults_state, True