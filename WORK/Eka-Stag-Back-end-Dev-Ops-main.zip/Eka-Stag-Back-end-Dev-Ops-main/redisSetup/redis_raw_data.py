#Django Imports
import os
import cantools
import paho.mqtt.client as mqtt
import logging,sys,time, signal
from datetime import datetime
import pandas as pd
from django.utils import timezone
from typing import Optional
from dotenv import load_dotenv
from devices.models import Device, DeviceData, ExtraDevice, LiveData
import redis
import json
from django_redis import get_redis_connection

# Load environment variables from .env file
load_dotenv()

class MQTTDataProcessor:
    def __init__(self, config: dict):
        self.config = config
        self.setup_logging()
        self.setup_mqtt_client()
        self.running = True
        self.mqtt_data_df = pd.DataFrame()
        self.seen_devices = set()
        self.redis_conn = get_redis_connection("streams")

        # Signal handlers for shutdown
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGTERM, self.signal_handler)


    def setup_logging(self):
        # Configure logging
        log_format = '%(asctime)s - %(levelname)s - %(message)s'
        logging.basicConfig(
            level=logging.INFO,
            format=log_format,
            handlers=[
                logging.FileHandler('mqtt_processor.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
        self.logger = logging.getLogger(__name__)

    def setup_mqtt_client(self):
        """Setup MQTT client and callbacks"""
        self.client = mqtt.Client()
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.on_disconnect = self.on_disconnect

        # Credentials
        if self.config.get('username') and self.config.get('password'):
            self.client.username_pw_set(self.config['username'], self.config['password'])

    def signal_handler(self, signum, frame):
        # Handle shutdown signal
        self.logger.info("Shutdown signal received. Cleaning up...")
        try:
            if not self.mqtt_data_df.empty:
                self.upload_to_s3(self.mqtt_data_df)
            else:
                self.logger.info("No data to save.")
        except Exception as e:
            self.logger.error(f"Error saving final data: {str(e)}")

        self.running = False
        self.disconnect()
        sys.exit(0)


    def on_connect(self, client, userdata, flags, rc):
        """Callback when client connects"""
        if rc == 0:
            self.logger.info("Connected to MQTT broker")
            self.client.subscribe(self.config['topic'])
        else:
            self.logger.error(f"Connection failed with code {rc}")
    
    def on_message(self, client, userdata, msg):

        self.logger.info("MQTT message received")

        try:
            payload = msg.payload.decode()

            stream_id = self.redis_conn.xadd(
                "telematics_raw",
                {"payload": payload},
                maxlen=1000,
                approximate=True
            )

            self.logger.info(f"Redis stream id: {stream_id}")

        except Exception as e:
            self.logger.error(f"Error pushing to Redis: {e}")


    def on_disconnect(self, client, userdata, rc):
        """Callback when client disconnects"""
        self.logger.warning("Disconnected from MQTT broker")
        if rc != 0 and self.running:
            self.logger.info("Attempting to reconnect...")
            self.connect()

    def connect(self):
        try:
            self.client.connect(self.config['broker_host'], self.config['broker_port'], keepalive=60)
        except Exception as e:
            self.logger.error(f"Connection error: {str(e)}")
            return False
        return True

    def disconnect(self):
        self.client.disconnect()
        self.client.loop_stop()

    def run(self):
        """Main run loop"""
        if self.connect():
            self.client.loop_start()
        try:
            while True:
                time.sleep(1)   # keep process alive
        except KeyboardInterrupt:
            pass
        finally:
            self.client.disconnect()

def main():
    config = {
        'broker_host': '43.204.176.28',
        'broker_port': 1883,
        'topic': 'devicedata/#',
        'username': 'EKA',
        'password': 'EKA@123',
        'dbc_paths': {
            '3w': 'dbcs/3w.dbc',
            '4w': 'dbcs/4w.dbc',
        }
    }

    processor = MQTTDataProcessor(config)
    processor.run()

