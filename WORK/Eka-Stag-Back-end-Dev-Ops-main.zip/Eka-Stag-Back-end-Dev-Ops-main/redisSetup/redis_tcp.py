import socket
import threading
from datetime import datetime
import time
from typing import Optional, Any
import json

from devices.models import DeviceData, ExtraDevice
from redisSetup.data_parsing_functions import get_device_details, live_data
from redisSetup.redis_decoder import update_live_table
from django_redis import get_redis_connection
from django.db import transaction

LIVE_DATA_KEY = "live_data"
CHANGED_DEVICES_KEY = "changed_devices"
CURRENTLY_CONNECTED_DEVICES_KEY = "currently_connected_devices"

r = get_redis_connection("streams")
r_live = get_redis_connection("default")


def normalize(v):
    if hasattr(v, "isoformat"):
        return v.isoformat()
    return v

def convert_value(val: str) -> Optional[Any]:
    if val is None:
        return "N"

    val = str(val).strip()

    if val in ("", "-", "N", "NULL"):
        return "N"

    try:
        return float(val) if "." in val else int(val)
    except ValueError:
        return val


param_names = [
    "Protocol_Version", "BCM_Battery_Voltage", "BCM_Continous_ChaG_Current_Limit", "Battery_SOC",
    "BCM_MaxiM_Peak_Charging_Current", "DOD", "A_KWh_Remain", "Nominal_Battery_Capacity",
    "Charge_Point_Voltage", "EV_Error_Code", "EVCC_Chaarge_Done_Value", "A_Charging_Done", "EV_Ready_1",
    "Proxymity_Pilot_Resistance", "EVCC_Status_Code_1", "EVCC_Ready_1", "CP_Duty_Value", "Contactor_Control",
    "Charging_Status_1", "Charger_Gun_Detected", "Brake_Failure", "VCU_Ready", "MCU_Motor_Speed", "DCDC_Enable_Command",
    "BMS_VoltageSet", "BMS_CurrentSet", "OBC_AC_Voltage", "OBC_AC_Current", "OBC_Current_Limit",
    "OBC_Battery_Voltage", "HVPDU_Accessory_Contactor", "HVPDU_DC_Charge_Contactor", "HVPDU_2IN1_Contactor",
    "HVPDU_Battery_Postive_Contactor", "HVPDU_PreCharge_Contactor", "HVPDU_Battery_Negative_Contactor",
    "A_Pack_Voltage_Value", "A_Pack_Current_Value", "A_SOC_Value", "DCDC_Enable_Status", "Reverse", "Neutral",
    "Drive", "MCU_Temperature", "Motor_Temperature", "WheelBasedVehicleSpeed_Rx", "ODOMETER", "Undervoltage_indication",
    "System_Error_Motor_Controller", "Power_reduction_Index", "operation_Ready", "Motor_overheat", "Vehicle_Fault",
    "battery_cut_off", "A_Min_Cell_Temp", "A_Max_Cell_Temp", "A_Min_Cell_Volt",
    "A_Max_Cell_Volt", "Battery_Indication_SOC", "Power_Battery_Failure", "Low_Battery", "Gun_Detection_2",
    "Gun_Detection_1", "Insulation_Fault", "DCDC_Work_State", "DCDC_Output_Voltage", "DCDC_Temp_1", "DCDC_Output_Current",
    "DCDC_Input_Voltage", "DCDC_Fault_State", "MCU_Command_Mode", "MCU_Precharge_Allow", "MCU_IGBT_Enable_Fdbk",
    "MCU_Active_Discharge_Enable_Fdbk", "MCU_Motor_Torque_Estimated", "MCU_HighPowerCurrent", "Motor_Speed_2", "MCU_Fail_Grade",
    "Motor_Torque_Low_Limit", "Motor_Torque_High_Limit", "Motor_Temperature_2", "MCU_Temperature_2",
    "Motor_Rotation_Count", "MCU_HighPowerVoltage", "Motor_DC_Current", "MCU_DTC_Code", "Hardware_Error_Code6",
    "Hardware_Error_Code5", "Hardware_Error_Code4", "Hardware_Error_Code3", "Hardware_Error_Code2",
    "Hardware_Error_Code1", "MCU_Fault_Reset", "MCU_Enable", "MCU_Control_Mode", "Demand_Torque",
    "Demand_T_High_Postive_VLimit", "Demand_T_High_Negative_VLimit", "Demand_Speed", "DCDC_Enable_Cmd_2",
    "BMS_VoltageSet_2", "BMS_CurrentSet_2", "Contactor_Cmd", "A_Main_Contactors_Status"
]


def decoded_msg_to_processor(processor_payload):

    for payload in processor_payload:

        r.xadd(
            "telematics_decoded",
            payload,
            maxlen=1000,
            approximate=True
        )


class CANParser:
    def default_data(self, message, device_id):

        def get_field(parts, index, default="-"):
            if index < len(parts):
                value = parts[index].strip()
                return value if value else default
            return default

        try:

            if isinstance(message, bytes):
                message = message.decode()

            if device_id is None:
                return None
            
            parts = message.split(",")

            for index, value in enumerate(parts):
                print(f"{index:02d} -> {repr(value)}")

            if len(parts) < 33:
                print(f"Incomplete packet ({len(parts)} fields)")
                return None

            timestamp = datetime.now().isoformat()

            field_names = [
                "header", "vendor_id", "version", "packet_type",
                "alert_id", "packet_status", "IMEI",
                "vehicle_reg_no", "gps_fix", "date", "time",
                "latitude", "latitude_dir",
                "longitude", "longitude_dir",
                "speed", "heading", "no_of_stattalites",
                "altitude", "pdop", "hdop",
                "operator", "ignition",
                "main_power_status",
                "main_input_voltage",
                "internal_battery_voltage",
                "emergency_status",
                "temper_alert",
                "gsm_strength",
                "MCC", "MNC", "LAC",
                "cell_id"
            ]

            parsed_data = {
                "timestamp": timestamp,
                "device_id": device_id,
                "extra_data": json.dumps({})
            }

            # Fixed fields
            for i, field in enumerate(field_names):

                if field == "NMR" or i >= 33:
                    continue

                parsed_data[field] = get_field(parts, i)


            packet_status = parsed_data["packet_status"]
            ignition = parsed_data["ignition"]


            # Variable fields
            parsed_data["NMR"] = "|".join(parts[33:min(44, len(parts))])

            parsed_data["digital_input_status"] = get_field(parts, 46)
            parsed_data["digital_output_status"] = get_field(parts, 47)
            parsed_data["analog_input_1"] = get_field(parts, 48)
            parsed_data["analog_input_2"] = get_field(parts, 49)
            parsed_data["frame_number"] = get_field(parts, 50)
            parsed_data["odometer"] = get_field(parts, 51)
            if packet_status == "L":
                parsed_data["mis_field_2"] = get_field(parts, 52)
                print(parsed_data["mis_field_2"])
                parsed_data["debug_info"] = get_field(parts, 55)
            if packet_status == "H":
                parsed_data["debug_info"] = get_field(parts, 52)

            can_section = parsed_data.pop("mis_field_2") if "mis_field_2" in parsed_data else None


            return {"device_data" :parsed_data,"can_section":can_section,"ignition":ignition}

        except Exception as e:

            print(f"Error parsing message: {e}")
            print(f"Packet Length : {len(parts)}")
            return {"device_data" :None,"can_section":None}

    def parse_can_data(self, can_section: str,ignition) -> dict:
        if can_section.startswith("CAN|"):
            can_section = can_section[4:]
        values = can_section.split('|') if can_section else []
        parsed = {}
        for key, value in zip(param_names, values):
            parsed[key] = convert_value(value)

        if parsed:
            parsed["Ignition_Sense"] = ignition
        return parsed

class VehicleTCPServer:
    def __init__(self, host='0.0.0.0', port=1884):
        self.host = host
        self.port = port
        # self.db = MySQLHandler()
        self.parser = CANParser()
        
        self.batch_data = []
        self.live_updates = []
        self.redis_live_updates = []
        self.processor_payload = []
        self.unknown_ids = set()

        self.batch_size = 50
        self.lock = threading.Lock()
        threading.Thread(target=self.periodic_flush,daemon=True).start()

    def start(self):
        print(f"[+] Starting TCP server at {self.host}:{self.port}")
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind((self.host, self.port))
            s.listen()
            while True:
                conn, addr = s.accept()
                print(f"[+] Connection from {addr}")
                threading.Thread(target=self.handle_client, args=(conn,), daemon=True).start()


    def handle_client(self, conn):

        with conn:

            try:

                while True:

                    data = conn.recv(4096)

                    if not data:
                        break

                    text = data.decode(errors="ignore").strip()
                    # History packets (multiple packets)
                    if text.count("$") > 1:
                        packets = text.split("$")
                        for packet in packets:
                            if not packet:
                                continue

                            packet = "$" + packet
                            if "*" not in packet:
                                continue

                            packet = (packet.split("*", 1)[0]+ "*")
                            self.process_line(packet)

                    # Single packet (live)
                    else:

                        if not text.startswith("$"):
                            continue

                        if "*" not in text:
                            continue

                        packet = (
                            text.split("*", 1)[0]
                            + "*"
                        )

                        self.process_line(packet)

            except Exception as e:

                print(f"[!] Error handling client: {e}")

    def extract_device_id(self, message: str) -> Optional[str]:
        try:
            if isinstance(message, bytes):
                message = message.decode()
            parts = message.split(',')
            if len(parts) >= 7:
                return parts[6]  # 7th element (index 6) is device ID
            else:
                print("Unable to extract device ID - malformed message.")
                return None
        except Exception as e:
            print(f"Error extracting device ID: {e}")
            return None
        
    def process_line(self, message: str):
        try:
            device_id = self.extract_device_id(message)
            print(f"[PROCESS] Device : {device_id}")

            if not device_id:
                print("[PROCESS] Unknown Device")
                return
            
            device_details = get_device_details(device_id)

            if not device_details:

                should_flush = False

                with self.lock:

                    self.unknown_ids.add(device_id)

                    if len(self.unknown_ids) >= self.batch_size:
                        should_flush = True

                if should_flush:
                    self.flush_batch()

                return

            
            result = self.parser.default_data(message,device_id)

            if not result:
                return

            base_data=result["device_data"]
            can_section =result["can_section"]
            ignition = result["ignition"]

            if not base_data:
                return

            can_data = {}

            if can_section:
                can_data = self.parser.parse_can_data(
                    can_section,ignition
                )

                print(can_data)

            # DeviceData payload
            device_data = base_data

            should_flush = False

            with self.lock:

                self.batch_data.append(
                    DeviceData(
                        **device_data,
                        can_data=can_data
                    )
                )

                self.processor_payload.append({
                    **{
                        k: normalize(v)
                        for k, v in device_data.items()
                    },
                    "can_data": json.dumps(
                        can_data,
                        default=str
                    )
                })

                live_row = live_data(
                    device_data=device_data,
                    device_type=device_details.get(
                        "device_type"
                    ),
                    device_type_name=device_details.get(
                        "device_type_name"
                    ),
                    can_data=can_data,
                    device_id=device_id,
                )

                if live_row:

                    self.live_updates.append(
                        live_row
                    )

                    self.redis_live_updates.append({
                        "imei": live_row["imei"],
                        "payload": live_row
                    })

                if len(self.batch_data) >= self.batch_size:
                    should_flush = True

            if should_flush:
                self.flush_batch()
        except Exception as e:
            print(
                f"[!] Error processing line: {e}"
            )
        
    def periodic_flush(self):

        while True:
            time.sleep(5)
            
            with self.lock:
                has_data = (
                    self.batch_data or
                    self.live_updates or
                    self.redis_live_updates or
                    self.processor_payload or
                    self.unknown_ids
                )

            if has_data:
                self.flush_batch()
        
    def flush_batch(self):

        with self.lock:

            batch = self.batch_data
            live_updates = self.live_updates
            redis_live_updates = self.redis_live_updates
            processor_payload = self.processor_payload
            unknown_ids = self.unknown_ids


            self.batch_data = []
            self.live_updates = []
            self.redis_live_updates = []
            self.processor_payload = []
            self.unknown_ids = set()

        try:

            if batch:
                try:
                    with transaction.atomic():
                        DeviceData.objects.bulk_create(
                            batch,
                            batch_size=self.batch_size
                        )
                except Exception as e:
                    print(f"DeviceData insert error: {e}")

            if live_updates:
                try:
                    update_live_table(live_updates)
                except Exception as e:
                    print(f"LiveData insert error: {e}")

            if redis_live_updates:

                imeis = list([item["imei"]for item in redis_live_updates])

                existing_payloads = r_live.hmget( LIVE_DATA_KEY, imeis)

                existing_map = {}
                for imei, payload in zip(imeis,existing_payloads):
                    if payload:
                        try:
                            existing_map[imei] = json.loads(payload)
                        except:
                            existing_map[imei] = {}
                    else:
                        existing_map[imei] = {}

                pipe = r_live.pipeline()

                for item in redis_live_updates:

                    existing_payload = existing_map.get(item["imei"],{})

                    existing_can_data = (existing_payload.get("can_data")or {})

                    current_can_data = (item["payload"].get("can_data")or {})

                    item["payload"]["can_data"] = {**existing_can_data,**current_can_data}

                    pipe.hset(
                        LIVE_DATA_KEY,
                        item["imei"],
                        json.dumps(
                            item["payload"],
                            default=str
                        )
                    )

                    pipe.sadd(
                        CHANGED_DEVICES_KEY,
                        item["imei"]
                    )

                    pipe.sadd(
                        CURRENTLY_CONNECTED_DEVICES_KEY,
                        item["imei"]
                    )

                pipe.execute()

            if unknown_ids:

                existing = set(
                    ExtraDevice.objects.filter(
                        device_id__in=unknown_ids
                    ).values_list(
                        "device_id",
                        flat=True
                    )
                )

                to_create = [
                    ExtraDevice(device_id=d)
                    for d in unknown_ids
                    if d not in existing
                ]

                if to_create:
                    ExtraDevice.objects.bulk_create(
                        to_create
                    )

            if processor_payload:
                decoded_msg_to_processor(
                    processor_payload
                )

        except Exception as e:
            print(f"Flush error: {e}")




# if __name__ == "__main__":
#     server = VehicleTCPServer()
#     server.start()





#Mapping for cpuma

# "Protocol_Version" - "not used"
# "BCM_Battery_Voltage" - "not used"
# "BCM_Continous_ChaG_Current_Limit" - "not used"
# "Battery_SOC" - "not used"
# "BCM_MaxiM_Peak_Charging_Current" - "not used"
# "DOD" - "not used"
# "BCM_KWH_Remaining" - "A_KWh_Remain"
# "Nominal_Battery_Capacity" - "not used"
# "Charge_Point_Voltage" - "not used"
# "EV_Error_Code" - "not used"
# "Vehicle_Stop_Charging" - "EVCC_Chaarge_Done_Value"
# "Charging_Complete" - "A_Charging_Done"
# "EV_Ready"  - "EV_Ready_1"
# "Proxymity_Pilot_Resistance" - "not used"
# "EVCC_Status_Code" - "EVCC_Status_Code_1"
# "EVCC_Ready" - "EVCC_Ready_1"
# "CP_Duty_Value" - "not used"
# "Contactor_Control" - "not used"
# "Charging_Status" - "Charging_Status_1"
# "Charger_Gun_Detected" - "not used"
# "Brake_Failure" - "not used"
# "VCU_Ready" - "not used"
# "Motor_Speed" - "MCU_Motor_Speed"
# "DCDC_Enable_Cmd" - "DCDC_Enable_Command"
# "BMS_VoltageSet" - "not used"
# "BMS_CurrentSet" - "not used"
# "OBC_AC_Voltage" - "not used"
# "OBC_AC_Current" - "not used"
# "OBC_Current_Limit" - "not used"
# "OBC_Battery_Voltage" - "not used"
# "HVPDU_Accessory_Contactor" - "not used"
# "HVPDU_DC_Charge_Contactor" - "not used"
# "HVPDU_2IN1_Contactor" - "not used"
# "HVPDU_Battery_Postive_Contactor" - "not used"
# "HVPDU_PreCharge_Contactor" - "not used"
# "HVPDU_Battery_Negative_Contactor" - "not used"
# "Total_Battery_Voltage" - "A_Pack_Voltage_Value"
# "Total_Battery_Current" - "A_Pack_Current_Value"
# "Battery_SOC_2" - "A_SOC_Value"
# "DCDC_Enable_Status" - "not used"
# "Reverse" - "combined" - "DNR"
# "Neutral" - "combined" - "DNR"
# "Drive" - "combined" - "DNR"
# "MCU_Temperature" - "MCU_Temperature"
# "Motor_Temperature" - "Motor_Temperature"
# "Vehicle_Speed" - "WheelBasedVehicleSpeed_Rx"
# "Mileage" - "ODOMETER"
# "Undervoltage_indication" - "not used"
# "System_Error_Motor_Controller" - "not used"
# "Power_reduction_Index" - "not used"
# "operation_Ready" - "not used"
# "Motor_overheat" - "not used"
# "Vehicle_Fault" - "not used"
# "battery_cut_off" - "not used"
# "Battery_Cell_Min_Temp" - "A_Min_Cell_Temp"
# "Battery_Cell_Max_Temp" - "A_Max_Cell_Temp"
# "Battery_Cell_Min_Voltage" - "A_Min_Cell_Volt"
# "Battery_Cell_Max_Voltage" - "A_Max_Cell_Volt"
# "Battery_Indication_SOC" - "not used"
# "Power_Battery_Failure" - "not used"
# "Low_Battery" - "not used"
# "Gun_Detection2" - "Gun_Detection_2"
# "Gun_Detection1" - "Gun_Detection_1"
# "Insulation_Fault" - "not used"
# "DCDC_Work_State" - "not used"
# "DCDC_Vout" - "DCDC_Output_Voltage"
# "DCDC_Temp" - "DCDC_Temp_1"
# "DCDC_Iout" - "DCDC_Output_Current"
# "DCDC_InVoltage" - "DCDC_Input_Voltage"
# "DCDC_Fault_State" - "not used"
# "MCU_Work_Mode" - "MCU_Command_Mode"
# "MCU_Precharge_Allow" - "not used"
# "MCU_IGBT_Enable_Fdbk" - "not used"
# "MCU_Active_Discharge_Enable_Fdbk" - "not used"
# "Motor_Torque" - "MCU_Motor_Torque_Estimated"
# "Motor_AC_Current" - "not used"
# "Motor_Speed_2" - "not used"
# "MCU_Fail_Grade" - "not used"
# "Motor_Torque_Low_Limit" - "not used"
# "Motor_Torque_High_Limit" - "not used"
# "Motor_Temperature_2" - "not used"
# "MCU_Temperature_2" - "not used"
# "Motor_Rotation_Count" - "not used"
# "Motor_DC_Voltage" - "MCU_HighPowerVoltage"
# "Motor_DC_Current" - "MCU_HighPowerCurrent"
# "MCU_DTC_Code" - "not used"
# "Hardware_Error_Code6" - "not used"
# "Hardware_Error_Code5" - "not used"
# "Hardware_Error_Code4" - "not used"
# "Hardware_Error_Code3" - "not used"
# "Hardware_Error_Code2" - "not used"
# "Hardware_Error_Code1" - "not used"
# "MCU_Fault_Reset" - "not used"
# "MCU_Enable" - "not used"
# "MCU_Control_Mode" - "not used"
# "Demand_Torque" - "not used"
# "Demand_T_High_Postive_VLimit" - "not used"
# "Demand_T_High_Negative_VLimit" - "not used"
# "Demand_Speed" - "not used"
# "DCDC_Enable_Cmd_2" - "not used"
# "BMS_VoltageSet_2" - "not used"
# "BMS_CurrentSet_2" - "not used"
# "Contactor_Cmd" - "not used"
# "Contactor_On_Off" - "A_Main_Contactors_Status"




# import socket
# import time

# LISTEN_HOST = "0.0.0.0"
# LISTEN_PORT = 1884

# # Django TCP Worker
# FORWARD_HOST = "tcp_decoder"      
# FORWARD_PORT = 2993


# def connect_to_decoder():
#     while True:
#         try:
#             sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#             sock.connect((FORWARD_HOST, FORWARD_PORT))
#             print(f"Connected to decoder at {FORWARD_HOST}:{FORWARD_PORT}")
#             return sock
#         except Exception as e:
#             print(f"Decoder unavailable: {e}")
#             time.sleep(5)


# forward_socket = connect_to_decoder()

# server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# server.setsockopt(
#     socket.SOL_SOCKET,
#     socket.SO_REUSEADDR,
#     1
# )

# server.bind((LISTEN_HOST, LISTEN_PORT))
# server.listen(100)

# print(f"Listening on {LISTEN_HOST}:{LISTEN_PORT}")

# while True:

#     conn, addr = server.accept()

#     print(f"Device connected: {addr}")

#     try:

#         while True:

#             data = conn.recv(4096)

#             if not data:
#                 break

#             try:
#                 forward_socket.sendall(data)

#             except Exception:

#                 print("Decoder disconnected. Reconnecting...")

#                 try:
#                     forward_socket.close()
#                 except:
#                     pass

#                 forward_socket = connect_to_decoder()
#                 forward_socket.sendall(data)

#     except Exception as e:
#         print(f"Device error: {e}")

#     finally:
#         conn.close()
#         print(f"Device disconnected: {addr}")
