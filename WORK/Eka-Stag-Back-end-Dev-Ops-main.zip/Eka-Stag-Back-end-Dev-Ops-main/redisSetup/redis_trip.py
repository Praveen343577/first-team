import os
import json
import math
import threading
import time
from datetime import datetime, timedelta, timezone as dt_timezone
from django.utils import timezone
from django_redis import get_redis_connection
from django.db import close_old_connections
from operations.models import Trips

r = get_redis_connection("streams")

STREAM = "trip_updates_stream"
GROUP = "trip_group"
CONSUMER = f"trip_worker_{os.getpid()}"


def haversine(lat1, lon1, lat2, lon2):
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (
        math.sin(dlat / 2) ** 2 +
        math.cos(math.radians(lat1)) *
        math.cos(math.radians(lat2)) *
        math.sin(dlon / 2) ** 2
    )
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def parse_iso(dt):
    if not dt:
        return None
    parsed = datetime.fromisoformat(dt.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else timezone.make_aware(parsed, dt_timezone.utc)


def sync_trips_loop():
    while True:
        try:
            now = timezone.now()

            trips = Trips.objects.filter(
                start_time__gte=now - timedelta(hours=6),
                start_time__lte=now + timedelta(minutes=15),
                status__in=["scheduled", "started"]
            ).values("id", "vehicle__device_id", "start_time", "end_time")

            active_values = set()

            for trip in trips:
                start_ts = int(trip["start_time"].timestamp())
                end_ts = int(trip["end_time"].timestamp()) if trip["end_time"] else start_ts + 6 * 3600

                value = f"{trip['id']}:{trip['vehicle__device_id']}:{start_ts}:{end_ts}"
                active_values.add(value)

                r.zadd("active_trips", {value: start_ts})

            existing = r.zrange("active_trips", 0, -1)
            for val in existing:
                if val.decode() not in active_values:
                    r.zrem("active_trips", val)

        except Exception as e:
            print("[SYNC ERROR]", e)

        time.sleep(30)

def find_trip(device_id, now_ts):

    active_trip = r.get(f"bus:{device_id}:active_trip")

    if active_trip:
        return active_trip.decode()

    # fallback: time-based lookup
    vals = r.zrangebyscore("active_trips", now_ts - 6*3600, now_ts + 5*60)

    for v in vals:
        tid, dev, start, end = v.decode().split(":")

        if dev == device_id and int(start) <= now_ts <= int(end):
            return tid

    return None


def update_trip_progress_redis(state, trip, lat, lon):

    try:
        if state.get("status") in ["completed", "cancelled"]:
            return

        now = timezone.now()

        stops_list = sorted(trip.stop_schedule or [], key=lambda x: x["stop_order"])
        if not stops_list:
            return

        total_stops = len(stops_list)

        if not state.get("trip_progress"):
            state["trip_progress"] = {
                "current_index": 0,
                "stops": [{
                    "stop_order": s["stop_order"],
                    "stop_name": s["stop_name"],
                    "planned_arrival": s.get("arrival_time"),
                    "planned_departure": s.get("departure_time"),
                    "actual_arrival": None,
                    "actual_departure": None,
                    "status": "pending",
                    "delayed": False,
                    "last_distance": None
                } for s in stops_list]
            }

        progress = state["trip_progress"]
        stops = progress["stops"]
        current_index = progress.get("current_index", 0)

        ARRIVAL_RADIUS = 0.15
        DEPARTURE_RADIUS = 0.25
        SKIP_RADIUS = ARRIVAL_RADIUS * 3

        if current_index >= total_stops:
            state["status"] = "completed"
            return

        curr_state = stops[current_index]
        curr_plan = stops_list[current_index]

        dist = haversine(
            lat, lon,
            float(curr_plan["latitude"]),
            float(curr_plan["longitude"])
        )

        last_dist = curr_state.get("last_distance")

        curr_state["last_distance"] = dist

        moving_towards = last_dist is not None and dist < last_dist
        moving_away = last_dist is not None and dist > last_dist

        dist_next = None
        if current_index + 1 < total_stops:
            next_plan = stops_list[current_index + 1]
            dist_next = haversine(
                lat, lon,
                float(next_plan["latitude"]),
                float(next_plan["longitude"])
            )

        if not curr_state["actual_arrival"]:
            if dist <= ARRIVAL_RADIUS or (moving_towards and dist <= ARRIVAL_RADIUS * 1.2):
                curr_state["actual_arrival"] = now.isoformat()
                curr_state["status"] = "arrived"

                planned_arr = parse_iso(curr_plan.get("arrival_time"))
                if planned_arr and now > planned_arr:
                    curr_state["delayed"] = True

        if not curr_state["actual_departure"]:

            if curr_state["actual_arrival"] and dist >= DEPARTURE_RADIUS:
                curr_state["actual_departure"] = now.isoformat()
                curr_state["status"] = "completed"
                current_index += 1

            elif (
                not curr_state["actual_arrival"]
                and last_dist is not None
                and moving_away
                and last_dist < SKIP_RADIUS
            ):
                curr_state["status"] = "completed"
                curr_state["actual_departure"] = now.isoformat()

                planned_arr = parse_iso(curr_plan.get("arrival_time"))
                if planned_arr and now > planned_arr:
                    curr_state["delayed"] = True

                current_index += 1
            
        if current_index == total_stops - 1:

            if curr_state["actual_arrival"] and dist >= DEPARTURE_RADIUS:
                curr_state["actual_departure"] = now.isoformat()
                curr_state["status"] = "completed"
                current_index += 1

            elif (
                not curr_state["actual_arrival"]
                and last_dist is not None
                and moving_away
            ):
                curr_state["status"] = "completed"
                curr_state["actual_departure"] = now.isoformat()

                planned_arr = parse_iso(curr_plan.get("arrival_time"))
                if planned_arr and now > planned_arr:
                    curr_state["delayed"] = True

                current_index += 1

                if dist_next is not None and dist_next <= ARRIVAL_RADIUS:
                    if not curr_state["actual_departure"]:
                        curr_state["actual_departure"] = now.isoformat()
                        curr_state["status"] = "completed"

                    current_index += 1

        for i in range(current_index, total_stops - 1):
            curr_plan_i = stops_list[i]
            next_plan_i = stops_list[i + 1]

            dist_curr = haversine(lat, lon, float(curr_plan_i["latitude"]), float(curr_plan_i["longitude"]))
            dist_next_i = haversine(lat, lon, float(next_plan_i["latitude"]), float(next_plan_i["longitude"]))

            if dist_next_i < dist_curr:
                state_stop = stops[i]

                if state_stop["status"] != "completed":
                    state_stop["status"] = "completed"
                    state_stop["actual_departure"] = now.isoformat()

                    planned_arr = parse_iso(curr_plan_i.get("arrival_time"))
                    if planned_arr and now > planned_arr:
                        state_stop["delayed"] = True

                current_index = i + 1
            else:
                break

        progress["current_index"] = current_index

        state["progress"] = (current_index / total_stops) * 100 if total_stops else 0
        state["status"] = "completed" if current_index >= total_stops else "started"

    except Exception as e:
        print(f"[TRIP LOGIC ERROR] {e}")


def run():

    threading.Thread(target=sync_trips_loop, daemon=True).start()

    try:
        r.xgroup_create(STREAM, GROUP, id="0", mkstream=True)
    except:
        pass

    while True:
        close_old_connections()

        msgs = r.xreadgroup(GROUP, CONSUMER, {STREAM: ">"}, count=100, block=200)

        if not msgs:
            continue

        for _, entries in msgs:
            for msg_id, data in entries:
                try:
                    p = {k.decode(): v.decode() for k, v in data.items()}

                    device_id = p["device_id"]
                    lat = float(p["latitude"])
                    lon = float(p["longitude"])
                    ts = p["timestamp"]

                    now_ts = int(datetime.fromisoformat(ts).replace(tzinfo=timezone.utc).timestamp())

                    db_trip_id = find_trip(device_id, now_ts)
                    if not db_trip_id:
                        continue

                    active_trip = r.get(f"bus:{device_id}:active_trip")

                    if not active_trip:
                        r.set(f"bus:{device_id}:active_trip", db_trip_id, ex=8 * 3600)
                    else:
                        db_trip_id = active_trip.decode()

                    if not r.setnx(f"lock:trip:{db_trip_id}", 1):
                        continue
                    r.expire(f"lock:trip:{db_trip_id}", 5)

                    trip = Trips.objects.filter(id=int(db_trip_id)).first()

                    if not trip:
                        r.delete(f"bus:{device_id}:active_trip")
                        r.delete(f"lock:trip:{db_trip_id}")
                        continue

                    key = f"trip:{db_trip_id}:state"
                    state_raw = r.get(key)

                    if not state_raw:
                        state = {
                            "status": trip.status,
                            "progress": trip.progress or 0,
                            "trip_progress": None,
                            "last_update": None
                        }
                    else:
                        state = json.loads(state_raw)

                    if state.get("last_update") and now_ts <= state["last_update"]:
                        continue

                    update_trip_progress_redis(state, trip, lat, lon)

                    state["last_update"] = now_ts

                    if state.get("status") == "completed":
                        r.delete(f"bus:{device_id}:active_trip")

                    r.set(key, json.dumps(state), ex=86400)
                    r.sadd("dirty_trips", db_trip_id)

                except Exception as e:
                    print("Trip worker error:", e)

                finally:
                    r.xack(STREAM, GROUP, msg_id)