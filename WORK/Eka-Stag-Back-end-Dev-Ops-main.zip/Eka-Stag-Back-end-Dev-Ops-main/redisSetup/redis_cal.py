from devices.models import DeviceTotalCalculationData
import numpy as np
import re
import pandas as pd
from datetime import datetime, timedelta
from django.utils import timezone
from django.utils.timezone import make_aware, is_naive
from datetime import datetime
from django.utils.timezone import now
import pytz
from pytz import timezone,utc
from django.utils import timezone as dj_timezone
from redisSetup.data_parsing_functions import get_device_details
from devices.models import DailySummaryReport



def safe_float(v):
    try:
        if v in ("N", None, "", "nan"):
            return float("nan")
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


def r_initialize_metrics(variant, odometer):

    odometer = safe_float(odometer)

    if np.isnan(odometer) or odometer == 0:
        return {}, False

    electric_ecr = {
        '7M': 0.8,'9M': 1,'12M': 1.3,'13.5M': 1.4,'55T': 1.4,'1.5t':0.35,'3w_6s': 0.08, '5T': 0.35,
    }

    diesel_mileage = {
        '7M': 8,'9M': 4,'12M': 4,'13.5M': 3.5,'55T': 2.5,'1.5t': 6,'3w_6s': 25, '5T': 10,
    }

    battery_capacity_kwh = {
        '7M':100,'9M':200,'12M':300,'13.5M':451,'55T':423,'1.5t':32,'3w_6s':15, '5T':35,
    }

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    liters_per_km = 1 / diesel_mileage[variant]

    co2_saved = (
        liters_per_km * EMISSION_FACTOR_DIESEL
        - electric_ecr[variant] * GRID_CO2_INTENSITY
    )

    cost_saved = (
        liters_per_km * diesel_price
        - electric_ecr[variant] * electricity_price
    )

    factor = electric_ecr.get(variant, 1)

    traction_energy = factor * odometer
    regen_energy = traction_energy * 0.3
    energy_consumption = traction_energy - regen_energy
    charging_units = factor * odometer * 1.1

    runtime = odometer / 30
    idle = runtime * 0.15

    battery_capacity = battery_capacity_kwh.get(variant, 100)
    charging_count = round(charging_units / battery_capacity)

    return {
        "total_distance": odometer,
        "co2_saving": co2_saved * odometer,
        "energy_consumption": energy_consumption,
        "run_time": runtime,
        "traction_energy": traction_energy,
        "regen_energy": regen_energy,
        "idle_time": idle,
        "charging_unit": charging_units,
        "charging_count": charging_count,
        "cost_saved": cost_saved * odometer,
        "last_charging_state": False,
        "last_charging_state_time": None,
        "last_soc": None,
        "db_created": False,
        "db_id": None
    }, True

######## 3w #############
def r_total_calculations_3w(device_data, device_id, odometer, variant, total_data):

    if not device_data:
        return total_data, False

    try:
        odometer = float(odometer)
    except (TypeError, ValueError):
        return total_data, False

    if odometer == 0:
        return total_data, False

    diesel_mileage = {'3w_6s': 25}
    electric_ecr = {'3w_6s': 0.08}

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    liters_per_km = 1 / diesel_mileage[variant]

    co2_saved = (
        liters_per_km * EMISSION_FACTOR_DIESEL
        - electric_ecr[variant] * GRID_CO2_INTENSITY
    )

    cost_saved = (
        liters_per_km * diesel_price
        - electric_ecr[variant] * electricity_price
    )

    total_data["total_distance"] = odometer
    total_data["co2_saving"] = co2_saved * odometer
    total_data["cost_saved"] = cost_saved * odometer

    # ---------- Charging Detection ----------
    charger_vol = device_data.get("Charger_Output_VOL")
    charger_cur = device_data.get("Charger_Output_CUR")

    try:
        charger_vol = float(charger_vol)
    except:
        charger_vol = None

    try:
        charger_cur = float(charger_cur)
    except:
        charger_cur = None

    is_charging = not (charger_vol is None and charger_cur is None)

    # ---------- Timestamp ----------
    current_time = pd.to_datetime(
        device_data.get("timestamp"),
        errors="coerce",
        utc=True
    )

    # ---------- SOC ----------
    try:
        current_soc = float(device_data.get("SOC"))
    except:
        current_soc = None

    last_state = total_data.get("last_charging_state", False)
    last_time = total_data.get("last_charging_state_time")
    last_soc = total_data.get("last_soc")

    if isinstance(last_time, str):
        last_time = pd.to_datetime(last_time, utc=True)

    TIME_GAP_THRESHOLD = 600
    SOC_JUMP_THRESHOLD = 5

    time_diff = None
    if last_time is not None and current_time is not None:
        time_diff = (current_time - last_time).total_seconds()

    if last_time is None:

        if is_charging:
            total_data["charging_count"] += 1
            total_data["last_charging_state_time"] = current_time.isoformat()

        total_data["last_charging_state"] = is_charging

    else:

        if last_state != is_charging:

            if not last_state and is_charging:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1

                total_data["last_charging_state_time"] = current_time.isoformat()

            total_data["last_charging_state"] = is_charging

        # SOC jump detection
        if (
            not is_charging
            and current_soc is not None
            and last_soc is not None
        ):
            if current_soc - last_soc > SOC_JUMP_THRESHOLD:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1
                    total_data["last_charging_state"] = True
                    total_data["last_charging_state_time"] = current_time.isoformat()

    total_data["last_soc"] = current_soc

    # ---------- Energy ----------
    try:
        voltage = float(device_data.get("BatteryVoltage"))
        current = float(device_data.get("BatteryCurrent"))
    except:
        return total_data, False

    energy_kwh = ((voltage / 10000) * (current / 1000) * 10) / (1000 * 3600)

    if is_charging:
        total_data["charging_unit"] += energy_kwh
    else:

        total_data["energy_consumption"] += abs(energy_kwh)

        if energy_kwh > 0:
            total_data["regen_energy"] += energy_kwh
        else:
            total_data["traction_energy"] += abs(energy_kwh)

    # ---------- Speed ----------
    try:
        speed = float(device_data.get("MCU_Speed_Kmph"))
    except:
        speed = None

    if speed is not None:

        if speed > 5:
            total_data["run_time"] += 10 / 3600
        else:
            total_data["idle_time"] += 10 / 3600

    return total_data, True
    

############# 4 Wheeler ##################
 
def r_total_calculations(device_data, device_id, variant, odometer, total_data):

    if not device_data:
        return total_data, False

    try:
        odometer = float(odometer)
    except (TypeError, ValueError):
        return total_data, False

    if odometer == 0:
        return total_data, False

    diesel_mileage = {
        '9M':4,'12M':4,'7M':8,'13.5M':3.5,'55T':2.5,'1.5t':6,'5T':10
    }

    electric_ecr = {
        '9M':1,'12M':1.3,'7M':0.8,'13.5M':1.4,'55T':1.4,'1.5t':0.35,'5T':0.35
    }

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    liters_per_km = 1 / diesel_mileage[variant]

    co2_saved = (
        liters_per_km * EMISSION_FACTOR_DIESEL
        - electric_ecr[variant] * GRID_CO2_INTENSITY
    )

    cost_saved = (
        liters_per_km * diesel_price
        - electric_ecr[variant] * electricity_price
    )

    total_data["total_distance"] = odometer
    total_data["co2_saving"] = co2_saved * odometer
    total_data["cost_saved"] = cost_saved * odometer

    # ---------- VCU FLAG ----------
    try:
        vcu_flag = int(device_data.get("VCU_Flag"))
    except:
        return total_data, False

    is_charging = vcu_flag == 92

    # ---------- Runtime / Idle ----------
    if vcu_flag in (50,51,52,60):
        total_data["run_time"] += 10/3600

    if vcu_flag in (13,70):
        total_data["idle_time"] += 10/3600

    # ---------- Charging Logic ----------
    TIME_GAP_THRESHOLD = 600
    SOC_JUMP_THRESHOLD = 5

    current_time = pd.to_datetime(
        device_data.get("timestamp"),
        errors="coerce",
        utc=True
    )

    current_soc = device_data.get("SOC")

    try:
        current_soc = float(current_soc)
    except:
        current_soc = None

    last_state = total_data.get("last_charging_state", False)
    last_time = total_data.get("last_charging_state_time")
    last_soc = total_data.get("last_soc")

    if isinstance(last_time, str):
        last_time = pd.to_datetime(last_time, utc=True)

    time_diff = None
    if last_time is not None and current_time is not None:
        time_diff = (current_time - last_time).total_seconds()

    if last_time is None:

        if is_charging:
            total_data["charging_count"] += 1
            total_data["last_charging_state_time"] = current_time.isoformat()

        total_data["last_charging_state"] = is_charging

    else:

        if last_state != is_charging:

            if not last_state and is_charging:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1

                total_data["last_charging_state_time"] = current_time.isoformat()

            total_data["last_charging_state"] = is_charging

        # ---------- SOC Jump Detection ----------
        if (
            not is_charging
            and current_soc is not None
            and last_soc is not None
        ):
            if current_soc - last_soc > SOC_JUMP_THRESHOLD:

                if time_diff is None or time_diff > TIME_GAP_THRESHOLD:
                    total_data["charging_count"] += 1
                    total_data["last_charging_state"] = True
                    total_data["last_charging_state_time"] = current_time.isoformat()

    total_data["last_soc"] = current_soc

    # ---------- Packs ----------
    active_packs = {
        '12M':['A','B','C'],
        '9M':['A','B'],
        '7M':['A'],
        '55T':['A'],
        '13.5M':['A']
    }.get(variant, ['A'])

    kwh_total = 0
    regen = 0
    traction = 0
    charging_units = 0

    for pack in active_packs:

        v = device_data.get(f"{pack}_Pack_Voltage_Value")
        c = device_data.get(f"{pack}_Pack_Current_Value")

        try:
            v = float(v)
            c = float(c)
        except:
            continue

        energy = (v * c * 10) / (1000 * 3600)

        if is_charging:
            charging_units += energy
        else:
            kwh_total += energy

            if energy > 0:
                regen += energy
            else:
                traction += energy

    total_data["traction_energy"] += abs(traction)
    total_data["regen_energy"] += regen
    total_data["charging_unit"] += charging_units
    total_data["energy_consumption"] += abs(kwh_total)

    return total_data, True
 
##########################################################################################################################################################################################################


##### For summary calculations #####


IST = dj_timezone.get_fixed_timezone(330)


def make_aware_ist(dt):
    if not dt:
        return None

    if isinstance(dt, str):
        dt = datetime.fromisoformat(dt)  # 2025-12-27T10:44:40.153617

    if dj_timezone.is_naive(dt):
        dt = dj_timezone.make_aware(dt, dj_timezone.utc)

    return dj_timezone.localtime(dt, IST)


def get_local_date_from_utc_timestamp(utc_timestamp):
    ist_dt = make_aware_ist(utc_timestamp)
    if not ist_dt:
        return None
    return ist_dt.date()

def safe_float(value, default=0.0):
    try:
        if value in (None, "", "N"):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default

def r_live_daily_report_4w_calculation(device_details, device_id, variant, end_lat, end_long,timestamp,can_data,daily_report):


    report_date = get_local_date_from_utc_timestamp(
        can_data.get("timestamp") or timestamp
    )

    if not report_date:
        return daily_report,False
    


    today_ist = dj_timezone.localtime(dj_timezone.now(), IST).date()

    # For MMI – only today’s data
    if report_date != today_ist:
        print("Date in can_data is not current date")
        return daily_report,False
    

    if daily_report and daily_report.get("date") != report_date.isoformat():
        daily_report = {}


    
    # Handle empty state
    if not daily_report:

        last_odo = (
            DailySummaryReport.objects
            .filter(imei=device_id, end_odometer__gt=0)
            .order_by("-date")
            .values_list("end_odometer", flat=True)
            .first()
            or 0
        )

        last_soc = (
            DailySummaryReport.objects
            .filter(imei=device_id, end_soc__gt=0)
            .order_by("-date")
            .values_list("end_soc", flat=True)
            .first()
            or 0
        )

        daily_report = {
            "date": report_date.isoformat(),
            "imei": device_id,
            "vrn": device_details.get("VRN") if device_details else None,
            "vehicle_type": device_details.get("device_type") if device_details else None,
            "vehicle_type_name": device_details.get("device_type_name") if device_details else None,
            "chassis_number": device_details.get("chassis_number") if device_details else None,
            "fleet": device_details.get("fleet") if device_details else None,
            "city": device_details.get("city") if device_details else None,
            "latitude": end_lat,
            "longitude": end_long,
            "start_time_of_day": None,
            "runtime_minutes":0,
            "idle_minutes":0,
            "charging_minutes":0,
            "stoppage_minutes":0,
            "start_odometer":None,
            "end_odometer":None,
            "distance":0,
            "average_speed":0,
            "no_of_movement_sessions":0,
            "no_of_charging_cycles":0,
            "no_of_idle_sessions":0,
            "start_soc":None,
            "end_soc":None,
            "energy_consumed":0,
            "regen_energy":0,
            "motor_ec":0,
            "dcdc_ec":0,
            "ecompressor_and_steering_ec":0,
            "bcs_ec":0,
            "tcs_ec":0,
            "energy_consumption":0,
            "charging_unit":0,
            "depth_of_discharge":0,
            "insufficient_charge":0,
            "battery_temperature":None,     
            "motor_temperature":None,
            "mode":None,
            "sessions": [],
            "last_odo": last_odo,
            "last_soc": last_soc,
            "co2_saving": 0,
            "cost_saved": 0,
            "db_created": False

        }

    # Handle empty CAN data
    if not can_data:
        daily_report["latitude"] = end_lat
        daily_report["longitude"] = end_long
        daily_report["stop_time_of_day"] = make_aware_ist(datetime.now()).isoformat()
        daily_report["vrn"] = ( daily_report.get("vrn") or device_details.get("VRN"))
        daily_report["chassis_number"] = ( daily_report.get("chassis_number") or device_details.get("chassis_number"))
        daily_report["vehicle_type"] = ( daily_report.get("vehicle_type") or device_details.get("device_type"))
        daily_report["vehicle_type_name"] = ( daily_report.get("vehicle_type_name") or device_details.get("device_type_name"))
        daily_report["fleet"] = (  daily_report.get("fleet")  or device_details.get("fleet"))
        daily_report["city"] = ( daily_report.get("city") or device_details.get("city"))
        daily_report["depth_of_discharge"] = bool(daily_report.get("depth_of_discharge"))
        daily_report["insufficient_charge"] = bool(daily_report.get("insufficient_charge"))

        return daily_report,True # Exit if no CAN data
    

    # Create DataFrame
    # df = pd.DataFrame([device_data.can_data]) 
    # df.replace('N', np.nan, inplace=True)
    # df = df.apply(pd.to_numeric, errors='coerce').fillna(0)

############################################################################################################################
    # df = pd.DataFrame([can_data])

    # # Vectorized: convert 'N' to NaN
    # df = df.where(df != 'N', np.nan)
    # df = df.apply(pd.to_numeric, errors='coerce')

    # # Return early if VCU_Flag is missing
    # if 'VCU_Flag' not in df.columns:
    #     return daily_report,False
    
    # # Return early if ignition is ON and VCU_Flag is null
    # if 'Ignition_Sense' in df.columns:
    #     if df.at[0, 'Ignition_Sense'] == 1 and pd.isna(df.at[0, 'VCU_Flag']):
    #         return daily_report,False

    # # Fill remaining NaNs with 0
    # df.fillna(0, inplace=True)
    
    # if df.empty:
    #     return daily_report,False
################################################################################################################################

    #Signal extraction and conversion
    can_signals = {k: safe_float(v)for k, v in can_data.items()}


    # Return early if VCU_Flag is missing
    if 'VCU_Flag' not in can_data:
        return daily_report,False
    
    # Return early if ignition is ON and VCU_Flag is null
    vcu_flag = can_data.get("VCU_Flag")

    if 'Ignition_Sense' in can_data:
        if can_signals.get('Ignition_Sense') == 1 and vcu_flag in (None, "", "N"):
            return daily_report,False

    # # Fill remaining NaNs with 0
    # df.fillna(0, inplace=True)
    
    # if df.empty:
    #     return daily_report,False

    # Variant-specific signals
    signal_mapping_variant_wise = {
        "7M": ["A"],
        "9M": ["A", "B"],
        "12M": ["A", "B", "C"],
        "13.5M": ["A"],
        "55T": ["A"],
        "1.5t": ["A"],
        "5T": ["A"]
    }
    soc_cols = ["A_SOC_Value", "B_SOC_Value", "C_SOC_Value"]
    packs_config = ["A", "B", "C"]

    applicable_signals = signal_mapping_variant_wise.get(variant, [])
    if not applicable_signals:
        raise ValueError(f"Unsupported variant: {variant}")

    soc_columns = [col for col in soc_cols if col.split("_")[0] in applicable_signals]
    packs = [col for col in packs_config if col in applicable_signals]

    # Get or create daily report
    # daily_report, created = DailySummaryReport.objects.get_or_create(
    #     imei=device_id, date=report_date
    # )
    # if created:
    #     device = Device.objects.get(device_id=device_id)
    #     daily_report.vrn = device.VRN
    #     daily_report.vehicle_type = device.device_type
    #     daily_report.vehicle_type_name = device.device_type_name
    #     daily_report.chassis_number = device.chassis_number
    #     daily_report.fleet = device.fleet
    #     daily_report.city = device.city



    last_stop_time = daily_report.get("stop_time_of_day")
    if last_stop_time:
        last_stop_time = datetime.fromisoformat(last_stop_time)

    current_timestamp = timestamp

    if daily_report.get("start_time_of_day") is None:
        daily_report["start_time_of_day"] = current_timestamp.isoformat()


    # Handle first entry case
    if last_stop_time is None:
        time_diff_seconds = 0
    else:
        last_stop_time = last_stop_time
        time_diff_seconds = max((current_timestamp - last_stop_time).total_seconds(), 0)
        if time_diff_seconds < 1:
            return daily_report,False

    # Mode detection
    # charging_mask = df["VCU_Flag"].isin([89, 90, 91, 92])
    # not_charging_mask = ~charging_mask


    charging_mask = ( can_signals.get("Gun_Detection_1", 0) == 1 or can_signals.get("Gun_Detection_2", 0) == 1)

    not_charging_mask = not charging_mask

    current_mode = "Unknown"

    ignition_on = can_signals.get("Ignition_Sense", 0) == 1
    vcu_flag = can_signals.get("VCU_Flag", 0)

    if not ignition_on:
        current_mode = "Stopped"

    elif vcu_flag in (89, 90, 91, 92):
        current_mode = "Charging"

    elif not_charging_mask and vcu_flag in (50, 51, 52, 60):
        current_mode = "Movement"

    elif not_charging_mask and vcu_flag != 0 and (vcu_flag < 50 or vcu_flag == 70):
        current_mode = "Idle"
    # df.loc[~df["Mode"].isin(["Charging", "Movement", "Idle"]), "Mode"] = "Stopped"

    # # Charging/Movement/Idle only if Ignition is on
    # df.loc[ignition_on_mask & charging_mask & df["WheelBasedVehicleSpeed_Rx"] == 0, "Mode"] = "Charging"
    # df.loc[ignition_on_mask & not_charging_mask & df["WheelBasedVehicleSpeed_Rx"] > 0 , "Mode"] = "Movement"


#########################################################################################################################################################################################
    # default_odo = daily_report.get("last_odo")

    # # SOC and odometer
    # df["SOC"] = df[soc_columns].mean(axis=1)
    
    # # odoometer checks for the jumps
    # last_odometer = daily_report.get("end_odometer") or daily_report.get("start_odometer") or default_odo
    # # jumps > 200 km within 6 hours (~21600 seconds) are ignored
    # JUMP_THRESHOLD = 200
    # TIME_THRESHOLD_SECONDS = 6 * 3600

    # #first_entry = last_stop_time is None or time_diff_seconds == 0
    # first_entry = daily_report.get("end_odometer") is None 

    # # Try ODOMETER_CRUT first
    # odom_crut = float(df.at[0, "ODOMETER_CRUT"]) if "ODOMETER_CRUT" in df.columns else None
    # odom = float(df.at[0, "ODOMETER"]) if "ODOMETER" in df.columns else None

    # def valid_odom_check(odom_value):
    #     if odom_value is None or odom_value <= 0:
    #         return False
    #     if first_entry:
    #         return True
    #     return not (time_diff_seconds < TIME_THRESHOLD_SECONDS and abs(odom_value - last_odometer) > JUMP_THRESHOLD)

    # if odom_crut is not None and valid_odom_check(odom_crut):
    #     current_odometer = odom_crut
    # elif odom is not None and valid_odom_check(odom) and odom > last_odometer:
    #     current_odometer = odom
    # else:
    #     current_odometer = last_odometer




    # # Current SOC and mode
    # current_soc = df.at[0, "SOC"]
    # current_mode = df.at[0, "Mode"]
    # prev_mode = daily_report.get("mode") or "Unknown"

    
    # # Initialize start values if not set
    # if daily_report.get("start_odometer") is None or daily_report.get("start_odometer") == 0:
    #     daily_report["start_odometer"] = round(current_odometer if current_odometer > 0 else default_odo, 2)


    # prev_soc = DailySummaryReport.objects.filter(imei=device_id,end_soc__gt=0).exclude(date=report_date).order_by('-date').values_list('end_soc', flat=True).first() or 0
    # if daily_report.get("start_soc") is None or daily_report.get("start_soc") == 0:
    #     if current_soc is not None and current_soc > 0:
    #         daily_report["start_soc" ]= current_soc
    #     else:
    #         daily_report["start_soc" ]= prev_soc

        

    # # Previous end odometer (fallback)
    # prev_end_odometer = round(daily_report.get("end_odometer") or current_odometer,2)

    # # Calculate incremental distance
    # distance_km = max(current_odometer - prev_end_odometer, 0)

    # # Update end_odometer only if current_odometer is valid (>0)
    # if current_odometer > 0:
    #     daily_report["end_odometer"] = round(current_odometer, 2)
    # elif daily_report.get("end_odometer") is None:
    #     daily_report["end_odometer"]= round(default_odo, 2)

    # # Always update SOC
    # if current_soc is not None and current_soc > 0:
    #     daily_report["end_soc"] = current_soc
    # else:
    #     daily_report["end_soc"] = daily_report.get("end_soc") or prev_soc

########################################################################################################################################################

    default_odo = daily_report.get("last_odo", 0)
    default_soc = daily_report.get("last_soc", 0)

    # SOC and odometer

    soc_values = [can_signals.get(col, 0) for col in soc_columns]

    # Previous SOC fallback chain
    prev_soc = daily_report.get("end_soc")

    if prev_soc is None:
        prev_soc = daily_report.get("start_soc")

    if prev_soc is None:
        prev_soc = default_soc

    if prev_soc is None:
        prev_soc = 0

    current_soc = (
        round(sum(soc_values) / len(soc_values), 2)
        if soc_values else 0
    )

    # Vehicle OFF / N converted to 0
    if current_soc <= 0:
        current_soc = prev_soc


    # Current known odometer fallback chain
    last_odometer = ( daily_report.get("end_odometer") or daily_report.get("start_odometer") or default_odo or 0)

    # Jumps > 200 km within 6 hours are ignored
    JUMP_THRESHOLD = 200
    TIME_THRESHOLD_SECONDS = 6 * 3600

    first_entry = daily_report.get("end_odometer") is None

    # Odometer values from packet
    odom_crut = can_signals.get("ODOMETER_CRUT")
    odom = can_signals.get("ODOMETER")


    def valid_odom_check(odom_value):
        if not odom_value or odom_value <= 0:
            return False

        if first_entry:
            return True

        return not (
            time_diff_seconds < TIME_THRESHOLD_SECONDS
            and abs(odom_value - last_odometer) > JUMP_THRESHOLD
    )

    # Prefer ODOMETER_CRUT
    if valid_odom_check(odom_crut) and odom_crut >= last_odometer:
        current_odometer = odom_crut

    elif valid_odom_check(odom) and odom >= last_odometer:
        current_odometer = odom

    else:
        current_odometer = last_odometer


    # Mode
    prev_mode = daily_report.get("mode") or "Unknown"

    # Initialize start odometer once
    if daily_report.get("start_odometer") is None:
        daily_report["start_odometer"] = round( current_odometer if current_odometer > 0 else last_odometer, 2,)


    # SOC fallback chain
    # prev_soc = ( daily_report.get("end_soc") or daily_report.get("start_soc") or default_soc or 0)
    # prev_soc = daily_report.get("end_soc")

    # if prev_soc is None:
    #     prev_soc = daily_report.get("start_soc")

    # if prev_soc is None:
    #     prev_soc = default_soc

    # if prev_soc is None:
    #     prev_soc = 0

    # Initialize start SOC once
    if daily_report.get("start_soc") is None:
        daily_report["start_soc"] = (  current_soc  if current_soc > 0  else prev_soc)


    # Previous end odometer
    prev_end_odometer = round( daily_report.get("end_odometer") or current_odometer, 2,)

    # Incremental distance
    distance_km = max( current_odometer - prev_end_odometer, 0,)

    # Update end odometer
    if current_odometer > 0:
        daily_report["end_odometer"] = round( current_odometer, 2,)
    elif not daily_report.get("end_odometer"):
        daily_report["end_odometer"] = round( last_odometer, 2,)


    # Update end SOC
    if current_soc is not None and current_soc > 0:
        daily_report["end_soc"] = current_soc
    else:
        daily_report["end_soc"] = prev_soc

    # Current coordinates
    current_lat = end_lat
    current_long = end_long

    # Energy per pack
    pack_kwh = {}

    for p in packs:
        pack_kwh[p] = (can_signals.get(f"{p}_Pack_Voltage_Value", 0) * can_signals.get(f"{p}_Pack_Current_Value", 0) * time_diff_seconds / (3600 * 1000))

    # Energy consumed / regen
    ec = sum( energy for energy in pack_kwh.values() if not_charging_mask and energy < 0)

    total_ec = (daily_report.get("energy_consumed") or 0) + (-ec)

    regen = sum( energy for energy in pack_kwh.values() if not_charging_mask and energy > 0)

    total_regen = (daily_report.get("regen_energy") or 0) + regen

    ecr_distance = (daily_report.get("distance") or 0) + distance_km

    ecr = ( (total_ec - total_regen) / ecr_distance if ecr_distance else 0)

    # Battery temperatures
    battery_temps = [ can_signals.get(f"{p}_Max_Cell_Temp", 0) for p in packs]

    current_battery_temp = max(battery_temps) if battery_temps else 0

    max_battery_temp = max( daily_report.get("battery_temperature") or 0, round(current_battery_temp, 2),)

    # For sessions battery temp
    session_battery_temp = round(current_battery_temp, 2)

    current_motor_temp = can_signals.get("Motor_Temperature", 0)

    max_motor_temperature = max( daily_report.get("motor_temperature") or 0, round(current_motor_temp, 2),)

    session_motor_temp = round(current_motor_temp, 2)

    # Charging units
    charging_units = ( sum(pack_kwh.values()) if charging_mask else 0)

    # MCU, DCDC, TCS, BCS, ECompressor
    mcu_energy = (can_signals.get("MCU_HighPowerVoltage", 0) * can_signals.get("MCU_HighPowerCurrent", 0) * time_diff_seconds / (3600 * 1000))

    kwh_dcdc = (can_signals.get("DCDC_Input_Voltage", 0) * can_signals.get("DCDC_Input_Current", 0) * time_diff_seconds / (3600 * 1000))

    kwh_bcs = (can_signals.get("T2B_HV_Voltage_Input", 0) * can_signals.get("T2B_HV_Current_Input", 0) * time_diff_seconds / (3600 * 1000))

    kwh_tcs = (can_signals.get("Pump_Voltage", 0) * can_signals.get("Pump_Current", 0) * time_diff_seconds / (3600 * 1000))

    kwh_ecompressor = (
        ( can_signals.get("ECompressor_Input_Power", 0) + can_signals.get("Streering_Input_Power", 0)) * time_diff_seconds / (3600 * 1000))

    # Minutes
    runtime_minutes = 0
    idle_minutes = 0
    charging_minutes = 0
    stoppage_minutes = 0

    # current_minutes = ( current_timestamp.hour * 60 + current_timestamp.minute + current_timestamp.second / 60)

    if current_mode.lower() == "movement":
        runtime_minutes += time_diff_seconds / 60

    elif current_mode.lower() == "idle":
        idle_minutes += time_diff_seconds / 60

    elif current_mode.lower() == "charging":
        charging_minutes += time_diff_seconds / 60

    else:
        stoppage_minutes += time_diff_seconds / 60

    prev_runtime = daily_report.get("runtime_minutes") or 0

    total_runtime_minutes = prev_runtime + runtime_minutes

    if daily_report.get("start_odometer") is None:
        total_distance = 0
    elif ( daily_report.get("start_odometer") and daily_report.get("start_odometer") <= current_odometer):
        total_distance = ( current_odometer - daily_report.get("start_odometer"))
    else:
        total_distance = ( daily_report.get("distance") if daily_report.get("distance") else 0)

    average_speed = ( total_distance / (total_runtime_minutes / 60) if total_runtime_minutes > 0 else 0)

    # Max speed session wise
    session_current_speed = can_signals.get( "WheelBasedVehicleSpeed_Rx", 0,)

    diesel_mileage = {
        '9M': 4,
        '12M': 4,
        '7M': 8,
        '13.5M': 3.5,
        '55T': 2.5,
        '1.5t': 6,
        '5T': 10
    }
 
    electric_ecr = {
        '9M': 1,
        '12M': 1.3,
        '7M': 0.8,
        '13.5M': 1.4,
        '55T': 1.4,
        '1.5t':0.35,
        '5T': 0.35
    }
 
    EMISSION_FACTOR_DIESEL = 2.68   # kg CO2/litre
    GRID_CO2_INTENSITY = 0.2      # kg CO2/kWh
    diesel_price = 90               # ₹ per litre
    electricity_price = 8           # ₹ per kWh
 
    # Fuel/CO2 savings (only for this variant)
    liters_per_km = 1 / diesel_mileage[variant]
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price
 
    ecr_variant = electric_ecr[variant]
    co2_electric = ecr_variant * GRID_CO2_INTENSITY
    cost_electric = ecr_variant * electricity_price
 
    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric

    if total_distance:
        daily_report["co2_saving"] = co2_saved * total_distance
        daily_report["cost_saved" ]= cost_saved * total_distance

    # Insufficient charge & DOD
    charging_ended = prev_mode.lower() == "charging" and current_mode.lower() != "charging"
    dod = (daily_report.get('depth_of_discharge',0) or (current_soc is not None and current_soc < 20))

    if charging_ended:
        last_charging_soc = ( current_soc if current_soc is not None else daily_report.get("end_soc"))
        insufficient_charge = ( last_charging_soc is not None and last_charging_soc <= 90)
    else:
        insufficient_charge = bool(daily_report.get('insufficient_charge',0))


    # charging_ended = prev_mode.lower() == "charging" and current_mode.lower() != "charging"
    # if charging_ended:
    #     last_soc = current_soc if pd.notnull(current_soc) else daily_report.get("end_soc")

    #     insufficient_charge = 1 if (last_soc is not None and last_soc <= 90) else 0

    #     dod = 1 if (last_soc is not None and last_soc < 20) else 0
    # else:
    #     insufficient_charge = daily_report.get("insufficient_charge", 0)
    #     dod = daily_report.get("depth_of_discharge", 0)

    # Sessions
    # if not daily_report.get("sessions"):
    #     daily_report["sessions"] = []

    # def make_session_serializable(session):
    #     # Convert datetime objects to ISO strings
    #     # for key in ["start_time_val", "end_time_val"]:
    #     #     if isinstance(session.get(key), datetime):
    #     #         session[key] = make_aware_ist(session[key]).isoformat()
    #     # Convert numpy numbers to native Python types
    #     for key, value in session.items():
    #         if isinstance(value, (np.integer, np.int64, np.int32)):
    #             session[key] = int(value)
    #         elif isinstance(value, (np.floating, np.float64, np.float32)):
    #             session[key] = float(value)
    #     return session

    # def update_last_session(session, current_timestamp, current_odometer, current_soc, ec, regen, ecr,
    #                         charging_units,session_current_speed,session_battery_temp,current_lat,current_long):
    #     # Convert datetime and numpy values immediately
    #     session["end_time_val"] = make_aware_ist(current_timestamp).isoformat()
    #     if not session.get("start_odo_val") or session["start_odo_val"] == 0:
    #         session["start_odo_val"] = round(float(current_odometer), 2)
    #     session["end_odo_val"] = round(float(current_odometer), 2)
    #     if not session.get("start_soc_val") or session["start_soc_val"] == 0:
    #         session["start_soc_val"] = float(current_soc)
    #     session["end_soc_val"] = float(current_soc)
    #     session["duration"] = (datetime.fromisoformat(session["end_time_val"]) - datetime.fromisoformat(session["start_time_val"])).total_seconds() / 60
    #     session["end_latitude"] = current_lat
    #     session["end_longitude"] = current_long
    #     session["battery_temperature"] = max(session["battery_temperature"],session_battery_temp)
    #     if "session_ec" in session:
    #         session["session_ec"] += float(ec)
    #     if "distance" in session:
    #         session["distance"] = max(session["end_odo_val"] - session["start_odo_val"], 0)
    #         session["session_regen"] += float(regen)
    #         session["session_ecr"] = (-(session["session_ec"]) + session["session_regen"]) / session["distance"] if session["distance"] else 0
    #         session["session_traction"] += 0 if mcu_energy < 0 else mcu_energy
    #         session["max_speed"] = max(session["max_speed"],session_current_speed)
    #         if "motor_temperature" in session:
    #             session["motor_temperature"] = max(session["motor_temperature"],session_motor_temp)
    #     if "deep_discharge" in session and session["deep_discharge"] != 1:
    #         session["deep_discharge"] = 1 if current_soc < 20 else 0
    #     if "charging_units" in session:
    #         session["charging_units"] += charging_units


    # start_odo_val = current_odometer if current_odometer and current_odometer > 0 else daily_report.get("start_odometer") or 0
    # # Creating a new session
    # if prev_mode is None or prev_mode.lower() != current_mode.lower():
    #     #assignment    
    #     allow_new_session = False
    #     if daily_report.get("sessions"):
    #         sessions = daily_report.setdefault("sessions", [])
    #         if sessions:
    #             last_session = sessions[-1]
    #         # updating the insufficient charge only after charging session is ended.
    #         if "insufficient_charge" in last_session:
    #             last_session["insufficient_charge"] = 1 if current_soc < 90 else 0

    #         last_end_time = datetime.fromisoformat(last_session["end_time_val"])                                                                                                                                                                                                                                                                                                                 
    #         duration = (current_timestamp - last_end_time).total_seconds() / 60

    #         if last_session.get("duration", 0) == 0 and last_session.get("distance", 0) == 0:
    #             sessions.pop()

    #             last_session_name = last_session.get("label", "").lower()
                
    #             if last_session_name == "movement":
    #                 daily_report["no_of_movement_sessions"] = max((daily_report.get("no_of_movement_sessions", 1) - 1, 0))
    #             elif last_session_name == "charging":
    #                 daily_report["no_of_charging_cycles"] = max((daily_report.get("no_of_charging_cycles", 1) - 1, 0))
    #             elif last_session_name == "idle":
    #                 daily_report["no_of_idle_sessions"] = max((daily_report.get("no_of_idle_sessions", 1) - 1, 0))


    #         if duration > 0.1667:  # threshold ~10 sec
    #             allow_new_session = True
    #     else:
    #         allow_new_session = True

    #     if allow_new_session:
    #         new_session = {
    #             "label": current_mode,
    #             "start_latitude": current_lat,
    #             "start_longitude": current_long,
    #             "end_latitude":current_lat,
    #             "end_longitude":current_long,
    #             "start_time_val": make_aware_ist(current_timestamp).isoformat(),
    #             "end_time_val": make_aware_ist(current_timestamp).isoformat(),
    #             "duration": 0,
    #             "start_odo_val": round(start_odo_val, 2),
    #             "end_odo_val": round(start_odo_val, 2),
    #             "start_soc_val": float(current_soc),
    #             "end_soc_val": float(current_soc),
    #             "battery_temperature": session_battery_temp,
    #         }
    #         new_session = make_session_serializable(new_session)
    #         daily_report.setdefault("sessions", []).append(new_session)

    #     if current_mode.lower() == "movement":
    #         daily_report["no_of_movement_sessions"] = (daily_report.get("no_of_movement_sessions") or 0) + 1
    #         # adding session parameters based on the mode
    #         new_session["distance"] = 0
    #         new_session["session_ec"] = 0.0
    #         new_session["session_regen"] = 0.0
    #         new_session["session_ecr"] = 0.0
    #         new_session["session_traction"] = 0.0
    #         new_session["max_speed"] = session_current_speed
    #         new_session["motor_temperature"] = session_motor_temp
    #         new_session["deep_discharge"] = 1 if current_soc < 20 else 0

    #     elif current_mode.lower() == "charging":
    #         daily_report["no_of_charging_cycles"] = (daily_report.get("no_of_charging_cycles") or 0) + 1
    #         # adding session parameters based on the mode
    #         new_session["charging_units"] = charging_units
    #         new_session["insufficient_charge"] = 0 

    #     elif current_mode.lower() == "idle":
    #         daily_report["no_of_idle_sessions"] = (daily_report.get("no_of_idle_sessions") or 0) + 1
    #         # adding session parameters based on the mode
    #         new_session["session_ec"] = 0.0
    #         new_session["deep_discharge"] = 1 if current_soc < 20 else 0

            
    # elif daily_report.get("sessions"):
    #     update_last_session(daily_report["sessions"][-1], current_timestamp, current_odometer, current_soc, ec, regen, ecr,
    #                         charging_units,session_current_speed,session_battery_temp,current_lat,current_long)

    # if daily_report.get("sessions"):
    #     daily_report["sessions"] = [make_session_serializable(s) for s in daily_report["sessions"]]


#############################################################################################################################################
    # if not daily_report.get("sessions"):
    #     daily_report["sessions"] = []


    # def make_session_serializable(session):
    #     for key, value in session.items():

    #         if isinstance(value, (np.integer, np.int64, np.int32)):
    #             session[key] = int(value)

    #         elif isinstance(value, (np.floating, np.float64, np.float32)):
    #             session[key] = float(value)

    #         elif isinstance(value, datetime):
    #             session[key] = make_aware_ist(value).isoformat()

    #     return session


    # def update_last_session(session,current_timestamp,current_odometer,current_soc,ec,regen,ecr,charging_units,session_current_speed,session_battery_temp,current_lat,current_long):

    #     label = session.get("label", "").lower()

    #     current_time_iso = make_aware_ist(current_timestamp).isoformat()

    #     # Base updates
    #     session["end_time_val"] = current_time_iso

    #     if not session.get("start_odo_val") or session["start_odo_val"] == 0:
    #         session["start_odo_val"] = round(float(current_odometer), 2)

    #     session["end_odo_val"] = round(float(current_odometer), 2)

    #     if not session.get("start_soc_val") or session["start_soc_val"] == 0:
    #         session["start_soc_val"] = float(current_soc)

    #     session["end_soc_val"] = float(current_soc)
    #     session["duration"] = (datetime.fromisoformat(session["end_time_val"]) - datetime.fromisoformat(session["start_time_val"])).total_seconds() / 60
    #     session["end_latitude"] = current_lat
    #     session["end_longitude"] = current_long

    #     session["battery_temperature"] = max(session.get("battery_temperature", 0),session_battery_temp)

    #     # Session EC
    #     if "session_ec" in session:
    #         session["session_ec"] += float(ec)

    #     # Movement session updates
    #     if label == "movement":

    #         session.setdefault("distance", 0.0)
    #         session.setdefault("session_regen", 0.0)
    #         session.setdefault("session_ecr", 0.0)
    #         session.setdefault("session_traction", 0.0)
    #         session.setdefault("max_speed", 0.0)

    #         session["distance"] = max(session["end_odo_val"] - session["start_odo_val"],0)
    #         session["session_regen"] += float(regen)
    #         session["session_ecr"] = ((-(session["session_ec"]) + session["session_regen"])/ session["distance"]if session["distance"] else 0)
    #         session["session_traction"] += (0 if mcu_energy < 0 else mcu_energy)
    #         session["max_speed"] = max(session["max_speed"],session_current_speed)

    #         if "motor_temperature" in session:
    #             session["motor_temperature"] = max(session["motor_temperature"],session_motor_temp)

    #         session.setdefault("zero_speed_start_time", None)
    #         session.setdefault("last_idle_update_time", None)
    #         session.setdefault("idle_duration", 0.0)
    #         session.setdefault("idle_energy", 0.0)

    #         if session_current_speed == 0:

    #             # Store first zero speed timestamp only once
    #             if session["zero_speed_start_time"] is None:

    #                 session["zero_speed_start_time"] = current_time_iso
    #                 session["last_idle_update_time"] = current_time_iso

    #             else:

    #                 zero_start = datetime.fromisoformat(session["zero_speed_start_time"])
    #                 stationary_minutes = (current_timestamp - zero_start).total_seconds() / 60
    #                 # Start idle accumulation only after 2 mins continuous zero speed
    #                 if stationary_minutes >= 2:

    #                     last_idle_update = datetime.fromisoformat(session["last_idle_update_time"])

    #                     incremental_idle = (current_timestamp - last_idle_update).total_seconds() / 60

    #                     incremental_idle = max(incremental_idle, 0)

    #                     session["idle_duration"] += incremental_idle

    #                     session["idle_energy"] += max(float(-(ec)), 0)

    #                     # update incremental checkpoint
    #                     session["last_idle_update_time"] = current_time_iso

    #         else:
    #             # Vehicle moved again - reset 
    #             session["zero_speed_start_time"] = None
    #             session["last_idle_update_time"] = None

    #     # Deep discharge
    #     if "deep_discharge" in session and session["deep_discharge"] != 1:
    #         session["deep_discharge"] = 1 if current_soc < 20 else 0

    #     # Charging updates
    #     if "charging_units" in session:
    #         session["charging_units"] += charging_units


    # start_odo_val = (
    #     current_odometer
    #     if current_odometer and current_odometer > 0
    #     else daily_report.get("start_odometer") or 0
    # )

    # current_label = current_mode.lower()

    # last_session = (daily_report["sessions"][-1] if daily_report.get("sessions") else None)
    # last_label = (last_session.get("label", "").lower() if last_session else None)
    # same_session = last_label == current_label


    # if same_session and last_session:
    #     update_last_session(last_session,current_timestamp,current_odometer,current_soc,ec,regen,ecr,charging_units,session_current_speed,session_battery_temp,current_lat,current_long)

    # else:
    #     allow_new_session = False

    #     if daily_report.get("sessions"):

    #         last_session = daily_report["sessions"][-1]

    #         # Update charging completion flag
    #         if "insufficient_charge" in last_session:
    #             last_session["insufficient_charge"] = (1 if current_soc < 90 else 0)

    #         last_end_time = datetime.fromisoformat(last_session.get("end_time_val"))

    #         duration = (current_timestamp - last_end_time).total_seconds() / 60

    #         # Remove noisy sessions
    #         if (last_session.get("duration", 0) < 0.1667 and last_session.get("distance", 0) == 0):

    #             removed_session = daily_report["sessions"].pop()
    #             removed_label = removed_session.get("label","").lower()

    #             if removed_label == "movement":
    #                 daily_report["no_of_movement_sessions"] = max((daily_report.get("no_of_movement_sessions") or 1) - 1,0)

    #             elif removed_label == "charging":
    #                 daily_report["no_of_charging_cycles"] = max((daily_report.get("no_of_charging_cycles") or 1) - 1,0)

    #             elif removed_label == "idle":
    #                 daily_report["no_of_idle_sessions"] = max((daily_report.get("no_of_idle_sessions") or 1) - 1,0)

    #             # Recalculate after pop
    #             last_session = (daily_report["sessions"][-1] if daily_report.get("sessions") else None)

    #             last_label = (last_session.get("label", "").lower() if last_session else None)

    #             same_session = last_label == current_label

    #             # Continue same session after pop
    #             if same_session and last_session:
    #                 update_last_session(last_session,current_timestamp,current_odometer,current_soc,ec,regen,ecr,charging_units,session_current_speed,session_battery_temp,current_lat,current_long)

    #                 allow_new_session = False

    #             else:
    #                 allow_new_session = True

    #         elif duration > 0.1667:
    #             allow_new_session = True

    #     else:
    #         allow_new_session = True


    #     # Create session
    #     if allow_new_session:

    #         new_session = {
    #             "label": current_mode,
    #             "start_latitude": current_lat,
    #             "start_longitude": current_long,
    #             "end_latitude": current_lat,
    #             "end_longitude": current_long,
    #             "start_time_val": make_aware_ist(current_timestamp).isoformat(),
    #             "end_time_val": make_aware_ist(current_timestamp).isoformat(),
    #             "duration": 0,
    #             "start_odo_val": round(start_odo_val, 2),
    #             "end_odo_val": round(start_odo_val, 2),
    #             "start_soc_val": float(current_soc),
    #             "end_soc_val": float(current_soc),
    #             "battery_temperature": session_battery_temp,
    #         }


    #         # Movement session
    #         if current_label == "movement":
    #             daily_report["no_of_movement_sessions"] = ((daily_report.get("no_of_movement_sessions") or 0) + 1)
    #             new_session.update({
    #                 "distance": 0.0,
    #                 "session_ec": 0.0,
    #                 "session_regen": 0.0,
    #                 "session_ecr": 0.0,
    #                 "session_traction": 0.0,
    #                 "max_speed": session_current_speed,
    #                 "motor_temperature": session_motor_temp,
    #                 "deep_discharge": 1 if current_soc < 20 else 0,
    #                 "zero_speed_start_time": None,
    #                 "last_idle_update_time": None,
    #                 "idle_duration": 0.0,
    #                 "idle_energy": 0.0,
    #             })


    #         # Charging session
    #         elif current_label == "charging":
    #             daily_report["no_of_charging_cycles"] = ((daily_report.get("no_of_charging_cycles") or 0) + 1)
    #             new_session.update({
    #                 "charging_units": charging_units,
    #                 "insufficient_charge": 0
    #             })

    #         # Idle session
    #         elif current_label == "idle":
    #             daily_report["no_of_idle_sessions"] = ((daily_report.get("no_of_idle_sessions") or 0) + 1)
    #             new_session.update({
    #                 "session_ec": 0.0,
    #                 "deep_discharge": 1 if current_soc < 20 else 0
    #             })

    #         new_session = make_session_serializable(new_session)

    #         daily_report["sessions"].append(new_session)

    # # Final serialization
    # if daily_report.get("sessions"):
    #     daily_report["sessions"] = [make_session_serializable(s) for s in daily_report["sessions"]]
    # device = get_device_details(device_id)
######################################################################################################################################################################

    sessions = daily_report.setdefault("sessions", [])


    def make_session_serializable(session):
        for key, value in session.items():

            if isinstance(value, (np.integer, np.int64, np.int32)):
                session[key] = int(value)

            elif isinstance(value, (np.floating, np.float64, np.float32)):
                session[key] = float(value)

            elif isinstance(value, datetime):
                session[key] = make_aware_ist(value).isoformat()

        return session


    def update_last_session(
        session,
        current_timestamp,
        current_odometer,
        current_soc,
        ec,
        regen,
        ecr,
        charging_units,
        session_current_speed,
        session_battery_temp,
        current_lat,
        current_long,
    ):

        label = session.get("label", "").lower()

        current_time_iso = make_aware_ist(current_timestamp).isoformat()

        session["end_time_val"] = current_time_iso

        if not session.get("start_odo_val") and session.get("start_odo_val") != 0:
            session["start_odo_val"] = round(float(current_odometer), 2)

        session["end_odo_val"] = round(float(current_odometer), 2)

        if not session.get("start_soc_val") and session.get("start_soc_val") != 0:
            session["start_soc_val"] = float(current_soc)

        session["end_soc_val"] = float(current_soc)

        session["duration"] = (
            datetime.fromisoformat(session["end_time_val"])
            - datetime.fromisoformat(session["start_time_val"])
        ).total_seconds() / 60

        session["end_latitude"] = current_lat
        session["end_longitude"] = current_long

        session["battery_temperature"] = max(
            session.get("battery_temperature", 0),
            session_battery_temp,
        )

        if "session_ec" in session:
            session["session_ec"] += float(ec)

        # Movement session updates
        if label == "movement":

            session.setdefault("distance", 0.0)
            session.setdefault("session_regen", 0.0)
            session.setdefault("session_ecr", 0.0)
            session.setdefault("session_traction", 0.0)
            session.setdefault("max_speed", 0.0)

            session["distance"] = max(
                session["end_odo_val"] - session["start_odo_val"],
                0,
            )

            session["session_regen"] += float(regen)

            session["session_ecr"] = (
                (
                    -(session["session_ec"])
                    + session["session_regen"]
                )
                / session["distance"]
                if session["distance"]
                else 0
            )

            session["session_traction"] += (
                0 if mcu_energy < 0 else mcu_energy
            )

            session["max_speed"] = max(
                session["max_speed"],
                session_current_speed,
            )

            if "motor_temperature" in session:
                session["motor_temperature"] = max(
                    session["motor_temperature"],
                    session_motor_temp,
                )

            session.setdefault("zero_speed_start_time", None)
            session.setdefault("last_idle_update_time", None)
            session.setdefault("idle_duration", 0.0)
            session.setdefault("idle_energy", 0.0)

            if session_current_speed == 0:

                if session["zero_speed_start_time"] is None:

                    session["zero_speed_start_time"] = current_time_iso
                    session["last_idle_update_time"] = current_time_iso

                else:

                    zero_start = datetime.fromisoformat(
                        session["zero_speed_start_time"]
                    )

                    stationary_minutes = (
                        current_timestamp - zero_start
                    ).total_seconds() / 60

                    if stationary_minutes >= 2:

                        last_idle_update = datetime.fromisoformat(
                            session["last_idle_update_time"]
                        )

                        incremental_idle = (
                            current_timestamp - last_idle_update
                        ).total_seconds() / 60

                        incremental_idle = max(incremental_idle, 0)

                        session["idle_duration"] += incremental_idle

                        session["idle_energy"] += max(
                            float(-(ec)),
                            0,
                        )

                        session["last_idle_update_time"] = current_time_iso

            else:

                session["zero_speed_start_time"] = None
                session["last_idle_update_time"] = None

        if "deep_discharge" in session and session["deep_discharge"] != 1:
            session["deep_discharge"] = 1 if current_soc < 20 else 0

        if "charging_units" in session:
            session["charging_units"] += charging_units


    start_odo_val = (
        current_odometer
        if current_odometer and current_odometer > 0
        else (daily_report.get("start_odometer") or 0)
    )

    current_label = current_mode.lower()

    last_session = sessions[-1] if sessions else None
    last_label = (
        last_session.get("label", "").lower()
        if last_session
        else None
    )

    same_session = last_label == current_label

    if same_session and last_session:

        update_last_session(
            last_session,
            current_timestamp,
            current_odometer,
            current_soc,
            ec,
            regen,
            ecr,
            charging_units,
            session_current_speed,
            session_battery_temp,
            current_lat,
            current_long,
        )

    else:

        allow_new_session = False

        if sessions:

            last_session = sessions[-1]

            if "insufficient_charge" in last_session:
                last_session["insufficient_charge"] = (
                    1 if current_soc < 90 else 0
                )

            last_end_time = datetime.fromisoformat(
                last_session["end_time_val"]
            )

            duration = (
                current_timestamp - last_end_time
            ).total_seconds() / 60

            if (
                last_session.get("duration", 0) < 0.1667
                and last_session.get("distance", 0) == 0
            ):

                removed_session = sessions.pop()

                removed_label = (
                    removed_session.get("label", "")
                    .lower()
                )

                if removed_label == "movement":

                    daily_report["no_of_movement_sessions"] = max(
                        (daily_report.get("no_of_movement_sessions") or 1) - 1,
                        0,
                    )

                elif removed_label == "charging":

                    daily_report["no_of_charging_cycles"] = max(
                        (daily_report.get("no_of_charging_cycles") or 1) - 1,
                        0,
                    )

                elif removed_label == "idle":

                    daily_report["no_of_idle_sessions"] = max(
                        (daily_report.get("no_of_idle_sessions") or 1) - 1,
                        0,
                    )

                last_session = sessions[-1] if sessions else None

                last_label = (
                    last_session.get("label", "").lower()
                    if last_session
                    else None
                )

                same_session = last_label == current_label

                if same_session and last_session:

                    update_last_session(
                        last_session,
                        current_timestamp,
                        current_odometer,
                        current_soc,
                        ec,
                        regen,
                        ecr,
                        charging_units,
                        session_current_speed,
                        session_battery_temp,
                        current_lat,
                        current_long,
                    )

                    allow_new_session = False

                else:
                    allow_new_session = True

            elif duration > 0.1667:
                allow_new_session = True

        else:
            allow_new_session = True

        if allow_new_session:

            current_time_iso = make_aware_ist(
                current_timestamp
            ).isoformat()

            new_session = {
                "label": current_mode,
                "start_latitude": current_lat,
                "start_longitude": current_long,
                "end_latitude": current_lat,
                "end_longitude": current_long,
                "start_time_val": current_time_iso,
                "end_time_val": current_time_iso,
                "duration": 0,
                "start_odo_val": round(start_odo_val, 2),
                "end_odo_val": round(start_odo_val, 2),
                "start_soc_val": float(current_soc),
                "end_soc_val": float(current_soc),
                "battery_temperature": session_battery_temp,
            }

            if current_label == "movement":

                daily_report["no_of_movement_sessions"] = (
                    (daily_report.get("no_of_movement_sessions") or 0)
                    + 1
                )

                new_session.update({
                    "distance": 0.0,
                    "session_ec": 0.0,
                    "session_regen": 0.0,
                    "session_ecr": 0.0,
                    "session_traction": 0.0,
                    "max_speed": session_current_speed,
                    "motor_temperature": session_motor_temp,
                    "deep_discharge": 1 if current_soc < 20 else 0,
                    "zero_speed_start_time": None,
                    "last_idle_update_time": None,
                    "idle_duration": 0.0,
                    "idle_energy": 0.0,
                })

            elif current_label == "charging":

                daily_report["no_of_charging_cycles"] = (
                    (daily_report.get("no_of_charging_cycles") or 0)
                    + 1
                )

                new_session.update({
                    "charging_units": charging_units,
                    "insufficient_charge": 0,
                })

            elif current_label == "idle":

                daily_report["no_of_idle_sessions"] = (
                    (daily_report.get("no_of_idle_sessions") or 0)
                    + 1
                )

                new_session.update({
                    "session_ec": 0.0,
                    "deep_discharge": 1 if current_soc < 20 else 0,
                })

            sessions.append(
                make_session_serializable(new_session)
            )

    daily_report["vrn"] = ( daily_report.get("vrn") or device_details.get("VRN"))
    daily_report["chassis_number"] = ( daily_report.get("chassis_number") or device_details.get("chassis_number"))
    daily_report["vehicle_type"] = ( daily_report.get("vehicle_type") or device_details.get("device_type"))
    daily_report["vehicle_type_name"] = ( daily_report.get("vehicle_type_name") or device_details.get("device_type_name"))
    daily_report["fleet"] = (  daily_report.get("fleet")  or device_details.get("fleet"))
    daily_report["city"] = ( daily_report.get("city") or device_details.get("city"))

    # Update daily report fields
    daily_report["latitude"] = current_lat
    daily_report["longitude"] = current_long
    daily_report["mode"] = current_mode
    # daily_report.end_odometer = current_odometer
    # daily_report.end_soc = current_soc
    daily_report["stop_time_of_day"] = current_timestamp.isoformat()
    daily_report["distance"] = round(total_distance, 2)
    daily_report["runtime_minutes"] = round((daily_report.get("runtime_minutes") or 0) + runtime_minutes, 2)
    daily_report["idle_minutes"] = round((daily_report.get("idle_minutes") or 0) + idle_minutes, 2)
    daily_report["charging_minutes"] = round((daily_report.get("charging_minutes") or 0) + charging_minutes, 2)
    daily_report["stoppage_minutes"] = round((daily_report.get("stoppage_minutes") or 0) + stoppage_minutes, 2)
    daily_report["average_speed"] = round(average_speed, 2)
    daily_report["energy_consumed"] = round((daily_report.get("energy_consumed") or 0) + (-ec),3,)
    daily_report["regen_energy"] = round((daily_report.get("regen_energy") or 0) + regen,3,)
    daily_report["motor_ec"] = round((daily_report.get("motor_ec") or 0)+ (0 if mcu_energy < 0 else mcu_energy),3,)
    daily_report["dcdc_ec"] = round((daily_report.get("dcdc_ec") or 0) + kwh_dcdc,3,)
    daily_report["bcs_ec"] = round((daily_report.get("bcs_ec") or 0) + kwh_bcs, 3,)
    daily_report["tcs_ec"] = round((daily_report.get("tcs_ec") or 0) + kwh_tcs,3,)
    daily_report["ecompressor_and_steering_ec"] = round((daily_report.get("ecompressor_and_steering_ec") or 0)+ kwh_ecompressor,2,)
    daily_report["energy_consumption"] = round(ecr, 3)
    daily_report["charging_unit"] = round((daily_report.get("charging_unit") or 0)+ charging_units,3,)
    daily_report["battery_temperature"] = max_battery_temp
    daily_report["motor_temperature"] = max_motor_temperature
    daily_report["insufficient_charge"] = bool(insufficient_charge)
    daily_report["depth_of_discharge"] = bool(dod)


    return daily_report,True



def r_live_daily_report_3w_calculation(device_details,device_id,end_lat, end_long,timestamp,can_data,daily_report):


    # Convert date
    report_date = get_local_date_from_utc_timestamp(can_data.get("timestamp") or timestamp)

    # if not report_date:
    #     return daily_report, False

    if daily_report and daily_report.get("date") != report_date.isoformat():
        daily_report = {}


    # Handle empty state
    if not daily_report:

        last_odo = (
            DailySummaryReport.objects
            .filter(imei=device_id, end_odometer__gt=0)
            .order_by("-date")
            .values_list("end_odometer", flat=True)
            .first()
            or 0
        )

        last_soc = (
            DailySummaryReport.objects
            .filter(imei=device_id, end_soc__gt=0)
            .order_by("-date")
            .values_list("end_soc", flat=True)
            .first()
            or 0
        )

        daily_report = {
            "date": report_date.isoformat(),
            "imei": device_id,
            "vrn": device_details.get("VRN") if device_details else None,
            "vehicle_type": device_details.get("device_type") if device_details else None,
            "vehicle_type_name": device_details.get("device_type_name") if device_details else None,
            "chassis_number": device_details.get("chassis_number") if device_details else None,
            "fleet": device_details.get("fleet") if device_details else None,
            "city": device_details.get("city") if device_details else None,
            "latitude": end_lat,
            "longitude": end_long,
            "start_time_of_day": None,
            "runtime_minutes":0,
            "idle_minutes":0,
            "charging_minutes":0,
            "stoppage_minutes":0,
            "start_odometer":None,
            "end_odometer":None,
            "distance":0,
            "average_speed":0,
            "no_of_movement_sessions":0,
            "no_of_charging_cycles":0,
            "no_of_idle_sessions":0,
            "start_soc":None,
            "end_soc":None,
            "energy_consumed":0,
            "regen_energy":0,
            "motor_ec":0,
            "dcdc_ec":0,
            "ecompressor_and_steering_ec":0,
            "bcs_ec":0,
            "tcs_ec":0,
            "energy_consumption":0,
            "charging_unit":0,
            "depth_of_discharge":0,
            "insufficient_charge":0,
            "battery_temperature":None,     
            "motor_temperature":None,
            "mode":None,
            "sessions": [],
            "last_odo": last_odo,
            "last_soc": last_soc,
            "co2_saving": 0,
            "cost_saved": 0,
            "db_created": False

        }

    # Handle empty CAN data
    if not can_data:
        daily_report["latitude"] = end_lat
        daily_report["longitude"] = end_long
        daily_report["stop_time_of_day"] = make_aware_ist(datetime.now()).isoformat()
        daily_report["vrn"] = ( daily_report.get("vrn") or device_details.get("VRN"))
        daily_report["chassis_number"] = ( daily_report.get("chassis_number") or device_details.get("chassis_number"))
        daily_report["vehicle_type"] = ( daily_report.get("vehicle_type") or device_details.get("device_type"))
        daily_report["vehicle_type_name"] = ( daily_report.get("vehicle_type_name") or device_details.get("device_type_name"))
        daily_report["fleet"] = (  daily_report.get("fleet")  or device_details.get("fleet"))
        daily_report["city"] = ( daily_report.get("city") or device_details.get("city"))
        daily_report["depth_of_discharge"] = bool(daily_report.get("depth_of_discharge"))
        daily_report["insufficient_charge"] = bool(daily_report.get("insufficient_charge"))


        return daily_report,True  # Exit if no CAN data

#######################################################################
    # # Create DataFrame
    # df = pd.DataFrame([can_data]) 

    # df = df.where(df != 'N', np.nan)
    # df = df.apply(pd.to_numeric, errors='coerce')
    # df.fillna(0, inplace=True)

    # if df.empty:
    #     return daily_report,False
    #####################################################
   

    # Convert CAN signals once
    can_signals = {k: safe_float(v) for k, v in can_data.items()}

    last_stop_time = daily_report.get("stop_time_of_day")
    if last_stop_time:
        last_stop_time = datetime.fromisoformat(last_stop_time)

    current_timestamp = timestamp

    if daily_report.get("start_time_of_day") is None:
        daily_report["start_time_of_day"] = current_timestamp.isoformat()

    # Handle first entry case
    if last_stop_time is None:
        time_diff_seconds = 0
    else:
        last_stop_time = make_aware_ist(last_stop_time)
        time_diff_seconds = max(
            (current_timestamp - last_stop_time).total_seconds(),
            0
        )

        if time_diff_seconds < 1:
            return daily_report, False

    # Mode detection
    charger_voltage = can_signals.get("Charger_Output_VOL", 0)
    charger_current = can_signals.get("Charger_Output_CUR", 0)

    # Charging mask: either voltage OR current > 0
    charging_mask = (charger_voltage > 0 or charger_current > 0)

    # Not charging mask
    not_charging_mask = not charging_mask

    # Mode detection
    ignition_status = can_signals.get("IgnitionStatus", 0)
    mcu_speed = can_signals.get("MCU_Speed_Kmph", 0)

    if charging_mask:
        current_mode = "Charging"
    elif not_charging_mask and ignition_status == 1 and mcu_speed > 0:
        current_mode = "Movement"
    elif not_charging_mask and ignition_status == 1 and mcu_speed == 0:
        current_mode = "Idle"
    else:
        current_mode = "Stopped"

    # SOC
    raw_soc = can_signals.get("SOC")

    # Odometer
    mcu_odometer = can_signals.get("MCU_Odometer_Val")

    default_odo = daily_report.get("last_odo", 0)
    default_soc = daily_report.get("last_soc", 0)

    # Current known odometer fallback chain
    last_odometer = (
        daily_report.get("end_odometer")
        or daily_report.get("start_odometer")
        or default_odo
        or 0
    )

    # Valid odometer check
    if (
        mcu_odometer is not None
        and 0 <= mcu_odometer < 10000000
        and mcu_odometer >= last_odometer
    ):
        current_odometer = mcu_odometer
    else:
        current_odometer = last_odometer

    # Mode
    prev_mode = daily_report.get("mode") or "Unknown"

    # Initialize start odometer once
    if daily_report.get("start_odometer") is None:
        daily_report["start_odometer"] = round(
            current_odometer if current_odometer > 0 else last_odometer,
            2,
        )

    # SOC fallback chain
    prev_soc = daily_report.get("end_soc")

    if prev_soc is None:
        prev_soc = daily_report.get("start_soc")

    if prev_soc is None:
        prev_soc = default_soc

    if prev_soc is None:
        prev_soc = 0

    # Use previous valid SOC when vehicle sends 0 / N
    if raw_soc is not None and raw_soc > 0:
        current_soc = raw_soc
    else:
        current_soc = prev_soc

    # Initialize start SOC once
    if daily_report.get("start_soc") is None:
        daily_report["start_soc"] = current_soc

    # Previous end odometer
    prev_end_odometer = round(
        daily_report.get("end_odometer")
        or current_odometer,
        2,
    )

    # Incremental distance
    distance_km = max(
        current_odometer - prev_end_odometer,
        0,
    )

    # Update end odometer
    if current_odometer > 0:
        daily_report["end_odometer"] = round(
            current_odometer,
            2,
        )
    elif not daily_report.get("end_odometer"):
        daily_report["end_odometer"] = round(
            last_odometer,
            2,
        )

    # Update end SOC
    daily_report["end_soc"] = current_soc

    current_lat = end_lat
    current_long = end_long

    # Energy calculations
    battery_voltage = can_signals.get("BatteryVoltage", 0)
    battery_current = can_signals.get("BatteryCurrent", 0)

    energy_kwh = ( battery_voltage / 10000 * battery_current / 1000 * time_diff_seconds / 3600000)

    if charging_mask:
        charging_units = energy_kwh
        ec = 0
        regen = 0
    else:
        charging_units = 0

        if energy_kwh < 0:
            ec = energy_kwh
            regen = 0
        else:
            ec = 0
            regen = energy_kwh

    total_ec = (daily_report.get("energy_consumed") or 0) + (-ec)
    total_regen = (daily_report.get("regen_energy") or 0) + regen

    ecr_distance = (daily_report.get("distance") or 0) + distance_km

    ecr = ( (total_ec - total_regen) / ecr_distance if ecr_distance else 0)

    # Temperatures
    battery_temps = [
        can_signals.get("TS1", 0),
        can_signals.get("TS2", 0),
        can_signals.get("TS3", 0),
        can_signals.get("TS4", 0),
        can_signals.get("TS5", 0),
        can_signals.get("TS6", 0),
    ]

    session_battery_temp = max(battery_temps)

    max_battery_temp = max(daily_report.get("battery_temperature") or 0, round(session_battery_temp, 2),)

    session_motor_temp = can_signals.get("MCU_Motor_Temp", 0)

    max_motor_temperature = max(daily_report.get("motor_temperature") or 0, round(session_motor_temp, 2),)

    # Minutes
    runtime_minutes = idle_minutes = charging_minutes = stoppage_minutes = 0

    if current_mode.lower() == "movement":
        runtime_minutes = time_diff_seconds / 60

    elif current_mode.lower() == "idle":
        idle_minutes = time_diff_seconds / 60

    elif current_mode.lower() == "charging":
        charging_minutes = time_diff_seconds / 60

    else:
        stoppage_minutes = time_diff_seconds / 60

    # Average speed
    prev_runtime = daily_report.get("runtime_minutes") or 0
    total_runtime_minutes = prev_runtime + runtime_minutes

    start_odometer = daily_report.get("start_odometer")

    if start_odometer is None:
        total_distance = 0
    elif start_odometer <= current_odometer:
        total_distance = current_odometer - start_odometer
    else:
        total_distance = daily_report.get("distance") or 0

    average_speed = (total_distance / (total_runtime_minutes / 60)  if total_runtime_minutes > 0  else 0)

    # max speed session wise
    session_current_speed = can_signals.get("MCU_Speed_Kmph", 0)

    diesel_mileage = {'3w_6s': 25}
    electric_ecr = {'3w_6s': 0.08}

    EMISSION_FACTOR_DIESEL = 2.68
    GRID_CO2_INTENSITY = 0.2
    diesel_price = 90
    electricity_price = 8

    # Calculations
    liters_per_km = 1 / diesel_mileage['3w_6s']
    co2_diesel = liters_per_km * EMISSION_FACTOR_DIESEL
    cost_diesel = liters_per_km * diesel_price

    ecr_variant = electric_ecr['3w_6s']
    co2_electric = ecr_variant * GRID_CO2_INTENSITY
    cost_electric = ecr_variant * electricity_price

    co2_saved = co2_diesel - co2_electric
    cost_saved = cost_diesel - cost_electric

    if total_distance:
        daily_report["co2_saving"] = co2_saved * total_distance
        daily_report["cost_saved"] = cost_saved * total_distance

    # Insufficient charge & DOD
    charging_ended = ( prev_mode.lower() == "charging" and current_mode.lower() != "charging")

    dod = bool(daily_report.get("depth_of_discharge") or (current_soc is not None and current_soc < 20))

    if charging_ended:
        last_charging_soc = ( current_soc if current_soc is not None else daily_report.get("end_soc"))
        insufficient_charge = ( last_charging_soc is not None and last_charging_soc <= 90)
    else:
        insufficient_charge = bool(daily_report.get("insufficient_charge"))

    # charging_ended = prev_mode.lower() == "charging" and current_mode.lower() != "charging"
    # if charging_ended:
    #     last_soc = current_soc if pd.notnull(current_soc) else daily_report.get("end_soc")

    #     insufficient_charge = 1 if (last_soc is not None and last_soc <= 90) else 0

    #     dod = 1 if (last_soc is not None and last_soc < 20) else 0
    # else:
    #     insufficient_charge = daily_report.get("insufficient_charge") or 0
    #     dod = daily_report.get("depth_of_discharge") or 0

    # Sessions
    # if not daily_report.get("sessions"):
    #     daily_report["sessions"] = []

    # def make_session_serializable(session):
    #     # Convert datetime objects to ISO strings
    #     # for key in ["start_time_val", "end_time_val"]:
    #     #     if isinstance(session.get(key), datetime):
    #     #         session[key] = make_aware_ist(session[key]).isoformat()
    #     # Convert numpy numbers to native Python types
    #     for key, value in session.items():
    #         if isinstance(value, (np.integer, np.int64, np.int32)):
    #             session[key] = int(value)
    #         elif isinstance(value, (np.floating, np.float64, np.float32)):
    #             session[key] = float(value)
    #     return session

    # def update_last_session(session, current_timestamp, current_odometer, current_soc, ec, regen, ecr,
    #                         charging_units,session_current_speed,session_battery_temp,current_lat,current_long):
    #     # Convert datetime and numpy values immediately
    #     session["end_time_val"] = make_aware_ist(current_timestamp).isoformat()
    #     if not session.get("start_odo_val") or session["start_odo_val"] == 0:
    #         session["start_odo_val"] = round(float(current_odometer), 2)
    #     session["end_odo_val"] = round(float(current_odometer), 2)
    #     if not session.get("start_soc_val") or session["start_soc_val"] == 0:
    #         session["start_soc_val"] = float(current_soc)
    #     session["end_soc_val"] = float(current_soc)
    #     session["duration"] = (datetime.fromisoformat(session["end_time_val"]) - datetime.fromisoformat(session["start_time_val"])).total_seconds() / 60
    #     session["end_latitude"] = current_lat
    #     session["end_longitude"] = current_long
    #     session["battery_temperature"] = max(session["battery_temperature"],session_battery_temp)
    #     if "session_ec" in session:
    #         session["session_ec"] += float(ec)
    #     if "distance" in session:
    #         session["distance"] = max(session["end_odo_val"] - session["start_odo_val"], 0)
    #         session["session_regen"] += float(regen)
    #         session["session_ecr"] = (-(session["session_ec"]) + session["session_regen"]) / session["distance"] if session["distance"] else 0
    #         session["max_speed"] = max(session["max_speed"],session_current_speed)
    #         if "motor_temperature" in session:
    #             session["motor_temperature"] = max(session["motor_temperature"],session_motor_temp)
    #     if "deep_discharge" in session and session["deep_discharge"] != 1:
    #         session["deep_discharge"] = 1 if current_soc < 20 else 0
    #     if "charging_units" in session:
    #         session["charging_units"] += charging_units


    # start_odo_val = current_odometer if current_odometer and current_odometer > 0 else daily_report.get("start_odometer") or 0
    # # Creating a new session
    # if prev_mode is None or prev_mode.lower() != current_mode.lower():
    #     #assignment    
    #     allow_new_session = False
    #     if daily_report.get("sessions"):
    #         sessions = daily_report.setdefault("sessions", [])
    #         if sessions:
    #             last_session = sessions[-1]
    #         # updating the insufficient charge only after charging session is ended.
    #         if "insufficient_charge" in last_session:
    #             last_session["insufficient_charge"] = 1 if current_soc < 90 else 0

    #         last_end_time = datetime.fromisoformat(last_session["end_time_val"])
    #         duration = (current_timestamp - last_end_time).total_seconds() / 60

    #         if last_session.get("duration", 0) == 0 and last_session.get("distance", 0) == 0:
    #             sessions.pop()

    #             last_session_name = last_session.get("label", "").lower()
                
    #             if last_session_name == "movement":
    #                 daily_report["no_of_movement_sessions"] = max((daily_report.get("no_of_movement_sessions", 1) - 1, 0))
    #             elif last_session_name == "charging":
    #                 daily_report["no_of_charging_cycles"] = max((daily_report.get("no_of_charging_cycles", 1) - 1, 0))
    #             elif last_session_name == "idle":
    #                 daily_report["no_of_idle_sessions"] = max((daily_report.get("no_of_idle_sessions", 1) - 1, 0))

    #         if duration > 0.1667:  # threshold ~10 sec
    #             allow_new_session = True
    #     else:
    #         allow_new_session = True

    #     if allow_new_session:
    #         new_session = {
    #             "label": current_mode,
    #             "start_latitude": current_lat,
    #             "start_longitude": current_long,
    #             "end_latitude":current_lat,
    #             "end_longitude":current_long,
    #             "start_time_val": make_aware_ist(current_timestamp).isoformat(),
    #             "end_time_val": make_aware_ist(current_timestamp).isoformat(),
    #             "duration": 0,
    #             "start_odo_val": round(start_odo_val, 2),
    #             "end_odo_val": round(start_odo_val, 2),
    #             "start_soc_val": float(current_soc),
    #             "end_soc_val": float(current_soc),
    #             "battery_temperature": session_battery_temp,
    #         }
    #         new_session = make_session_serializable(new_session)
    #         daily_report.setdefault("sessions", []).append(new_session)

    #     if current_mode.lower() == "movement":
    #         daily_report["no_of_movement_sessions"] = (daily_report.get("no_of_movement_sessions") or 0) + 1
    #         # adding session parameters based on the mode
    #         new_session["distance"] = 0
    #         new_session["session_ec"] = 0.0
    #         new_session["session_regen"] = 0.0
    #         new_session["session_ecr"] = 0.0
    #         new_session["max_speed"] = session_current_speed
    #         new_session["motor_temperature"] = session_motor_temp
    #         new_session["deep_discharge"] = 1 if current_soc < 20 else 0

    #     elif current_mode.lower() == "charging":
    #         daily_report["no_of_charging_cycles"] = (daily_report.get("no_of_charging_cycles") or 0) + 1
    #         # adding session parameters based on the mode
    #         new_session["charging_units"] = charging_units
    #         new_session["insufficient_charge"] = 0 

    #     elif current_mode.lower() == "idle":
    #         daily_report["no_of_idle_sessions"] = (daily_report.get("no_of_idle_sessions") or 0) + 1
    #         # adding session parameters based on the mode
    #         new_session["session_ec"] = 0.0
    #         new_session["deep_discharge"] = 1 if current_soc < 20 else 0

            
    # elif daily_report.get("sessions"):
    #     update_last_session(daily_report["sessions"][-1], current_timestamp, current_odometer, current_soc, ec, regen, ecr,
    #                         charging_units,session_current_speed,session_battery_temp,current_lat,current_long)

    # if daily_report.get("sessions"):
    #     daily_report["sessions"] = [make_session_serializable(s) for s in daily_report["sessions"]]

    sessions = daily_report.setdefault("sessions", [])


    def iso(dt):
        return make_aware_ist(dt).isoformat()


    def make_session_serializable(session):

        for key in ["start_time_val", "end_time_val"]:

            if isinstance(session.get(key), datetime):
                session[key] = iso(session[key])

        for key, value in session.items():

            if isinstance(value, (np.integer, np.int64, np.int32)):
                session[key] = int(value)

            elif isinstance(value, (np.floating, np.float64, np.float32)):
                session[key] = float(value)

        return session


    def decrement_session_count(label):

        if label == "movement":
            daily_report["no_of_movement_sessions"] = max(
                (daily_report.get("no_of_movement_sessions") or 1) - 1,
                0,
            )

        elif label == "charging":
            daily_report["no_of_charging_cycles"] = max(
                (daily_report.get("no_of_charging_cycles") or 1) - 1,
                0,
            )

        elif label == "idle":
            daily_report["no_of_idle_sessions"] = max(
                (daily_report.get("no_of_idle_sessions") or 1) - 1,
                0,
            )


    def update_last_session(
        session,
        current_timestamp,
        current_odometer,
        current_soc,
        ec,
        regen,
        ecr,
        charging_units,
        session_current_speed,
        session_battery_temp,
        current_lat,
        current_long,
    ):

        label = session.get("label", "").lower()

        session["end_time_val"] = iso(current_timestamp)

        if session.get("start_odo_val") is None:
            session["start_odo_val"] = round(float(current_odometer), 2)

        if session.get("start_soc_val") is None:
            session["start_soc_val"] = (
                float(current_soc)
                if current_soc is not None
                else 0
            )

        session["end_odo_val"] = round(float(current_odometer), 2)

        session["end_soc_val"] = (
            float(current_soc)
            if current_soc is not None
            else session.get("end_soc_val", 0)
        )

        session["duration"] = (
            datetime.fromisoformat(session["end_time_val"])
            - datetime.fromisoformat(session["start_time_val"])
        ).total_seconds() / 60

        session["end_latitude"] = current_lat
        session["end_longitude"] = current_long

        session["battery_temperature"] = max(
            session.get("battery_temperature", 0),
            session_battery_temp,
        )

        if "session_ec" in session:
            session["session_ec"] += float(ec)

        # Movement session
        if label == "movement":

            session.setdefault("distance", 0.0)
            session.setdefault("session_regen", 0.0)
            session.setdefault("session_ecr", 0.0)
            session.setdefault("max_speed", 0.0)

            session["distance"] = max(
                session["end_odo_val"] - session["start_odo_val"],
                0,
            )

            session["session_regen"] += float(regen)

            session["session_ecr"] = (
                (
                    -(session["session_ec"])
                    + session["session_regen"]
                )
                / session["distance"]
                if session["distance"]
                else 0
            )

            session["max_speed"] = max(
                session["max_speed"],
                session_current_speed,
            )

            if "motor_temperature" in session:
                session["motor_temperature"] = max(
                    session["motor_temperature"],
                    session_motor_temp,
                )

            # Idle inside movement
            session.setdefault("zero_speed_start_time", None)
            session.setdefault("last_idle_update_time", None)
            session.setdefault("idle_duration", 0.0)
            session.setdefault("idle_energy", 0.0)

            if session_current_speed == 0:

                now_iso = iso(current_timestamp)

                if session["zero_speed_start_time"] is None:

                    session["zero_speed_start_time"] = now_iso
                    session["last_idle_update_time"] = now_iso

                else:

                    zero_start = datetime.fromisoformat(
                        session["zero_speed_start_time"]
                    )

                    stationary_minutes = (
                        current_timestamp - zero_start
                    ).total_seconds() / 60

                    if stationary_minutes >= 2:

                        last_idle_update = datetime.fromisoformat(
                            session["last_idle_update_time"]
                        )

                        incremental_idle = (
                            current_timestamp - last_idle_update
                        ).total_seconds() / 60

                        incremental_idle = max(
                            incremental_idle,
                            0,
                        )

                        session["idle_duration"] += incremental_idle

                        session["idle_energy"] += max(
                            float(-ec),
                            0,
                        )

                        session["last_idle_update_time"] = now_iso

            else:

                session["zero_speed_start_time"] = None
                session["last_idle_update_time"] = None

        # Deep discharge
        if (
            "deep_discharge" in session
            and session["deep_discharge"] != 1
        ):
            session["deep_discharge"] = (
                1 if current_soc is not None and current_soc < 20 else 0
            )

        # Charging
        if "charging_units" in session:
            session["charging_units"] += charging_units


    start_odo_val = (
        current_odometer
        if current_odometer is not None and current_odometer > 0
        else (daily_report.get("start_odometer") or 0)
    )

    current_label = current_mode.lower()

    last_session = sessions[-1] if sessions else None

    last_label = (
        last_session.get("label", "").lower()
        if last_session
        else None
    )

    same_session = last_label == current_label

    if same_session and last_session:

        update_last_session(
            last_session,
            current_timestamp,
            current_odometer,
            current_soc,
            ec,
            regen,
            ecr,
            charging_units,
            session_current_speed,
            session_battery_temp,
            current_lat,
            current_long,
        )

    else:

        allow_new_session = True

        if last_session:

            if (
                "insufficient_charge" in last_session
                and current_soc is not None
            ):
                last_session["insufficient_charge"] = (
                    1 if current_soc < 90 else 0
                )

            if (
                last_session.get("duration", 0) < 0.1667
                and last_session.get("distance", 0) == 0
            ):

                removed = sessions.pop()

                decrement_session_count(
                    removed.get("label", "").lower()
                )

                last_session = sessions[-1] if sessions else None

                last_label = (
                    last_session.get("label", "").lower()
                    if last_session
                    else None
                )

                if last_label == current_label:

                    update_last_session(
                        last_session,
                        current_timestamp,
                        current_odometer,
                        current_soc,
                        ec,
                        regen,
                        ecr,
                        charging_units,
                        session_current_speed,
                        session_battery_temp,
                        current_lat,
                        current_long,
                    )

                    allow_new_session = False

            else:

                last_end = datetime.fromisoformat(
                    last_session["end_time_val"]
                )

                duration_gap = (
                    current_timestamp - last_end
                ).total_seconds() / 60

                allow_new_session = duration_gap > 0.1667

        if allow_new_session:

            new_session = {
                "label": current_mode,
                "start_latitude": current_lat,
                "start_longitude": current_long,
                "end_latitude": current_lat,
                "end_longitude": current_long,
                "start_time_val": iso(current_timestamp),
                "end_time_val": iso(current_timestamp),
                "duration": 0,
                "start_odo_val": round(start_odo_val, 2),
                "end_odo_val": round(start_odo_val, 2),
                "start_soc_val": (
                    float(current_soc)
                    if current_soc is not None
                    else 0
                ),
                "end_soc_val": (
                    float(current_soc)
                    if current_soc is not None
                    else 0
                ),
                "battery_temperature": session_battery_temp,
            }

            # Movement
            if current_label == "movement":

                daily_report["no_of_movement_sessions"] = (
                    (daily_report.get("no_of_movement_sessions") or 0)
                    + 1
                )

                new_session.update({
                    "distance": 0,
                    "session_ec": 0.0,
                    "session_regen": 0.0,
                    "session_ecr": 0.0,
                    "max_speed": session_current_speed,
                    "motor_temperature": session_motor_temp,
                    "deep_discharge": (
                        1
                        if current_soc is not None and current_soc < 20
                        else 0
                    ),
                    "zero_speed_start_time": None,
                    "last_idle_update_time": None,
                    "idle_duration": 0.0,
                    "idle_energy": 0.0,
                })

            # Charging
            elif current_label == "charging":

                daily_report["no_of_charging_cycles"] = (
                    (daily_report.get("no_of_charging_cycles") or 0)
                    + 1
                )

                new_session.update({
                    "charging_units": charging_units,
                    "insufficient_charge": 0,
                })

            # Idle
            elif current_label == "idle":

                daily_report["no_of_idle_sessions"] = (
                    (daily_report.get("no_of_idle_sessions") or 0)
                    + 1
                )

                new_session.update({
                    "session_ec": 0.0,
                    "deep_discharge": (
                        1
                        if current_soc is not None and current_soc < 20
                        else 0
                    ),
                })

            sessions.append(
                make_session_serializable(new_session)
            )

    daily_report["vrn"] = ( daily_report.get("vrn") or device_details.get("VRN"))
    daily_report["chassis_number"] = ( daily_report.get("chassis_number") or device_details.get("chassis_number"))
    daily_report["vehicle_type"] = ( daily_report.get("vehicle_type") or device_details.get("device_type"))
    daily_report["vehicle_type_name"] = ( daily_report.get("vehicle_type_name") or device_details.get("device_type_name"))
    daily_report["fleet"] = (  daily_report.get("fleet")  or device_details.get("fleet"))
    daily_report["city"] = ( daily_report.get("city") or device_details.get("city"))

    # Update daily report fields
    daily_report["latitude"] = current_lat
    daily_report["longitude"] = current_long
    daily_report["mode"] = current_mode
    # daily_report.end_odometer = current_odometer
    # daily_report.end_soc = current_soc
    daily_report["stop_time_of_day"] = current_timestamp.isoformat()
    daily_report["distance"] = round(total_distance, 2)
    daily_report["runtime_minutes"] = round((daily_report.get("runtime_minutes") or 0) + runtime_minutes, 2)
    daily_report["idle_minutes"] = round((daily_report.get("idle_minutes") or 0) + idle_minutes, 2)
    daily_report["charging_minutes"] = round((daily_report.get("charging_minutes") or 0) + charging_minutes, 2)
    daily_report["stoppage_minutes"] = round((daily_report.get("stoppage_minutes") or 0) + stoppage_minutes, 2)
    daily_report["average_speed"] = round(average_speed, 2)
    daily_report["energy_consumed"] = round((daily_report.get("energy_consumed") or 0) + (-ec),3,)
    daily_report["regen_energy"] = round((daily_report.get("regen_energy") or 0) + regen,3,)
    daily_report["energy_consumption"] = round(ecr, 3)
    daily_report["charging_unit"] = round((daily_report.get("charging_unit") or 0)+ charging_units,3,)
    daily_report["battery_temperature"] = max_battery_temp
    daily_report["motor_temperature"] = max_motor_temperature
    daily_report["insufficient_charge"] = bool(insufficient_charge)
    daily_report["depth_of_discharge"] = bool(dod)

    return daily_report,True








    