from django.apps import AppConfig


class RedissetupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'redisSetup'
