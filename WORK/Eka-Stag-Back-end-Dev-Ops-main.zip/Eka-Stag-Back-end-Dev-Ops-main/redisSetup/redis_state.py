import json
import numpy as np
import pandas as pd
from datetime import datetime
from devices.models import FaultRule



def load_state(r, device_id):

    state = {}

    total = r.hgetall(f"device:{device_id}:total_cal")
    if total:
        state["total_cal"] = {k.decode(): json.loads(v) for k,v in total.items()}

    daily = r.hgetall(f"device:{device_id}:daily_summary")
    if daily:
        state["daily_summary"] = {k.decode(): json.loads(v) for k,v in daily.items()}

    alerts = r.hget(f"device:{device_id}", "alerts")
    if alerts:
        state["alerts"] = json.loads(alerts)

    faults = r.hget(f"device:{device_id}", "faults")
    if faults:
        state["faults"] = json.loads(faults)


    return state


def json_serializer(obj):

    if isinstance(obj, (np.bool_,)):
        return bool(obj)

    if isinstance(obj, (np.integer,)):
        return int(obj)

    if isinstance(obj, (np.floating,)):
        return float(obj)

    if isinstance(obj, (pd.Timestamp, datetime)):
        return obj.isoformat()

    return str(obj)


def processor_save_state(
    r,
    device_id,
    state,
    total_cal_updated=True,
    daily_report_updated=True,
    alerts_updated=True,
    faults_updated=True,
):
    pipe = r.pipeline()

    if total_cal_updated and "total_cal" in state:
        pipe.hset(
            f"device:{device_id}:total_cal",
            mapping={
                k: json.dumps(v, default=json_serializer)
                for k, v in state["total_cal"].items()
            }
        )

    if daily_report_updated and "daily_summary" in state:
        pipe.hset(
            f"device:{device_id}:daily_summary",
            mapping={
                k: json.dumps(v, default=json_serializer)
                for k, v in state["daily_summary"].items()
            }
        )

    if alerts_updated and "alerts" in state:
        pipe.hset(
            f"device:{device_id}",
            "alerts",
            json.dumps(state["alerts"], default=json_serializer)
        )

    if faults_updated and "faults" in state:
        pipe.hset(
            f"device:{device_id}",
            "faults",
            json.dumps(state["faults"], default=json_serializer)
        )

    pipe.execute()

def save_state(r, device_id, state):

    if "total_cal" in state:

        r.delete(f"device:{device_id}:total_cal")

        for k, v in state["total_cal"].items():

            r.hset(
                f"device:{device_id}:total_cal",
                k,
                json.dumps(v, default=json_serializer)
            )

    if "daily_summary" in state:

        r.delete(f"device:{device_id}:daily_summary")

        for k, v in state["daily_summary"].items():

            r.hset(
                f"device:{device_id}:daily_summary",
                k,
                json.dumps(v, default=json_serializer)
            )

    if "alerts" in state:

        r.hset(
            f"device:{device_id}",
            "alerts",
            json.dumps(state["alerts"], default=json_serializer)
        )

    if "faults" in state:

        r.hset(
            f"device:{device_id}",
            "faults",
            json.dumps(state["faults"], default=json_serializer)
        )



def save_state(pipe, device_id, state):

    if "total_cal" in state:
        pipe.hset(
            f"device:{device_id}:total_cal",
            mapping={
                k: json.dumps(v, default=json_serializer)
                for k, v in state["total_cal"].items()
            }
        )

    if "daily_summary" in state:
        pipe.hset(
            f"device:{device_id}:daily_summary",
            mapping={
                k: json.dumps(v, default=json_serializer)
                for k, v in state["daily_summary"].items()
            }
        )

    if "alerts" in state:
        pipe.hset(
            f"device:{device_id}",
            "alerts",
            json.dumps(state["alerts"], default=json_serializer)
        )

    if "faults" in state:
        pipe.hset(
            f"device:{device_id}",
            "faults",
            json.dumps(state["faults"], default=json_serializer)
        )

FAULT_RULES_4W = None
FAULT_RULES_3W = None


def load_fault_rules():

    global FAULT_RULES_4W
    global FAULT_RULES_3W

    fault_rules_4w = {}
    fault_rules_3w = {}

    rules = FaultRule.objects.all().only(
        "id",
        "vehicle_type",
        "identifier",
        "component",
    )

    for rule in rules:

        vehicle_type = str(rule.vehicle_type).upper()

        if vehicle_type == "4W":

            fault_rules_4w[
                (
                    str(rule.component).upper(),
                    str(rule.identifier),
                )
            ] = {
                "id": rule.id,
                "component": rule.component,
            }

        elif vehicle_type == "3W":

            fault_rules_3w[str(rule.identifier)] = {
                "id": rule.id,
                "component": rule.component,
            }

    FAULT_RULES_4W = fault_rules_4w
    FAULT_RULES_3W = fault_rules_3w

    print(
        f"Loaded {len(FAULT_RULES_4W)} 4W rules and "
        f"{len(FAULT_RULES_3W)} 3W rules into memory"
    )

#Redis Setup for Fault Rules
def get_fault_rules():

    global FAULT_RULES_4W
    global FAULT_RULES_3W

    if FAULT_RULES_4W is None or FAULT_RULES_3W is None:
        load_fault_rules()

    return FAULT_RULES_4W, FAULT_RULES_3W