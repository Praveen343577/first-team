import os
import redis
from django_redis import get_redis_connection
import json
from redisSetup.data_parsing_functions import get_device_details
from redisSetup.redis_state import load_state, processor_save_state,load_fault_rules
from redisSetup.processor_cal import (
    processor_alerts,
    processor_faults,
    processor_data_summary,
    processor_device_calculations,
)
from devices.models import DeviceTotalCalculationData, DailySummaryReport
import pandas as pd
import socket


STREAM = "telematics_decoded"
GROUP = "processor_group"
BATCH_SIZE = 100
CONSUMER = f"{socket.gethostname()}_{os.getpid()}"

r = get_redis_connection("streams")


def ensure_group():
    try:
        r.xgroup_create(STREAM, GROUP, id="0", mkstream=True)
        print("Consumer group created")
    except redis.exceptions.ResponseError:
        pass

def normalize_total_cal_state(state):
    defaults = {
        "total_distance": 0,
        "co2_saving": 0,
        "energy_consumption": 0,
        "run_time": 0,
        "traction_energy": 0,
        "regen_energy": 0,
        "idle_time": 0,
        "charging_unit": 0,
        "charging_count": 0,
        "cost_saved": 0,
        "last_charging_state": False,
        "last_charging_state_time": None,
        "last_soc": None,
        "db_created": False,
        "db_id": None,
    }

    for k, v in defaults.items():
        if k not in state:
            state[k] = v

    return state

def load_total_cal_from_db(device_id):
    obj = (
        DeviceTotalCalculationData.objects
        .filter(device_id=device_id)
        .values(
            "id",
            "total_distance",
            "co2_saving",
            "energy_consumption",
            "run_time",
            "traction_energy",
            "regen_energy",
            "idle_time",
            "charging_unit",
            "charging_count",
            "cost_saved",
            "last_charging_state",
            "last_charging_state_time",
            "last_soc",
        )
        .first()
    )

    if not obj:
        return {}

    if obj["last_charging_state_time"]:
        obj["last_charging_state_time"] = obj["last_charging_state_time"].isoformat()

    obj["db_created"] = True
    obj["db_id"] = obj.pop("id")

    defaults = {
        "energy_consumption":0,
        "run_time":0,
        "traction_energy":0,
        "regen_energy":0,
        "idle_time":0,
        "charging_unit":0,
        "charging_count":0,
        "last_charging_state":False,
        "last_charging_state_time":None,
        "last_soc":None
    }

    for k,v in defaults.items():
        if obj.get(k) is None:
            obj[k] = v

    return obj


# def load_daily_summary_from_db(device_id,device_details):

#     from django.utils import timezone as dj_timezone

#     IST = dj_timezone.get_fixed_timezone(330)
#     today_ist = dj_timezone.localtime(dj_timezone.now(), IST).date()

#     obj = DailySummaryReport.objects.filter(imei=device_id, date=today_ist).first()

#     if not obj:
#         return {}

#     return {
#         "date": obj.date.isoformat(),
#         "imei": obj.imei,
#         "vrn": obj.vrn,
#         "chassis_number": obj.chassis_number,
#         "vehicle_type": obj.vehicle_type,
#         "vehicle_type_name": obj.vehicle_type_name,
#         "fleet": obj.fleet,
#         "city": obj.city,
#         "latitude": obj.latitude,
#         "longitude": obj.longitude,
#         "start_time_of_day": obj.start_time_of_day.isoformat()
#         if obj.start_time_of_day
#         else None,
#         "stop_time_of_day": obj.stop_time_of_day.isoformat()
#         if obj.stop_time_of_day
#         else None,
#         "runtime_minutes": obj.runtime_minutes,
#         "idle_minutes": obj.idle_minutes,
#         "charging_minutes": obj.charging_minutes,
#         "stoppage_minutes": obj.stoppage_minutes,
#         "start_odometer": obj.start_odometer,
#         "end_odometer": obj.end_odometer,
#         "distance": obj.distance,
#         "average_speed": obj.average_speed,
#         "no_of_movement_sessions": obj.no_of_movement_sessions,
#         "no_of_charging_cycles": obj.no_of_charging_cycles,
#         "no_of_idle_sessions": obj.no_of_idle_sessions,
#         "start_soc": obj.start_soc,
#         "end_soc": obj.end_soc,
#         "energy_consumed": obj.energy_consumed,
#         "regen_energy": obj.regen_energy,
#         "motor_ec": obj.motor_ec,
#         "dcdc_ec": obj.dcdc_ec,
#         "ecompressor_and_steering_ec": obj.ecompressor_and_steering_ec,
#         "bcs_ec": obj.bcs_ec,
#         "tcs_ec": obj.tcs_ec,
#         "energy_consumption": obj.energy_consumption,
#         "charging_unit": obj.charging_unit,
#         "depth_of_discharge": obj.depth_of_discharge,
#         "insufficient_charge": obj.insufficient_charge,
#         "battery_temperature": obj.battery_temperature,
#         "motor_temperature": obj.motor_temperature,
#         "mode": obj.mode,
#         "sessions": obj.sessions or [],
#         "co2_saving": obj.co2_saving,
#         "cost_saved": obj.cost_saved,
#         "db_created": True,
#         "db_id": obj.id,
#     }

def load_daily_summary_from_db(device_id, device_details):

    from django.utils import timezone as dj_timezone

    IST = dj_timezone.get_fixed_timezone(330)
    today_ist = dj_timezone.localtime(dj_timezone.now(),IST).date()

    obj = DailySummaryReport.objects.filter(imei=device_id,date=today_ist).first()

    if not obj:
        return {}

    # fallback metadata from cache/db
    if not device_details:
        device_details = get_device_details(device_id) or {}

    return {
        "date": obj.date.isoformat(),
        "imei": obj.imei or device_id,
        "vrn": obj.vrn or device_details.get("VRN") or "",
        "chassis_number": obj.chassis_number or device_details.get("chassis_number") or "",
        "vehicle_type": obj.vehicle_type or device_details.get("device_type") or "",
        "vehicle_type_name": obj.vehicle_type_name or device_details.get("device_type_name") or "",
        "fleet": obj.fleet or device_details.get("fleet") or "",
        "city": obj.city or device_details.get("city") or "",
        "runtime_minutes": obj.runtime_minutes or 0,
        "idle_minutes": obj.idle_minutes or 0,
        "charging_minutes": obj.charging_minutes or 0,
        "stoppage_minutes": obj.stoppage_minutes or 0,
        "start_odometer": obj.start_odometer or 0,
        "end_odometer": obj.end_odometer or 0,
        "distance": obj.distance or 0,
        "average_speed": obj.average_speed or 0,
        "no_of_movement_sessions": obj.no_of_movement_sessions or 0,
        "no_of_charging_cycles": obj.no_of_charging_cycles or 0,
        "no_of_idle_sessions": obj.no_of_idle_sessions or 0,
        "start_soc": obj.start_soc or 0,
        "end_soc": obj.end_soc or 0,
        "energy_consumed": obj.energy_consumed or 0,
        "regen_energy": obj.regen_energy or 0,
        "motor_ec": obj.motor_ec or 0,
        "dcdc_ec": obj.dcdc_ec or 0,
        "ecompressor_and_steering_ec": obj.ecompressor_and_steering_ec or 0,
        "bcs_ec": obj.bcs_ec or 0,
        "tcs_ec": obj.tcs_ec or 0,
        "energy_consumption": obj.energy_consumption or 0,
        "charging_unit": obj.charging_unit or 0,
        "depth_of_discharge": bool(obj.depth_of_discharge),
        "insufficient_charge": bool(obj.insufficient_charge),
        "battery_temperature": obj.battery_temperature or 0,
        "motor_temperature": obj.motor_temperature or 0,
        "mode": obj.mode or "Stopped",
        "sessions": obj.sessions or [],
        "co2_saving": obj.co2_saving or 0,
        "cost_saved": obj.cost_saved or 0
        }

from django.db import close_old_connections
from time import perf_counter
def run():

    ensure_group()

    #Loading fault rules into memory for processing
    load_fault_rules()

    while True:

        close_old_connections()

        messages = r.xreadgroup(
            GROUP, CONSUMER, {STREAM: ">"}, count=BATCH_SIZE, block=200
        )

        if not messages:
            continue

        for _, entries in messages:

            for msg_id, data in entries:

                #Timing variables for performance monitoring
                # packet_start = perf_counter()
                # payload_decode_time = 0
                # device_details_time = 0
                # state_load_time = 0
                # total_cal_time = 0
                # daily_summary_time = 0
                # alerts_time = 0
                # faults_time = 0
                # save_state_time = 0

                try:

                    # payload = {k.decode(): v.decode() for k, v in data.items()}
                    # payload["can_data"] = json.loads(payload.get("can_data", "{}"))

                    #For performance monitoring of payload decoding
                    # t = perf_counter()

                    payload = {k.decode(): v.decode() for k, v in data.items()}
                    payload["can_data"] = json.loads(payload.get("can_data", "{}"))

                    # payload_decode_time = perf_counter() -  t

                    ###############

                    device_id = payload.get("device_id")

                    # t = perf_counter()

                    device_details = get_device_details(device_id)

                    # device_details_time = perf_counter() - t

                    ########

                    # print(f"[RECEIVED] device={device_id}")

                    device_details = get_device_details(device_id)

                    device_type = device_details.get("device_type") if device_details else None
                    device_type_name = device_details.get("device_type_name") if device_details else None

                    header = payload.get("header")
                    packet_status = payload.get("packet_status")
                    latitude = payload.get("latitude")
                    longitude = payload.get("longitude")

                    timestamp = pd.to_datetime(payload.get("timestamp"), utc=True)
                    can_data = payload.get("can_data", {})

                    # state = load_state(r, device_id)

                    # t = perf_counter()

                    state = load_state(r, device_id)

                    # state_load_time = perf_counter() - t

                    total_cal_updated = False
                    daily_report_updated = False
                    alerts_updated = False
                    faults_updated = False

                    # TOTAL CAL
                    try:

                        # total_cal_start = perf_counter()

                        if not state.get("total_cal"):
                            state["total_cal"] = load_total_cal_from_db(device_id)

                        total_cal_state = state["total_cal"]

                        total_cal_state = normalize_total_cal_state(total_cal_state)

                        updated_total_cal_state, total_cal_updated = processor_device_calculations(
                            device_id,
                            device_type,
                            device_type_name,
                            can_data,
                            total_cal_state,
                        )

                        if updated_total_cal_state:

                            if "total_cal" not in state:
                                state["total_cal"] = updated_total_cal_state
                            else:
                                state["total_cal"].update(updated_total_cal_state)

                        # total_cal_time = perf_counter() - total_cal_start

                    except Exception as e:
                        print(f"Error in total_cal {device_id}: {e}")

                    # DAILY SUMMARY
                    try:

                        # daily_summary_start = perf_counter()

                        if not state.get("daily_summary"):
                            state["daily_summary"] = load_daily_summary_from_db(device_id,device_details)

                        # if "last_odo" not in state:
                        #     state["last_odo"] = (
                        #         DailySummaryReport.objects
                        #         .filter(imei=device_id, end_odometer__gt=0)
                        #         .order_by('-date')
                        #         .values_list('end_odometer', flat=True)
                        #         .first() or 0
                        #     )

                        # if "last_soc" not in state:
                        #     state["last_soc"] = (
                        #         DailySummaryReport.objects
                        #         .filter(imei=device_id, end_soc__gt=0)
                        #         .order_by('-date')
                        #         .values_list('end_soc', flat=True)
                        #         .first() or 0
                        #     )

                        # state["daily_summary"]["last_odo"] = state.get("last_odo", 0)
                        # state["daily_summary"]["last_soc"] = state.get("last_soc", 0)

                        daily_summary_state = state["daily_summary"]

                        updated_daily_summary_state, daily_report_updated = processor_data_summary(
                            device_details,
                            device_id,
                            device_type,
                            device_type_name,
                            header,
                            packet_status,
                            latitude,
                            longitude,
                            timestamp,
                            can_data,
                            daily_summary_state,
                        )

                        if daily_report_updated and updated_daily_summary_state:
                            state["daily_summary"].update(updated_daily_summary_state)

                        # daily_summary_time = perf_counter() - daily_summary_start
                                                
                        # daily_summary_time = perf_counter() - daily_summary_start

                    except Exception as e:
                        print(f"Error in daily_summary {device_id}: {e}")

                    # ALERTS
                    try:
                        # alerts_start = perf_counter()

                        if not state.get("alerts"):
                            state["alerts"] = {"active": {}, "buffer": []}

                        alerts_state = state["alerts"]

                        updated_alert_state, alerts_updated = processor_alerts(
                            device_id,
                            device_type,
                            device_type_name,
                            header,
                            latitude,
                            longitude,
                            timestamp,
                            can_data,
                            alerts_state,
                        )

                        if updated_alert_state:

                            if "alerts" not in state:
                                state["alerts"] = updated_alert_state
                            else:
                                state["alerts"].update(updated_alert_state)

                        # alerts_time = perf_counter() - alerts_start

                    except Exception as e:
                        print(f"Error alerts {device_id}: {e}")

                    # FAULTS
                    try:
                        # faults_start = perf_counter()
                        if not state.get("faults"):
                            state["faults"] = {"active": {}, "buffer": []}

                        faults_state = state["faults"]

                        updated_faults_state, faults_updated = processor_faults(
                            device_id,
                            device_type,
                            device_type_name,
                            header,
                            latitude,
                            longitude,
                            timestamp,
                            can_data,
                            faults_state,
                        )

                        if updated_faults_state:

                            if "faults" not in state:
                                state["faults"] = updated_faults_state
                            else:
                                state["faults"].update(updated_faults_state)

                        # faults_time = perf_counter() - faults_start

                    except Exception as e:
                        print(f"Error faults {device_id}: {e}")

                    # save_state(r, device_id, state)
                    # t = perf_counter()

                    processor_save_state( r, device_id, state, total_cal_updated, daily_report_updated, alerts_updated, faults_updated)

                    # save_state_time = perf_counter() - t

                    # ACTIVE TRACKING USING SETS

                    if total_cal_updated:
                        r.sadd("active_total_cal", device_id)

                    if daily_report_updated:
                        r.sadd("active_daily_summary", device_id)

                    if alerts_updated:
                        r.sadd("active_alerts", device_id)

                    if faults_updated:
                        r.sadd("active_faults", device_id)

                    # r.xack(STREAM, GROUP, msg_id)

                    # packet_time = perf_counter() - packet_start

                    # if packet_time > 0.1:
                    #     print(
                    #         f"[PERF] imei={device_id} "
                    #         f"total={packet_time:.3f}s "
                    #         f"decode={payload_decode_time:.3f}s "
                    #         f"device={device_details_time:.3f}s "
                    #         f"load={state_load_time:.3f}s "
                    #         f"totalcal={total_cal_time:.3f}s "
                    #         f"daily={daily_summary_time:.3f}s "
                    #         f"alerts={alerts_time:.3f}s "
                    #         f"faults={faults_time:.3f}s "
                    #         f"save={save_state_time:.3f}s"
                    #     )

                    r.xadd(
                        "trip_updates_stream",
                        {
                            "device_id": device_id,
                            "latitude": latitude,
                            "longitude": longitude,
                            "timestamp": payload.get("timestamp"),
                        }
                    )

                except Exception as e:

                    print(f"[WORKER ERROR] {msg_id} {e}")

                finally:
                    r.xack(STREAM, GROUP, msg_id)