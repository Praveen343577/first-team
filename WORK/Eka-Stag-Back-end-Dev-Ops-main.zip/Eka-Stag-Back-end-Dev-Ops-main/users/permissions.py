from rest_framework.permissions import BasePermission

class CanViewLiveData(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_superuser or request.user.is_staff:
            return True
        return hasattr(request.user, "subscription") and request.user.subscription.subscription_type in ["basic", "gold", "platinum"]

class CanViewDailyCalc(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_superuser or request.user.is_staff:
            return True
        return hasattr(request.user, "subscription") and request.user.subscription.subscription_type in ["gold", "platinum"]

class CanViewReportsAndMIS(BasePermission):
    def has_permission(self, request, view):
        if request.user.is_superuser or request.user.is_staff:
            return True
        return hasattr(request.user, "subscription") and request.user.subscription.subscription_type == "platinum"
    
