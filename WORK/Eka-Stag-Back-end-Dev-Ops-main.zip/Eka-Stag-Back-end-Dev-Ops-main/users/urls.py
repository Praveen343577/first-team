from django.urls import path
from rest_framework.authtoken.views import obtain_auth_token
from users.views import *

urlpatterns = [
    path('token/', obtain_auth_token, name='api_token_auth'),
    path("create-user/", AdminCreateUserAPI.as_view(), name="admin-create-user"),
    path('assign-devices/', AssignDevicesToUser.as_view(), name='assign-devices'),
    path('latest-device-data/', UserLatestDeviceDataView.as_view(), name='latest-device-data'),
    path('change-password/', FirstTimePasswordChangeView.as_view(), name='change-password'),
    path("plans/", SubscriptionPlanListAPIView.as_view(), name="subscription-plans"),
    path("buy/", BuySubscriptionAPIView.as_view(), name="buy-subscription"),
    path("create-order/", CreateSubscriptionOrder.as_view(), name="create-order"),
    path("verify-payment/", VerifySubscriptionPayment.as_view(), name="verify-payment"),
    path("login/", LoginAPIView.as_view(), name="login"),
]
