from django.db import migrations, models
from django.conf import settings

class Migration(migrations.Migration):

    dependencies = [
        ('users', '0005_remove_usersubscription_is_active_and_more'),
    ]

    operations = [
        migrations.CreateModel(
            name='UserDeviceAssignment',
            fields=[
                ('id', models.BigAutoField(primary_key=True, auto_created=True, serialize=False, verbose_name='ID')),
                ('device', models.JSONField(default=list, blank=True)),
                ('assigned_at', models.DateTimeField(auto_now_add=True)),
                ('user', models.ForeignKey(on_delete=models.CASCADE, related_name='devices', to=settings.AUTH_USER_MODEL)),
            ],
        ),
    ]