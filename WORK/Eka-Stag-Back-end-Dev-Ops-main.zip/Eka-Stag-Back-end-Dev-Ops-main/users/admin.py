from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, UserDeviceAssignment,UserSubscription,SubscriptionPlan

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    pass

admin.site.register(UserDeviceAssignment)
admin.site.register(UserSubscription)
admin.site.register(SubscriptionPlan)
