from rest_framework import serializers
from users.models import User, UserDeviceAssignment


from rest_framework import serializers
from devices.models import Device, DeviceData
from users.models import User, SubscriptionPlan

class UserCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "email", "full_name", "mobile"]

    def create(self, validated_data):
        import secrets, string
        alphabet = string.ascii_letters + string.digits
        random_password = ''.join(secrets.choice(alphabet) for i in range(10))

        user = User.objects.create_user(
            email=validated_data["email"],
            full_name=validated_data.get("full_name", ""),
            mobile=validated_data.get("mobile", ""),
            password=random_password
        )
        user.generated_password = random_password
        return user

class UserProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'full_name', 'mobile']

class DeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Device
        fields = ['id', 'device_id', 'device_type']

class DeviceDataSerializer(serializers.ModelSerializer):
    device = DeviceSerializer()

    class Meta:
        model = DeviceData
        fields = '__all__'

class AssignDeviceSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()
    device_ids = serializers.ListField(child=serializers.IntegerField())
    
class UserAssignDeviceSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserDeviceAssignment
        fields = '__all__'

class SubscriptionPlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = SubscriptionPlan
        fields = ["id", "name", "description", "price", "duration_days"]

class BuySubscriptionSerializer(serializers.Serializer):
    plan_id = serializers.IntegerField()

    def validate_plan_id(self, value):
        try:
            plan = SubscriptionPlan.objects.get(id=value)
        except SubscriptionPlan.DoesNotExist:
            raise serializers.ValidationError("Invalid subscription plan.")
        return plan


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        from django.contrib.auth import authenticate
        from devices.models import Device
        from devices.serializers import DeviceSerializer
        from users.models import UserDeviceAssignment, UserSubscription

        email = data.get("email")
        password = data.get("password")

        user = authenticate(username=email, password=password)
        if not user:
            raise serializers.ValidationError("Invalid email or password")

        # Fetch all device IDs for this user
        assignments = UserDeviceAssignment.objects.filter(user=user).first()


        # Remove duplicates
        all_device_ids = assignments.devices #changed the device to devices                                                                                                      

        # Fetch Device objects
        device_objs = Device.objects.filter(device_id__in=all_device_ids)
        device_list = DeviceSerializer(device_objs, many=True).data

        # Subscription info
        subscription_data = None
        try:
            subscription = user.subscription
            if subscription.is_active:
                subscription_data = {
                    "plan": subscription.plan.name,
                    "features": subscription.plan.features,
                }
        except UserSubscription.DoesNotExist:
            pass

        return {
            "user_id": user.id,
            "username": user.username,
            "mobile": user.mobile,
            "devices": device_list,
            "subscription": subscription_data,
        }