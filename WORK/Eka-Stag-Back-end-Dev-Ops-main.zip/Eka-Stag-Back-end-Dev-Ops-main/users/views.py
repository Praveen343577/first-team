import string, secrets
import razorpay
from rest_framework import permissions, status,generics
from rest_framework.views import APIView
from rest_framework.response import Response
from django.contrib.auth.password_validation import validate_password
from rest_framework.permissions import IsAdminUser

from ekaConnect import settings
from users.models import  UserDeviceAssignment, User, SubscriptionPlan,UserSubscription
from devices.models import Device, DeviceData
from users.serializers import *

class AdminCreateUserAPI(APIView):
    permission_classes = [permissions.IsAdminUser]  # only admins can access

    def post(self, request):
        email = request.data.get("email")
        full_name = request.data.get("full_name", "")
        mobile = request.data.get("mobile", "")

        if not email:
            return Response({"error": "Email is required"}, status=status.HTTP_400_BAD_REQUEST)

        alphabet = string.ascii_letters + string.digits + string.punctuation
        random_password = ''.join(secrets.choice(alphabet) for _ in range(10))

        user, password = User.objects.create_user(
            email=email,
            full_name=full_name,
            mobile=mobile
        )

        return Response({
            "id": user.id,
            "email": user.email,
            "random_password": random_password, 
        }, status=status.HTTP_201_CREATED)

class AssignDevicesToUser(APIView):
    permission_classes = [permissions.IsAdminUser]

    def post(self, request):
        serializer = AssignDeviceSerializer(data=request.data)
        if serializer.is_valid():
            user = User.objects.get(pk=serializer.validated_data['user_id'])
            for device_id in serializer.validated_data['device_ids']:
                device = Device.objects.get(pk=device_id)
                UserDeviceAssignment.objects.get_or_create(user=user, device=device)
            return Response({"message": "Devices assigned successfully."})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    def get(self, request):
        device_id = request.query_params.get('device_id', None)
        if device_id:
            assignments = UserDeviceAssignment.objects.filter(device_id=device_id)
        else:
            assignments = UserDeviceAssignment.objects.all()
            
        serializers = UserAssignDeviceSerializer(assignments,many=True)

        return Response(serializers.data, status=status.HTTP_200_OK)

 
    def delete(self, request):
        device_id = request.data.get('device_id')
        user_id = request.data.get('user_id')  # optional: delete for specific user

        if not device_id:
            return Response({"error": "device_id is required"}, status=status.HTTP_400_BAD_REQUEST)

        assignments = UserDeviceAssignment.objects.filter(device_id=device_id)
        if user_id:
            assignments = assignments.filter(user_id=user_id)

        deleted_count, _ = assignments.delete()
        if deleted_count == 0:
            return Response({"message": "No assignment found to delete."}, status=status.HTTP_404_NOT_FOUND)
        return Response({"message": f"{deleted_count} assignment(s) deleted successfully."}, status=status.HTTP_200_OK)

class UserLatestDeviceDataView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        assigned_devices = UserDeviceAssignment.objects.filter(user=request.user).values_list('device_id', flat=True)
        latest_entries = []

        for device_id in assigned_devices:
            latest_data = DeviceData.objects.filter(device_id=device_id).order_by('-timestamp').first()
            if latest_data:
                latest_entries.append(latest_data)

        page = self.paginate_queryset(latest_entries)
        if page is not None:
            serializer = DeviceDataSerializer(page, many=True)
            return self.get_paginated_response(serializer.data)

        serializer = DeviceDataSerializer(latest_entries, many=True)
        return Response(serializer.data)

    def paginate_queryset(self, queryset):
        page = int(self.request.query_params.get('page', 1))
        page_size = int(self.request.query_params.get('page_size', 10))
        start = (page - 1) * page_size
        end = start + page_size
        self.total_count = len(queryset)
        self.page_size = page_size
        self.page = page
        return queryset[start:end]

    def get_paginated_response(self, data):
        return Response({
            "count": self.total_count,
            "page": self.page,
            "page_size": self.page_size,
            "results": data
        })

class FirstTimePasswordChangeView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        password = request.data.get("password")
        try:
            validate_password(password, request.user)
            request.user.set_password(password)
            request.user.save()
            return Response({"message": "Password updated successfully."})
        except Exception as e:
            return Response({"error": str(e)}, status=400)

class AssignSubscriptionView(generics.CreateAPIView):
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        user_id = request.data.get("user_id")
        plan_name = request.data.get("plan")

        try:
            user = User.objects.get(id=user_id)
            plan = SubscriptionPlan.objects.get(name=plan_name)

            subscription, created = UserSubscription.objects.update_or_create(
                user=user,
                defaults={"plan": plan, "is_active": True}
            )

            return Response({
                "message": f"Subscription {plan.name} assigned to {user.email}",
                "features": plan.features
            }, status=status.HTTP_200_OK)

        except User.DoesNotExist:
            return Response({"error": "User not found"}, status=status.HTTP_404_NOT_FOUND)
        except SubscriptionPlan.DoesNotExist:
            return Response({"error": "Plan not found"}, status=status.HTTP_404_NOT_FOUND)

class SubscriptionPlanListAPIView(generics.ListAPIView):
    queryset = SubscriptionPlan.objects.all()
    serializer_class = SubscriptionPlanSerializer
    permission_classes = [permissions.IsAuthenticated]
    
class BuySubscriptionAPIView(generics.GenericAPIView):
    serializer_class = BuySubscriptionSerializer
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        plan = serializer.validated_data["plan_id"]

        # check if user already has subscription
        subscription, created = UserSubscription.objects.get_or_create(user=request.user)
        subscription.activate(plan)

        return Response(
            {"message": f"Subscription {plan.name} activated until {subscription.end_date}"},
            status=status.HTTP_200_OK,
        )

class CreateSubscriptionOrder(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        PLAN_PRICES = {
            "basic": 10000,     
            "gold": 50000,      
            "platinum": 100000, 
        }
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

        plan = request.data.get("plan")
        if plan not in PLAN_PRICES:
            return Response({"error": "Invalid plan"}, status=400)

        amount = PLAN_PRICES[plan]


        order = client.order.create({
            "amount": amount,
            "currency": "INR",
            "payment_capture": 1
        })

        subscription = UserSubscription.objects.create(
            user=request.user,
            plan=plan,
            razorpay_order_id=order["id"],
        )

        return Response({
            "order_id": order["id"],
            "amount": amount,
            "currency": "INR",
            "subscription_id": subscription.id,
            "razorpay_key": settings.RAZORPAY_KEY_ID
        })

class VerifySubscriptionPayment(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        payment_id = request.data.get("razorpay_payment_id")
        order_id = request.data.get("razorpay_order_id")
        signature = request.data.get("razorpay_signature")
        client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

        try:
            client.utility.verify_payment_signature({
                "razorpay_order_id": order_id,
                "razorpay_payment_id": payment_id,
                "razorpay_signature": signature
            })
        except razorpay.errors.SignatureVerificationError:
            return Response({"error": "Payment verification failed"}, status=400)

        subscription = UserSubscription.objects.get(
            user=request.user, razorpay_order_id=order_id
        )
        subscription.razorpay_payment_id = payment_id
        subscription.razorpay_signature = signature
        subscription.is_active = True
        subscription.save()

        return Response({"status": "success", "message": "Subscription activated"})



class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            return Response(serializer.validated_data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)