# data/sample_data.py

import pandas as pd
import numpy as np
from datetime import datetime, timedelta


def make_sample_data():

    # Daily cashflow for last 14 days
    today = datetime.utcnow().date()
    dates = [today - timedelta(days=i) for i in range(13, -1, -1)]
    income = (np.random.rand(len(dates)) * 100).round(2)
    expense = (np.random.rand(len(dates)) * 80).round(2)

    df_daily = pd.DataFrame({
        'date': dates,
        'income': income,
        'expense': expense
    })

    # Accounts table sample
    df_accounts = pd.DataFrame({
        'No': [1, 2, 3, 4, 5, 6],
        'Bank': ['Maybank', 'Ocbc Bank', 'RHB Bank', 'Public Bank', 'UOB Bank', 'Ambank'],
        'Holder Name': ['Cash', 'Carissa', 'Renee', 'Preston', 'Bowman', 'Wendy'],
        'Balance': ['RM521,611.20', 'RM160,156.00', 'RM52,229.00', 'RM82,786.00', 'RM105,150.00', 'RM5,484.40'],
        'Status': ['Active', 'Paused', 'Canceled', 'Active', 'Paused', 'Canceled']
    })

    # Projects for donut chart
    df_project = pd.DataFrame({
        'status': ['On Going', 'On Hold', 'Finished', 'On Hold'],
        'count': [25, 32, 68, 15]
    })

    return df_daily, df_accounts, df_project
