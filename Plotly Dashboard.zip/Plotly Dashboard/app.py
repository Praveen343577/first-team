import dash
from dash import Dash, html
import dash_bootstrap_components as dbc

app = Dash(
    __name__,
    use_pages=True,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    suppress_callback_exceptions=True
)

server = app.server

app.layout = html.Div([
    dash.page_container   # <-- THIS WORKS NOW
])

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=8050)
