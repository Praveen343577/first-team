# pages/dashboard.py
import dash
from dash import html, dcc, Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd


from data.sample_data import make_sample_data


dash.register_page(__name__, path='/', name='Dashboard')


# Generate sample data
df_daily, df_accounts, df_project = make_sample_data()


# Create figures
fig_cashflow = px.bar(df_daily, x='date', y=['income', 'expense'], barmode='group', title='Cashflow')
fig_donut = px.pie(df_project, names='status', values='count', hole=0.6, title='Project Status')


layout = html.Div([
dbc.Row([
dbc.Col(html.Div(""), width=2, style={"background":"#f8f9fa"}),
dbc.Col([
html.Div(className='topbar', children=[
html.H2('Dashboard / Accounting', className='page-title'),
html.Div(className='topbar-actions', children=[
dcc.Input(placeholder='Find something', className='search-input'),
html.Div('Adam Smith', className='profile')
])
]),


# Stat cards
dbc.Row([
dbc.Col(dbc.Card([
dbc.CardBody([
html.Div('Total Customers', className='stat-title'),
html.H3('212', className='stat-value'),
html.Div('+9.5% today', className='stat-change')
])
]), md=3),
dbc.Col(dbc.Card([
dbc.CardBody([
html.Div('Total Vendors', className='stat-title'),
html.H3('82', className='stat-value'),
html.Div('-5.5% today', className='stat-change')
])
]), md=3),
dbc.Col(dbc.Card([
dbc.CardBody([
html.Div('Total Invoices', className='stat-title'),
html.H3('132', className='stat-value'),
html.Div('+8.5% today', className='stat-change')
])
]), md=3),
dbc.Col(dbc.Card([
dbc.CardBody([
html.Div('Total Bills', className='stat-title'),
html.H3('164', className='stat-value'),
html.Div('-8.5% today', className='stat-change')
])
]), md=3),
], className='mt-3'),


# Main grid: Cashflow + Income cards
dbc.Row([
dbc.Col(dbc.Card(dbc.CardBody([
html.H5('Cashflow'),
dcc.Graph(id='cashflow-graph', figure=fig_cashflow)
])), md=8),
dbc.Col(dbc.Card(dbc.CardBody([
html.H5('Income Vs Expense'),
html.Div([html.Div([html.B('Income This Month'), html.Div('RM247.00')], className='small-stat'),
html.Div([html.B('Expense This Month'), html.Div('RM254.00')], className='small-stat')
], className='income-grid')
])), md=4)
], className='mt-3'),


# Lower row: donut + account table
dbc.Row([
dbc.Col(dbc.Card(dbc.CardBody([
html.H5('Project Status'),
dcc.Graph(id='donut', figure=fig_donut),
html.Div(id='donut-legend')
])), md=4),
dbc.Col(dbc.Card(dbc.CardBody([
html.H5('Account Balance'),
dbc.Table.from_dataframe(df_accounts.head(6), striped=False, bordered=False, hover=False, responsive=True, className='table-sm')
])), md=8)
], className='mt-3 pb-5')


], width=10)
], className='no-gutters')
])




# If needed, callbacks can be added here for interactivity