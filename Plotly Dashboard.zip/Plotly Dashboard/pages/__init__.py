# pages/__init__.py
from importlib import import_module
import pkgutil
import inspect


def register_pages(app):
  # Import every module in pages to let dash.register_page decorators run
  import pages
  package = pages
  prefix = package.__name__ + "."
  for _, modname, _ in pkgutil.iter_modules(package.__path__, prefix):
    import_module(modname)


# After importing, dash.pages should be registered automatically.
# No further action required here.