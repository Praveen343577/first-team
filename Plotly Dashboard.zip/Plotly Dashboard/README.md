# Dash Multi-page Dashboard


## Quick start


1. Create and activate a virtualenv (recommended):


```bash
python -m venv venv
source venv/bin/activate # mac/linux
venv\Scripts\activate # windows